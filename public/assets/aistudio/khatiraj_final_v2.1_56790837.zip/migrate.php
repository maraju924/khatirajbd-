<?php
/**
 * KhatiRaj BD — Database Migration
 *
 * Fresh deploy: creates all missing tables.
 * Existing database: adds only new tables/columns (safe to run multiple times).
 *
 * Usage:
 *   1. Create empty MySQL database (name must match config/database.php)
 *   2. Put LIVE DB credentials in config/database.php (or env vars)
 *   3. Set a strong MIGRATION_SECRET via env MIGRATION_SECRET or edit the define below
 *      (web migrate refuses to run while the placeholder secret is still set)
 *   4. CLI:  php migrate.php
 *      Web:  https://yoursite.com/migrate.php?key=YOUR_STRONG_SECRET
 *   5. Login with the one-time admin password printed in migrate output → change it immediately
 *   6. DELETE migrate.php from production after a successful run
 *
 * Prerequisites:
 *   1. Create empty MySQL database (default name: khatiraj — see config/database.php)
 *   2. Run this script once after every deploy
 *
 * Future schema changes:
 *   - New table: add CREATE TABLE IF NOT EXISTS to $createStatements below
 *   - New column: add entry to $columnUpgrades [table, column, definition, after_column]
 *   - Bump MIGRATION_VERSION
 *
 * Security: set a strong secret, rotate the seeded admin password, then delete this file on live.
 */

declare(strict_types=1);

define('MIGRATION_VERSION', '2026.07.16');

/**
 * Prefer env MIGRATION_SECRET. Placeholder values are blocked for web access.
 * Set something long and random before running migrate via browser.
 */
$migrationSecretFromEnv = getenv('MIGRATION_SECRET');
define(
    'MIGRATION_SECRET',
    ($migrationSecretFromEnv !== false && $migrationSecretFromEnv !== '')
        ? $migrationSecretFromEnv
        : 'CHANGE_ME_SET_A_STRONG_SECRET'
);

$isCli = PHP_SAPI === 'cli';

$insecureMigrationSecrets = [
    'CHANGE_ME_SET_A_STRONG_SECRET',
    'khatiraj-migrate-change-me',
    'YOUR_SECRET_KEY',
];

if (!$isCli) {
    header('Content-Type: text/plain; charset=utf-8');

    if (
        in_array(MIGRATION_SECRET, $insecureMigrationSecrets, true)
        || strlen(MIGRATION_SECRET) < 24
    ) {
        http_response_code(403);
        echo "Forbidden. Set a strong MIGRATION_SECRET (env preferred, min 24 chars) before web migrate.\n";
        echo "Example: set MIGRATION_SECRET in the server environment, or replace the define in migrate.php.\n";
        echo "Then open: migrate.php?key=YOUR_STRONG_SECRET\n";
        echo "After migrating, delete migrate.php from production.\n";
        exit(1);
    }

    $key = (string) ($_GET['key'] ?? '');
    if ($key === '' || !hash_equals(MIGRATION_SECRET, $key)) {
        http_response_code(403);
        echo "Forbidden. Use: migrate.php?key=YOUR_STRONG_SECRET\n";
        exit(1);
    }
} elseif (in_array(MIGRATION_SECRET, $insecureMigrationSecrets, true)) {
    fwrite(STDERR, "[WARN] MIGRATION_SECRET is still a placeholder. Web migrate is blocked until you set a strong secret.\n");
}

require_once __DIR__ . '/config/database.php';

final class DatabaseMigrator
{
    private PDO $pdo;
    /** @var list<string> */
    private array $log = [];

    /** @var array<string, string> */
    private array $createStatements;

    /** @var list<array{0:string,1:string,2:string,3:?string}> */
    private array $columnUpgrades;

    /** @var list<array{0:string,1:string,2:string}> */
    private array $indexUpgrades;

    public function __construct(PDO $pdo, array $createStatements, array $columnUpgrades, array $indexUpgrades = [])
    {
        $this->pdo = $pdo;
        $this->createStatements = $createStatements;
        $this->columnUpgrades = $columnUpgrades;
        $this->indexUpgrades = $indexUpgrades;
    }

    public function run(): array
    {
        $this->ensureMigrationTable();
        $this->runTableMigrations();
        $this->runColumnUpgrades();
        $this->runIndexUpgrades();
        $this->runSchemaHelpers();
        $this->markVersionApplied(MIGRATION_VERSION);
        return $this->log;
    }

    private function ensureMigrationTable(): void
    {
        $this->pdo->exec("CREATE TABLE IF NOT EXISTS schema_migrations (
            id INT AUTO_INCREMENT PRIMARY KEY,
            version VARCHAR(50) NOT NULL,
            applied_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            UNIQUE KEY uk_version (version)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
    }

    private function tableExists(string $table): bool
    {
        $stmt = $this->pdo->prepare('SHOW TABLES LIKE ?');
        $stmt->execute([$table]);
        return (bool) $stmt->fetchColumn();
    }

    private function columnExists(string $table, string $column): bool
    {
        if (!$this->tableExists($table)) {
            return false;
        }
        $stmt = $this->pdo->prepare("SHOW COLUMNS FROM `$table` LIKE ?");
        $stmt->execute([$column]);
        return (bool) $stmt->fetch(PDO::FETCH_ASSOC);
    }

    private function runTableMigrations(): void
    {
        foreach ($this->createStatements as $table => $sql) {
            try {
                $existed = $this->tableExists($table);
                $this->pdo->exec($sql);
                if ($existed) {
                    $this->log[] = "[OK] Table `$table` already exists (verified)";
                } else {
                    $this->log[] = "[NEW] Created table `$table`";
                }
            } catch (PDOException $e) {
                $this->log[] = "[ERR] Table `$table`: " . $e->getMessage();
            }
        }
    }

    private function runColumnUpgrades(): void
    {
        foreach ($this->columnUpgrades as [$table, $column, $definition, $after]) {
            if ($this->columnExists($table, $column)) {
                $this->log[] = "[OK] Column `$table`.`$column` already exists";
                continue;
            }
            if (!$this->tableExists($table)) {
                $this->log[] = "[SKIP] Column `$table`.`$column` — table missing";
                continue;
            }
            try {
                $afterSql = $after ? " AFTER `$after`" : '';
                $this->pdo->exec("ALTER TABLE `$table` ADD COLUMN `$column` $definition$afterSql");
                $this->log[] = "[NEW] Added column `$table`.`$column`";
            } catch (PDOException $e) {
                $this->log[] = "[ERR] Column `$table`.`$column`: " . $e->getMessage();
            }
        }
    }

    private function indexExists(string $table, string $indexName): bool
    {
        if (!$this->tableExists($table)) {
            return false;
        }
        $stmt = $this->pdo->prepare("SHOW INDEX FROM `$table` WHERE Key_name = ?");
        $stmt->execute([$indexName]);
        return (bool) $stmt->fetch(PDO::FETCH_ASSOC);
    }

    private function runIndexUpgrades(): void
    {
        foreach ($this->indexUpgrades as [$table, $indexName, $columns]) {
            if ($this->indexExists($table, $indexName)) {
                $this->log[] = "[OK] Index `$table`.`$indexName` already exists";
                continue;
            }
            if (!$this->tableExists($table)) {
                $this->log[] = "[SKIP] Index `$table`.`$indexName` — table missing";
                continue;
            }
            try {
                $this->pdo->exec("ALTER TABLE `$table` ADD INDEX `$indexName` ($columns)");
                $this->log[] = "[NEW] Added index `$table`.`$indexName`";
            } catch (PDOException $e) {
                $this->log[] = "[ERR] Index `$table`.`$indexName`: " . $e->getMessage();
            }
        }
    }

    private function runSchemaHelpers(): void
    {
        try {
            require_once __DIR__ . '/app/Helpers/ProductVariantHelper.php';
            ProductVariantHelper::ensureTables($this->pdo);
            $this->log[] = '[OK] Product variant schema verified';
        } catch (Throwable $e) {
            $this->log[] = '[ERR] Product variant schema: ' . $e->getMessage();
        }

        try {
            require_once __DIR__ . '/app/Services/AbandonedCartService.php';
            (new AbandonedCartService($this->pdo))->ensureTable();
            $this->log[] = '[OK] Abandoned cart schema verified';
        } catch (Throwable $e) {
            $this->log[] = '[ERR] Abandoned cart schema: ' . $e->getMessage();
        }

        try {
            $this->seedPageRegistry();
            $this->log[] = '[OK] Page registry seeding verified';
            $this->pruneNonManageablePages();
            $this->log[] = '[OK] Non-manageable page registry prune verified';
            $this->seedPageContent();
            $this->log[] = '[OK] Page content seeding verified';
            $this->seedFreshInstallDefaults();
            $this->log[] = '[OK] Fresh-install defaults seeding verified';
        } catch (Throwable $e) {
            $this->log[] = '[ERR] Page/defaults seeding: ' . $e->getMessage();
        }
    }

    /**
     * Seed only when empty — safe for existing production DBs.
     * Ensures a brand-new site can log in and checkout after migrate.
     */
    private function seedFreshInstallDefaults(): void
    {
        // 1) Default super admin — one-time random password (change immediately after first login)
        $adminCount = (int) $this->pdo->query('SELECT COUNT(*) FROM admins')->fetchColumn();
        if ($adminCount === 0) {
            $tempPassword = bin2hex(random_bytes(8));
            $hash = password_hash($tempPassword, PASSWORD_DEFAULT);
            $stmt = $this->pdo->prepare(
                "INSERT INTO admins (name, email, password, role) VALUES (?, ?, ?, 'super_admin')"
            );
            $stmt->execute(['Super Admin', 'maraju924@gmail.com', $hash]);
            $this->log[] = '[NEW] Seeded admin maraju924@gmail.com — temporary password: ' . $tempPassword;
            $this->log[] = '[ACTION] Change this password immediately after first login, then delete migrate.php on production.';
        }

        // 2) Tracking settings row (admin UPDATE WHERE id=1)
        $tsCount = (int) $this->pdo->query('SELECT COUNT(*) FROM tracking_settings')->fetchColumn();
        if ($tsCount === 0) {
            $this->pdo->exec('INSERT INTO tracking_settings (id, enable_advanced_matching, is_test_mode) VALUES (1, 0, 0)');
            $this->log[] = '[NEW] Seeded tracking_settings row id=1';
        }

        // 3) Default shipping zones (Bangladesh COD typical)
        $zoneCount = (int) $this->pdo->query('SELECT COUNT(*) FROM shipping_zones')->fetchColumn();
        if ($zoneCount === 0) {
            $ins = $this->pdo->prepare('INSERT INTO shipping_zones (name, charge, status) VALUES (?, ?, 1)');
            $ins->execute(['Inside Dhaka', 60.00]);
            $ins->execute(['Outside Dhaka', 120.00]);
            $this->log[] = '[NEW] Seeded default shipping zones (Inside/Outside Dhaka)';
        }

        // 4) Essential settings keys (insert only if missing)
        $cronKey = bin2hex(random_bytes(16));
        $defaults = [
            'site_name' => 'Khati Raj BD',
            'support_email' => 'support@example.com',
            'support_phone' => '01XXXXXXXXX',
            'address' => '',
            'allow_cod' => '1',
            'enable_sticky_order' => '1',
            'enable_sales_popup' => '0',
            'enable_whatsapp' => '0',
            'footer_about_text' => 'খাঁটি ও মানসম্পন্ন পণ্যের বিশ্বস্ত ই-কমার্স।',
            'footer_copyright' => '© ' . date('Y') . ' Khati Raj BD. All rights reserved.',
            'footer_col2_title' => 'Quick Links',
            'footer_col3_title' => 'Contact',
            'abandoned_cart_enabled' => '0',
            'abandoned_cart_delay_minutes' => '60',
            'abandoned_cart_max_reminders' => '2',
            'abandoned_cart_cron_key' => $cronKey,
            'abandoned_cart_whatsapp_enabled' => '0',
            'abandoned_cart_sms_text' => 'আপনার কার্টে প্রোডাক্ট অপেক্ষা করছে। এখনই অর্ডার সম্পন্ন করুন: {link}',
            'abandoned_cart_whatsapp_text' => 'আসসালামু আলাইকুম {name}, আপনার কার্টে প্রোডাক্ট অপেক্ষা করছে। অর্ডার সম্পন্ন করুন: {link}',
            'sms_enabled' => '0',
            'email_enabled' => '0',
            'wa_api_enabled' => '0',
            'flash_sale_status' => '0',
            'steadfast_api_key' => '',
            'steadfast_secret_key' => '',
            'steadfast_note' => 'মার্চেন্ট এর অনুমতি ব্যতীত কোনো প্রোডাক্ট খুলবেন না। এবং সকল আপডেট মার্চেন্টকে জানাবেন।',
            'global_show_seo_guide' => '0',
            'tracking_exclude_admin' => '1',
            'tracking_debug' => '0',
        ];

        $sel = $this->pdo->prepare('SELECT id FROM settings WHERE key_name = ?');
        $ins = $this->pdo->prepare('INSERT INTO settings (key_name, value) VALUES (?, ?)');
        $added = 0;
        foreach ($defaults as $key => $val) {
            $sel->execute([$key]);
            if (!$sel->fetchColumn()) {
                // Don't overwrite existing cron key with a new random one on re-run — only insert if missing
                $ins->execute([$key, $val]);
                $added++;
            }
        }
        if ($added > 0) {
            $this->log[] = "[NEW] Seeded {$added} default settings keys";
        }
    }

    private function seedPageRegistry(): void
    {
        // Only pages that belong in Page & SEO Manager (content + home/thanks).
        // Shop/auth/cart/templates etc. use header or entity-level SEO — not seeded here.
        $pages = [
            ['home', '/', 'system', 'হোম পেজ', 'default', 'sections', 1, 1],
            ['thanks', '/thanks', 'commerce', 'অর্ডার থ্যাংকস পেজ', 'default', 'sections', 1, 2],
            ['blog_index', '/blog', 'content', 'ব্লগ তালিকা', 'default', 'sections', 1, 3],
        ];

        $stmtSelect = $this->pdo->prepare("SELECT id FROM page_registry WHERE route_key = ?");
        $stmtInsert = $this->pdo->prepare("INSERT INTO page_registry (route_key, slug, page_group, page_name, template, content_mode, status, sort_order) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");

        foreach ($pages as $p) {
            $stmtSelect->execute([$p[0]]);
            if (!$stmtSelect->fetchColumn()) {
                $stmtInsert->execute($p);
            }
        }

        $settings = [
            'global_meta_title_suffix' => '| Khati Raj BD',
            'global_meta_description' => 'Khati Raj Bangladesh provides premium quality organic and authentic local foods, honey, ghee, and groceries.',
            'global_meta_keywords' => 'organic food, honey, ghee, authentic food, bangladesh grocery, khati raj bd',
            'global_og_image' => '',
            'site_favicon' => '',
        ];

        $stmtSetSelect = $this->pdo->prepare("SELECT id FROM settings WHERE key_name = ?");
        $stmtSetInsert = $this->pdo->prepare("INSERT INTO settings (key_name, value) VALUES (?, ?)");

        foreach ($settings as $key => $val) {
            $stmtSetSelect->execute([$key]);
            if (!$stmtSetSelect->fetchColumn()) {
                $stmtSetInsert->execute([$key, $val]);
            }
        }
    }

    /**
     * Remove system/auth/commerce templates that should not appear in Page & SEO Manager.
     * page_sections cascade via FK ON DELETE CASCADE.
     */
    private function pruneNonManageablePages(): void
    {
        require_once __DIR__ . '/app/Helpers/PageHelper.php';
        $keys = PageHelper::NON_MANAGEABLE_ROUTE_KEYS;
        if ($keys === []) {
            return;
        }

        $placeholders = implode(',', array_fill(0, count($keys), '?'));
        $stmt = $this->pdo->prepare("DELETE FROM page_registry WHERE route_key IN ($placeholders)");
        $stmt->execute($keys);
        $removed = $stmt->rowCount();
        if ($removed > 0) {
            $this->log[] = "[CLEAN] Removed {$removed} non-manageable page_registry rows";
        }
    }

    private function seedPageContent(): void
    {
        require_once __DIR__ . '/app/Helpers/LegalPagesSeeder.php';
        LegalPagesSeeder::seed($this->pdo, $this->log);
    }

    private function markVersionApplied(string $version): void
    {
        $stmt = $this->pdo->prepare('INSERT IGNORE INTO schema_migrations (version) VALUES (?)');
        $stmt->execute([$version]);
        $this->log[] = '[DONE] Migration version ' . $version . ' recorded';
    }
}

$createStatements = array (
  'page_registry' => 'CREATE TABLE IF NOT EXISTS `page_registry` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `route_key` varchar(50) NOT NULL,
  `slug` varchar(150) DEFAULT NULL,
  `page_group` varchar(50) NOT NULL,
  `page_name` varchar(100) NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `h1_title` varchar(255) DEFAULT NULL,
  `subtitle` varchar(255) DEFAULT NULL,
  `meta_title` varchar(255) DEFAULT NULL,
  `meta_description` text DEFAULT NULL,
  `meta_keywords` text DEFAULT NULL,
  `focus_keyword` varchar(255) DEFAULT NULL,
  `og_image` varchar(255) DEFAULT NULL,
  `canonical_override` varchar(255) DEFAULT NULL,
  `template` varchar(50) NOT NULL DEFAULT \'default\',
  `content_mode` varchar(50) NOT NULL DEFAULT \'none\',
  `content_html` longtext DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `sort_order` int(11) NOT NULL DEFAULT 0,
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT NULL ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `route_key` (`route_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci',
  'page_sections' => 'CREATE TABLE IF NOT EXISTS `page_sections` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `page_id` int(11) NOT NULL,
  `section_key` varchar(50) NOT NULL,
  `section_type` varchar(50) NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `subtitle` varchar(255) DEFAULT NULL,
  `content` longtext DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `icon` varchar(50) DEFAULT NULL,
  `btn_text` varchar(50) DEFAULT NULL,
  `btn_link` varchar(255) DEFAULT NULL,
  `extra_json` text DEFAULT NULL,
  `sort_order` int(11) NOT NULL DEFAULT 0,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `page_id` (`page_id`),
  CONSTRAINT `fk_page_sections_registry` FOREIGN KEY (`page_id`) REFERENCES `page_registry` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci',
  'categories' => 'CREATE TABLE IF NOT EXISTS `categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parent_id` int(11) DEFAULT NULL,
  `name` varchar(100) NOT NULL,
  `slug` varchar(150) NOT NULL,
  `image` varchar(255) DEFAULT NULL,
  `status` tinyint(1) DEFAULT 1,
  `meta_title` varchar(255) DEFAULT NULL,
  `meta_description` text DEFAULT NULL,
  `meta_keywords` text DEFAULT NULL,
  `description` text DEFAULT NULL,
  `h1_title` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `slug` (`slug`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci',
  'shipping_zones' => 'CREATE TABLE IF NOT EXISTS `shipping_zones` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `charge` decimal(10,2) NOT NULL DEFAULT 0.00,
  `status` tinyint(1) DEFAULT 1,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci',
  'shipping_classes' => 'CREATE TABLE IF NOT EXISTS `shipping_classes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `extra_charge` decimal(10,2) NOT NULL DEFAULT 0.00,
  `status` tinyint(1) DEFAULT 1,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci',
  'settings' => 'CREATE TABLE IF NOT EXISTS `settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `key_name` varchar(100) NOT NULL,
  `value` text DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT NULL ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `key_name` (`key_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci',
  'social_links' => 'CREATE TABLE IF NOT EXISTS `social_links` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `platform_name` varchar(50) NOT NULL,
  `icon_class` varchar(100) NOT NULL,
  `url` varchar(255) NOT NULL,
  `status` tinyint(1) DEFAULT 1,
  `sort_order` int(11) DEFAULT 0,
  `created_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci',
  'users' => 'CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `phone` varchar(15) NOT NULL,
  `password` varchar(255) NOT NULL,
  `address` text DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  `reset_token` varchar(100) DEFAULT NULL,
  `token_expiry` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`),
  UNIQUE KEY `phone` (`phone`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci',
  'admins' => 'CREATE TABLE IF NOT EXISTS `admins` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` enum(\'super_admin\',\'editor\',\'moderator\') DEFAULT \'super_admin\',
  `created_at` datetime DEFAULT current_timestamp(),
  `reset_token` varchar(100) DEFAULT NULL,
  `token_expiry` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci',
  'coupons' => 'CREATE TABLE IF NOT EXISTS `coupons` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(50) NOT NULL,
  `type` enum(\'fixed\',\'percent\') NOT NULL,
  `value` decimal(10,2) NOT NULL,
  `min_order_amount` decimal(10,2) DEFAULT 0.00,
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `status` tinyint(1) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci',
  'sliders' => 'CREATE TABLE IF NOT EXISTS `sliders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) DEFAULT NULL,
  `subtitle` varchar(255) DEFAULT NULL,
  `image` varchar(255) NOT NULL,
  `btn_text` varchar(50) DEFAULT NULL,
  `btn_link` varchar(255) DEFAULT NULL,
  `overlay_color` varchar(20) DEFAULT \'#000000\',
  `overlay_opacity` decimal(3,2) DEFAULT 0.40,
  `sort_order` int(11) DEFAULT 0,
  `status` tinyint(1) DEFAULT 1,
  `position` varchar(50) DEFAULT \'main_hero\',
  `created_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci',
  'blog_posts' => 'CREATE TABLE IF NOT EXISTS `blog_posts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(500) NOT NULL,
  `slug` varchar(500) NOT NULL,
  `excerpt` text DEFAULT NULL,
  `content` longtext NOT NULL,
  `image` varchar(500) DEFAULT NULL,
  `meta_title` varchar(500) DEFAULT NULL,
  `meta_description` text DEFAULT NULL,
  `meta_keywords` varchar(500) DEFAULT NULL,
  `author_id` int(11) DEFAULT NULL,
  `status` tinyint(1) DEFAULT 0 COMMENT \'0=draft, 1=published\',
  `views` int(11) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `slug` (`slug`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci',
  'menus' => 'CREATE TABLE IF NOT EXISTS `menus` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parent_id` int(11) DEFAULT NULL,
  `location` varchar(20) DEFAULT \'header\',
  `title` varchar(100) NOT NULL,
  `url` varchar(255) NOT NULL,
  `sort_order` int(11) DEFAULT 0,
  `status` tinyint(1) DEFAULT 1,
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `fk_menu_parent` (`parent_id`),
  CONSTRAINT `fk_menu_parent` FOREIGN KEY (`parent_id`) REFERENCES `menus` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci',
  'payment_methods' => 'CREATE TABLE IF NOT EXISTS `payment_methods` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `slug` varchar(50) NOT NULL,
  `type` enum(\'mobile_banking\',\'bank_transfer\',\'card\',\'payment_gateway\') NOT NULL,
  `logo` varchar(255) DEFAULT NULL,
  `account_number` varchar(50) DEFAULT NULL,
  `account_name` varchar(100) DEFAULT NULL,
  `instructions` text DEFAULT NULL,
  `charge_type` enum(\'fixed\',\'percentage\') DEFAULT \'fixed\',
  `charge_amount` decimal(10,2) DEFAULT 0.00,
  `min_amount` decimal(10,2) DEFAULT 0.00,
  `max_amount` decimal(10,2) DEFAULT 999999.99,
  `credentials` text DEFAULT NULL COMMENT \'JSON encoded API credentials\',
  `is_active` tinyint(1) DEFAULT 1,
  `sort_order` int(11) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `slug` (`slug`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci',
  'products' => 'CREATE TABLE IF NOT EXISTS `products` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `brand` varchar(100) DEFAULT NULL,
  `sku` varchar(50) DEFAULT NULL,
  `product_type` enum(\'physical\',\'digital\') DEFAULT \'physical\',
  `slug` varchar(255) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `offer_price` decimal(10,2) DEFAULT NULL,
  `quantity` int(11) DEFAULT 0,
  `weight` varchar(50) DEFAULT NULL,
  `dimensions` varchar(100) DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `image_alt_text` varchar(255) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `digital_file_url` varchar(255) DEFAULT NULL,
  `status` tinyint(1) DEFAULT 1,
  `show_on_website` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` datetime DEFAULT current_timestamp(),
  `benefits` text DEFAULT NULL,
  `trust_points` text DEFAULT NULL,
  `video_url` varchar(255) DEFAULT NULL,
  `stock_status` varchar(50) DEFAULT \'In Stock\',
  `benefits_title` varchar(255) DEFAULT \'উপকারিতা:\',
  `trust_title` varchar(255) DEFAULT \'কেন আমাদের থেকে নিবেন?\',
  `details_title` varchar(255) DEFAULT \'বিস্তারিত বিবরণ:\',
  `shipping_class_id` int(11) DEFAULT NULL,
  `show_seo_guide` tinyint(1) DEFAULT 0,
  `meta_title` varchar(255) DEFAULT NULL,
  `meta_description` text DEFAULT NULL,
  `meta_keywords` text DEFAULT NULL,
  `focus_keyword` varchar(255) DEFAULT NULL,
  `allow_cod` tinyint(1) DEFAULT 1,
  PRIMARY KEY (`id`),
  UNIQUE KEY `slug` (`slug`),
  KEY `category_id` (`category_id`),
  CONSTRAINT `fk_product_category` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci',
  'orders' => 'CREATE TABLE IF NOT EXISTS `orders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL COMMENT \'Null if guest checkout\',
  `customer_name` varchar(100) DEFAULT NULL,
  `tracking_id` varchar(20) NOT NULL,
  `courier_consignment_id` varchar(100) DEFAULT NULL,
  `courier_status` varchar(50) DEFAULT NULL,
  `total_amount` decimal(10,2) NOT NULL,
  `discount_amount` decimal(10,2) DEFAULT 0.00,
  `coupon_code` varchar(50) DEFAULT NULL,
  `payment_method` enum(\'COD\',\'Online\') NOT NULL DEFAULT \'COD\',
  `payment_status` enum(\'Pending\',\'Paid\',\'Failed\') DEFAULT \'Pending\',
  `digital_delivery_status` enum(\'Pending\',\'Sent\',\'Failed\',\'N/A\') DEFAULT \'N/A\',
  `digital_delivery_at` datetime DEFAULT NULL,
  `order_status` enum(\'Pending\',\'Processing\',\'Shipped\',\'Delivered\',\'Cancelled\') DEFAULT \'Pending\',
  `shipping_address` text NOT NULL,
  `customer_phone` varchar(15) NOT NULL,
  `customer_email` varchar(255) DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `access_token` varchar(64) DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `tracking_id` (`tracking_id`),
  UNIQUE KEY `access_token` (`access_token`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci',
  'order_items' => 'CREATE TABLE IF NOT EXISTS `order_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `qty` int(11) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `variant_id` int(11) DEFAULT NULL,
  `variant_label` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `order_id` (`order_id`),
  KEY `product_id` (`product_id`),
  CONSTRAINT `fk_order_items_order` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci',
  'product_images' => 'CREATE TABLE IF NOT EXISTS `product_images` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) NOT NULL,
  `image_path` varchar(255) NOT NULL,
  `sort_order` int(11) DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `product_id` (`product_id`),
  CONSTRAINT `fk_product_images_product` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci',
  'product_shipping_zones' => 'CREATE TABLE IF NOT EXISTS `product_shipping_zones` (
  `product_id` int(11) NOT NULL,
  `shipping_zone_id` int(11) NOT NULL,
  PRIMARY KEY (`product_id`,`shipping_zone_id`),
  KEY `fk_psz_zone` (`shipping_zone_id`),
  CONSTRAINT `fk_psz_product` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_psz_zone` FOREIGN KEY (`shipping_zone_id`) REFERENCES `shipping_zones` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci',
  'product_payment_methods' => 'CREATE TABLE IF NOT EXISTS `product_payment_methods` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) NOT NULL,
  `payment_method_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `product_id` (`product_id`,`payment_method_id`),
  KEY `payment_method_id` (`payment_method_id`),
  CONSTRAINT `product_payment_methods_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE,
  CONSTRAINT `product_payment_methods_ibfk_2` FOREIGN KEY (`payment_method_id`) REFERENCES `payment_methods` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci',
  'landing_pages' => 'CREATE TABLE IF NOT EXISTS `landing_pages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) NOT NULL,
  `product_ids` varchar(1024) DEFAULT NULL,
  `slug` varchar(255) NOT NULL,
  `template_type` enum(\'default\',\'custom\') NOT NULL DEFAULT \'default\',
  `page_title` varchar(255) NOT NULL,
  `meta_description` text DEFAULT NULL,
  `hero_title` varchar(255) DEFAULT NULL,
  `hero_subtitle` text DEFAULT NULL,
  `hero_image` varchar(255) DEFAULT NULL,
  `hero_video_url` varchar(255) DEFAULT NULL,
  `benefits_title` varchar(255) DEFAULT \'এই প্রোডাক্টের উপকারিতা\',
  `benefits_content` text DEFAULT NULL,
  `trust_title` varchar(255) DEFAULT \'কেন আমাদের থেকে নিবেন?\',
  `trust_content` text DEFAULT NULL,
  `cta_text` varchar(100) DEFAULT \'এখনই অর্ডার করুন\',
  `custom_html` longtext DEFAULT NULL,
  `custom_js` text DEFAULT NULL,
  `custom_css` text DEFAULT NULL,
  `shipping_config` text DEFAULT NULL,
  `status` tinyint(1) DEFAULT 1,
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `slug` (`slug`),
  KEY `product_id` (`product_id`),
  CONSTRAINT `fk_landing_product` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci',
  'payment_transactions' => 'CREATE TABLE IF NOT EXISTS `payment_transactions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_id` int(11) DEFAULT NULL,
  `invoice_id` varchar(50) NOT NULL,
  `payment_method_id` int(11) NOT NULL,
  `customer_name` varchar(100) NOT NULL,
  `customer_email` varchar(100) DEFAULT NULL,
  `customer_phone` varchar(20) DEFAULT NULL,
  `amount` decimal(10,2) NOT NULL,
  `charge` decimal(10,2) DEFAULT 0.00,
  `total_amount` decimal(10,2) NOT NULL,
  `currency` varchar(10) DEFAULT \'BDT\',
  `transaction_id` varchar(100) DEFAULT NULL COMMENT \'Customer transaction ID\',
  `sender_number` varchar(20) DEFAULT NULL,
  `status` enum(\'pending\',\'processing\',\'completed\',\'failed\',\'cancelled\',\'refunded\') DEFAULT \'pending\',
  `admin_note` text DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `invoice_id` (`invoice_id`),
  KEY `payment_method_id` (`payment_method_id`),
  KEY `order_id` (`order_id`),
  CONSTRAINT `payment_transactions_ibfk_1` FOREIGN KEY (`payment_method_id`) REFERENCES `payment_methods` (`id`),
  CONSTRAINT `payment_transactions_ibfk_2` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci',
  'reviews' => 'CREATE TABLE IF NOT EXISTS `reviews` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `user_name` varchar(255) NOT NULL,
  `user_email` varchar(255) NOT NULL,
  `rating` int(11) NOT NULL,
  `comment` text DEFAULT NULL,
  `status` tinyint(1) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci',
  'wishlist' => 'CREATE TABLE IF NOT EXISTS `wishlist` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `product_id` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_prod` (`user_id`,`product_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci',
  'product_variant_attributes' => 'CREATE TABLE IF NOT EXISTS `product_variant_attributes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `display_type` enum(\'button\',\'color\') DEFAULT \'button\',
  `sort_order` int(11) DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `product_id` (`product_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci',
  'product_variant_attribute_values' => 'CREATE TABLE IF NOT EXISTS `product_variant_attribute_values` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `attribute_id` int(11) NOT NULL,
  `value` varchar(100) NOT NULL,
  `color_hex` varchar(7) DEFAULT NULL,
  `sort_order` int(11) DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `attribute_id` (`attribute_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci',
  'product_variants' => 'CREATE TABLE IF NOT EXISTS `product_variants` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) NOT NULL,
  `sku` varchar(100) DEFAULT NULL,
  `combination_json` text NOT NULL,
  `price` decimal(10,2) DEFAULT NULL,
  `offer_price` decimal(10,2) DEFAULT NULL,
  `quantity` int(11) DEFAULT 0,
  `stock_status` varchar(50) DEFAULT \'In Stock\',
  `sort_order` int(11) DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `product_id` (`product_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci',
  'product_sections' => 'CREATE TABLE IF NOT EXISTS `product_sections` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `icon` varchar(50) DEFAULT \'fas fa-check-circle\',
  `sort_order` int(11) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `product_id` (`product_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci',
  'product_section_items' => 'CREATE TABLE IF NOT EXISTS `product_section_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `section_id` int(11) NOT NULL,
  `text_content` text NOT NULL,
  `sort_order` int(11) DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `section_id` (`section_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci',
  'abandoned_carts' => 'CREATE TABLE IF NOT EXISTS `abandoned_carts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `session_id` varchar(64) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `customer_name` varchar(100) DEFAULT NULL,
  `customer_phone` varchar(20) DEFAULT NULL,
  `customer_email` varchar(100) DEFAULT NULL,
  `customer_area` varchar(150) DEFAULT NULL,
  `customer_address` text DEFAULT NULL,
  `cart_data` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`cart_data`)),
  `cart_total` decimal(10,2) DEFAULT 0.00,
  `recovery_token` varchar(64) NOT NULL,
  `status` enum(\'active\',\'recovered\',\'expired\') DEFAULT \'active\',
  `sms_sent_count` tinyint(3) unsigned DEFAULT 0,
  `whatsapp_sent_count` tinyint(3) unsigned DEFAULT 0,
  `last_reminder_at` datetime DEFAULT NULL,
  `recovered_at` datetime DEFAULT NULL,
  `order_id` int(11) DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_recovery_token` (`recovery_token`),
  KEY `idx_status_phone` (`status`,`customer_phone`),
  KEY `idx_session` (`session_id`),
  KEY `idx_updated` (`updated_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci',
  'tracking_settings' => 'CREATE TABLE IF NOT EXISTS `tracking_settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `meta_pixel_id` varchar(50) DEFAULT NULL,
  `meta_capi_access_token` text DEFAULT NULL COMMENT \'Encrypted\',
  `tiktok_pixel_id` varchar(50) DEFAULT NULL,
  `tiktok_events_api_token` text DEFAULT NULL COMMENT \'Encrypted\',
  `enable_advanced_matching` tinyint(1) DEFAULT 0,
  `is_test_mode` tinyint(1) DEFAULT 0,
  `meta_test_event_code` varchar(50) DEFAULT NULL,
  `google_verification_code` varchar(255) DEFAULT NULL,
  `google_analytics_id` varchar(50) DEFAULT NULL,
  `google_tag_manager_id` varchar(50) DEFAULT NULL,
  `google_search_console_embed` text DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `updated_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci',
  'tracking_logs' => 'CREATE TABLE IF NOT EXISTS `tracking_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `platform` enum(\'meta\',\'tiktok\') NOT NULL,
  `event_name` varchar(50) NOT NULL,
  `event_id` varchar(100) DEFAULT NULL,
  `status` enum(\'success\',\'failed\') NOT NULL,
  `response_code` int(11) DEFAULT NULL,
  `error_message` text DEFAULT NULL,
  `payload_summary` text DEFAULT NULL COMMENT \'Sanitized - no tokens\',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_platform_event` (`platform`,`event_name`),
  KEY `idx_created_at` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci',
  'media_metadata' => 'CREATE TABLE IF NOT EXISTS `media_metadata` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `file_path` varchar(255) NOT NULL,
  `alt_text` varchar(255) DEFAULT NULL,
  `title_text` varchar(255) DEFAULT NULL,
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `file_path` (`file_path`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci',
  'transactions' => 'CREATE TABLE IF NOT EXISTS `transactions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `invoice_id` varchar(50) NOT NULL,
  `payment_method_id` int(11) NOT NULL,
  `customer_name` varchar(100) NOT NULL,
  `customer_email` varchar(100) DEFAULT NULL,
  `customer_phone` varchar(20) DEFAULT NULL,
  `amount` decimal(10,2) NOT NULL,
  `charge` decimal(10,2) DEFAULT 0.00,
  `total_amount` decimal(10,2) NOT NULL,
  `currency` varchar(10) DEFAULT \'BDT\',
  `transaction_id` varchar(100) DEFAULT NULL COMMENT \'Provider transaction ID\',
  `sender_number` varchar(20) DEFAULT NULL,
  `status` enum(\'pending\',\'processing\',\'completed\',\'failed\',\'cancelled\',\'refunded\') DEFAULT \'pending\',
  `metadata` text DEFAULT NULL COMMENT \'JSON encoded additional data\',
  `callback_url` varchar(255) DEFAULT NULL,
  `success_url` varchar(255) DEFAULT NULL,
  `cancel_url` varchar(255) DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `note` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `invoice_id` (`invoice_id`),
  KEY `payment_method_id` (`payment_method_id`),
  CONSTRAINT `transactions_ibfk_1` FOREIGN KEY (`payment_method_id`) REFERENCES `payment_methods` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci',
  'page_visits' => 'CREATE TABLE IF NOT EXISTS `page_visits` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `session_id` varchar(64) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `page_url` varchar(500) NOT NULL,
  `page_title` varchar(255) DEFAULT NULL,
  `referrer` varchar(500) DEFAULT NULL,
  `utm_source` varchar(100) DEFAULT NULL,
  `utm_medium` varchar(100) DEFAULT NULL,
  `utm_campaign` varchar(200) DEFAULT NULL,
  `utm_term` varchar(200) DEFAULT NULL,
  `utm_content` varchar(200) DEFAULT NULL,
  `device_type` enum(\'desktop\',\'mobile\',\'tablet\') DEFAULT \'desktop\',
  `browser` varchar(50) DEFAULT NULL,
  `os` varchar(50) DEFAULT NULL,
  `screen_resolution` varchar(20) DEFAULT NULL,
  `country` varchar(5) DEFAULT NULL,
  `city` varchar(100) DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `is_bot` tinyint(1) DEFAULT 0,
  `landing_page` varchar(500) DEFAULT NULL,
  `time_on_page` int(11) DEFAULT NULL COMMENT \'Seconds via JS beacon\',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_pv_session` (`session_id`),
  KEY `idx_pv_created` (`created_at`),
  KEY `idx_pv_page` (`page_url`(191)),
  KEY `idx_pv_utm` (`utm_source`,`utm_medium`,`utm_campaign`(100))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci',
  'analytics_alerts' => 'CREATE TABLE IF NOT EXISTS `analytics_alerts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `alert_type` varchar(50) NOT NULL COMMENT \'e.g. low_stock, high_abandoned, revenue_drop\',
  `title` varchar(200) NOT NULL,
  `condition_json` text NOT NULL COMMENT \'JSON rule definition\',
  `is_active` tinyint(1) DEFAULT 1,
  `last_triggered_at` datetime DEFAULT NULL,
  `trigger_count` int(11) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci',
  'order_notes' => 'CREATE TABLE IF NOT EXISTS `order_notes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_id` int(11) NOT NULL,
  `admin_name` varchar(100) NOT NULL,
  `note` text NOT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_order` (`order_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci',
);
$columnUpgrades = array (
  0 => 
  array (
    0 => 'order_items',
    1 => 'variant_id',
    2 => 'INT NULL DEFAULT NULL',
    3 => 'price',
  ),
  1 => 
  array (
    0 => 'order_items',
    1 => 'variant_label',
    2 => 'VARCHAR(255) NULL DEFAULT NULL',
    3 => 'variant_id',
  ),
  2 => 
  array (
    0 => 'landing_pages',
    1 => 'product_ids',
    2 => 'VARCHAR(1024) NULL DEFAULT NULL',
    3 => 'product_id',
  ),
  3 => 
  array (
    0 => 'abandoned_carts',
    1 => 'customer_email',
    2 => 'VARCHAR(100) NULL DEFAULT NULL',
    3 => 'customer_phone',
  ),
  4 => 
  array (
    0 => 'abandoned_carts',
    1 => 'customer_area',
    2 => 'VARCHAR(150) NULL DEFAULT NULL',
    3 => 'customer_email',
  ),
  5 => 
  array (
    0 => 'abandoned_carts',
    1 => 'customer_address',
    2 => 'TEXT NULL DEFAULT NULL',
    3 => 'customer_area',
  ),
  6 => 
  array (
    0 => 'admins',
    1 => 'username',
    2 => 'VARCHAR(100) NULL DEFAULT NULL',
    3 => 'email',
  ),
  7 => 
  array (
    0 => 'categories',
    1 => 'meta_title',
    2 => 'VARCHAR(255) NULL DEFAULT NULL',
    3 => 'status',
  ),
  8 => 
  array (
    0 => 'categories',
    1 => 'meta_description',
    2 => 'TEXT NULL DEFAULT NULL',
    3 => 'meta_title',
  ),
  9 => 
  array (
    0 => 'categories',
    1 => 'meta_keywords',
    2 => 'TEXT NULL DEFAULT NULL',
    3 => 'meta_description',
  ),
  10 => 
  array (
    0 => 'categories',
    1 => 'description',
    2 => 'TEXT NULL DEFAULT NULL',
    3 => 'meta_keywords',
  ),
  11 => 
  array (
    0 => 'categories',
    1 => 'h1_title',
    2 => 'VARCHAR(255) NULL DEFAULT NULL',
    3 => 'description',
  ),
  12 =>
  array (
    0 => 'orders',
    1 => 'customer_email',
    2 => 'VARCHAR(255) NULL DEFAULT NULL',
    3 => 'customer_phone',
  ),
  13 =>
  array (
    0 => 'orders',
    1 => 'digital_delivery_status',
    2 => "ENUM('Pending','Sent','Failed','N/A') DEFAULT 'N/A'",
    3 => 'customer_email',
  ),
  14 =>
  array (
    0 => 'orders',
    1 => 'digital_delivery_at',
    2 => 'DATETIME NULL DEFAULT NULL',
    3 => 'digital_delivery_status',
  ),
  15 =>
  array (
    0 => 'orders',
    1 => 'ip_address',
    2 => 'VARCHAR(45) NULL DEFAULT NULL',
    3 => 'digital_delivery_at',
  ),
  16 =>
  array (
    0 => 'orders',
    1 => 'user_agent',
    2 => 'TEXT NULL DEFAULT NULL',
    3 => 'ip_address',
  ),
  17 =>
  array (
    0 => 'orders',
    1 => 'access_token',
    2 => 'VARCHAR(64) NULL DEFAULT NULL',
    3 => 'user_agent',
  ),
  18 =>
  array (
    0 => 'sliders',
    1 => 'position',
    2 => "VARCHAR(50) NULL DEFAULT 'main_hero'",
    3 => 'status',
  ),
  // Courier columns — present in CREATE for fresh installs; ALTER for older DBs
  19 =>
  array (
    0 => 'orders',
    1 => 'courier_consignment_id',
    2 => 'VARCHAR(100) NULL DEFAULT NULL',
    3 => 'tracking_id',
  ),
  20 =>
  array (
    0 => 'orders',
    1 => 'courier_status',
    2 => 'VARCHAR(50) NULL DEFAULT NULL',
    3 => 'courier_consignment_id',
  ),
  21 =>
  array (
    0 => 'products',
    1 => 'allow_cod',
    2 => 'TINYINT(1) NULL DEFAULT 1',
    3 => 'focus_keyword',
  ),
  22 =>
  array (
    0 => 'products',
    1 => 'show_on_website',
    2 => 'TINYINT(1) NOT NULL DEFAULT 1',
    3 => 'status',
  ),
);

$indexUpgrades = array(
  array('reviews', 'idx_reviews_product_status', '`product_id`, `status`'),
  array('orders', 'idx_orders_status_created', '`order_status`, `created_at`'),
  array('orders', 'idx_orders_access_token', '`access_token`'),
  array('orders', 'idx_orders_courier', '`courier_consignment_id`'),
  array('orders', 'idx_orders_phone', '`customer_phone`'),
  array('products', 'idx_products_status_visible', '`status`, `show_on_website`'),
  array('menus', 'idx_menus_location_status_sort', '`location`, `status`, `sort_order`'),
  array('sliders', 'idx_sliders_status_sort', '`status`, `sort_order`'),
  array('order_notes', 'idx_order', '`order_id`'),
  array('tracking_logs', 'idx_tracking_status_created', '`status`, `created_at`'),
);

echo "KhatiRaj Database Migration\n";
echo str_repeat('=', 40) . "\n";
echo 'Version: ' . MIGRATION_VERSION . "\n\n";

try {
    $migrator = new DatabaseMigrator($pdo, $createStatements, $columnUpgrades, $indexUpgrades);
    $log = $migrator->run();
    foreach ($log as $line) {
        echo $line . "\n";
    }

    // Backfill missing order access tokens
    require_once __DIR__ . '/app/Helpers/OrderAccessHelper.php';
    $missing = $pdo->query("SELECT id FROM orders WHERE access_token IS NULL OR access_token = ''")->fetchAll(PDO::FETCH_COLUMN);
    foreach ($missing as $orderId) {
        OrderAccessHelper::getOrCreateToken($pdo, (int) $orderId);
        echo "Backfilled access_token for order #{$orderId}\n";
    }

    echo "\nMigration completed successfully.\n";
    exit(0);
} catch (Throwable $e) {
    echo "\n[FATAL] " . $e->getMessage() . "\n";
    exit(1);
}
