<?php
// scratch/db_migrate.php
require_once 'config/database.php';

try {
    // Check if column product_ids already exists
    $stmt = $pdo->query("SHOW COLUMNS FROM landing_pages LIKE 'product_ids'");
    $exists = $stmt->fetch();
    
    if (!$exists) {
        $pdo->exec("ALTER TABLE landing_pages ADD COLUMN product_ids varchar(1024) NULL DEFAULT NULL AFTER product_id");
        echo "Column 'product_ids' successfully added to 'landing_pages' table.\n";
    } else {
        echo "Column 'product_ids' already exists in 'landing_pages' table.\n";
    }
} catch (Exception $e) {
    echo "Error during migration: " . $e->getMessage() . "\n";
}
?>
