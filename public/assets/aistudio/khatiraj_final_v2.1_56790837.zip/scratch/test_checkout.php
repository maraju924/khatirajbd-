<?php
require __DIR__ . '/../config/database.php';
require __DIR__ . '/../app/Helpers/ProductVariantHelper.php';

ProductVariantHelper::ensureTables($pdo);

echo "order_items columns:\n";
$stmt = $pdo->query('DESCRIBE order_items');
while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
    echo "  {$row['Field']} - {$row['Type']}\n";
}

echo "\nTest INSERT:\n";
try {
    $pdo->beginTransaction();
    $pdo->exec("INSERT INTO orders (customer_name, customer_phone, shipping_address, tracking_id, total_amount, payment_method, payment_status, order_status) VALUES ('Test', '01700000000', 'Test Addr', 'TEST-123', 100, 'COD', 'Pending', 'Pending')");
    $orderId = $pdo->lastInsertId();
    $stmt = $pdo->prepare("INSERT INTO order_items (order_id, product_id, qty, price, variant_id, variant_label) VALUES (?, ?, ?, ?, ?, ?)");
    $stmt->execute([$orderId, 1, 1, 100, 1, 'Color: red']);
    $pdo->rollBack();
    echo "INSERT OK\n";
} catch (Exception $e) {
    $pdo->rollBack();
    echo "INSERT FAILED: " . $e->getMessage() . "\n";
}
