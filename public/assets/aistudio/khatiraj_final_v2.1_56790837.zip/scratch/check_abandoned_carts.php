<?php
require_once __DIR__ . '/../config/database.php';

try {
    $count = $pdo->query("SELECT COUNT(*) FROM abandoned_carts")->fetchColumn();
    echo "abandoned_carts count: $count\n";
    
    $q = $pdo->query("SELECT * FROM abandoned_carts LIMIT 5");
    $rows = $q->fetchAll();
    echo "Rows:\n";
    print_r($rows);
} catch (Exception $e) {
    echo "Error: " . $e->getMessage() . "\n";
}
