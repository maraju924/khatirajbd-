<?php
// app/Services/MetaCapiService.php
// Meta (Facebook) Conversions API Service

require_once __DIR__ . '/../../config/tracking_encryption.php';

class MetaCapiService {
    private $pixelId;
    private $accessToken;
    private $testEventCode;
    private $isTestMode;
    private $pdo;

    public function __construct() {
        global $pdo;
        $this->pdo = $pdo;
        $this->loadSettings();
    }

    /**
     * Load tracking settings from DB
     */
    private function loadSettings(): void {
        try {
            $stmt = $this->pdo->query("SELECT * FROM tracking_settings WHERE id = 1");
            $settings = $stmt->fetch(PDO::FETCH_ASSOC);

            if ($settings) {
                $this->pixelId = $settings['meta_pixel_id'] ?? '';
                $this->accessToken = !empty($settings['meta_capi_access_token'])
                    ? TrackingEncryption::decrypt($settings['meta_capi_access_token'])
                    : '';
                $this->isTestMode = (bool)($settings['is_test_mode'] ?? false);
                $this->testEventCode = $settings['meta_test_event_code'] ?? '';
            }
        } catch (PDOException $e) {
            // Silently fail - tracking should never break the site
        }
    }

    /**
     * Check if service is properly configured
     */
    public function isConfigured(): bool {
        return !empty($this->pixelId) && !empty($this->accessToken);
    }

    /**
     * Send an event to Meta Conversions API.
     *
     * @param string $eventName e.g. 'Purchase', 'ViewContent', 'AddToCart'
     * @param array $userData ['email' => ..., 'phone' => ..., 'first_name' => ..., 'client_ip_address' => ..., 'client_user_agent' => ...]
     * @param array $customData ['value' => ..., 'currency' => ..., 'content_ids' => [...], 'content_type' => ...]
     * @param string|null $eventId Unique event ID for deduplication
     * @return bool
     */
    public function sendEvent(string $eventName, array $userData = [], array $customData = [], ?string $eventId = null): bool {
        if (!$this->isConfigured()) {
            return false;
        }

        try {
            // Build user_data with hashed PII
            $hashedUserData = [];

            if (!empty($userData['email'])) {
                $hashedUserData['em'] = [TrackingEncryption::hashPII($userData['email'])];
            }
            if (!empty($userData['phone'])) {
                $normalizedPhone = TrackingEncryption::normalizePhone($userData['phone']);
                $hashedUserData['ph'] = [TrackingEncryption::hashPII($normalizedPhone)];
            }
            if (!empty($userData['first_name'])) {
                $hashedUserData['fn'] = [TrackingEncryption::hashPII($userData['first_name'])];
            }
            if (!empty($userData['client_ip_address'])) {
                $hashedUserData['client_ip_address'] = $userData['client_ip_address'];
            }
            if (!empty($userData['client_user_agent'])) {
                $hashedUserData['client_user_agent'] = $userData['client_user_agent'];
            }

            // Meta browser cookies dramatically improve event match quality
            $fbp = $userData['fbp'] ?? ($_COOKIE['_fbp'] ?? null);
            $fbc = $userData['fbc'] ?? ($_COOKIE['_fbc'] ?? null);
            if (!empty($fbp)) {
                $hashedUserData['fbp'] = $fbp;
            }
            if (!empty($fbc)) {
                $hashedUserData['fbc'] = $fbc;
            }

            // Build event data
            $eventData = [
                'event_name' => $eventName,
                'event_time' => time(),
                'action_source' => 'website',
                'user_data' => $hashedUserData,
            ];

            if ($eventId) {
                $eventData['event_id'] = $eventId;
            }

            if (!empty($userData['event_source_url'])) {
                $eventData['event_source_url'] = $userData['event_source_url'];
            } else {
                // Build current URL
                $protocol = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on') ? 'https' : 'http';
                $eventData['event_source_url'] = $protocol . '://' . ($_SERVER['HTTP_HOST'] ?? 'localhost') . ($_SERVER['REQUEST_URI'] ?? '/');
            }

            if (!empty($customData)) {
                $eventData['custom_data'] = $customData;
            }

            // Build payload
            $payload = [
                'data' => [json_encode($eventData)],
            ];

            // Add test event code if in test mode
            if ($this->isTestMode && !empty($this->testEventCode)) {
                $payload['test_event_code'] = $this->testEventCode;
            }

            // Meta Graph API endpoint
            $url = "https://graph.facebook.com/v21.0/{$this->pixelId}/events?access_token=" . urlencode($this->accessToken);

            // Make cURL request
            $ch = curl_init();
            curl_setopt_array($ch, [
                CURLOPT_URL => $url,
                CURLOPT_POST => true,
                CURLOPT_POSTFIELDS => http_build_query($payload),
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_TIMEOUT => 10,
                CURLOPT_SSL_VERIFYPEER => true,
            ]);

            $response = curl_exec($ch);
            $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            $curlError = curl_error($ch);
            curl_close($ch);

            $success = ($httpCode >= 200 && $httpCode < 300);

            // Log the result
            $this->logEvent(
                $eventName,
                $eventId,
                $success ? 'success' : 'failed',
                $httpCode,
                $success ? null : ($curlError ?: $response),
                json_encode(['event_name' => $eventName, 'custom_data' => $customData ?? []])
            );

            return $success;

        } catch (\Exception $e) {
            $this->logEvent($eventName, $eventId, 'failed', 0, $e->getMessage(), null);
            return false;
        }
    }

    /**
     * Test the API connection with current credentials.
     * @return array ['success' => bool, 'message' => string]
     */
    public function testConnection(): array {
        if (!$this->isConfigured()) {
            return ['success' => false, 'message' => 'Meta Pixel ID or CAPI Access Token is not configured.'];
        }

        try {
            // Send a minimal test event
            $testPayload = [
                'data' => [json_encode([
                    'event_name' => 'PageView',
                    'event_time' => time(),
                    'action_source' => 'website',
                    'user_data' => ['client_ip_address' => '0.0.0.0'],
                ])],
            ];

            if ($this->isTestMode && !empty($this->testEventCode)) {
                $testPayload['test_event_code'] = $this->testEventCode;
            }

            $url = "https://graph.facebook.com/v21.0/{$this->pixelId}/events?access_token=" . urlencode($this->accessToken);

            $ch = curl_init();
            curl_setopt_array($ch, [
                CURLOPT_URL => $url,
                CURLOPT_POST => true,
                CURLOPT_POSTFIELDS => http_build_query($testPayload),
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_TIMEOUT => 15,
                CURLOPT_SSL_VERIFYPEER => true,
            ]);

            $response = curl_exec($ch);
            $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            curl_close($ch);

            if ($httpCode >= 200 && $httpCode < 300) {
                return ['success' => true, 'message' => 'Meta CAPI connection successful! (HTTP ' . $httpCode . ')'];
            } else {
                $responseData = json_decode($response, true);
                $errorMsg = $responseData['error']['message'] ?? $response;
                return ['success' => false, 'message' => 'Meta CAPI error (HTTP ' . $httpCode . '): ' . $errorMsg];
            }

        } catch (\Exception $e) {
            return ['success' => false, 'message' => 'Connection error: ' . $e->getMessage()];
        }
    }

    /**
     * Log tracking event result to tracking_logs table
     */
    private function logEvent(string $eventName, ?string $eventId, string $status, int $responseCode, ?string $errorMessage, ?string $payloadSummary): void {
        try {
            $stmt = $this->pdo->prepare("
                INSERT INTO tracking_logs (platform, event_name, event_id, status, response_code, error_message, payload_summary)
                VALUES ('meta', ?, ?, ?, ?, ?, ?)
            ");
            $stmt->execute([$eventName, $eventId, $status, $responseCode, $errorMessage, $payloadSummary]);
        } catch (\Exception $e) {
            // Never let logging break the flow
        }
    }
}
