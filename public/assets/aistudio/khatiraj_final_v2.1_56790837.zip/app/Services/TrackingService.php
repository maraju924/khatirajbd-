<?php
// app/Services/TrackingService.php
// Facade that fires events to both Meta and TikTok in one call.
// Controllers should use this class as the single entry point.

require_once __DIR__ . '/MetaCapiService.php';
require_once __DIR__ . '/TikTokEventsService.php';

class TrackingService {
    private $metaService;
    private $tiktokService;

    public function __construct() {
        $this->metaService = new MetaCapiService();
        $this->tiktokService = new TikTokEventsService();
    }

    /**
     * Fire a tracking event to both Meta CAPI and TikTok Events API.
     * Wrapped in try-catch — will NEVER throw or break the main flow.
     *
     * @param string $eventName Event name (Meta naming convention, e.g. 'Purchase')
     * @param array $userData User data for hashing
     * @param array $customData Custom/property data
     * @param string|null $eventId Unique ID for deduplication
     * @param string|null $tiktokEventName Override TikTok event name if different from Meta (e.g. 'CompletePayment' for Purchase)
     * @return array ['meta' => bool, 'tiktok' => bool]
     */
    public function fireEvent(string $eventName, array $userData = [], array $customData = [], ?string $eventId = null, ?string $tiktokEventName = null): array {
        $results = ['meta' => false, 'tiktok' => false];

        // Add IP and User-Agent if not already set
        if (empty($userData['client_ip_address'])) {
            $userData['client_ip_address'] = $_SERVER['REMOTE_ADDR'] ?? null;
        }
        if (empty($userData['client_user_agent'])) {
            $userData['client_user_agent'] = $_SERVER['HTTP_USER_AGENT'] ?? null;
        }

        // Fire Meta CAPI
        try {
            if ($this->metaService->isConfigured()) {
                $results['meta'] = $this->metaService->sendEvent($eventName, $userData, $customData, $eventId);
            }
        } catch (\Exception $e) {
            // Silently fail
        }

        // Fire TikTok Events API
        try {
            if ($this->tiktokService->isConfigured()) {
                $ttEventName = $tiktokEventName ?? $this->mapToTikTokEvent($eventName);
                if ($ttEventName) {
                    $results['tiktok'] = $this->tiktokService->sendEvent($ttEventName, $userData, $customData, $eventId);
                }
            }
        } catch (\Exception $e) {
            // Silently fail
        }

        return $results;
    }

    /**
     * Map Meta event names to TikTok event names.
     * Returns null if event has no TikTok equivalent.
     */
    private function mapToTikTokEvent(string $metaEventName): ?string {
        $map = [
            'PageView' => 'Pageview',
            'ViewContent' => 'ViewContent',
            'Search' => 'Search',
            'AddToCart' => 'AddToCart',
            'AddToWishlist' => null, // TikTok doesn't have this
            'InitiateCheckout' => 'InitiateCheckout',
            'AddPaymentInfo' => 'AddPaymentInfo',
            'Purchase' => 'CompletePayment',
            'CompleteRegistration' => 'CompleteRegistration',
        ];

        return $map[$metaEventName] ?? $metaEventName;
    }

    /**
     * Build standard user data array from session/request.
     * Convenience helper for controllers.
     */
    public static function buildUserData(?string $email = null, ?string $phone = null, ?string $name = null): array {
        return [
            'email' => $email ?? ($_SESSION['user_email'] ?? null),
            'phone' => $phone ?? ($_SESSION['user_phone'] ?? null),
            'first_name' => $name ?? ($_SESSION['user_name'] ?? null),
            'client_ip_address' => $_SERVER['REMOTE_ADDR'] ?? null,
            'client_user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? null,
        ];
    }

    /**
     * Generate a unique event ID for deduplication.
     *
     * @param string $prefix e.g. 'purchase', 'view', 'cart'
     * @param string|null $identifier e.g. order ID, product ID
     * @return string
     */
    public static function generateEventId(string $prefix, ?string $identifier = null): string {
        if ($identifier) {
            return $prefix . '_' . $identifier . '_' . time();
        }
        return $prefix . '_' . bin2hex(random_bytes(8));
    }
}
