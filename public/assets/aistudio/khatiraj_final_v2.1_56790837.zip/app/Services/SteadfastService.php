<?php
// app/Services/SteadfastService.php

class SteadfastService {
    private $apiKey;
    private $secretKey;
    private $baseUrl;

    public function __construct() {
        global $pdo;
        // Try to fetch from database settings first
        $stmt = $pdo->query("SELECT * FROM settings WHERE key_name IN ('steadfast_api_key', 'steadfast_secret_key')");
        $results = $stmt->fetchAll(PDO::FETCH_KEY_PAIR);

        $staticConfig = file_exists(__DIR__ . '/../../config/courier.php') ? include __DIR__ . '/../../config/courier.php' : [];

        $this->apiKey = $results['steadfast_api_key'] ?? $staticConfig['steadfast']['api_key'] ?? '';
        $this->secretKey = $results['steadfast_secret_key'] ?? $staticConfig['steadfast']['secret_key'] ?? '';
        $this->baseUrl = $staticConfig['steadfast']['base_url'] ?? 'https://portal.packzy.com/api/v1';
    }

    public function createOrder($orderData) {
        $url = $this->baseUrl . '/create_order';
        
        $payload = [
            'invoice' => $orderData['invoice'],
            'recipient_name' => $orderData['recipient_name'],
            'recipient_phone' => $orderData['recipient_phone'],
            'recipient_address' => $orderData['recipient_address'],
            'cod_amount' => $orderData['cod_amount'],
            'note' => $orderData['note'] ?? '',
            'item_description' => $orderData['item_description'] ?? ''
        ];

        return $this->request('POST', $url, $payload);
    }

    public function getStatusByTrackingCode($trackingCode) {
        $url = $this->baseUrl . '/status_by_trackingcode/' . $trackingCode;
        return $this->request('GET', $url);
    }

    public function getStatusByConsignmentId($consignmentId) {
        $url = $this->baseUrl . '/status_by_cid/' . $consignmentId;
        return $this->request('GET', $url);
    }

    public function getStatusByInvoice($invoice) {
        $url = $this->baseUrl . '/status_by_invoice/' . rawurlencode($invoice);
        return $this->request('GET', $url);
    }

    public function getBalance() {
        return $this->request('GET', $this->baseUrl . '/get_balance');
    }

    public function getPayments() {
        return $this->request('GET', $this->baseUrl . '/payments');
    }

    public function getPaymentDetails($paymentId) {
        return $this->request('GET', $this->baseUrl . '/payments/' . (int) $paymentId);
    }

    public function getReturnRequests() {
        return $this->request('GET', $this->baseUrl . '/get_return_requests');
    }

    public function checkFraud($phone) {
        $url = $this->baseUrl . '/fraud_check/' . $phone;
        return $this->request('GET', $url);
    }

    public function isConfigured(): bool {
        return !empty($this->apiKey) && !empty($this->secretKey);
    }

    private function request($method, $url, $data = []) {
        $ch = curl_init();
        
        $headers = [
            'Api-Key: ' . $this->apiKey,
            'Secret-Key: ' . $this->secretKey,
            'Content-Type: application/json'
        ];

        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_TIMEOUT, 20);

        if ($method === 'POST') {
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
        }

        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);

        if (curl_errno($ch)) {
            $error_msg = curl_error($ch);
            curl_close($ch);
            return [
                'status' => 0,
                'error' => 'CURL Error: ' . $error_msg,
                'response' => null
            ];
        }
        curl_close($ch);

        $decoded = json_decode($response, true);
        if ($httpCode === 200 || $httpCode === 201) {
            if ($decoded === null) {
                return [
                    'status' => $httpCode,
                    'error' => 'Invalid JSON response',
                    'response' => $response
                ];
            }
            return $decoded;
        }

        return [
            'status' => $httpCode,
            'error' => 'API Request Failed (' . $httpCode . ')',
            'response' => $response
        ];
    }
}
