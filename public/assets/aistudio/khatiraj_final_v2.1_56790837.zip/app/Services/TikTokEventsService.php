<?php
// app/Services/TikTokEventsService.php
// TikTok Events API Service

require_once __DIR__ . '/../../config/tracking_encryption.php';

class TikTokEventsService {
    private $pixelId;
    private $accessToken;
    private $isTestMode;
    private $pdo;

    public function __construct() {
        global $pdo;
        $this->pdo = $pdo;
        $this->loadSettings();
    }

    /**
     * Load tracking settings from DB
     */
    private function loadSettings(): void {
        try {
            $stmt = $this->pdo->query("SELECT * FROM tracking_settings WHERE id = 1");
            $settings = $stmt->fetch(PDO::FETCH_ASSOC);

            if ($settings) {
                $this->pixelId = $settings['tiktok_pixel_id'] ?? '';
                $this->accessToken = !empty($settings['tiktok_events_api_token'])
                    ? TrackingEncryption::decrypt($settings['tiktok_events_api_token'])
                    : '';
                $this->isTestMode = (bool)($settings['is_test_mode'] ?? false);
            }
        } catch (PDOException $e) {
            // Silently fail
        }
    }

    /**
     * Check if service is properly configured
     */
    public function isConfigured(): bool {
        return !empty($this->pixelId) && !empty($this->accessToken);
    }

    /**
     * Send an event to TikTok Events API.
     *
     * @param string $eventName e.g. 'CompletePayment', 'ViewContent', 'AddToCart'
     * @param array $userData ['email' => ..., 'phone' => ..., 'client_ip_address' => ..., 'client_user_agent' => ...]
     * @param array $customData ['value' => ..., 'currency' => ..., 'content_id' => ..., 'quantity' => ...]
     * @param string|null $eventId Unique event ID for deduplication
     * @return bool
     */
    public function sendEvent(string $eventName, array $userData = [], array $customData = [], ?string $eventId = null): bool {
        if (!$this->isConfigured()) {
            return false;
        }

        try {
            // Build context
            $context = [
                'user_agent' => $userData['client_user_agent'] ?? ($_SERVER['HTTP_USER_AGENT'] ?? ''),
                'ip' => $userData['client_ip_address'] ?? ($_SERVER['REMOTE_ADDR'] ?? ''),
            ];

            // Build page info
            $protocol = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on') ? 'https' : 'http';
            $pageUrl = $userData['event_source_url'] ?? ($protocol . '://' . ($_SERVER['HTTP_HOST'] ?? 'localhost') . ($_SERVER['REQUEST_URI'] ?? '/'));
            $context['page'] = [
                'url' => $pageUrl,
            ];

            // Add hashed user data
            $user = [];
            if (!empty($userData['email'])) {
                $user['email'] = TrackingEncryption::hashPII($userData['email']);
            }
            if (!empty($userData['phone'])) {
                $normalizedPhone = TrackingEncryption::normalizePhone($userData['phone']);
                $user['phone_number'] = TrackingEncryption::hashPII($normalizedPhone);
            }
            if (!empty($user)) {
                $context['user'] = $user;
            }

            // Build event payload
            // TikTok Events API v1.3 requires event_time (Unix seconds), not timestamp
            $eventPayload = [
                'event' => $eventName,
                'event_id' => $eventId ?? uniqid('tt_', true),
                'event_time' => time(),
                'context' => $context,
            ];

            // Build properties from customData
            if (!empty($customData)) {
                $properties = [];
                if (isset($customData['value'])) $properties['value'] = (string)$customData['value'];
                if (isset($customData['currency'])) $properties['currency'] = $customData['currency'];
                if (isset($customData['content_ids'])) {
                    $properties['contents'] = array_map(function($id) use ($customData) {
                        return [
                            'content_id' => (string)$id,
                            'content_type' => $customData['content_type'] ?? 'product',
                            'quantity' => $customData['quantity'] ?? 1,
                        ];
                    }, (array)$customData['content_ids']);
                }
                if (isset($customData['content_id'])) {
                    $properties['contents'] = [[
                        'content_id' => (string)$customData['content_id'],
                        'content_type' => $customData['content_type'] ?? 'product',
                        'quantity' => $customData['quantity'] ?? 1,
                    ]];
                }
                if (isset($customData['search_string'])) {
                    $properties['query'] = $customData['search_string'];
                }
                if (isset($customData['num_items'])) {
                    $properties['num_items'] = (int)$customData['num_items'];
                }
                if (!empty($properties)) {
                    $eventPayload['properties'] = $properties;
                }
            }

            // Full payload
            $payload = json_encode([
                'event_source' => 'web',
                'event_source_id' => $this->pixelId,
                'data' => [$eventPayload],
            ]);

            // TikTok Events API endpoint
            $url = 'https://business-api.tiktok.com/open_api/v1.3/event/track/';

            // Make cURL request - Token in header, NOT URL
            $ch = curl_init();
            curl_setopt_array($ch, [
                CURLOPT_URL => $url,
                CURLOPT_POST => true,
                CURLOPT_POSTFIELDS => $payload,
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_TIMEOUT => 10,
                CURLOPT_SSL_VERIFYPEER => true,
                CURLOPT_HTTPHEADER => [
                    'Content-Type: application/json',
                    'Access-Token: ' . $this->accessToken,
                ],
            ]);

            $response = curl_exec($ch);
            $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            $curlError = curl_error($ch);
            curl_close($ch);

            $responseData = json_decode($response, true);
            $success = ($httpCode >= 200 && $httpCode < 300) && (($responseData['code'] ?? -1) == 0);

            // Log the result
            $this->logEvent(
                $eventName,
                $eventPayload['event_id'],
                $success ? 'success' : 'failed',
                $httpCode,
                $success ? null : ($curlError ?: ($responseData['message'] ?? $response)),
                json_encode(['event_name' => $eventName, 'custom_data' => $customData ?? []])
            );

            return $success;

        } catch (\Exception $e) {
            $this->logEvent($eventName, $eventId, 'failed', 0, $e->getMessage(), null);
            return false;
        }
    }

    /**
     * Test the API connection with current credentials.
     * @return array ['success' => bool, 'message' => string]
     */
    public function testConnection(): array {
        if (!$this->isConfigured()) {
            return ['success' => false, 'message' => 'TikTok Pixel ID or Events API Token is not configured.'];
        }

        try {
            $payload = json_encode([
                'event_source' => 'web',
                'event_source_id' => $this->pixelId,
                'data' => [[
                    'event' => 'ViewContent',
                    'event_id' => 'test_' . uniqid(),
                    'event_time' => time(),
                    'context' => [
                        'user_agent' => 'TestAgent/1.0',
                        'ip' => '0.0.0.0',
                        'page' => ['url' => 'https://test.example.com/'],
                    ],
                    'properties' => [
                        'contents' => [['content_id' => 'test_product', 'content_type' => 'product']],
                    ],
                ]],
            ]);

            $url = 'https://business-api.tiktok.com/open_api/v1.3/event/track/';

            $ch = curl_init();
            curl_setopt_array($ch, [
                CURLOPT_URL => $url,
                CURLOPT_POST => true,
                CURLOPT_POSTFIELDS => $payload,
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_TIMEOUT => 15,
                CURLOPT_SSL_VERIFYPEER => true,
                CURLOPT_HTTPHEADER => [
                    'Content-Type: application/json',
                    'Access-Token: ' . $this->accessToken,
                ],
            ]);

            $response = curl_exec($ch);
            $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            curl_close($ch);

            $responseData = json_decode($response, true);

            if ($httpCode >= 200 && $httpCode < 300 && ($responseData['code'] ?? -1) == 0) {
                return ['success' => true, 'message' => 'TikTok Events API connection successful!'];
            } else {
                $errorMsg = $responseData['message'] ?? $response;
                return ['success' => false, 'message' => 'TikTok API error (HTTP ' . $httpCode . '): ' . $errorMsg];
            }

        } catch (\Exception $e) {
            return ['success' => false, 'message' => 'Connection error: ' . $e->getMessage()];
        }
    }

    /**
     * Log tracking event result
     */
    private function logEvent(string $eventName, ?string $eventId, string $status, int $responseCode, ?string $errorMessage, ?string $payloadSummary): void {
        try {
            $stmt = $this->pdo->prepare("
                INSERT INTO tracking_logs (platform, event_name, event_id, status, response_code, error_message, payload_summary)
                VALUES ('tiktok', ?, ?, ?, ?, ?, ?)
            ");
            $stmt->execute([$eventName, $eventId, $status, $responseCode, $errorMessage, $payloadSummary]);
        } catch (\Exception $e) {
            // Never let logging break the flow
        }
    }
}
