<?php
// app/Services/VisitorTracker.php
// Server-side page visit tracking service for Analytics Command Center

class VisitorTracker {

    // Common bot user-agent keywords
    private static $botKeywords = [
        'bot', 'crawl', 'spider', 'slurp', 'mediapartners', 'adsbot',
        'bingpreview', 'facebookexternalhit', 'facebot', 'twitterbot',
        'linkedinbot', 'whatsapp', 'telegrambot', 'pinterest', 'semrush',
        'ahrefsbot', 'mj12bot', 'dotbot', 'petalbot', 'yandex', 'baidu',
        'bytespider', 'applebot', 'duckduckbot', 'sogou', 'exabot',
        'ia_archiver', 'archive.org', 'headlesschrome', 'phantomjs',
        'lighthouse', 'pagespeed', 'gtmetrix', 'pingdom', 'uptimerobot'
    ];

    // Skip tracking for these URL patterns
    private static $skipPatterns = [
        '/admin/',
        '/api/',
        '/actions/',
        '.css', '.js', '.jpg', '.jpeg', '.png', '.gif', '.svg', '.ico',
        '.woff', '.woff2', '.ttf', '.eot',
        'xmlrpc', 'wp-login', 'wp-admin',
    ];

    /**
     * Track the current page visit. Call this once per page load.
     * Returns the inserted record ID, or false if skipped.
     */
    public static function track(): int|false {
        global $pdo;

        if (!$pdo) return false;

        // Don't track if table doesn't exist yet
        try {
            $pdo->query("SELECT 1 FROM page_visits LIMIT 1");
        } catch (\PDOException $e) {
            return false;
        }

        $requestUri = $_SERVER['REQUEST_URI'] ?? '/';
        $userAgent = $_SERVER['HTTP_USER_AGENT'] ?? '';

        // Skip static assets, admin pages, AJAX requests
        if (self::shouldSkip($requestUri, $userAgent)) {
            return false;
        }

        // Ensure session is started for session_id
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }

        $sessionId = session_id();
        $userId = $_SESSION['user_id'] ?? null;

        // Parse URL
        $parsedUrl = parse_url($requestUri);
        $pageUrl = $parsedUrl['path'] ?? '/';

        // UTM parameters — persist in session for the entire visit
        $utmParams = ['utm_source', 'utm_medium', 'utm_campaign', 'utm_term', 'utm_content'];
        foreach ($utmParams as $param) {
            if (isset($_GET[$param]) && !empty($_GET[$param])) {
                $_SESSION['_analytics_' . $param] = trim($_GET[$param]);
            }
        }

        // Landing page — first page in this session
        if (!isset($_SESSION['_analytics_landing_page'])) {
            $_SESSION['_analytics_landing_page'] = $pageUrl;
        }

        // Parse user agent
        $deviceType = self::detectDeviceType($userAgent);
        $browser = self::detectBrowser($userAgent);
        $os = self::detectOS($userAgent);
        $isBot = self::isBot($userAgent) ? 1 : 0;

        // Referrer
        $referrer = $_SERVER['HTTP_REFERER'] ?? null;
        if ($referrer) {
            // Don't store same-site referrers
            $refHost = parse_url($referrer, PHP_URL_HOST);
            $siteHost = $_SERVER['HTTP_HOST'] ?? '';
            if ($refHost === $siteHost) {
                $referrer = null;
            }
        }

        // IP address
        $ip = $_SERVER['HTTP_X_FORWARDED_FOR'] ?? $_SERVER['REMOTE_ADDR'] ?? null;
        if ($ip && strpos($ip, ',') !== false) {
            $ip = trim(explode(',', $ip)[0]);
        }

        // Store the visit ID in session so beacon.js can reference it
        try {
            $stmt = $pdo->prepare("
                INSERT INTO page_visits 
                (session_id, user_id, page_url, referrer, 
                 utm_source, utm_medium, utm_campaign, utm_term, utm_content,
                 device_type, browser, os, ip_address, is_bot, landing_page)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ");
            $stmt->execute([
                $sessionId,
                $userId,
                mb_substr($pageUrl, 0, 500),
                $referrer ? mb_substr($referrer, 0, 500) : null,
                $_SESSION['_analytics_utm_source'] ?? null,
                $_SESSION['_analytics_utm_medium'] ?? null,
                $_SESSION['_analytics_utm_campaign'] ?? null,
                $_SESSION['_analytics_utm_term'] ?? null,
                $_SESSION['_analytics_utm_content'] ?? null,
                $deviceType,
                $browser ? mb_substr($browser, 0, 50) : null,
                $os ? mb_substr($os, 0, 50) : null,
                $ip,
                $isBot,
                $_SESSION['_analytics_landing_page'] ?? $pageUrl,
            ]);

            $visitId = (int) $pdo->lastInsertId();
            // Store last visit ID for beacon update
            $_SESSION['_analytics_last_visit_id'] = $visitId;
            return $visitId;
        } catch (\PDOException $e) {
            // Never break the site
            return false;
        }
    }

    /**
     * Check if we should skip tracking this request.
     */
    private static function shouldSkip(string $uri, string $ua): bool {
        // Skip AJAX requests
        if (!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && 
            strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest') {
            return true;
        }

        // Skip POST requests (form submissions, API calls)
        if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
            return true;
        }

        $uriLower = strtolower($uri);
        foreach (self::$skipPatterns as $pattern) {
            if (strpos($uriLower, $pattern) !== false) {
                return true;
            }
        }

        return false;
    }

    /**
     * Detect device type from User-Agent.
     */
    private static function detectDeviceType(string $ua): string {
        $ua = strtolower($ua);

        // Tablet detection (before mobile, since tablets often match mobile too)
        if (preg_match('/tablet|ipad|playbook|silk|(puffin(?!.*(IP|AP|WP)))/', $ua)) {
            return 'tablet';
        }

        // Mobile detection
        if (preg_match('/mobile|android|iphone|ipod|blackberry|windows phone|opera mini|opera mobi|iemobile/', $ua)) {
            return 'mobile';
        }

        return 'desktop';
    }

    /**
     * Detect browser name from User-Agent.
     */
    private static function detectBrowser(string $ua): ?string {
        $browsers = [
            'Edg/' => 'Edge',
            'OPR/' => 'Opera',
            'Opera' => 'Opera',
            'SamsungBrowser/' => 'Samsung Internet',
            'UCBrowser/' => 'UC Browser',
            'MiuiBrowser/' => 'Mi Browser',
            'YaBrowser/' => 'Yandex',
            'Vivaldi/' => 'Vivaldi',
            'Brave' => 'Brave',
            'Chrome/' => 'Chrome',
            'Safari/' => 'Safari',
            'Firefox/' => 'Firefox',
            'MSIE ' => 'Internet Explorer',
            'Trident/' => 'Internet Explorer',
        ];

        foreach ($browsers as $key => $name) {
            if (strpos($ua, $key) !== false) {
                // Special case: "Safari" should only match if "Chrome" is not present
                if ($name === 'Safari' && strpos($ua, 'Chrome/') !== false) {
                    continue;
                }
                return $name;
            }
        }

        return 'Other';
    }

    /**
     * Detect OS from User-Agent.
     */
    private static function detectOS(string $ua): ?string {
        $osMap = [
            'Windows NT 10' => 'Windows 10/11',
            'Windows NT 6.3' => 'Windows 8.1',
            'Windows NT 6.2' => 'Windows 8',
            'Windows NT 6.1' => 'Windows 7',
            'Windows' => 'Windows',
            'Mac OS X' => 'macOS',
            'Macintosh' => 'macOS',
            'CrOS' => 'Chrome OS',
            'Android' => 'Android',
            'iPhone' => 'iOS',
            'iPad' => 'iPadOS',
            'Linux' => 'Linux',
            'Ubuntu' => 'Ubuntu',
        ];

        foreach ($osMap as $key => $name) {
            if (strpos($ua, $key) !== false) {
                return $name;
            }
        }

        return 'Other';
    }

    /**
     * Check if the User-Agent belongs to a bot/crawler.
     */
    private static function isBot(string $ua): bool {
        if (empty($ua)) return true;

        $uaLower = strtolower($ua);
        foreach (self::$botKeywords as $keyword) {
            if (strpos($uaLower, $keyword) !== false) {
                return true;
            }
        }

        return false;
    }

    /**
     * Auto-cleanup old page_visits records (older than 90 days).
     * Called with a daily throttle to prevent running on every request.
     */
    public static function cleanup(int $retentionDays = 90): int {
        global $pdo;
        if (!$pdo) return 0;

        // Check if cleanup ran today (using a transient in settings or a simple file check)
        $lockFile = sys_get_temp_dir() . '/kr_analytics_cleanup_' . date('Y-m-d') . '.lock';
        if (file_exists($lockFile)) {
            return 0;
        }

        try {
            $stmt = $pdo->prepare("DELETE FROM page_visits WHERE created_at < NOW() - INTERVAL ? DAY");
            $stmt->execute([$retentionDays]);
            $deleted = $stmt->rowCount();

            // Create lock file
            file_put_contents($lockFile, date('Y-m-d H:i:s'));

            return $deleted;
        } catch (\PDOException $e) {
            return 0;
        }
    }
}
