<?php
/**
 * Payment Gateway Service
 * Handles all payment operations for the ecommerce site
 */

class PaymentGateway {
    private $pdo;

    public function __construct($pdo) {
        $this->pdo = $pdo;
    }

    /**
     * Get all payment methods
     */
    public function getPaymentMethods($type = null, $activeOnly = true) {
        $sql = "SELECT * FROM payment_methods WHERE 1=1";
        $params = [];

        if ($activeOnly) {
            $sql .= " AND is_active = 1";
        }

        if ($type) {
            $sql .= " AND type = :type";
            $params['type'] = $type;
        }

        $sql .= " ORDER BY sort_order ASC";

        $stmt = $this->pdo->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetchAll();
    }

    /**
     * Get mobile banking methods
     */
    public function getMobileBankingMethods($activeOnly = true) {
        return $this->getPaymentMethods('mobile_banking', $activeOnly);
    }

    /**
     * Get bank transfer methods
     */
    public function getBankTransferMethods($activeOnly = true) {
        return $this->getPaymentMethods('bank_transfer', $activeOnly);
    }

    /**
     * Get automated payment gateway methods
     */
    public function getPaymentGatewayMethods($activeOnly = true) {
        return $this->getPaymentMethods('payment_gateway', $activeOnly);
    }

    /**
     * Get available payment methods for a list of product IDs
     */
    public function getAvailableMethodsForCart($productIds) {
        if (empty($productIds)) {
            return [
                'allow_cod' => true,
                'methods' => $this->getPaymentMethods(null, true)
            ];
        }

        $allow_cod = true;
        $common_method_ids = null;
        $has_restrictions = false;

        foreach ($productIds as $pid) {
            $stmt = $this->pdo->prepare("SELECT allow_cod FROM products WHERE id = ?");
            $stmt->execute([$pid]);
            $p_cod = $stmt->fetchColumn();
            if ($p_cod === 0) {
                $allow_cod = false;
            }

            $stmt_pm = $this->pdo->prepare("SELECT payment_method_id FROM product_payment_methods WHERE product_id = ?");
            $stmt_pm->execute([$pid]);
            $p_methods = $stmt_pm->fetchAll(PDO::FETCH_COLUMN);

            if (!empty($p_methods)) {
                $has_restrictions = true;
                if ($common_method_ids === null) {
                    $common_method_ids = $p_methods;
                } else {
                    $common_method_ids = array_intersect($common_method_ids, $p_methods);
                }
            }
        }

        if (!$has_restrictions) {
            $available_methods = $this->getPaymentMethods(null, true);
        } elseif (!empty($common_method_ids)) {
            $placeholders = implode(',', array_fill(0, count($common_method_ids), '?'));
            $sql = "SELECT * FROM payment_methods WHERE id IN ($placeholders) AND is_active = 1 ORDER BY sort_order";
            $stmt = $this->pdo->prepare($sql);
            $stmt->execute($common_method_ids);
            $available_methods = $stmt->fetchAll();
        } else {
            $available_methods = [];
        }

        return [
            'allow_cod' => $allow_cod,
            'methods' => $available_methods
        ];
    }

    /**
     * Get payment method by ID
     */
    public function getMethodById($id) {
        $stmt = $this->pdo->prepare("SELECT * FROM payment_methods WHERE id = ?");
        $stmt->execute([$id]);
        return $stmt->fetch();
    }

    /**
     * Get payment method by slug
     */
    public function getMethodBySlug($slug) {
        $stmt = $this->pdo->prepare("SELECT * FROM payment_methods WHERE slug = ? AND is_active = 1");
        $stmt->execute([$slug]);
        return $stmt->fetch();
    }

    /**
     * Generate unique invoice ID
     */
    private function generateInvoiceId() {
        return 'PAY-' . date('Ymd') . '-' . strtoupper(substr(uniqid(), -6));
    }

    /**
     * Calculate payment charge
     */
    public function calculateCharge($method, $amount) {
        if ($method['charge_type'] === 'percentage') {
            return round(($amount * $method['charge_amount']) / 100, 2);
        }
        return $method['charge_amount'];
    }

    /**
     * Create a new transaction
     */
    public function createTransaction($data) {
        $method = $this->getMethodById($data['payment_method_id']);
        if (!$method) {
            throw new Exception("Invalid payment method");
        }

        $invoiceId = $this->generateInvoiceId();
        $charge = $this->calculateCharge($method, $data['amount']);
        $totalAmount = $data['amount'] + $charge;

        $stmt = $this->pdo->prepare("
            INSERT INTO payment_transactions 
            (order_id, invoice_id, payment_method_id, customer_name, customer_phone, 
             amount, charge, total_amount, transaction_id, sender_number, 
             ip_address, user_agent, status) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'pending')
        ");

        $stmt->execute([
            $data['order_id'] ?? null,
            $invoiceId,
            $data['payment_method_id'],
            $data['customer_name'],
            $data['customer_phone'] ?? null,
            $data['amount'],
            $charge,
            $totalAmount,
            $data['transaction_id'] ?? null,
            $data['sender_number'] ?? null,
            $_SERVER['REMOTE_ADDR'] ?? null,
            $_SERVER['HTTP_USER_AGENT'] ?? null
        ]);

        return [
            'id' => $this->pdo->lastInsertId(),
            'invoice_id' => $invoiceId,
            'amount' => $data['amount'],
            'charge' => $charge,
            'total_amount' => $totalAmount,
            'payment_method' => $method
        ];
    }

    /**
     * Get transaction by invoice ID
     */
    public function getTransactionByInvoice($invoiceId) {
        $stmt = $this->pdo->prepare("
            SELECT t.*, pm.name as method_name, pm.slug as method_slug, pm.logo as method_logo
            FROM payment_transactions t
            JOIN payment_methods pm ON t.payment_method_id = pm.id
            WHERE t.invoice_id = ?
        ");
        $stmt->execute([$invoiceId]);
        return $stmt->fetch();
    }

    /**
     * Get transaction by ID
     */
    public function getTransactionById($id) {
        $stmt = $this->pdo->prepare("
            SELECT t.*, pm.name as method_name, pm.slug as method_slug, pm.logo as method_logo
            FROM payment_transactions t
            JOIN payment_methods pm ON t.payment_method_id = pm.id
            WHERE t.id = ?
        ");
        $stmt->execute([$id]);
        return $stmt->fetch();
    }

    /**
     * Get all transactions with optional filtering
     */
    public function getTransactions($status = null, $limit = 50, $offset = 0) {
        $sql = "
            SELECT t.*, pm.name as method_name, pm.slug as method_slug,
                   o.tracking_id, o.customer_name as order_customer
            FROM payment_transactions t
            JOIN payment_methods pm ON t.payment_method_id = pm.id
            LEFT JOIN orders o ON t.order_id = o.id
        ";
        $params = [];

        if ($status) {
            $sql .= " WHERE t.status = ?";
            $params[] = $status;
        }

        $sql .= " ORDER BY t.created_at DESC LIMIT " . (int)$limit . " OFFSET " . (int)$offset;
        
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute($params);
        
        return $stmt->fetchAll();
    }

    /**
     * Update transaction status
     */
    public function updateTransactionStatus($id, $status, $adminNote = null) {
        $stmt = $this->pdo->prepare("
            UPDATE payment_transactions 
            SET status = ?, admin_note = ?
            WHERE id = ?
        ");
        $stmt->execute([$status, $adminNote, $id]);

        // If approved, update the related order payment status
        if ($status === 'completed') {
            $transaction = $this->getTransactionById($id);
            if ($transaction && $transaction['order_id']) {
                $order_id = $transaction['order_id'];
                
                // 1. Update payment status to Paid
                $this->pdo->prepare("UPDATE orders SET payment_status = 'Paid' WHERE id = ?")
                          ->execute([$order_id]);

                // 2. Check if digital and update order status to Delivered + send email
                try {
                    $stmt_items = $this->pdo->prepare("SELECT oi.*, p.product_type, p.digital_file_url, p.name as product_name 
                                               FROM order_items oi 
                                               JOIN products p ON oi.product_id = p.id 
                                               WHERE oi.order_id = ?");
                    $stmt_items->execute([$order_id]);
                    $order_items = $stmt_items->fetchAll();

                    $has_digital = false;
                    foreach ($order_items as $item) {
                        if ($item['product_type'] === 'digital') {
                            $has_digital = true;
                            break;
                        }
                    }

                    if ($has_digital) {
                        // Update order status to Delivered
                        $this->pdo->prepare("UPDATE orders SET order_status = 'Delivered' WHERE id = ?")
                                  ->execute([$order_id]);

                        // Send email
                        require_once __DIR__ . '/../Helpers/EmailHelper.php';
                        $emailHelper = new \App\Helpers\EmailHelper($this->pdo);
                        
                        // Fetch fresh order details for the email
                        $stmt_order = $this->pdo->prepare("SELECT * FROM orders WHERE id = ?");
                        $stmt_order->execute([$order_id]);
                        $order = $stmt_order->fetch();
                        
                        if ($order) {
                            $emailHelper->sendDigitalDeliveryEmail($order, $order_items);
                        }
                    }
                } catch (Exception $e) { /* Silently fail */ }
            }
        }

        return true;
    }

    /**
     * Get transaction statistics
     */
    public function getStats() {
        $stats = [];
        
        // Total transactions
        $stmt = $this->pdo->query("SELECT COUNT(*) FROM payment_transactions");
        $stats['total'] = $stmt->fetchColumn();

        // Pending transactions
        $stmt = $this->pdo->query("SELECT COUNT(*) FROM payment_transactions WHERE status = 'pending'");
        $stats['pending'] = $stmt->fetchColumn();

        // Completed transactions
        $stmt = $this->pdo->query("SELECT COUNT(*) FROM payment_transactions WHERE status = 'completed'");
        $stats['completed'] = $stmt->fetchColumn();

        // Total amount (completed)
        $stmt = $this->pdo->query("SELECT COALESCE(SUM(total_amount), 0) FROM payment_transactions WHERE status = 'completed'");
        $stats['total_amount'] = $stmt->fetchColumn();

        return $stats;
    }

    /**
     * Update payment method
     */
    public function updatePaymentMethod($id, $data) {
        $fields = [];
        $params = [];

        foreach ($data as $key => $value) {
            $fields[] = "$key = ?";
            $params[] = $value;
        }
        $params[] = $id;

        $stmt = $this->pdo->prepare("UPDATE payment_methods SET " . implode(', ', $fields) . " WHERE id = ?");
        return $stmt->execute($params);
    }

    /**
     * Add new payment method
     */
    public function addPaymentMethod($data) {
        $fields = array_keys($data);
        $placeholders = array_fill(0, count($fields), '?');
        $params = array_values($data);

        $sql = "INSERT INTO payment_methods (" . implode(', ', $fields) . ") VALUES (" . implode(', ', $placeholders) . ")";
        $stmt = $this->pdo->prepare($sql);
        return $stmt->execute($params);
    }

    /**
     * Delete payment method
     */
    public function deletePaymentMethod($id) {
        // First check if there are transactions associated with this method
        $stmt = $this->pdo->prepare("SELECT COUNT(*) FROM payment_transactions WHERE payment_method_id = ?");
        $stmt->execute([$id]);
        if ($stmt->fetchColumn() > 0) {
            // Instead of deleting, we should probably just deactivate it if there are transactions
            // But if the user really wants to delete, we could throw an error or handle it
            throw new Exception("Cannot delete payment method with associated transactions. Please deactivate it instead.");
        }

        $stmt = $this->pdo->prepare("DELETE FROM payment_methods WHERE id = ?");
        return $stmt->execute([$id]);
    }

    /**
     * Toggle payment method active status
     */
    public function togglePaymentMethod($id) {
        $stmt = $this->pdo->prepare("UPDATE payment_methods SET is_active = NOT is_active WHERE id = ?");
        return $stmt->execute([$id]);
    }

    // ===================================================================
    // ZINIPAY AUTOMATED PAYMENT GATEWAY
    // ===================================================================

    /**
     * Get Zinipay API credentials from the database
     */
    public function getZinipayCredentials() {
        $stmt = $this->pdo->prepare("SELECT credentials FROM payment_methods WHERE slug = 'zinipay' AND is_active = 1");
        $stmt->execute();
        $row = $stmt->fetch();
        if (!$row || empty($row['credentials'])) {
            return null;
        }
        return json_decode($row['credentials'], true);
    }

    /**
     * Create a Zinipay payment
     * Calls the Zinipay API to generate a payment URL for the customer
     * 
     * @param float $amount Payment amount
     * @param string $invoiceId Internal invoice/order reference
     * @param array $metadata Additional data (order_id, customer info, etc.)
     * @return array|false Returns payment_url on success, false on failure
     */
    public function createZinipayPayment($amount, $invoiceId, $metadata = []) {
        $creds = $this->getZinipayCredentials();
        if (!$creds || empty($creds['api_key'])) {
            throw new Exception("Zinipay API key not configured. Please set it in Admin > Payment Methods.");
        }

        $apiKey = $creds['api_key'];

        // Build callback URLs - Force HTTPS as the live site uses it
        $siteUrl = 'https://' . $_SERVER['HTTP_HOST'];
        $baseUrl = defined('SITE_URL') ? SITE_URL : $siteUrl;
        
        // Ensure NO trailing slash in baseUrl for consistency
        $baseUrl = rtrim($baseUrl, '/');

        $postData = json_encode([
            'redirect_url' => $baseUrl . '/zinipay-success?invoiceId=' . $invoiceId,
            'cancel_url'   => $baseUrl . '/zinipay-cancel?invoiceId=' . $invoiceId,
            'webhook_url'  => $baseUrl . '/online%20payment/api/zinipay-callback.php',
            'metadata'     => array_merge($metadata, ['invoiceId' => $invoiceId]),
            'amount'       => (string) $amount,
            'cus_name'     => $metadata['customer_name'] ?? 'Customer',
            'cus_email'    => $metadata['customer_email'] ?? 'customer@example.com',
            'cus_phone'    => $metadata['customer_phone'] ?? ''
        ]);

        $ch = curl_init();
        curl_setopt_array($ch, [
            CURLOPT_URL            => 'https://api.zinipay.com/v1/payment/create',
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING       => '',
            CURLOPT_MAXREDIRS      => 10,
            CURLOPT_TIMEOUT        => 30,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION   => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST  => 'POST',
            CURLOPT_POSTFIELDS     => $postData,
            CURLOPT_HTTPHEADER     => [
                'zini-api-key: ' . $apiKey,
                'Content-Type: application/json'
            ],
        ]);

        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $curlError = curl_error($ch);
        curl_close($ch);

        if ($curlError) {
            throw new Exception("Zinipay API connection error: " . $curlError);
        }

        $result = json_decode($response, true);

        if (!$result) {
            throw new Exception("Invalid response from Zinipay API: " . $response);
        }

        if (isset($result['status']) && $result['status'] === true && !empty($result['payment_url'])) {
            return [
                'success'     => true,
                'payment_url' => $result['payment_url'],
                'message'     => $result['message'] ?? 'Payment URL generated'
            ];
        }

        $errorMsg = is_array($result['message'] ?? null) ? json_encode($result['message']) : ($result['message'] ?? 'Unknown error');
        throw new Exception("Zinipay error: " . $errorMsg);
    }

    /**
     * Verify a Zinipay payment
     * Calls the Zinipay verify API to confirm payment status
     * 
     * @param string $zinipayInvoiceId The Zinipay invoice/transaction ID
     * @return array Payment verification data
     */
    public function verifyZinipayPayment($zinipayInvoiceId) {
        $creds = $this->getZinipayCredentials();
        if (!$creds || empty($creds['api_key'])) {
            throw new Exception("Zinipay API key not configured.");
        }

        $apiKey = $creds['api_key'];

        $postData = json_encode([
            'invoiceId' => $zinipayInvoiceId,
            'apiKey'    => $apiKey
        ]);

        $ch = curl_init();
        curl_setopt_array($ch, [
            CURLOPT_URL            => 'https://api.zinipay.com/v1/payment/verify',
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_POST           => true,
            CURLOPT_POSTFIELDS     => $postData,
            CURLOPT_HTTPHEADER     => [
                'Content-Type: application/json',
                'zini-api-key: ' . $apiKey
            ],
            CURLOPT_TIMEOUT        => 30,
        ]);

        $response = curl_exec($ch);
        $curlError = curl_error($ch);
        curl_close($ch);

        if ($curlError) {
            throw new Exception("Zinipay verify API error: " . $curlError);
        }

        $result = json_decode($response, true);

        if (!$result) {
            throw new Exception("Invalid response from Zinipay verify API");
        }

        return $result;
    }
}
