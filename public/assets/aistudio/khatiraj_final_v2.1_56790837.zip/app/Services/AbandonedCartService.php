<?php

class AbandonedCartService {
    private $pdo;
    private $settings = [];

    public function __construct(PDO $pdo) {
        $this->pdo = $pdo;
        $this->loadSettings();
    }

    private function loadSettings(): void {
        global $site_settings;
        $keys = [
            'abandoned_cart_enabled',
            'abandoned_cart_delay_minutes',
            'abandoned_cart_max_reminders',
            'abandoned_cart_sms_text',
            'abandoned_cart_whatsapp_text',
            'abandoned_cart_whatsapp_enabled',
            'site_name',
        ];
        $this->settings = [];
        foreach ($keys as $key) {
            if (isset($site_settings[$key])) {
                $this->settings[$key] = $site_settings[$key];
            }
        }
        if (!empty($this->settings)) {
            return;
        }
        $placeholders = implode(',', array_fill(0, count($keys), '?'));
        $stmt = $this->pdo->prepare("SELECT key_name, value FROM settings WHERE key_name IN ($placeholders)");
        $stmt->execute($keys);
        $this->settings = $stmt->fetchAll(PDO::FETCH_KEY_PAIR);
    }

    public function isEnabled(): bool {
        return ($this->settings['abandoned_cart_enabled'] ?? '0') === '1';
    }

    public function getSessionId(): string {
        if (empty($_SESSION['cart_session_id'])) {
            $_SESSION['cart_session_id'] = bin2hex(random_bytes(16));
        }
        return $_SESSION['cart_session_id'];
    }

    public function ensureTable(): void {
        $this->pdo->exec("
            CREATE TABLE IF NOT EXISTS abandoned_carts (
                id INT AUTO_INCREMENT PRIMARY KEY,
                session_id VARCHAR(64) NOT NULL,
                user_id INT NULL,
                customer_name VARCHAR(100) NULL,
                customer_phone VARCHAR(20) NULL,
                customer_email VARCHAR(100) NULL,
                customer_area VARCHAR(150) NULL,
                customer_address TEXT NULL,
                cart_data JSON NOT NULL,
                cart_total DECIMAL(10,2) DEFAULT 0,
                recovery_token VARCHAR(64) NOT NULL,
                status ENUM('active','recovered','expired') DEFAULT 'active',
                sms_sent_count TINYINT UNSIGNED DEFAULT 0,
                whatsapp_sent_count TINYINT UNSIGNED DEFAULT 0,
                last_reminder_at DATETIME NULL,
                recovered_at DATETIME NULL,
                order_id INT NULL,
                ip_address VARCHAR(45) NULL,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                UNIQUE KEY uk_recovery_token (recovery_token),
                KEY idx_status_phone (status, customer_phone),
                KEY idx_session (session_id),
                KEY idx_updated (updated_at)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
        ");

        try {
            $cols = $this->pdo->query("SHOW COLUMNS FROM abandoned_carts")->fetchAll(PDO::FETCH_COLUMN);
            if (!in_array('customer_email', $cols)) {
                $this->pdo->exec("ALTER TABLE abandoned_carts ADD COLUMN customer_email VARCHAR(100) NULL AFTER customer_phone");
            }
            if (!in_array('customer_area', $cols)) {
                $this->pdo->exec("ALTER TABLE abandoned_carts ADD COLUMN customer_area VARCHAR(150) NULL AFTER customer_email");
            }
            if (!in_array('customer_address', $cols)) {
                $this->pdo->exec("ALTER TABLE abandoned_carts ADD COLUMN customer_address TEXT NULL AFTER customer_area");
            }
        } catch (PDOException $e) {
            // Non-blocking fallback
        }
    }

    public function syncSessionCart(
        ?string $customerName = null,
        ?string $customerPhone = null,
        ?string $customerEmail = null,
        ?string $customerArea = null,
        ?string $customerAddress = null
    ): ?int {
        $cart = $_SESSION['cart'] ?? [];
        if (empty($cart)) {
            return null;
        }

        $sessionId = $this->getSessionId();
        $userId = $_SESSION['user_id'] ?? null;
        $total = 0;
        foreach ($cart as $item) {
            $total += ($item['price'] ?? 0) * ($item['qty'] ?? 1);
        }

        $phone = $this->normalizePhone($customerPhone);
        if (!$phone && !empty($_SESSION['user_id'])) {
            $stmt = $this->pdo->prepare('SELECT phone FROM users WHERE id = ?');
            $stmt->execute([$_SESSION['user_id']]);
            $phone = $this->normalizePhone($stmt->fetchColumn() ?: '');
        }

        $name = $customerName ?: ($_SESSION['user_name'] ?? null);
        $email = $customerEmail ?: ($_SESSION['user_email'] ?? null);
        $area = $customerArea ?? null;
        $address = $customerAddress ?? null;
        $ip = $_SERVER['REMOTE_ADDR'] ?? null;

        $stmt = $this->pdo->prepare("
            SELECT id, recovery_token FROM abandoned_carts
            WHERE session_id = ? AND status = 'active'
            ORDER BY updated_at DESC LIMIT 1
        ");
        $stmt->execute([$sessionId]);
        $existing = $stmt->fetch();

        $cartJson = json_encode(array_values($cart), JSON_UNESCAPED_UNICODE);

        if ($existing) {
            $stmt = $this->pdo->prepare("
                UPDATE abandoned_carts SET
                    user_id = COALESCE(?, user_id),
                    customer_name = COALESCE(?, customer_name),
                    customer_phone = COALESCE(?, customer_phone),
                    customer_email = COALESCE(?, customer_email),
                    customer_area = COALESCE(?, customer_area),
                    customer_address = COALESCE(?, customer_address),
                    cart_data = ?,
                    cart_total = ?,
                    ip_address = COALESCE(?, ip_address),
                    updated_at = NOW()
                WHERE id = ?
            ");
            $stmt->execute([$userId, $name, $phone, $email, $area, $address, $cartJson, $total, $ip, $existing['id']]);
            return (int) $existing['id'];
        }

        $token = bin2hex(random_bytes(16));
        $stmt = $this->pdo->prepare("
            INSERT INTO abandoned_carts
                (session_id, user_id, customer_name, customer_phone, customer_email, customer_area, customer_address, cart_data, cart_total, recovery_token, ip_address)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ");
        $stmt->execute([$sessionId, $userId, $name, $phone, $email, $area, $address, $cartJson, $total, $token, $ip]);
        return (int) $this->pdo->lastInsertId();
    }

    public function updateContact(
        string $name,
        string $phone,
        string $email = '',
        string $area = '',
        string $address = ''
    ): ?int {
        $phone = $this->normalizePhone($phone);
        if (!$phone || strlen($phone) !== 11) {
            return null;
        }
        return $this->syncSessionCart(
            trim($name) ?: null,
            $phone,
            trim($email) ?: null,
            trim($area) ?: null,
            trim($address) ?: null
        );
    }

    public function markRecovered(?string $phone = null, ?int $orderId = null): void {
        $sessionId = $_SESSION['cart_session_id'] ?? null;

        if ($sessionId) {
            $stmt = $this->pdo->prepare("
                UPDATE abandoned_carts SET status = 'recovered', recovered_at = NOW(), order_id = ?
                WHERE session_id = ? AND status = 'active'
            ");
            $stmt->execute([$orderId, $sessionId]);
        }

        $normalizedPhone = $this->normalizePhone($phone ?? '');
        if ($normalizedPhone) {
            $stmt = $this->pdo->prepare("
                UPDATE abandoned_carts SET status = 'recovered', recovered_at = NOW(), order_id = COALESCE(?, order_id)
                WHERE customer_phone = ? AND status = 'active'
            ");
            $stmt->execute([$orderId, $normalizedPhone]);
        }
    }

    public function recoverByToken(string $token): array {
        $stmt = $this->pdo->prepare("SELECT * FROM abandoned_carts WHERE recovery_token = ? AND status = 'active' LIMIT 1");
        $stmt->execute([$token]);
        $row = $stmt->fetch();

        if (!$row) {
            return ['success' => false, 'message' => 'কার্ট পাওয়া যায়নি বা ইতিমধ্যে অর্ডার হয়েছে।'];
        }

        $cart = json_decode($row['cart_data'], true);
        if (!is_array($cart) || empty($cart)) {
            return ['success' => false, 'message' => 'কার্ট খালি।'];
        }

        $_SESSION['cart'] = [];
        foreach ($cart as $item) {
            $cartKey = $item['cart_key'] ?? null;
            if (!$cartKey) {
                $productId = (int) ($item['id'] ?? 0);
                $variantId = !empty($item['variant_id']) ? (int) $item['variant_id'] : null;
                if ($productId <= 0) {
                    continue;
                }
                require_once __DIR__ . '/../Helpers/ProductVariantHelper.php';
                $cartKey = ProductVariantHelper::buildCartKey($productId, $variantId);
                $item['cart_key'] = $cartKey;
            }
            $_SESSION['cart'][$cartKey] = $item;
        }
        $_SESSION['cart_session_id'] = $row['session_id'];

        return ['success' => true, 'message' => 'আপনার কার্ট পুনরুদ্ধার করা হয়েছে!', 'total' => $row['cart_total']];
    }

    public function processReminders(): array {
        // Automated reminders are disabled as requested. Carts are recovered manually via WhatsApp links.
        return [
            'processed' => 0,
            'sms_sent' => 0,
            'whatsapp_sent' => 0,
            'message' => 'Automated reminders are disabled. Use the admin panel to manually send WhatsApp reminders.'
        ];
    }

    public function expireOldCarts(): void {
        $this->pdo->exec("
            UPDATE abandoned_carts SET status = 'expired'
            WHERE status = 'active'
              AND updated_at < DATE_SUB(NOW(), INTERVAL 7 DAY)
        ");
    }

    private function buildMessageData(array $cart): array {
        $items = json_decode($cart['cart_data'], true) ?: [];
        $productNames = array_map(function ($item) {
            $qty = (int) ($item['qty'] ?? 1);
            return ($item['name'] ?? 'Product') . ' x' . $qty;
        }, $items);

        $products = implode(', ', array_slice($productNames, 0, 3));
        if (count($productNames) > 3) {
            $products .= ' +' . (count($productNames) - 3) . ' more';
        }

        // SITE_URL already includes BASE_URL — do not append it again
        $recoveryLink = SITE_URL . '/cart/recover/' . $cart['recovery_token'];
        $siteName = $this->settings['site_name'] ?? 'Khati Raj';

        return [
            'name' => $cart['customer_name'] ?: 'Customer',
            'phone' => $cart['customer_phone'],
            'email' => $cart['customer_email'] ?: '',
            'area' => $cart['customer_area'] ?: '',
            'address' => $cart['customer_address'] ?: '',
            'total' => number_format((float) $cart['cart_total'], 0),
            'products' => $products,
            'recovery_link' => $recoveryLink,
            'site_name' => $siteName,
        ];
    }

    private function renderTemplate(string $template, array $data): string {
        if (empty($template)) {
            $template = "হ্যালো {name}! {site_name}-এ আপনার কার্টে {total} টাকার পণ্য ({products}) রয়েছে। অর্ডার সম্পূর্ণ করুন: {recovery_link}";
        }

        return str_replace(
            ['{name}', '{total}', '{products}', '{recovery_link}', '{site_name}', '{phone}', '{email}', '{area}', '{address}'],
            [$data['name'], $data['total'], $data['products'], $data['recovery_link'], $data['site_name'], $data['phone'], $data['email'], $data['area'], $data['address']],
            $template
        );
    }

    private function normalizePhone(?string $phone): ?string {
        if (!$phone) {
            return null;
        }
        $phone = preg_replace('/[^0-9]/', '', $phone);
        if (strlen($phone) > 11) {
            $phone = substr($phone, -11);
        }
        if (strlen($phone) === 11 && str_starts_with($phone, '01')) {
            return $phone;
        }
        return null;
    }

    public function getWhatsAppPreviewMessage(array $cart): string {
        return $this->renderTemplate(
            $this->settings['abandoned_cart_whatsapp_text'] ?? '',
            $this->buildMessageData($cart)
        );
    }
}
