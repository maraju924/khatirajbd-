<?php
// app/Controllers/CartController.php
require_once __DIR__ . '/../Helpers/ProductVariantHelper.php';
require_once __DIR__ . '/../Helpers/CartShippingHelper.php';
require_once __DIR__ . '/../Helpers/PriceHelper.php';

class CartController {
    public function index() {
        global $pdo;
        $page_title = "Your Shopping Cart";
        PageHelper::load('cart', ['title' => $page_title]);
        $cart_items = $_SESSION['cart'] ?? [];
        
        $common_zone_ids = CartShippingHelper::getCommonZoneIds($pdo, $cart_items);
        $shipping_zones = CartShippingHelper::getShippingZones($pdo, $common_zone_ids);
        $extra_shipping = CartShippingHelper::getExtraShippingTotal($pdo, $cart_items);

        include 'views/layouts/header.php';
        include 'views/pages/cart.php';
        include 'views/layouts/footer.php';
    }

    public function handleRequest($path) {
        if (strpos($path, '/cart/add/') === 0) {
            $id = str_replace('/cart/add/', '', $path);
            $this->add($id);
        } elseif (strpos($path, '/cart/remove/') === 0) {
            $id = str_replace('/cart/remove/', '', $path);
            $this->remove($id);
        } elseif (strpos($path, '/cart/update/') === 0) {
            $id = str_replace('/cart/update/', '', $path);
            $this->update($id);
        } elseif ($path === '/cart/clear') {
            $this->clear();
        } else {
            $this->index();
        }
    }

    public function remove($cartKey) {
        $cartKey = preg_replace('/[^0-9_]/', '', $cartKey);
        if (isset($_SESSION['cart'][$cartKey])) {
            unset($_SESSION['cart'][$cartKey]);
        }
        if (!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest') {
            $count = 0;
            $total = 0;
            foreach($_SESSION['cart'] as $item) {
                $count += $item['qty'];
                $total += $item['price'] * $item['qty'];
            }
            echo json_encode(['status' => 'success', 'message' => 'Item removed', 'cart_count' => $count, 'total' => $total]);
            exit;
        }
        header('Location: ' . BASE_URL . '/cart?success=Item removed from cart');
        exit;
    }

    public function update($cartKey) {
        $cartKey = preg_replace('/[^0-9_]/', '', $cartKey);
        $action = $_GET['action'] ?? '';
        if (isset($_SESSION['cart'][$cartKey])) {
            if ($action === 'inc') {
                $_SESSION['cart'][$cartKey]['qty'] += 1;
            } elseif ($action === 'dec' && $_SESSION['cart'][$cartKey]['qty'] > 1) {
                $_SESSION['cart'][$cartKey]['qty'] -= 1;
            }
        }
        try {
            global $pdo;
            require_once __DIR__ . '/../Services/AbandonedCartService.php';
            (new AbandonedCartService($pdo))->syncSessionCart();
        } catch (Exception $e) {
            // Non-blocking
        }
        if (!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest') {
            $count = 0;
            $total = 0;
            $subtotal = 0;
            if(isset($_SESSION['cart'][$cartKey])) {
                $subtotal = $_SESSION['cart'][$cartKey]['price'] * $_SESSION['cart'][$cartKey]['qty'];
            }
            foreach($_SESSION['cart'] as $item) {
                $count += $item['qty'];
                $total += $item['price'] * $item['qty'];
            }
            echo json_encode([
                'status' => 'success', 
                'cart_count' => $count, 
                'total' => $total, 
                'item_subtotal' => $subtotal,
                'item_qty' => $_SESSION['cart'][$cartKey]['qty'] ?? 0
            ]);
            exit;
        }
        header('Location: ' . BASE_URL . '/cart');
        exit;
    }

    public function add($id) {
        global $pdo;

        $productId = (int) preg_replace('/_.*$/', '', (string) $id);
        $variantId = isset($_REQUEST['variant_id']) ? (int) $_REQUEST['variant_id'] : null;

        if (!$variantId && strpos((string) $id, '_') !== false) {
            [, $variantPart] = explode('_', (string) $id, 2);
            $variantId = (int) $variantPart;
        }

        $stmt = $pdo->prepare("SELECT id, name, price, offer_price, image FROM products WHERE id = ?");
        $stmt->execute([$productId]);
        $product = $stmt->fetch();

        if ($product) {
            $price = PriceHelper::effectivePrice($product['price'], $product['offer_price'] ?? null);
            $displayName = $product['name'];
            $variantLabel = null;

            if ($variantId) {
                $variant = ProductVariantHelper::getVariantById($pdo, $variantId);
                if (!$variant || (int) $variant['product_id'] !== $productId) {
                    header('Location: ' . BASE_URL . '/home?error=Invalid product variant');
                    exit;
                }

                $variantBase = ($variant['price'] !== null && $variant['price'] !== '')
                    ? (float) $variant['price']
                    : (float) $product['price'];
                $price = PriceHelper::effectivePrice($variantBase, $variant['offer_price'] ?? null);

                $variantLabel = $variant['label'];
            }

            if (!isset($_SESSION['cart'])) {
                $_SESSION['cart'] = [];
            }

            $qty = isset($_REQUEST['qty']) ? max(1, intval($_REQUEST['qty'])) : 1;
            $cartKey = ProductVariantHelper::buildCartKey($productId, $variantId ?: null);

            if (isset($_SESSION['cart'][$cartKey])) {
                $_SESSION['cart'][$cartKey]['qty'] += $qty;
            } else {
                $_SESSION['cart'][$cartKey] = [
                    'cart_key' => $cartKey,
                    'id' => $product['id'],
                    'variant_id' => $variantId,
                    'variant_label' => $variantLabel,
                    'name' => $displayName,
                    'price' => $price,
                    'image' => $product['image'],
                    'qty' => $qty
                ];
            }

            try {
                require_once __DIR__ . '/../Services/AbandonedCartService.php';
                (new AbandonedCartService($pdo))->syncSessionCart();
            } catch (Exception $e) {
                // Non-blocking
            }

            $is_ajax = !empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest';

            // AJAX adds fire AddToCart from the browser (pixel + CAPI relay).
            // Direct adds (e.g. "Order Now" full-page redirect) have no JS hook,
            // so fire the server-side event here instead.
            if (!$is_ajax) {
                try {
                    require_once __DIR__ . '/../Services/TrackingService.php';
                    $trackingService = new TrackingService();
                    $trackingService->fireEvent('AddToCart', TrackingService::buildUserData(), [
                        'content_ids' => [(string)$productId],
                        'content_type' => 'product',
                        'value' => (float)$price * $qty,
                        'currency' => 'BDT',
                        'quantity' => $qty,
                    ], TrackingService::generateEventId('ac', (string)$productId));
                } catch (Throwable $e) {
                    // Tracking must never break the cart flow
                }
            }

            if ($is_ajax) {
                $count = 0;
                foreach($_SESSION['cart'] as $item) $count += $item['qty'];
                echo json_encode(['status' => 'success', 'message' => 'Item added', 'cart_count' => $count, 'item_price' => $price]);
                exit;
            }

            $redirect = $_GET['redirect'] ?? '';
            if ($redirect === 'checkout') {
                header('Location: ' . BASE_URL . '/checkout');
                exit;
            }

            $referer = $_SERVER['HTTP_REFERER'] ?? (BASE_URL . '/home');
            header('Location: ' . $referer);
            exit;
        } else {
            header('Location: ' . BASE_URL . '/home?error=Product not found');
            exit;
        }
    }

    public function clear() {
        $_SESSION['cart'] = [];
        if (!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest') {
            echo json_encode(['status' => 'success', 'message' => 'Cart cleared']);
            exit;
        }
        header('Location: ' . BASE_URL . '/cart');
        exit;
    }
}

$controller = new CartController();
require_once __DIR__ . '/../Helpers/RouteHelper.php';
$path = RouteHelper::getPath();
$controller->handleRequest($path);
