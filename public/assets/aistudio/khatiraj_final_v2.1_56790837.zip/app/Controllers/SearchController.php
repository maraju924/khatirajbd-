<?php
// app/Controllers/SearchController.php

class SearchController {
    public function index() {
        global $pdo;

        header('Content-Type: application/json');

        $query = isset($_GET['q']) ? trim($_GET['q']) : '';

        if (empty($query)) {
            echo json_encode([]);
            exit();
        }

        try {
            $results = [];

            // Search Products
            $stmt = $pdo->prepare("SELECT id, name, price, offer_price, slug, image FROM products WHERE (name LIKE ? OR slug LIKE ?) AND status = 1 AND show_on_website = 1 LIMIT 10");
            $stmt->execute(["%$query%", "%$query%"]);
            $products = $stmt->fetchAll();

            foreach ($products as $p) {
                $price_html = $p['offer_price'] ? '৳' . number_format($p['offer_price']) : '৳' . number_format($p['price']);
                $results[] = [
                    'id' => $p['id'],
                    'title' => $p['name'],
                    'subtitle' => $price_html,
                    'link' => BASE_URL . '/product/' . $p['slug'],
                    'image' => $p['image'] ? $p['image'] : 'https://placehold.co/50x50?text=No+Image',
                    'type' => 'Product'
                ];
            }

            echo json_encode($results);

        } catch (PDOException $e) {
            echo json_encode(['status' => 'error', 'message' => $e->getMessage()]);
        }
    }
}

// Instantiate and run
if (!isset($pdo)) {
    require_once 'config/database.php';
}

$controller = new SearchController();
$controller->index();
