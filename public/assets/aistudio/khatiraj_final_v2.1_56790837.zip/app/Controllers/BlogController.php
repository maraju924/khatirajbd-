<?php
// app/Controllers/BlogController.php

class BlogController {
    
    public function index() {
        global $pdo;
        
        // Pagination
        $per_page = 9;
        $current_page = max(1, intval($_GET['p'] ?? 1));
        $offset = ($current_page - 1) * $per_page;
        
        // Total count
        $total = $pdo->query("SELECT COUNT(*) FROM blog_posts WHERE status = 1")->fetchColumn();
        $total_pages = ceil($total / $per_page);
        
        // Fetch posts
        $stmt = $pdo->prepare("SELECT * FROM blog_posts WHERE status = 1 ORDER BY created_at DESC LIMIT ? OFFSET ?");
        $stmt->bindValue(1, $per_page, PDO::PARAM_INT);
        $stmt->bindValue(2, $offset, PDO::PARAM_INT);
        $stmt->execute();
        $posts = $stmt->fetchAll();
        
        $page_title = "Blog - Khati Raj Bangladesh";
        $meta_description = "Read our latest articles on authentic products, health tips, and e-commerce insights from Khati Raj Bangladesh.";
        PageHelper::load('blog_index', [
            'title' => $page_title,
            'description' => $meta_description,
        ]);
        
        include 'views/layouts/header.php';
        include 'views/pages/blog.php';
        include 'views/layouts/footer.php';
    }
    
    public function show($slug) {
        global $pdo;
        
        $stmt = $pdo->prepare("SELECT * FROM blog_posts WHERE slug = ? AND status = 1");
        $stmt->execute([$slug]);
        $post = $stmt->fetch();
        
        if (!$post) {
            http_response_code(404);
            include 'views/404.php';
            return;
        }
        
        // Increment views
        $pdo->prepare("UPDATE blog_posts SET views = views + 1 WHERE id = ?")->execute([$post['id']]);
        
        // Related posts (latest 3 excluding current)
        $stmt_rel = $pdo->prepare("SELECT * FROM blog_posts WHERE id != ? AND status = 1 ORDER BY created_at DESC LIMIT 3");
        $stmt_rel->execute([$post['id']]);
        $related_posts = $stmt_rel->fetchAll();
        
        $page_title = $post['title'] . " - Khati Raj Blog";
        $meta_title = $post['meta_title'] ?: $page_title;
        $meta_description = $post['meta_description'] ?: mb_substr(strip_tags($post['excerpt'] ?: $post['content']), 0, 160);
        $meta_keywords = $post['meta_keywords'] ?? null;
        SeoHelper::setDefaults([
            'title' => $meta_title,
            'description' => (string)($meta_description ?? ''),
            'keywords' => (string)($meta_keywords ?? ''),
        ]);
        
        include 'views/layouts/header.php';
        include 'views/pages/blog-single.php';
        include 'views/layouts/footer.php';
    }
}
