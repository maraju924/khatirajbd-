<?php
// app/Controllers/ProductController.php

class ProductController {
    public function index() {
        global $pdo;
        $category_slug = $_GET['slug'] ?? null;
        $page_title = "Shop - All Products";
        
        if ($category_slug) {
            // Fetch Category Details
            $stmt_cat = $pdo->prepare("SELECT name FROM categories WHERE slug = ?");
            $stmt_cat->execute([$category_slug]);
            $category = $stmt_cat->fetch();
            
            if ($category) {
                $page_title = $category['name'];
                $stmt = $pdo->prepare("SELECT p.* FROM products p JOIN categories c ON p.category_id = c.id WHERE c.slug = ? AND p.status = 1 AND p.show_on_website = 1 ORDER BY p.id DESC");
                $stmt->execute([$category_slug]);
            } else {
                $stmt = $pdo->query("SELECT * FROM products WHERE status = 1 AND show_on_website = 1 ORDER BY id DESC");
            }
        } else {
            $stmt = $pdo->query("SELECT * FROM products WHERE status = 1 AND show_on_website = 1 ORDER BY id DESC");
        }

        $products = $stmt->fetchAll();

        if ($category_slug && !empty($category)) {
            // Category detail: prefer per-category SEO fields when available
            $catSeo = $pdo->prepare("SELECT * FROM categories WHERE slug = ?");
            $catSeo->execute([$category_slug]);
            $catRow = $catSeo->fetch() ?: [];
            PageHelper::load('category_detail', [
                'title' => (!empty($catRow['meta_title']) ? $catRow['meta_title'] : $page_title),
                'description' => $catRow['meta_description'] ?? '',
                'keywords' => $catRow['meta_keywords'] ?? '',
            ]);
            if (!empty($catRow['h1_title'])) {
                $category['h1_title'] = $catRow['h1_title'];
            }
            $category['description'] = $catRow['description'] ?? '';
        } else {
            PageHelper::load('shop', ['title' => $page_title]);
        }

        include 'views/layouts/header.php';
        include 'views/pages/shop.php';
        include 'views/layouts/footer.php';
    }

    public function details($slug) {
        global $pdo;
        
        $stmt = $pdo->prepare("SELECT * FROM products WHERE slug = ? AND status = 1");
        $stmt->execute([$slug]);
        $product = $stmt->fetch();

        if (!$product) {
            header("HTTP/1.0 404 Not Found");
            include 'views/404.php';
            return;
        }

        // Fetch Related Products (only website-visible ones)
        $stmt_rel = $pdo->prepare("SELECT * FROM products WHERE category_id = ? AND id != ? AND status = 1 AND show_on_website = 1 LIMIT 4");
        $stmt_rel->execute([$product['category_id'], $product['id']]);
        $related_products = $stmt_rel->fetchAll();

        // Fetch Approved Reviews
        $stmt_rev = $pdo->prepare("SELECT * FROM reviews WHERE product_id = ? AND status = 1 ORDER BY created_at DESC");
        $stmt_rev->execute([$product['id']]);
        $reviews = $stmt_rev->fetchAll();

        // Fetch Product Gallery Images
        $stmt_gal = $pdo->prepare("SELECT image_path FROM product_images WHERE product_id = ? ORDER BY sort_order ASC");
        $stmt_gal->execute([$product['id']]);
        $gallery_images = $stmt_gal->fetchAll(PDO::FETCH_COLUMN);

        // Fetch Product Dynamic Sections and Items
        $product_sections = [];
        try {
            $stmt_sec = $pdo->prepare("SELECT * FROM product_sections WHERE product_id = ? ORDER BY sort_order ASC, id ASC");
            $stmt_sec->execute([$product['id']]);
            $db_sections = $stmt_sec->fetchAll();

            $sectionIds = array_map(static fn($sec) => (int) $sec['id'], $db_sections);
            $itemsBySection = [];
            if (!empty($sectionIds)) {
                $placeholders = implode(',', array_fill(0, count($sectionIds), '?'));
                $stmt_items = $pdo->prepare("SELECT * FROM product_section_items WHERE section_id IN ($placeholders) ORDER BY sort_order ASC, id ASC");
                $stmt_items->execute($sectionIds);
                foreach ($stmt_items->fetchAll(PDO::FETCH_ASSOC) as $item) {
                    $itemsBySection[(int) $item['section_id']][] = $item;
                }
            }

            foreach ($db_sections as $sec) {
                $items = $itemsBySection[(int) $sec['id']] ?? [];
                $product_sections[] = [
                    'title' => $sec['title'],
                    'icon' => $sec['icon'],
                    'items' => $items
                ];
            }
        } catch (PDOException $e) {
            // Sections table may not exist until migrate.php is run on live.
        }

        // Handle Review Submission
        if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['submit_review'])) {
            $rating = intval($_POST['rating']);
            $comment = trim($_POST['comment']);
            $user_name = trim($_POST['user_name']);
            $user_email = trim($_POST['user_email']);
            $user_id = $_SESSION['user_id'] ?? null;

            if ($rating >= 1 && $rating <= 5 && !empty($user_name) && !empty($user_email)) {
                $stmt_ins = $pdo->prepare("INSERT INTO reviews (product_id, user_id, user_name, user_email, rating, comment) VALUES (?, ?, ?, ?, ?, ?)");
                $stmt_ins->execute([$product['id'], $user_id, $user_name, $user_email, $rating, $comment]);



                header('Location: ' . $_SERVER['HTTP_REFERER'] . '?review_success=1');
                exit;
            }
        }

        // Fetch dynamic shipping data for quick order - filtered by product zones
        $stmt_sz = $pdo->prepare("
            SELECT sz.* 
            FROM shipping_zones sz 
            INNER JOIN product_shipping_zones psz ON sz.id = psz.shipping_zone_id 
            WHERE psz.product_id = ? AND sz.status = 1
        ");
        $stmt_sz->execute([$product['id']]);
        $shipping_zones = $stmt_sz->fetchAll();
        
        // Fallback: If no specific zones assigned to this product, show all active zones
        if (empty($shipping_zones)) {
            $shipping_zones = $pdo->query("SELECT * FROM shipping_zones WHERE status = 1")->fetchAll();
        }
        
        // Fetch shipping class for current product
        $stmt_s = $pdo->prepare("
            SELECT sc.extra_charge 
            FROM products p 
            LEFT JOIN shipping_classes sc ON p.shipping_class_id = sc.id 
            WHERE p.id = ? AND (sc.status = 1 OR p.shipping_class_id IS NULL)
        ");
        $stmt_s->execute([$product['id']]);
        $extra_shipping = $stmt_s->fetchColumn() ?: 0;
        
        // Fetch restricted payment methods for the product (Quick Order)
        require_once 'app/Services/PaymentGateway.php';
        $pg = new PaymentGateway($pdo);
        $payment_restrict = $pg->getAvailableMethodsForCart([$product['id']]);
        
        $available_online_methods = $payment_restrict['methods'];
        $allow_cod = $payment_restrict['allow_cod'];

        require_once __DIR__ . '/../Helpers/ProductVariantHelper.php';
        $product_variant_data = ['enabled' => false, 'attributes' => [], 'variants' => []];
        try {
            $product_variant_data = ProductVariantHelper::loadForProduct($pdo, (int) $product['id']);
        } catch (Throwable $e) {
            // Variant tables may be missing on live until migration runs.
        }

        $page_title = $product['name'] . " - Khati Raj";
        $meta_title = $product['meta_title'] ?: $page_title;
        $meta_description = $product['meta_description'] ?: NULL;
        $meta_keywords = $product['meta_keywords'] ?? NULL;

        // Product SEO is owned by the product record itself; register as defaults.
        SeoHelper::setDefaults([
            'title' => $meta_title,
            'description' => (string)($meta_description ?? ''),
            'keywords' => (string)($meta_keywords ?? ''),
        ]);

        include 'views/layouts/header.php';
        include 'views/pages/product-details.php';
        include 'views/layouts/footer.php';
    }
}

$controller = new ProductController();
require_once __DIR__ . '/../Helpers/RouteHelper.php';
$path = RouteHelper::getPath();

if (strpos($path, '/product/') === 0) {
    $slug = rawurldecode(trim(substr($path, strlen('/product/')), '/'));
    $controller->details($slug);
} elseif (strpos($path, '/category/') === 0) {
    $slug = rawurldecode(trim(substr($path, strlen('/category/')), '/'));
    $_GET['slug'] = $slug;
    $controller->index();
} else {
    $controller->index();
}
