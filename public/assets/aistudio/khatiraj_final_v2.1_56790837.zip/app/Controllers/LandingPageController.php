<?php
/**
 * Landing Page Controller
 * Handles landing page display and order processing
 */

require_once 'config/database.php';
require_once 'app/Helpers/LanguageHelper.php';
require_once 'app/Helpers/OrderAccessHelper.php';
require_once 'app/Helpers/PriceHelper.php';
require_once 'app/Helpers/PhoneHelper.php';

class LandingPageController {
    private $pdo;
    
    public function __construct($pdo) {
        $this->pdo = $pdo;
    }
    
    /**
     * Display landing page
     */
    public function show($slug) {
        // Get landing page data
        $stmt = $this->pdo->prepare("
            SELECT lp.*, p.id as product_id, p.name as product_name, p.price, p.offer_price, 
                   p.image as product_image, p.description, p.benefits as product_benefits, 
                   p.trust_points as product_trust_points, p.video_url as product_video,
                   p.stock_status, p.product_type, c.name as category_name
            FROM landing_pages lp
            JOIN products p ON lp.product_id = p.id
            LEFT JOIN categories c ON p.category_id = c.id
            WHERE lp.slug = ? AND lp.status = 1
        ");
        $stmt->execute([$slug]);
        $landing_page = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$landing_page) {
            http_response_code(404);
            require_once 'views/404.php';
            return;
        }

        // Fetch all products associated with this landing page
        $lp_products = [];
        $selected_ids = [];
        if (!empty($landing_page['product_ids'])) {
            $selected_ids = array_filter(array_map('intval', explode(',', $landing_page['product_ids'])));
        }
        
        // Always ensure primary product_id is included
        if (!in_array($landing_page['product_id'], $selected_ids)) {
            $selected_ids[] = (int)$landing_page['product_id'];
        }
        
        if (!empty($selected_ids)) {
            $in_clause = implode(',', $selected_ids);
            $lp_products_stmt = $this->pdo->query("
                SELECT p.id, p.name, p.price, p.offer_price, p.image, p.stock_status, p.product_type 
                FROM products p 
                WHERE p.id IN ($in_clause) AND p.status = 1
                ORDER BY FIELD(p.id, $in_clause)
            ");
            $lp_products = $lp_products_stmt->fetchAll(PDO::FETCH_ASSOC);
        } else {
            $lp_products = [[
                'id' => $landing_page['product_id'],
                'name' => $landing_page['product_name'],
                'price' => $landing_page['price'],
                'offer_price' => $landing_page['offer_price'],
                'image' => $landing_page['product_image'],
                'stock_status' => $landing_page['stock_status'],
                'product_type' => $landing_page['product_type']
            ]];
        }
        
        // Get shipping zones and apply landing page overrides if configured
        $zones_stmt = $this->pdo->query("SELECT * FROM shipping_zones WHERE status = 1 ORDER BY charge ASC");
        $all_shipping_zones = $zones_stmt->fetchAll(PDO::FETCH_ASSOC);
        
        $shipping_zones = [];
        $shipping_config = !empty($landing_page['shipping_config']) ? json_decode($landing_page['shipping_config'], true) : [];
        
        if (!empty($shipping_config)) {
            foreach ($all_shipping_zones as $zone) {
                if (isset($shipping_config[$zone['id']]) && !empty($shipping_config[$zone['id']]['enabled'])) {
                    $custom_charge = $shipping_config[$zone['id']]['charge'];
                    if ($custom_charge !== '') {
                        $zone['charge'] = (float)$custom_charge;
                    }
                    $shipping_zones[] = $zone;
                }
            }
        } else {
            // Default: Fallback to all active global shipping zones
            $shipping_zones = $all_shipping_zones;
        }
        
        // Get payment methods
        $lp_payment_methods = [];
        try {
            $lp_payment_methods = $this->pdo->query("SELECT * FROM payment_methods WHERE is_active = 1 ORDER BY sort_order ASC")->fetchAll(PDO::FETCH_ASSOC);
        } catch (PDOException $e) { /* silent fail */ }
        
        // Get site settings (use global variable if available, else fetch)
        global $site_settings;
        $lp_settings = $site_settings ?? [];
        if (empty($lp_settings)) {
            try {
                $settings_stmt = $this->pdo->query("SELECT key_name, value FROM settings");
                while ($row = $settings_stmt->fetch(PDO::FETCH_ASSOC)) {
                    $lp_settings[$row['key_name']] = $row['value'];
                }
            } catch (PDOException $e) { /* silent fail */ }
        }
        
        // Check if COD is allowed
        $lp_allow_cod = (isset($lp_settings['allow_cod']) ? $lp_settings['allow_cod'] : '1') == '1';
        
        // Extra shipping charge
        $extra_shipping = 0;
        
        // Page metadata
        $meta_title = $landing_page['page_title'];
        $meta_description = $landing_page['meta_description'];
        
        // Hide standard header/footer contents
        $hide_header_footer = true;
        
        // Sync product data for global tracking (header.php)
        $product = $landing_page;
        $product['id'] = $landing_page['product_id'];
        $product['name'] = $landing_page['product_name'];
        $product['price'] = PriceHelper::effectivePrice($landing_page['price'], $landing_page['offer_price'] ?? null);
        
        // Ensure site settings are available globally for header.php
        $site_settings = $lp_settings;
        
        // Render landing page
        require_once 'views/layouts/header.php';
        require_once 'views/pages/landing-page.php';
        require_once 'views/layouts/footer.php';
    }
    
    /**
     * Process order from landing page
     */
    public function processOrder() {
        header('Content-Type: application/json');

        if (!CsrfHelper::validate()) {
            echo json_encode(['status' => 'error', 'message' => 'Invalid security token']);
            return;
        }
        
        try {
            // Get selected product IDs
            $selected_product_ids = [];
            if (isset($_POST['product_ids']) && is_array($_POST['product_ids'])) {
                $selected_product_ids = array_map('intval', $_POST['product_ids']);
            } elseif (!empty($_POST['product_id'])) {
                $selected_product_ids = [ (int)$_POST['product_id'] ];
            }

            if (empty($selected_product_ids)) {
                echo json_encode(['status' => 'error', 'message' => 'অনুগ্রহ করে অন্তত একটি প্রোডাক্ট নির্বাচন করুন']);
                return;
            }

            // Fetch selected products from DB
            $in_clause = implode(',', $selected_product_ids);
            $products_stmt = $this->pdo->query("SELECT * FROM products WHERE id IN ($in_clause) AND status = 1");
            $selected_products = $products_stmt->fetchAll(PDO::FETCH_ASSOC);

            if (empty($selected_products)) {
                echo json_encode(['status' => 'error', 'message' => 'কোনো ভ্যালিড প্রোডাক্ট পাওয়া যায়নি']);
                return;
            }

            // Map selected products by ID for easy access and check type
            $products_by_id = [];
            $has_digital = false;
            $has_physical = false;
            foreach ($selected_products as $p) {
                $products_by_id[$p['id']] = $p;
                if ($p['product_type'] === 'digital') {
                    $has_digital = true;
                } else {
                    $has_physical = true;
                }
            }

            // Validate required fields
            $required = ['name', 'phone'];
            if ($has_digital) {
                $required[] = 'email';
            }
            if ($has_physical) {
                $required[] = 'address';
                $required[] = 'area';
                $required[] = 'delivery_charge';
            }

            foreach ($required as $field) {
                if (!isset($_POST[$field]) || $_POST[$field] === '') {
                    $field_names = [
                        'name' => 'নাম',
                        'phone' => 'মোবাইল নাম্বার',
                        'address' => 'ঠিকানা',
                        'area' => 'থানা/জেলা',
                        'delivery_charge' => 'ডেলিভারি চার্জ'
                    ];
                    $label = $field_names[$field] ?? $field;
                    echo json_encode(['status' => 'error', 'message' => "অনুগ্রহ করে {$label} পূরণ করুন"]);
                    return;
                }
            }

            $normalizedPhone = PhoneHelper::normalizeBdPhone($_POST['phone'] ?? '');
            if ($normalizedPhone === null) {
                echo json_encode(['status' => 'error', 'message' => 'সঠিক মোবাইল নাম্বার দিন (01XXXXXXXXX)']);
                return;
            }
            $_POST['phone'] = $normalizedPhone;
            
            // Calculate totals and build item array
            $subtotal = 0;
            $order_items_data = [];
            
            foreach ($selected_product_ids as $pid) {
                if (!isset($products_by_id[$pid])) continue;
                $p = $products_by_id[$pid];
                
                $qty = 1;
                if (isset($_POST['qtys']) && is_array($_POST['qtys']) && isset($_POST['qtys'][$pid])) {
                    $qty = max(1, (int)$_POST['qtys'][$pid]);
                } elseif (isset($_POST['qty'])) {
                    $qty = max(1, (int)$_POST['qty']);
                }
                
                $price = PriceHelper::effectivePrice($p['price'], $p['offer_price'] ?? null);
                $subtotal += ($price * $qty);
                
                $order_items_data[] = [
                    'product_id' => $p['id'],
                    'qty' => $qty,
                    'price' => $price,
                    'name' => $p['name']
                ];
            }

            if (empty($order_items_data)) {
                echo json_encode(['status' => 'error', 'message' => 'অর্ডারে কোনো প্রোডাক্ট যুক্ত নেই']);
                return;
            }

            $delivery_charge = $has_physical ? (float)$_POST['delivery_charge'] : 0;
            
            // Apply Coupon Discount
            $discount = 0;
            $coupon_code = null;
            if (isset($_SESSION['coupon']) && is_array($_SESSION['coupon'])) {
                $discount = $_SESSION['coupon']['discount'] ?? 0;
                $coupon_code = $_SESSION['coupon']['code'] ?? null;
            }
            
            $total = $subtotal + $delivery_charge - $discount;
            
            // Generate tracking ID
            $tracking_id = 'LP' . strtoupper(substr(uniqid(), -8));
            
            // Payment method
            $payment_method = $_POST['payment_method'] ?? 'COD';
            if (!$has_physical) {
                $payment_method = 'Online';
            }
            
            // Create order
            $this->pdo->beginTransaction();
            
            // Create full shipping address
            $area = $_POST['area'] ?? 'Digital Delivery';
            $full_address = $has_physical ? ($_POST['address'] . ', ' . $area) : 'Digital Product - No Shipping Required';
            
            $digital_delivery_status = ($has_physical === false) ? 'Pending' : 'N/A';
            
            $access_token = OrderAccessHelper::generateToken();

            $order_stmt = $this->pdo->prepare("
                INSERT INTO orders (customer_name, customer_phone, customer_email, shipping_address, tracking_id, total_amount, discount_amount, coupon_code, payment_method, order_status, payment_status, digital_delivery_status, access_token)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'Pending', 'Pending', ?, ?)
            ");
            $order_stmt->execute([
                $_POST['name'],
                $_POST['phone'],
                $_POST['email'] ?? null,
                $full_address,
                $tracking_id,
                $total,
                $discount,
                $coupon_code,
                $payment_method,
                $digital_delivery_status,
                $access_token
            ]);
            
            $order_id = $this->pdo->lastInsertId();
            
            // Create order items
            $item_stmt = $this->pdo->prepare("
                INSERT INTO order_items (order_id, product_id, qty, price)
                VALUES (?, ?, ?, ?)
            ");
            foreach ($order_items_data as $item) {
                $item_stmt->execute([
                    $order_id,
                    $item['product_id'],
                    $item['qty'],
                    $item['price']
                ]);
            }
            $this->pdo->commit();

            // Server-side Tracking: Purchase
            try {
                require_once 'app/Services/TrackingService.php';
                $trackingService = new TrackingService();
                
                $email = $_POST['email'] ?? null;
                $phone = $_POST['phone'];
                $name = $_POST['name'];
                
                $userData = TrackingService::buildUserData($email, $phone, $name);
                $userData['client_ip_address'] = $_SERVER['REMOTE_ADDR'] ?? null;
                $userData['client_user_agent'] = $_SERVER['HTTP_USER_AGENT'] ?? null;
                
                $product_ids = array_column($order_items_data, 'product_id');
                $customData = [
                    'value' => $total,
                    'currency' => 'BDT',
                    'content_ids' => $product_ids,
                    'content_type' => 'product',
                    'num_items' => count($order_items_data)
                ];
                $eventId = 'pur_' . $order_id;
                $trackingService->fireEvent('Purchase', $userData, $customData, $eventId);
            } catch (\Exception $e) {
                // Silently ignore tracking failures
            }

            // Clear coupon
            unset($_SESSION['coupon']);

            // Set session data for tracking on thanks page
            $event_id = 'order_' . $order_id . '_' . time();
            $_SESSION['last_order_event_id'] = $event_id;
            
            // Build full contents array for Data Layer
            $contents = [];
            $content_ids = [];
            foreach ($order_items_data as $item) {
                $contents[] = [
                    'id' => $item['product_id'],
                    'name' => $item['name'],
                    'price' => $item['price'],
                    'quantity' => $item['qty']
                ];
                $content_ids[] = (string)$item['product_id'];
            }
            
            $_SESSION['last_order_data'] = [
                'order_id' => $order_id,
                'value' => $total,
                'currency' => 'BDT',
                'content_ids' => $content_ids,
                'content_type' => 'product',
                'contents' => $contents,
                'shipping' => $delivery_charge,
                'discount' => $discount,
                'coupon' => $coupon_code,
                'payment_method' => $payment_method,
                'customer_name' => $_POST['name'],
                'customer_phone' => $_POST['phone'],
                'customer_email' => $_POST['email'] ?? null,
                'customer_address' => $full_address,
                'order_source' => 'landing_page',
                'is_first_order' => false
            ];

            // Check if first order
            $stmt_count = $this->pdo->prepare("SELECT COUNT(*) FROM orders WHERE customer_phone = ? AND id != ?");
            $stmt_count->execute([$_POST['phone'], $order_id]);
            $_SESSION['last_order_data']['is_first_order'] = ($stmt_count->fetchColumn() == 0);


            
            // Handle payment method
            if ($payment_method === 'Online') {
                // Store order info in session for payment gateway (Required by CheckoutController)
                $_SESSION['pending_payment'] = [
                    'order_id' => $order_id,
                    'amount' => $total,
                    'customer_name' => $_POST['name'],
                    'customer_phone' => $_POST['phone'],
                    'tracking_id' => $tracking_id
                ];
                
                // Check if Zinipay (automated gateway) is available and should be used
                try {
                    require_once 'app/Services/PaymentGateway.php';
                    $pgService = new PaymentGateway($this->pdo);
                    $zinipayMethod = $pgService->getMethodBySlug('zinipay');
                    
                    if ($zinipayMethod && $zinipayMethod['is_active'] && $zinipayMethod['type'] === 'payment_gateway') {
                        // Create a transaction record for Zinipay
                        $txResult = $pgService->createTransaction([
                            'order_id' => $order_id,
                            'payment_method_id' => $zinipayMethod['id'],
                            'customer_name' => $_POST['name'],
                            'customer_phone' => $_POST['phone'],
                            'amount' => $total
                        ]);
                        
                        // Call Zinipay API to generate payment URL
                        $email = $_POST['email'] ?? null;
                        $zinipayResult = $pgService->createZinipayPayment($total, $txResult['invoice_id'], [
                            'order_id' => (string) $order_id,
                            'tracking_id' => $tracking_id,
                            'customer_phone' => $_POST['phone'],
                            'customer_name' => $_POST['name'],
                            'customer_email' => (!empty($email) && filter_var($email, FILTER_VALIDATE_EMAIL)) ? $email : 'customer@khatirajbd.com'
                        ]);
                        
                        if ($zinipayResult && $zinipayResult['success']) {
                            // Store Zinipay-specific data in session
                            $_SESSION['pending_payment']['zinipay_invoice'] = $txResult['invoice_id'];
                            $_SESSION['pending_payment']['payment_method'] = 'zinipay';
                            $redirect_url = $zinipayResult['payment_url'];
                        } else {
                            // Fallback to manual payment gateway
                            $redirect_url = BASE_URL . '/payment-gateway?order_id=' . $order_id . '&lp=1';
                        }
                    } else {
                        // No Zinipay or not active, use manual payment gateway
                        $redirect_url = BASE_URL . '/payment-gateway?order_id=' . $order_id . '&lp=1';
                    }
                } catch (Exception $e) {
                    // If Zinipay fails, fallback to manual payment gateway
                    $_SESSION['payment_error'] = (strpos($e->getMessage(), 'Zinipay error:') !== false) ? $e->getMessage() : 'পেমেন্ট গেটওয়েতে সমস্যা হয়েছে। অনুগ্রহ করে ম্যানুয়াল ভাবে ট্রানজেকশন দিন।'; 
                    $redirect_url = BASE_URL . '/payment-gateway?order_id=' . $order_id . '&lp=1';
                }

                echo json_encode([
                    'status' => 'success',
                    'redirect' => $redirect_url
                ]);
            } else {
                // COD - redirect to thanks page (CheckoutController expects ?id=ORDER_ID)
                echo json_encode([
                    'status' => 'success',
                    'redirect' => OrderAccessHelper::thanksUrl($access_token, ['lp' => 1])
                ]);
            }
            
        } catch (Exception $e) {
            if ($this->pdo->inTransaction()) {
                $this->pdo->rollBack();
            }
            echo json_encode(['status' => 'error', 'message' => 'অর্ডার প্রসেস করতে সমস্যা হয়েছে। ' . $e->getMessage()]);
        }
    }
}

// Router logic
if (!isset($controller)) {
    $controller = new LandingPageController($pdo);
}

// Ensure $path is available (it should be from index.php)
if (!isset($path)) {
    $path = substr($_SERVER['REQUEST_URI'], strlen(BASE_URL));
    $path = strtok($path, '?');
}

if ($path === '/lp/order-process' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $controller->processOrder();
} elseif (strpos($path, '/lp/') === 0) {
    $slug = substr($path, strlen('/lp/'));
    $slug = trim($slug, '/'); // Remove any trailing slash
    $controller->show($slug);
}
?>
