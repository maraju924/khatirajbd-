<?php
// app/Controllers/HomeController.php
require_once __DIR__ . '/../Helpers/CacheHelper.php';

class HomeController {
    public function index() {
        global $pdo;

        global $site_settings;
        $site_title = $site_settings['site_name'] ?? 'Khati Raj';
        $page_title = $site_title . " - Premium Organic E-commerce in Bangladesh";
        $meta_description = "আমরা খাঁটিরাজ (KhatiRaj BD) বাংলাদেশের একটি বিশ্বস্ত ও প্রিমিয়াম অর্গানিক ই-কমার্স ব্র্যান্ড। ১০০% খাঁটি, প্রাকৃতিক ও যাচাইকৃত পণ্য সরাসরি নির্ভরযোগ্য সোর্স থেকে সংগ্রহ করে আপনার দোরগোড়ায় পৌঁছে দিই।";
        $meta_keywords = "Khati Raj BD, Khati Raj Bangladesh, খাটিরাজ, KhatiRaj, খাঁটি রাজ বাংলাদেশ, organic products bd, authentic products bd, online shopping bangladesh, pure honey bd";

        PageHelper::load('home', [
            'title' => $page_title,
            'description' => $meta_description,
            'keywords' => $meta_keywords,
        ]);

        $stmt_cat = $pdo->query("SELECT * FROM categories WHERE status = 1 ORDER BY id ASC LIMIT 6");
        $categories = $stmt_cat->fetchAll();

        $products = CacheHelper::remember('home_top_products', 900, static function () use ($pdo) {
            $stmt_prod = $pdo->query("
                SELECT p.*, COALESCE(SUM(oi.qty), 0) as total_sales 
                FROM products p 
                LEFT JOIN order_items oi ON p.id = oi.product_id 
                LEFT JOIN orders o ON oi.order_id = o.id AND o.order_status != 'Cancelled'
                WHERE p.status = 1 AND p.show_on_website = 1
                GROUP BY p.id 
                ORDER BY total_sales DESC, p.id DESC 
                LIMIT 8
            ");
            return $stmt_prod->fetchAll();
        });

        $stmt_slide = $pdo->query("SELECT * FROM sliders WHERE status = 1 AND (position = 'main_hero' OR position IS NULL) ORDER BY sort_order ASC");
        $sliders = $stmt_slide->fetchAll();

        // Promo slider (between categories and products)
        $stmt_promo = $pdo->query("SELECT * FROM sliders WHERE status = 1 AND position = 'promo_slider' ORDER BY sort_order ASC");
        $promo_sliders = $stmt_promo->fetchAll();

        // Middle banner (between products and features)
        $stmt_mid = $pdo->query("SELECT * FROM sliders WHERE status = 1 AND position = 'middle_banner' ORDER BY sort_order ASC");
        $middle_banners = $stmt_mid->fetchAll();

        include 'views/layouts/header.php';
        include 'views/pages/home.php';
        include 'views/layouts/footer.php';
    }
}

if (!isset($pdo)) {
    require_once 'config/database.php';
}

$controller = new HomeController();
$controller->index();
