<?php
require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../Services/AbandonedCartService.php';

class AbandonedCartController {
    private $service;

    public function __construct(PDO $pdo) {
        $this->service = new AbandonedCartService($pdo);
    }

    public function handleRequest(string $path): void {
        if ($path === '/api/abandoned-cart/save') {
            $this->saveContact();
        } elseif (preg_match('#^/cart/recover/([a-f0-9]{32})$#', $path, $matches)) {
            $this->recover($matches[1]);
        } elseif ($path === '/cron/abandoned-cart') {
            $this->runCron();
        } else {
            http_response_code(404);
            echo json_encode(['status' => 'error', 'message' => 'Not found']);
        }
    }

    private function saveContact(): void {
        header('Content-Type: application/json');

        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            http_response_code(405);
            echo json_encode(['status' => 'error', 'message' => 'Method not allowed']);
            return;
        }

        $name = trim($_POST['name'] ?? '');
        $phone = trim($_POST['phone'] ?? '');
        $email = trim($_POST['email'] ?? '');
        $area = trim($_POST['area'] ?? '');
        $address = trim($_POST['address'] ?? '');

        if (empty($phone)) {
            echo json_encode(['status' => 'error', 'message' => 'Phone required']);
            return;
        }

        $id = $this->service->updateContact($name, $phone, $email, $area, $address);
        echo json_encode([
            'status' => $id ? 'success' : 'error',
            'cart_id' => $id,
            'message' => $id ? 'Cart saved' : 'Invalid phone or empty cart',
        ]);
    }

    private function recover(string $token): void {
        $result = $this->service->recoverByToken($token);

        if ($result['success']) {
            header('Location: ' . BASE_URL . '/checkout?recovered=1');
        } else {
            header('Location: ' . BASE_URL . '/cart?error=' . urlencode($result['message']));
        }
        exit;
    }

    private function runCron(): void {
        global $pdo;

        $stmt = $pdo->prepare("SELECT value FROM settings WHERE key_name = 'abandoned_cart_cron_key'");
        $stmt->execute();
        $expectedKey = $stmt->fetchColumn() ?: '';

        $providedKey = $_GET['key'] ?? ($_SERVER['HTTP_X_CRON_KEY'] ?? '');

        if (empty($expectedKey) || !hash_equals($expectedKey, $providedKey)) {
            http_response_code(403);
            header('Content-Type: application/json');
            echo json_encode(['status' => 'error', 'message' => 'Unauthorized']);
            return;
        }

        $stats = $this->service->processReminders();
        header('Content-Type: application/json');
        echo json_encode(['status' => 'success', 'stats' => $stats]);
    }
}

$controller = new AbandonedCartController($pdo);
$path = substr($_SERVER['REQUEST_URI'], strlen(BASE_URL));
$path = strtok($path, '?') ?: '/';
$controller->handleRequest($path);
