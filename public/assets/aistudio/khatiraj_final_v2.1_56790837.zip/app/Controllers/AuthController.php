<?php
// app/Controllers/AuthController.php

class AuthController {
    public function index() {
        global $pdo;
        $page_title = "Login / Register - Khati Raj";
        PageHelper::load('login', ['title' => $page_title]);
        
        $redirect = $_GET['redirect'] ?? '';
        
        include 'views/layouts/header.php';
        include 'views/pages/auth.php';
        include 'views/layouts/footer.php';
    }

    public function handleRequest($path) {
        if ($path === '/login-action') {
            $this->login();
        } elseif ($path === '/register-action') {
            $this->register();
        } elseif ($path === '/forgot-password') {
            $this->forgotPassword();
        } elseif ($path === '/send-reset-link') {
            $this->sendResetLink();
        } elseif ($path === '/reset-password') {
            $this->resetPasswordForm();
        } elseif ($path === '/update-password-action') {
            $this->updatePassword();
        } else {
            $this->index();
        }
    }

    public function forgotPassword() {
        $page_title = "Forgot Password - Khati Raj";
        PageHelper::load('forgot_password', ['title' => $page_title]);
        include 'views/layouts/header.php';
        include 'views/pages/forgot-password.php';
        include 'views/layouts/footer.php';
    }

    public function sendResetLink() {
        global $pdo;
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            if (!CsrfHelper::validate()) {
                header('Location: ' . BASE_URL . '/forgot-password?error=' . urlencode('Invalid security token.'));
                exit;
            }
            $email = trim($_POST['email']);
            
            $stmt = $pdo->prepare("SELECT id, name FROM users WHERE email = ?");
            $stmt->execute([$email]);
            $user = $stmt->fetch();

            if ($user) {
                $token = bin2hex(random_bytes(32));
                $expiry = date('Y-m-d H:i:s', strtotime('+1 hour'));

                $stmt = $pdo->prepare("UPDATE users SET reset_token = ?, token_expiry = ? WHERE id = ?");
                $stmt->execute([$token, $expiry, $user['id']]);

                require_once 'app/Helpers/EmailHelper.php';
                $emailHelper = new \App\Helpers\EmailHelper($pdo);
                
                $reset_url = SITE_URL . "/reset-password?token=" . $token;
                
                if ($emailHelper->sendPasswordResetEmail($email, $user['name'], $reset_url)) {
                    header('Location: ' . BASE_URL . '/forgot-password?success=Reset link sent to your email.');
                } else {
                    header('Location: ' . BASE_URL . '/forgot-password?error=Failed to send email. Please try again.');
                }
            } else {
                header('Location: ' . BASE_URL . '/forgot-password?error=No account found with this email.');
            }
            exit;
        }
    }

    public function resetPasswordForm() {
        global $pdo;
        $token = $_GET['token'] ?? '';
        
        if (!$token) {
            header('Location: ' . BASE_URL . '/login?error=Invalid reset token.');
            exit;
        }

        $stmt = $pdo->prepare("SELECT id FROM users WHERE reset_token = ? AND token_expiry > NOW()");
        $stmt->execute([$token]);
        if (!$stmt->fetch()) {
            header('Location: ' . BASE_URL . '/login?error=Invalid or expired reset token.');
            exit;
        }

        $page_title = "Reset Password - Khati Raj";
        PageHelper::load('reset_password', ['title' => $page_title]);
        include 'views/layouts/header.php';
        include 'views/pages/reset-password.php';
        include 'views/layouts/footer.php';
    }

    public function updatePassword() {
        global $pdo;
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            if (!CsrfHelper::validate()) {
                header('Location: ' . BASE_URL . '/login?error=' . urlencode('Invalid security token.'));
                exit;
            }
            $token = $_POST['token'];
            $password = $_POST['password'];
            $confirm_password = $_POST['confirm_password'];

            if ($password !== $confirm_password) {
                header('Location: ' . BASE_URL . '/reset-password?token=' . $token . '&error=Passwords do not match.');
                exit;
            }

            $stmt = $pdo->prepare("SELECT id FROM users WHERE reset_token = ? AND token_expiry > NOW()");
            $stmt->execute([$token]);
            $user = $stmt->fetch();

            if ($user) {
                $hashed_password = password_hash($password, PASSWORD_BCRYPT);
                $stmt = $pdo->prepare("UPDATE users SET password = ?, reset_token = NULL, token_expiry = NULL WHERE id = ?");
                $stmt->execute([$hashed_password, $user['id']]);

                header('Location: ' . BASE_URL . '/login?success=Password updated! Please login.');
            } else {
                header('Location: ' . BASE_URL . '/login?error=Invalid or expired reset token.');
            }
            exit;
        }
    }

    public function login() {
        global $pdo;
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            if (!CsrfHelper::validate()) {
                header('Location: ' . BASE_URL . '/login?error=' . urlencode('Invalid security token.'));
                exit;
            }
            $email = $_POST['email'];
            $password = $_POST['password'];

            $stmt = $pdo->prepare("SELECT * FROM users WHERE email = ?");
            $stmt->execute([$email]);
            $user = $stmt->fetch();

            if ($user && password_verify($password, $user['password'])) {
                session_regenerate_id(true);
                $_SESSION['user_logged_in'] = true;
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['user_name'] = $user['name'];

                $redirect = $_POST['redirect'] ?? '';
                if (!empty($redirect)) {
                    header('Location: ' . BASE_URL . '/' . ltrim($redirect, '/'));
                } else {
                    header('Location: ' . BASE_URL . '/home');
                }
                exit;
            } else {
                $redirect_param = !empty($_POST['redirect']) ? '&redirect=' . urlencode($_POST['redirect']) : '';
                header('Location: ' . BASE_URL . '/login?error=Invalid email or password' . $redirect_param);
                exit;
            }
        }
    }

    public function register() {
        global $pdo;
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            if (!CsrfHelper::validate()) {
                header('Location: ' . BASE_URL . '/register?error=' . urlencode('Invalid security token.'));
                exit;
            }
            $name = trim($_POST['name']);
            $email = trim($_POST['email']);
            $phone = trim($_POST['phone']);
            $password = $_POST['password'];

            if (empty($name) || empty($email) || empty($phone) || empty($password)) {
                header('Location: ' . BASE_URL . '/register?error=All fields are required');
                exit;
            }

            try {
                // Check if email or phone exists
                $stmt = $pdo->prepare("SELECT id FROM users WHERE email = ? OR phone = ?");
                $stmt->execute([$email, $phone]);
                if ($stmt->rowCount() > 0) {
                    header('Location: ' . BASE_URL . '/register?error=Email or Phone already exists');
                    exit;
                }

                $hashed_password = password_hash($password, PASSWORD_BCRYPT);
                $stmt = $pdo->prepare("INSERT INTO users (name, email, phone, password) VALUES (?, ?, ?, ?)");
                $stmt->execute([$name, $email, $phone, $hashed_password]);

                // Server-side Tracking: CompleteRegistration
                try {
                    require_once 'app/Services/TrackingService.php';
                    $trackingService = new TrackingService();
                    $userData = TrackingService::buildUserData($email, $phone, $name);
                    $eventId = TrackingService::generateEventId('reg', $email);
                    $trackingService->fireEvent('CompleteRegistration', $userData, [], $eventId);
                } catch (\Exception $e) {
                    // Silently ignore tracking errors
                }

                $redirect = $_POST['redirect'] ?? '';
                $redirect_param = !empty($redirect) ? '&redirect=' . urlencode($redirect) : '';
                header('Location: ' . BASE_URL . '/login?success=Account created! Please login.' . $redirect_param . '&registered=1&u_em=' . urlencode($email));
                exit;
            } catch (PDOException $e) {
                error_log('User register error: ' . $e->getMessage());
                $redirect = $_POST['redirect'] ?? '';
                $redirect_param = !empty($redirect) ? '&redirect=' . urlencode($redirect) : '';
                header('Location: ' . BASE_URL . '/register?error=' . urlencode('Registration failed. Please try again.') . $redirect_param);
                exit;
            }
        }
    }
}

$controller = new AuthController();
require_once __DIR__ . '/../Helpers/RouteHelper.php';
$path = RouteHelper::getPath();
$controller->handleRequest($path);
