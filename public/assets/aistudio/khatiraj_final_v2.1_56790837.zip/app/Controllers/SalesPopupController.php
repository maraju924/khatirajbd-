<?php
// app/Controllers/SalesPopupController.php
require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../Helpers/CacheHelper.php';

class SalesPopupController {
    public function getRecent() {
        global $pdo;

        $data = CacheHelper::remember('recent_sales_popup', 180, static function () use ($pdo) {
            $stmt = $pdo->query("
                SELECT o.customer_name, o.shipping_address, o.created_at, p.name as p_name, p.image as p_image
                FROM orders o
                JOIN order_items oi ON o.id = oi.order_id
                JOIN products p ON oi.product_id = p.id
                WHERE o.order_status != 'Cancelled'
                ORDER BY o.created_at DESC
                LIMIT 5
            ");
            $results = $stmt->fetchAll();

            $payload = [];
            foreach ($results as $row) {
                $parts = explode(',', $row['shipping_address']);
                $area = trim(end($parts));

                $payload[] = [
                    'name' => $row['customer_name'],
                    'area' => $area,
                    'product' => $row['p_name'],
                    'image' => $row['p_image'],
                    'time' => self::timeElapsedString($row['created_at']),
                ];
            }
            return $payload;
        });

        header('Content-Type: application/json');
        echo json_encode($data);
    }

    private static function timeElapsedString($datetime, $full = false) {
        $now = new DateTime;
        $ago = new DateTime($datetime);
        $diff = $now->diff($ago);

        $weeks = floor($diff->d / 7);
        $days = $diff->d - ($weeks * 7);

        $string = array(
            'y' => 'year',
            'm' => 'month',
            'w' => 'week',
            'd' => 'day',
            'h' => 'hour',
            'i' => 'minute',
            's' => 'second',
        );

        $diff_values = [
            'y' => $diff->y,
            'm' => $diff->m,
            'w' => $weeks,
            'd' => $days,
            'h' => $diff->h,
            'i' => $diff->i,
            's' => $diff->s,
        ];

        foreach ($string as $k => &$v) {
            if ($diff_values[$k]) {
                $v = $diff_values[$k] . ' ' . $v . ($diff_values[$k] > 1 ? 's' : '');
            } else {
                unset($string[$k]);
            }
        }

        if (!$full) $string = array_slice($string, 0, 1);
        return $string ? implode(', ', $string) . ' ago' : 'just now';
    }
}

$controller = new SalesPopupController();
$controller->getRecent();
