<?php
// app/Controllers/TrackController.php
// Server-side relay for browser tracking events.
// The browser pixel (fbq) fires an event with an eventID, then posts the same
// event here so it is also sent via Meta CAPI (and TikTok Events API if configured)
// with the SAME event_id — the platforms deduplicate, so each event counts once
// but is delivered even when ad-blockers kill the browser pixel.

require_once __DIR__ . '/../Services/TrackingService.php';

class TrackController {

    // Purchase and CompleteRegistration are fired server-side directly by the
    // controllers that create orders/accounts, so they must not be relayed.
    private const ALLOWED_EVENTS = [
        'PageView',
        'ViewContent',
        'Search',
        'AddToCart',
        'InitiateCheckout',
        'AddPaymentInfo',
    ];

    public function relay(): void {
        header('Content-Type: application/json');

        if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') {
            http_response_code(405);
            echo json_encode(['success' => false, 'error' => 'POST required']);
            return;
        }

        // Skip obvious bots/crawlers — they should not generate ad events
        $ua = $_SERVER['HTTP_USER_AGENT'] ?? '';
        if ($ua === '' || preg_match('/bot|crawl|spider|slurp|curl|wget|facebookexternalhit|headless/i', $ua)) {
            echo json_encode(['success' => false, 'error' => 'ignored']);
            return;
        }

        $input = json_decode(file_get_contents('php://input'), true);
        if (!is_array($input)) {
            http_response_code(400);
            echo json_encode(['success' => false, 'error' => 'Invalid JSON']);
            return;
        }

        $eventName = (string)($input['event'] ?? '');
        if (!in_array($eventName, self::ALLOWED_EVENTS, true)) {
            http_response_code(400);
            echo json_encode(['success' => false, 'error' => 'Event not allowed']);
            return;
        }

        $eventId = substr(preg_replace('/[^A-Za-z0-9_\-\.]/', '', (string)($input['event_id'] ?? '')), 0, 100);
        if ($eventId === '') {
            $eventId = TrackingService::generateEventId(strtolower($eventName));
        }

        $customData = $this->sanitizeCustomData(is_array($input['custom_data'] ?? null) ? $input['custom_data'] : []);

        $userData = TrackingService::buildUserData();

        // Only trust same-host page URLs for event_source_url
        $url = $input['url'] ?? '';
        if (is_string($url) && $url !== '') {
            $host = parse_url($url, PHP_URL_HOST);
            if ($host && strcasecmp($host, $_SERVER['HTTP_HOST'] ?? '') === 0) {
                $userData['event_source_url'] = substr($url, 0, 500);
            }
        }

        try {
            $trackingService = new TrackingService();
            $results = $trackingService->fireEvent($eventName, $userData, $customData, $eventId);
            echo json_encode(['success' => (bool)($results['meta'] || $results['tiktok'])]);
        } catch (Throwable $e) {
            echo json_encode(['success' => false]);
        }
    }

    private function sanitizeCustomData(array $raw): array {
        $clean = [];

        if (isset($raw['value']) && is_numeric($raw['value'])) {
            $clean['value'] = round((float)$raw['value'], 2);
        }
        if (!empty($raw['currency']) && is_string($raw['currency'])) {
            $currency = strtoupper(preg_replace('/[^A-Za-z]/', '', $raw['currency']));
            if ($currency !== '') {
                $clean['currency'] = substr($currency, 0, 3);
            }
        }
        if (!empty($raw['content_ids']) && is_array($raw['content_ids'])) {
            $ids = array_slice(array_filter($raw['content_ids'], 'is_scalar'), 0, 50);
            if ($ids) {
                $clean['content_ids'] = array_values(array_map('strval', $ids));
            }
        }
        if (!empty($raw['content_type']) && is_string($raw['content_type'])) {
            $clean['content_type'] = substr($raw['content_type'], 0, 30);
        }
        if (!empty($raw['content_name']) && is_string($raw['content_name'])) {
            $clean['content_name'] = mb_substr($raw['content_name'], 0, 100);
        }
        if (isset($raw['quantity']) && is_numeric($raw['quantity'])) {
            $clean['quantity'] = max(1, (int)$raw['quantity']);
        }
        if (isset($raw['num_items']) && is_numeric($raw['num_items'])) {
            $clean['num_items'] = max(1, (int)$raw['num_items']);
        }
        if (!empty($raw['search_string']) && is_string($raw['search_string'])) {
            $clean['search_string'] = mb_substr($raw['search_string'], 0, 100);
        }

        return $clean;
    }
}

$controller = new TrackController();
$controller->relay();
