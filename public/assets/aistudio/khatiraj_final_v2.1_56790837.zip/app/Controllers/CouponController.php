<?php
// app/Controllers/CouponController.php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
require_once dirname(__DIR__, 2) . '/config/database.php';

class CouponController {
    public function apply() {
        global $pdo;
        $code = strtoupper(trim($_POST['code'] ?? ''));
        $subtotal = floatval($_POST['subtotal'] ?? 0);

        if (empty($code)) {
            echo json_encode(['status' => 'error', 'message' => 'Please enter a coupon code.']);
            exit;
        }

        $stmt = $pdo->prepare("SELECT * FROM coupons WHERE code = ? AND status = 1 AND (start_date IS NULL OR start_date <= CURDATE()) AND (end_date IS NULL OR end_date >= CURDATE())");
        $stmt->execute([$code]);
        $coupon = $stmt->fetch();

        if (!$coupon) {
            echo json_encode(['status' => 'error', 'message' => 'Invalid or expired coupon code.']);
            exit;
        }

        if ($subtotal < $coupon['min_order_amount']) {
            echo json_encode(['status' => 'error', 'message' => 'Minimum order amount for this coupon is ৳' . number_format($coupon['min_order_amount'])]);
            exit;
        }

        $discount = 0;
        if ($coupon['type'] === 'fixed') {
            $discount = min($coupon['value'], $subtotal);
        } else {
            $discount = ($subtotal * $coupon['value']) / 100;
        }

        $_SESSION['coupon'] = [
            'code' => $coupon['code'],
            'type' => $coupon['type'],
            'value' => $coupon['value'],
            'discount' => $discount
        ];

        echo json_encode([
            'status' => 'success',
            'message' => 'Coupon applied successfully!',
            'discount' => $discount,
            'code' => $coupon['code']
        ]);
    }

    public function remove() {
        unset($_SESSION['coupon']);
        echo json_encode(['status' => 'success', 'message' => 'Coupon removed.']);
    }
}

$controller = new CouponController();
$path = str_replace(BASE_URL, '', $_SERVER['REQUEST_URI']);
$path = strtok($path, '?');

if ($path === '/api/apply-coupon') {
    $controller->apply();
} elseif ($path === '/api/remove-coupon') {
    $controller->remove();
}
?>
