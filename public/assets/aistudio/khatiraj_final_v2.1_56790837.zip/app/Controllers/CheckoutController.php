<?php
// app/Controllers/CheckoutController.php
require_once 'app/Services/SteadfastService.php';
require_once __DIR__ . '/../Helpers/CartShippingHelper.php';
require_once __DIR__ . '/../Helpers/OrderAccessHelper.php';
require_once __DIR__ . '/../Helpers/PriceHelper.php';
require_once __DIR__ . '/../Helpers/PhoneHelper.php';

class CheckoutController {
    public function index() {
        global $pdo;
        $page_title = "Checkout - Khati Raj";
        PageHelper::load('checkout', ['title' => $page_title]);
        $cart_items = $_SESSION['cart'] ?? [];
        
        $common_zone_ids = CartShippingHelper::getCommonZoneIds($pdo, $cart_items);
        $shipping_zones = CartShippingHelper::getShippingZones($pdo, $common_zone_ids);
        $extra_shipping_total = CartShippingHelper::getExtraShippingTotal($pdo, $cart_items);
        $_SESSION['extra_shipping'] = $extra_shipping_total;
        $is_all_digital = CartShippingHelper::isAllDigital($pdo, $cart_items);
        
        // Fetch restricted payment methods based on cart items
        require_once 'app/Services/PaymentGateway.php';
        $pg = new PaymentGateway($pdo);
        $product_ids = array_column($cart_items, 'id');
        $payment_restrict = $pg->getAvailableMethodsForCart($product_ids);
        
        $available_online_methods = $payment_restrict['methods'];
        $allow_cod = $payment_restrict['allow_cod'];

        try {
            require_once __DIR__ . '/../Services/AbandonedCartService.php';
            (new AbandonedCartService($pdo))->syncSessionCart();
        } catch (Exception $e) {
            // Non-blocking
        }

        include 'views/layouts/header.php';
        include 'views/pages/checkout.php';
        include 'views/layouts/footer.php';
    }

    public function handleRequest($path) {
        if ($path === '/order-process') {
            $this->orderProcess();
        } elseif (preg_match('#^/thanks/([a-f0-9]{64})$#', $path, $m)) {
            $_GET['token'] = $m[1];
            $this->thanks();
        } elseif ($path === '/thanks') {
            $this->thanks();
        } elseif (preg_match('#^/order-summary/([a-f0-9]{64})$#', $path, $m)) {
            $_GET['token'] = $m[1];
            $this->orderSummaryPublic();
        } elseif ($path === '/order-summary-public') {
            $this->orderSummaryPublic();
        } elseif ($path === '/payment-gateway') {
            $this->paymentGateway();
        } elseif ($path === '/payment-submit') {
            $this->paymentSubmit();
        } elseif ($path === '/zinipay-success') {
            $this->zinipaySuccess();
        } elseif ($path === '/zinipay-cancel') {
            $this->zinipayCancel();
        } else {
            $this->index();
        }
    }

    public function paymentGateway() {
        global $pdo;
        
        $order_id = $_GET['order_id'] ?? null;
        $pending = $_SESSION['pending_payment'] ?? null;
        $lp = isset($_GET['lp']) && $_GET['lp'] == 1;
        
        if (!$order_id || !$pending || $pending['order_id'] != $order_id) {
            header('Location: ' . BASE_URL . '/checkout' . ($lp ? '?lp=1' : ''));
            exit;
        }
        
        // Get order details
        $stmt = $pdo->prepare("SELECT * FROM orders WHERE id = ?");
        $stmt->execute([$order_id]);
        $order = $stmt->fetch();
        
        if (!$order || $order['payment_status'] === 'Paid') {
            header('Location: ' . OrderAccessHelper::thanksUrlForOrder($pdo, (int) $order_id, $lp ? ['lp' => 1] : []));
            exit;
        }
        
        // Load payment gateway service
        require_once 'app/Services/PaymentGateway.php';
        $paymentGateway = new PaymentGateway($pdo);
        
        $mobileBankingMethods = $paymentGateway->getMobileBankingMethods();
        $bankTransferMethods = $paymentGateway->getBankTransferMethods();
        $gatewayMethods = $paymentGateway->getPaymentGatewayMethods();
        
        // Merge gateways into mobile banking or keep separate for the view
        $allOnlineMethods = array_merge($mobileBankingMethods, $bankTransferMethods, $gatewayMethods);
        
        // Site settings
        $stmt = $pdo->query("SELECT key_name, value FROM settings");
        $site_settings = $stmt->fetchAll(PDO::FETCH_KEY_PAIR);
        
        $page_title = "পেমেন্ট করুন - " . ($site_settings['site_name'] ?? 'Payment');
        PageHelper::load('payment_gateway', ['title' => $page_title]);
        
        $payment_error = $_SESSION['payment_error'] ?? null;
        unset($_SESSION['payment_error']);
        
        if ($lp) $hide_header_footer = true;
        
        include 'views/layouts/header.php';
        include 'views/pages/payment-gateway.php';
        include 'views/layouts/footer.php';
    }

    public function paymentSubmit() {
        global $pdo;
        
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            header('Location: ' . BASE_URL . '/checkout');
            exit;
        }

        header('Content-Type: application/json; charset=utf-8');

        if (!CsrfHelper::validate()) {
            echo json_encode(['status' => 'error', 'message' => 'Invalid security token']);
            exit;
        }
        
        $order_id = $_POST['order_id'] ?? null;
        $payment_method_id = $_POST['payment_method_id'] ?? null;
        $transaction_id = $_POST['transaction_id'] ?? null;
        $sender_number = $_POST['sender_number'] ?? null;
        $lp = isset($_POST['lp']) && $_POST['lp'] == 1;
        
        $pending = $_SESSION['pending_payment'] ?? null;
        
        if (!$order_id || !$pending || $pending['order_id'] != $order_id) {
            echo json_encode(['status' => 'error', 'message' => 'Invalid session']);
            exit;
        }
        
        try {
            require_once 'app/Services/PaymentGateway.php';
            $paymentGateway = new PaymentGateway($pdo);
            
            // Create transaction
            $result = $paymentGateway->createTransaction([
                'order_id' => $order_id,
                'payment_method_id' => $payment_method_id,
                'customer_name' => $pending['customer_name'],
                'customer_phone' => $pending['customer_phone'],
                'amount' => $pending['amount'],
                'transaction_id' => $transaction_id,
                'sender_number' => $sender_number
            ]);
            
            // Clear pending payment
            unset($_SESSION['pending_payment']);
            
            // Return success
            echo json_encode([
                'status' => 'success',
                'message' => 'পেমেন্ট সফলভাবে জমা হয়েছে। অনুগ্রহ করে ভেরিফিকেশনের জন্য অপেক্ষা করুন।',
                'redirect' => OrderAccessHelper::thanksUrlForOrder($pdo, (int) $order_id, array_filter([
                    'payment' => 'pending',
                    'lp' => $lp ? 1 : null,
                ])),
                'invoice_id' => $result['invoice_id']
            ]);
            
        } catch (Exception $e) {
            echo json_encode(['status' => 'error', 'message' => $e->getMessage()]);
        }
        exit;
    }

    public function thanks() {
        global $pdo;
        $token = OrderAccessHelper::resolveTokenFromRequest();
        $lp = isset($_GET['lp']) && $_GET['lp'] == 1;

        if (!$token) {
            header('Location: ' . BASE_URL . '/home');
            exit;
        }

        $order = OrderAccessHelper::findByToken($pdo, $token);
        if (!$order) {
            header('Location: ' . BASE_URL . '/home');
            exit;
        }

        $order_id = (int) $order['id'];

        // Fetch order items with product details (for digital downloads)
        $stmt_items = $pdo->prepare("
            SELECT oi.*, p.product_type, p.digital_file_url, p.name as product_name 
            FROM order_items oi 
            JOIN products p ON oi.product_id = p.id 
            WHERE oi.order_id = ?
        ");
        $stmt_items->execute([$order_id]);
        $order_items = $stmt_items->fetchAll();

        $page_title = "ধন্যবাদ - আপনার অর্ডার সফল হয়েছে";
        
        PageHelper::load('thanks', ['title' => $page_title]);

        if ($lp) $hide_header_footer = true;
        
        include 'views/layouts/header.php';
        include 'views/pages/thanks.php';
        include 'views/layouts/footer.php';
    }

    public function orderSummaryPublic() {
        global $pdo;
        $token = OrderAccessHelper::resolveTokenFromRequest();
        if (!$token) {
            http_response_code(404);
            die('Invalid order link');
        }

        $order = OrderAccessHelper::findByToken($pdo, $token);
        if (!$order) {
            http_response_code(404);
            die('Order not found');
        }

        $order_id = (int) $order['id'];

        // Fetch Order Items
        $stmt = $pdo->prepare("SELECT oi.*, p.name as product_name FROM order_items oi JOIN products p ON oi.product_id = p.id WHERE oi.order_id = ?");
        $stmt->execute([$order_id]);
        $items = $stmt->fetchAll();

        // Site settings for logo/name
        $stmt_s = $pdo->query("SELECT key_name, value FROM settings");
        $site_settings = $stmt_s->fetchAll(PDO::FETCH_KEY_PAIR);

        include 'views/pages/order-summary-print.php';
    }

    public function orderProcess() {
        global $pdo;
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            return;
        }

        $isAjax = !empty($_SERVER['HTTP_X_REQUESTED_WITH'])
            && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest';

        if ($isAjax) {
            header('Content-Type: application/json; charset=utf-8');
        }

        if (!CsrfHelper::validate()) {
            if ($isAjax) {
                echo json_encode(['status' => 'error', 'message' => 'Invalid security token']);
                return;
            }
            header('Location: ' . BASE_URL . '/checkout?error=' . urlencode('Invalid security token'));
            exit;
        }

        try {
            $name = trim($_POST['name'] ?? '');
            $phone = trim($_POST['phone'] ?? '');
            $area = $_POST['area'] ?? 'Digital Delivery';
            $address = $_POST['address'] ?? 'Digital Product - No Shipping Required';
            $delivery_charge = floatval($_POST['delivery_charge'] ?? 0);
            $user_id = $_SESSION['user_id'] ?? null;

            if ($name === '' || $phone === '') {
                throw new InvalidArgumentException('Name and phone are required.');
            }

            $normalizedPhone = PhoneHelper::normalizeBdPhone($phone);
            if (!$normalizedPhone) {
                throw new InvalidArgumentException('সঠিক মোবাইল নাম্বার দিন (01XXXXXXXXX)');
            }
            $phone = $normalizedPhone;

            // Handle Quick Order (Directly from Product Page)
            if (isset($_POST['quick_order'])) {
                $product_id = $_POST['product_id'];
                $qty = intval($_POST['qty']);

                // Fetch product details for price validation
                $stmt_p = $pdo->prepare("SELECT name, price, offer_price FROM products WHERE id = ?");
                $stmt_p->execute([$product_id]);
                $product = $stmt_p->fetch();

                if (!$product) {
                    throw new RuntimeException('Product not found');
                }

                $price = PriceHelper::effectivePrice($product['price'], $product['offer_price'] ?? null);
                $cart_items = [
                    ['id' => $product_id, 'name' => $product['name'], 'price' => $price, 'qty' => $qty]
                ];
            } else {
                $cart_items = $_SESSION['cart'] ?? [];
            }

            if (empty($cart_items)) {
                if ($isAjax) {
                    echo json_encode(['status' => 'error', 'message' => 'Cart is empty']);
                    exit;
                }
                header('Location: ' . BASE_URL . '/cart?error=Cart is empty');
                exit;
            }

            $subtotal = 0;
            foreach ($cart_items as $item) {
                $subtotal += $item['price'] * $item['qty'];
            }
            
            // Apply Coupon Discount
            $discount = 0;
            if (isset($_SESSION['coupon']) && is_array($_SESSION['coupon'])) {
                $discount = $_SESSION['coupon']['discount'] ?? 0;
            }
            
            $total = $subtotal + $delivery_charge - $discount;
            $tracking_id = "ORD-" . strtoupper(uniqid());

            $pdo->beginTransaction();

            // 1. Insert Order - Check payment method
            $payment_method = $_POST['payment_method'] ?? 'COD';
            
            $full_address = $address . ", " . $area;
            $email = $_POST['email'] ?? null;
            $ip = $_SERVER['REMOTE_ADDR'] ?? '';
            $ua = $_SERVER['HTTP_USER_AGENT'] ?? 'Unknown';

            // Check if any product is digital
            $digital_delivery_status = 'N/A';
            $product_ids = array_column($cart_items, 'id');
            if (!empty($product_ids)) {
                $placeholders = implode(',', array_fill(0, count($product_ids), '?'));
                $stmt_digital = $pdo->prepare("SELECT COUNT(*) FROM products WHERE id IN ($placeholders) AND product_type = 'digital'");
                $stmt_digital->execute($product_ids);
                if ($stmt_digital->fetchColumn() > 0) {
                    $digital_delivery_status = 'Pending';
                }
            }

            $access_token = OrderAccessHelper::generateToken();

            $stmt = $pdo->prepare("INSERT INTO orders (user_id, customer_name, customer_phone, customer_email, shipping_address, tracking_id, total_amount, discount_amount, coupon_code, payment_method, payment_status, order_status, ip_address, user_agent, digital_delivery_status, access_token) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'Pending', 'Pending', ?, ?, ?, ?)");
            $stmt->execute([$user_id, $name, $phone, $email, $full_address, $tracking_id, $total, $discount, ($_SESSION['coupon']['code'] ?? null), $payment_method, $ip, $ua, $digital_delivery_status, $access_token]);
            $order_id = $pdo->lastInsertId();

            // 2. Insert Order Items
            $stmt_item = $pdo->prepare("INSERT INTO order_items (order_id, product_id, qty, price, variant_id, variant_label) VALUES (?, ?, ?, ?, ?, ?)");
            foreach ($cart_items as $item) {
                $stmt_item->execute([
                    $order_id,
                    $item['id'],
                    $item['qty'],
                    $item['price'],
                    $item['variant_id'] ?? null,
                    $item['variant_label'] ?? null
                ]);
            }

            $pdo->commit();

            try {
                require_once __DIR__ . '/../Helpers/CacheHelper.php';
                CacheHelper::forget('home_top_products');
                CacheHelper::forget('recent_sales_popup');
            } catch (Throwable $e) {
                // Non-blocking
            }

            try {
                require_once __DIR__ . '/../Services/AbandonedCartService.php';
                (new AbandonedCartService($pdo))->markRecovered($phone, (int) $order_id);
            } catch (Throwable $e) {
                // Non-blocking
            }

            // Server-side Tracking: Purchase
            try {
                require_once __DIR__ . '/../Services/TrackingService.php';
                $trackingService = new TrackingService();
                $userData = TrackingService::buildUserData($email, $phone, $name);
                $userData['client_ip_address'] = $ip;
                $userData['client_user_agent'] = $ua;
                
                $product_ids = array_column($cart_items, 'id');
                $customData = [
                    'value' => $total,
                    'currency' => 'BDT',
                    'content_ids' => $product_ids,
                    'content_type' => 'product',
                    'num_items' => count($cart_items)
                ];
                $eventId = 'pur_' . $order_id;
                $trackingService->fireEvent('Purchase', $userData, $customData, $eventId);
            } catch (Throwable $e) {
                // Silently ignore tracking failures
            }
            
            // --- SMS Notification for Order Placed ---
            try {
                require_once __DIR__ . '/../Helpers/SmsHelper.php';
                $smsHelper = new \App\Helpers\SmsHelper($pdo);
                $smsHelper->sendOrderPlacedSms([
                    'id' => $order_id,
                    'customer_name' => $name,
                    'customer_phone' => $phone,
                    'total_amount' => $total,
                    'tracking_id' => $tracking_id
                ]);
            } catch (Throwable $e) {
                // Silently fail if SMS fails
            }

            // Only clear full cart if not a Quick Order
            if (!isset($_POST['quick_order'])) {
                $_SESSION['cart'] = []; 
            }
            
            // Clear coupon
            unset($_SESSION['coupon']);
            
            // Determine redirect based on payment method
            if ($payment_method === 'Online') {
                // Store order info in session for payment gateway
                $_SESSION['pending_payment'] = [
                    'order_id' => $order_id,
                    'amount' => $total,
                    'customer_name' => $name,
                    'customer_phone' => $phone,
                    'tracking_id' => $tracking_id
                ];
                
                // Check if Zinipay (automated gateway) is available and should be used
                try {
                    require_once __DIR__ . '/../Services/PaymentGateway.php';
                    $pgService = new PaymentGateway($pdo);
                    $zinipayMethod = $pgService->getMethodBySlug('zinipay');
                    
                    if ($zinipayMethod && $zinipayMethod['is_active'] && $zinipayMethod['type'] === 'payment_gateway') {
                        // Create a transaction record for Zinipay
                        $txResult = $pgService->createTransaction([
                            'order_id' => $order_id,
                            'payment_method_id' => $zinipayMethod['id'],
                            'customer_name' => $name,
                            'customer_phone' => $phone,
                            'amount' => $total
                        ]);
                        
                        // Call Zinipay API to generate payment URL
                        $zinipayResult = $pgService->createZinipayPayment($total, $txResult['invoice_id'], [
                            'order_id' => (string) $order_id,
                            'tracking_id' => $tracking_id,
                            'customer_phone' => $phone,
                            'customer_name' => $name,
                            'customer_email' => (!empty($email) && filter_var($email, FILTER_VALIDATE_EMAIL)) ? $email : 'customer@khatirajbd.com'
                        ]);
                        
                        if ($zinipayResult && $zinipayResult['success']) {
                            // Store Zinipay-specific data in session
                            $_SESSION['pending_payment']['zinipay_invoice'] = $txResult['invoice_id'];
                            $_SESSION['pending_payment']['payment_method'] = 'zinipay';
                            $redirect_url = $zinipayResult['payment_url'];
                        } else {
                            // Fallback to manual payment gateway
                            $redirect_url = BASE_URL . '/payment-gateway?order_id=' . $order_id;
                        }
                    } else {
                        // No Zinipay or not active, use manual payment gateway
                        $redirect_url = BASE_URL . '/payment-gateway?order_id=' . $order_id;
                    }
                } catch (Throwable $e) {
                    // If Zinipay fails, fallback to manual payment gateway
                    $_SESSION['payment_error'] = (strpos($e->getMessage(), 'Zinipay error:') !== false) ? $e->getMessage() : 'পেমেন্ট গেটওয়েতে সমস্যা হয়েছে। অনুগ্রহ করে ম্যানুয়াল ভাবে ট্রানজেকশন দিন।'; 
                    $redirect_url = BASE_URL . '/payment-gateway?order_id=' . $order_id;
                }
            } else {
                $redirect_url = OrderAccessHelper::thanksUrl($access_token);
            }
            
            if ($isAjax) {
                echo json_encode(['status' => 'success', 'redirect' => $redirect_url]);
                exit;
            }
            
            header('Location: ' . $redirect_url);
            exit;

        } catch (Throwable $e) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }

            error_log('Checkout orderProcess error: ' . $e->getMessage());

            if ($isAjax) {
                echo json_encode([
                    'status' => 'error',
                    'message' => 'Order could not be placed. Please try again.'
                ]);
                exit;
            }

            $referer = $_SERVER['HTTP_REFERER'] ?? (BASE_URL . '/checkout');
            header('Location: ' . $referer . '?error=' . urlencode('Order could not be placed. Please try again.'));
            exit;
        }
    }

    /**
     * Handle Zinipay success callback
     * Customer is redirected here after successful payment on Zinipay portal
     */
    public function zinipaySuccess() {
        global $pdo;
        
        $zinipayInvoiceId = $_GET['invoiceId'] ?? null;
        $pending = $_SESSION['pending_payment'] ?? null;
        
        if (!$zinipayInvoiceId) {
            header('Location: ' . BASE_URL . '/home');
            exit;
        }
        
        try {
            require_once 'app/Services/PaymentGateway.php';
            $pgService = new PaymentGateway($pdo);
            
            // Verify payment with Zinipay API
            $verifyResult = $pgService->verifyZinipayPayment($zinipayInvoiceId);
            
            // Check if payment is completed
            $isCompleted = false;
            $transactionId = '';
            
            if (isset($verifyResult['status']) && strtoupper($verifyResult['status']) === 'COMPLETED') {
                $isCompleted = true;
                $transactionId = $verifyResult['transaction_id'] ?? '';
            }
            
            // Find the matching transaction by looking up metadata or invoice
            // The invoiceId from Zinipay callback maps to our internal invoice_id
            $internalInvoice = $pending['zinipay_invoice'] ?? null;
            $orderId = $pending['order_id'] ?? null;
            
            if ($internalInvoice) {
                $transaction = $pgService->getTransactionByInvoice($internalInvoice);
                
                if ($transaction) {
                    if ($isCompleted) {
                        // Update transaction with Zinipay transaction ID and mark as completed
                        $stmt = $pdo->prepare("UPDATE payment_transactions SET transaction_id = ?, status = 'completed' WHERE id = ?");
                        $stmt->execute([$transactionId, $transaction['id']]);
                        
                        // This will also update the order payment_status to 'Paid' and handle digital delivery
                        $pgService->updateTransactionStatus($transaction['id'], 'completed', 'Verified via Zinipay API. TxID: ' . $transactionId);
                        

                        // Clear pending payment session
                        unset($_SESSION['pending_payment']);
                        
                        // Redirect to thanks page
                        header('Location: ' . OrderAccessHelper::thanksUrlForOrder($pdo, (int) $orderId, ['payment' => 'success']));
                        exit;
                    } else {
                        // Payment not yet completed - mark as processing
                        $pgService->updateTransactionStatus($transaction['id'], 'processing', 'Zinipay status: ' . ($verifyResult['status'] ?? 'unknown'));
                        
                        // Still redirect to thanks but with pending status
                        unset($_SESSION['pending_payment']);
                        header('Location: ' . OrderAccessHelper::thanksUrlForOrder($pdo, (int) $orderId, ['payment' => 'pending']));
                        exit;
                    }
                }
            }
            
            // Fallback: if we can't find the transaction, redirect to thanks with order_id from session
            if ($orderId) {
                unset($_SESSION['pending_payment']);
                header('Location: ' . OrderAccessHelper::thanksUrlForOrder($pdo, (int) $orderId, ['payment' => 'pending']));
                exit;
            }
            
            header('Location: ' . BASE_URL . '/home');
            exit;
            
        } catch (Exception $e) {
            // On error, redirect to thanks with pending status so admin can verify manually
            $orderId = $pending['order_id'] ?? null;
            if ($orderId) {
                unset($_SESSION['pending_payment']);
                header('Location: ' . OrderAccessHelper::thanksUrlForOrder($pdo, (int) $orderId, ['payment' => 'pending']));
                exit;
            }
            header('Location: ' . BASE_URL . '/home');
            exit;
        }
    }

    /**
     * Handle Zinipay cancel callback
     * Customer is redirected here after cancelling payment on Zinipay portal
     */
    public function zinipayCancel() {
        global $pdo;
        
        $zinipayInvoiceId = $_GET['invoiceId'] ?? null;
        $pending = $_SESSION['pending_payment'] ?? null;
        $orderId = $pending['order_id'] ?? null;
        
        try {
            if ($pending && !empty($pending['zinipay_invoice'])) {
                require_once 'app/Services/PaymentGateway.php';
                $pgService = new PaymentGateway($pdo);
                
                $transaction = $pgService->getTransactionByInvoice($pending['zinipay_invoice']);
                if ($transaction) {
                    $pgService->updateTransactionStatus($transaction['id'], 'cancelled', 'Customer cancelled payment on Zinipay portal');
                }
            }
        } catch (Exception $e) {
            // Silently fail
        }
        
        if ($orderId) {
            // Redirect to payment-gateway page so user can try again with manual method
            header('Location: ' . BASE_URL . '/payment-gateway?order_id=' . $orderId);
            exit;
        }
        
        header('Location: ' . BASE_URL . '/home');
        exit;
    }
}

$controller = new CheckoutController();
require_once __DIR__ . '/../Helpers/RouteHelper.php';
$path = RouteHelper::getPath();
$controller->handleRequest($path);
