<?php
// app/Controllers/UserController.php

// Ensure user is logged in
if (!isset($_SESSION['user_logged_in']) || $_SESSION['user_logged_in'] !== true) {
    header('Location: ' . BASE_URL . '/login');
    exit;
}

$action = $path; // From index.php

switch ($action) {
    case '/dashboard':
        // Fetch User Data
        $user_id = $_SESSION['user_id'];
        $stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
        $stmt->execute([$user_id]);
        $user = $stmt->fetch();
        
        // Fetch Orders
        $stmt_orders = $pdo->prepare("SELECT * FROM orders WHERE user_id = ? ORDER BY created_at DESC");
        $stmt_orders->execute([$user_id]);
        $orders = $stmt_orders->fetchAll();
        
        $page_title = "My Dashboard - Khati Raj";
        PageHelper::load('dashboard', ['title' => $page_title]);
        require_once 'views/layouts/header.php';
        require_once 'views/pages/dashboard.php';
        require_once 'views/layouts/footer.php';
        break;
        
    case '/orders':
         // Redirect to dashboard for now, or separate page later
         header('Location: ' . BASE_URL . '/dashboard');
         break;
         
    case '/profile-update':
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $user_id = $_SESSION['user_id'];
            $name = trim($_POST['name']);
            $phone = trim($_POST['phone']); // Email usually unique/read-only or requires verify
            $address = trim($_POST['address']);
            $current_password = $_POST['current_password'];
            $new_password = $_POST['new_password'];
            
             // Validation logic could go here
            
            // Password change logic
            if (!empty($new_password)) {
                // Verify current
                $stmt = $pdo->prepare("SELECT password FROM users WHERE id = ?");
                $stmt->execute([$user_id]);
                $u = $stmt->fetch();
                
                if (password_verify($current_password, $u['password'])) {
                     $hashed = password_hash($new_password, PASSWORD_DEFAULT);
                     $stmt = $pdo->prepare("UPDATE users SET name=?, phone=?, address=?, password=? WHERE id=?");
                     $stmt->execute([$name, $phone, $address, $hashed, $user_id]);
                     $_SESSION['success'] = "Profile and password updated!";
                } else {
                    $_SESSION['error'] = "Current password incorrect.";
                }
            } else {
                $stmt = $pdo->prepare("UPDATE users SET name=?, phone=?, address=? WHERE id=?");
                $stmt->execute([$name, $phone, $address, $user_id]);
                $_SESSION['success'] = "Profile updated!";
            }
            $_SESSION['user_name'] = $name; // Update session name
            header('Location: ' . BASE_URL . '/dashboard');
        }
        break;

    case '/logout-action':
        unset($_SESSION['user_logged_in']);
        unset($_SESSION['user_id']);
        unset($_SESSION['user_email']);
        unset($_SESSION['user_name']);
        // Keep cart? Usually yes.
        header('Location: ' . BASE_URL . '/login');
        break;
}
?>
