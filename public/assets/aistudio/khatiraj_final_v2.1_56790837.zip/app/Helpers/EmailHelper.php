<?php
namespace App\Helpers;

use PDO;
use Exception;

class EmailHelper {
    private $pdo;
    private $settings = [];

    public function __construct(PDO $pdo) {
        $this->pdo = $pdo;
        $this->loadSettings();
    }

    private function loadSettings() {
        $stmt = $this->pdo->query("SELECT * FROM settings WHERE key_name LIKE 'smtp_%' OR key_name = 'email_enabled' OR key_name = 'email_digital_delivery_text'");
        while ($row = $stmt->fetch()) {
            $this->settings[$row['key_name']] = $row['value'];
        }
    }

    public function isEnabled() {
        return ($this->settings['email_enabled'] ?? '0') == '1';
    }

    public function sendDigitalDeliveryEmail($order, $items) {
        if (!$this->isEnabled()) return false;

        $customer_email = $order['customer_email'];
        if (!$customer_email) return false;

        $customer_name = $order['customer_name'] ?: 'Customer';
        $order_id = $order['tracking_id'];
        
        $download_links = "";
        foreach ($items as $item) {
            if ($item['product_type'] === 'digital' && !empty($item['digital_file_url'])) {
                $download_links .= "- " . $item['product_name'] . ": " . $item['digital_file_url'] . "\n";
            }
        }

        if (empty($download_links)) return false;

        $template = $this->settings['email_digital_delivery_text'] ?? "আস্সালামু আলাইকুম {customer_name},\n\nআপনার ডিজিটাল প্রোডাক্টের অর্ডার #{order_id} সফলভাবে সম্পন্ন হয়েছে। নিচে আপনার কাঙ্ক্ষিত প্রোডাক্টটির ডাউনলোড লিংক দেওয়া হলো:";
        
        $message_body = str_replace(
            ['{customer_name}', '{order_id}', '{download_links}'],
            [$customer_name, $order_id, ''], // Remove {download_links} placeholder from text if present
            $template
        );

        $html_items = "";
        foreach ($items as $item) {
            if ($item['product_type'] === 'digital' && !empty($item['digital_file_url'])) {
                $img_url = !empty($item['image']) ? (defined('SITE_URL') ? SITE_URL : '') . "/uploads/products/" . $item['image'] : "https://via.placeholder.com/150";
                
                // Ensure download link is absolute
                $download_url = $item['digital_file_url'];
                if (!preg_match("~^https?://~", $download_url)) {
                    $download_url = (defined('SITE_URL') ? SITE_URL : '') . "/" . ltrim($download_url, '/');
                }

                $html_items .= "
                <div style='margin-bottom: 25px; padding: 20px; border: 1px solid #eee; border-radius: 12px; background-color: #fcfcfc;'>
                    <table width='100%' cellpadding='0' cellspacing='0'>
                        <tr>
                            <td width='120' valign='top'>
                                <img src='{$img_url}' alt='{$item['product_name']}' style='width: 100px; height: 100px; object-fit: cover; border-radius: 8px;'>
                            </td>
                            <td style='padding-left: 20px;' valign='top'>
                                <h3 style='margin: 0 0 10px 0; color: #333; font-size: 18px;'>{$item['product_name']}</h3>
                                <p style='margin: 0 0 15px 0; color: #666; font-size: 14px;'>আপনার ডিজিটাল প্রোডাক্টটি নিচের বাটনে ক্লিক করে ডাউনলোড করুন।</p>
                                <a href='{$download_url}' style='display: inline-block; padding: 12px 25px; background-color: #e63946; color: #ffffff; text-decoration: none; border-radius: 30px; font-weight: bold; font-size: 14px; box-shadow: 0 4px 6px rgba(230, 57, 70, 0.2);'>
                                    Download Now
                                </a>
                            </td>
                        </tr>
                    </table>
                </div>";
            }
        }

        $subject = "Your Download Links - Order #{$order_id}";

        $email_html = "
        <!DOCTYPE html>
        <html>
        <head>
            <meta charset='UTF-8'>
            <style>
                body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; line-height: 1.6; color: #444; margin: 0; padding: 0; }
                .container { max-width: 600px; margin: 20px auto; padding: 0; border: 1px solid #eee; border-radius: 15px; overflow: hidden; box-shadow: 0 10px 30px rgba(0,0,0,0.05); }
                .header { background: linear-gradient(135deg, #e63946 0%, #d62828 100%); padding: 40px 20px; text-align: center; color: white; }
                .content { padding: 30px 25px; background: white; }
                .footer { background: #f8f9fa; padding: 20px; text-align: center; font-size: 12px; color: #888; border-top: 1px solid #eee; }
                .btn { display: inline-block; padding: 12px 25px; background-color: #e63946; color: white; text-decoration: none; border-radius: 5px; font-weight: bold; }
            </style>
        </head>
        <body>
            <div class='container'>
                <div class='header'>
                    <h1 style='margin: 0; font-size: 24px; text-transform: uppercase; letter-spacing: 2px;'>Download Ready</h1>
                </div>
                <div class='content'>
                    <p style='font-size: 16px; margin-bottom: 25px;'>".nl2br(htmlspecialchars($message_body))."</p>
                    {$html_items}
                    <div style='margin-top: 30px; padding: 20px; background-color: #fff9f9; border-left: 4px solid #e63946; border-radius: 4px;'>
                        <p style='margin: 0; font-size: 14px; color: #555;'>যদি কোনো সমস্যা হয়, তবে আমাদের ফেসবুক পেজ অথবা সরাসরি যোগাযোগ করুন।</p>
                    </div>
                </div>
                <div class='footer'>
                    <p style='margin: 0;'>© ".date('Y')." Khati Raj BD. All rights reserved.</p>
                </div>
            </div>
        </body>
        </html>";

        $result = $this->sendSmtpEmail($customer_email, $subject, $email_html, true);

        if ($result) {
            $stmt = $this->pdo->prepare("UPDATE orders SET digital_delivery_status = 'Sent', digital_delivery_at = NOW() WHERE id = ?");
            $stmt->execute([$order['id']]);
        } else {
            $stmt = $this->pdo->prepare("UPDATE orders SET digital_delivery_status = 'Failed' WHERE id = ?");
            $stmt->execute([$order['id']]);
        }

        return $result;
    }

    public function sendPasswordResetEmail($to, $name, $reset_url, $isAdmin = false) {
        if (!$this->isEnabled()) return false;

        $subject = "Password Reset Request - " . ($isAdmin ? "Admin Panel" : "Khati Raj BD");
        
        $email_html = "
        <!DOCTYPE html>
        <html>
        <head>
            <meta charset='UTF-8'>
            <style>
                body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; line-height: 1.6; color: #444; margin: 0; padding: 0; }
                .container { max-width: 600px; margin: 20px auto; padding: 0; border: 1px solid #eee; border-radius: 15px; overflow: hidden; box-shadow: 0 10px 30px rgba(0,0,0,0.05); }
                .header { background: linear-gradient(135deg, #e63946 0%, #d62828 100%); padding: 30px 20px; text-align: center; color: white; }
                .content { padding: 30px 25px; background: white; text-align: center; }
                .footer { background: #f8f9fa; padding: 20px; text-align: center; font-size: 12px; color: #888; border-top: 1px solid #eee; }
                .btn { display: inline-block; padding: 15px 30px; background-color: #e63946; color: white !important; text-decoration: none; border-radius: 30px; font-weight: bold; margin: 20px 0; }
            </style>
        </head>
        <body>
            <div class='container'>
                <div class='header'>
                    <h1 style='margin: 0; font-size: 20px; text-transform: uppercase; letter-spacing: 2px;'>Password Reset</h1>
                </div>
                <div class='content'>
                    <h2 style='color: #333;'>Hello {$name},</h2>
                    <p style='font-size: 16px; color: #666;'>We received a request to reset your password. If you didn't make this request, you can safely ignore this email.</p>
                    <p style='font-size: 16px; color: #666;'>To reset your password, click the button below:</p>
                    <a href='{$reset_url}' class='btn'>Reset Password</a>
                    <p style='font-size: 14px; color: #888; margin-top: 20px;'>This link will expire in 1 hour.</p>
                    <hr style='border: 0; border-top: 1px solid #eee; margin: 30px 0;'>
                    <p style='font-size: 12px; color: #aaa;'>If the button doesn't work, copy and paste this link into your browser:<br>{$reset_url}</p>
                </div>
                <div class='footer'>
                    <p style='margin: 0;'>© ".date('Y')." Khati Raj BD. All rights reserved.</p>
                </div>
            </div>
        </body>
        </html>";

        return $this->sendSmtpEmail($to, $subject, $email_html, true);
    }

    private function sendSmtpEmail($to, $subject, $body, $isHtml = false) {
        $host = $this->settings['smtp_host'] ?? 'smtp.gmail.com';
        $port = intval($this->settings['smtp_port'] ?? 587);
        $user = $this->settings['smtp_user'] ?? '';
        $pass = $this->settings['smtp_pass'] ?? '';
        $encryption = $this->settings['smtp_encryption'] ?? 'tls';

        if (empty($user) || empty($pass)) {
            error_log("SMTP Error: Username or Password not configured.");
            return false;
        }

        try {
            $timeout = 15;
            $errno = 0;
            $errstr = '';

            $socket_host = ($encryption === 'ssl' ? 'ssl://' : '') . $host;
            $socket = @fsockopen($socket_host, $port, $errno, $errstr, $timeout);

            if (!$socket) {
                throw new Exception("Could not connect to SMTP host $socket_host:$port. Error: $errstr ($errno)");
            }

            $this->getResponse($socket); // 220

            fwrite($socket, "EHLO " . ($_SERVER['SERVER_NAME'] ?: 'localhost') . "\r\n");
            $this->getResponse($socket); // 250

            if ($encryption === 'tls') {
                fwrite($socket, "STARTTLS\r\n");
                $this->getResponse($socket); // 220
                if (!stream_socket_enable_crypto($socket, true, STREAM_CRYPTO_METHOD_ANY_CLIENT)) {
                    throw new Exception("Failed to start TLS encryption on $host");
                }
                fwrite($socket, "EHLO " . ($_SERVER['SERVER_NAME'] ?: 'localhost') . "\r\n");
                $this->getResponse($socket); // 250
            }

            fwrite($socket, "AUTH LOGIN\r\n");
            $this->getResponse($socket); // 334

            fwrite($socket, base64_encode($user) . "\r\n");
            $this->getResponse($socket); // 334

            fwrite($socket, base64_encode($pass) . "\r\n");
            $this->getResponse($socket); // 235

            fwrite($socket, "MAIL FROM:<$user>\r\n");
            $this->getResponse($socket); // 250

            fwrite($socket, "RCPT TO:<$to>\r\n");
            $this->getResponse($socket); // 250

            fwrite($socket, "DATA\r\n");
            $this->getResponse($socket); // 354

            $contentType = $isHtml ? "text/html" : "text/plain";
            $headers = "MIME-Version: 1.0\r\n";
            $headers .= "Content-Type: $contentType; charset=UTF-8\r\n";
            $headers .= "From: Khati Raj BD <$user>\r\n";
            $headers .= "To: $to\r\n";
            $headers .= "Subject: =?UTF-8?B?" . base64_encode($subject) . "?=\r\n";
            $headers .= "Date: " . date('r') . "\r\n";
            $headers .= "X-Mailer: PHP/" . phpversion() . "\r\n";

            fwrite($socket, $headers . "\r\n" . $body . "\r\n.\r\n");
            $this->getResponse($socket); // 250

            fwrite($socket, "QUIT\r\n");
            fclose($socket);

            return true;
        } catch (Exception $e) {
            error_log("SMTP Error: " . $e->getMessage());
            return false;
        }
    }

    private function getResponse($socket) {
        $response = "";
        while ($line = fgets($socket, 512)) {
            $response .= $line;
            if (substr($line, 3, 1) === ' ') break;
        }
        $code = (int)substr($response, 0, 3);
        if ($code >= 400) throw new Exception("SMTP Error: $response");
        return $response;
    }
}
