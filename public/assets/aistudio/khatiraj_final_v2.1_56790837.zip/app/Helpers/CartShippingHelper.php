<?php
// app/Helpers/CartShippingHelper.php

class CartShippingHelper
{
    public static function getProductIds(array $cartItems): array
    {
        $ids = [];
        foreach ($cartItems as $item) {
            if (!empty($item['id'])) {
                $ids[] = (int) $item['id'];
            }
        }
        return array_values(array_unique($ids));
    }

    public static function getCommonZoneIds(PDO $pdo, array $cartItems): ?array
    {
        $productIds = self::getProductIds($cartItems);
        if (empty($productIds)) {
            return null;
        }

        $placeholders = implode(',', array_fill(0, count($productIds), '?'));
        $stmt = $pdo->prepare("SELECT product_id, shipping_zone_id FROM product_shipping_zones WHERE product_id IN ($placeholders)");
        $stmt->execute($productIds);
        $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

        $zonesByProduct = [];
        foreach ($rows as $row) {
            $zonesByProduct[(int) $row['product_id']][] = (int) $row['shipping_zone_id'];
        }

        $commonZoneIds = null;
        foreach ($productIds as $productId) {
            $productZones = $zonesByProduct[$productId] ?? [];
            if (empty($productZones)) {
                continue;
            }
            if ($commonZoneIds === null) {
                $commonZoneIds = $productZones;
            } else {
                $commonZoneIds = array_values(array_intersect($commonZoneIds, $productZones));
            }
        }

        return $commonZoneIds;
    }

    public static function getShippingZones(PDO $pdo, ?array $commonZoneIds): array
    {
        if ($commonZoneIds !== null && !empty($commonZoneIds)) {
            $placeholders = implode(',', array_fill(0, count($commonZoneIds), '?'));
            $stmt = $pdo->prepare("SELECT * FROM shipping_zones WHERE id IN ($placeholders) AND status = 1");
            $stmt->execute(array_values($commonZoneIds));
            return $stmt->fetchAll();
        }

        return $pdo->query("SELECT * FROM shipping_zones WHERE status = 1")->fetchAll();
    }

    public static function getExtraShippingTotal(PDO $pdo, array $cartItems): float
    {
        $productIds = self::getProductIds($cartItems);
        if (empty($productIds)) {
            return 0.0;
        }

        $placeholders = implode(',', array_fill(0, count($productIds), '?'));
        $stmt = $pdo->prepare("
            SELECT p.id, COALESCE(sc.extra_charge, 0) AS extra_charge
            FROM products p
            LEFT JOIN shipping_classes sc ON p.shipping_class_id = sc.id AND sc.status = 1
            WHERE p.id IN ($placeholders)
        ");
        $stmt->execute($productIds);
        $extraByProduct = [];
        foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) as $row) {
            $extraByProduct[(int) $row['id']] = (float) $row['extra_charge'];
        }

        $total = 0.0;
        foreach ($cartItems as $item) {
            $pid = (int) ($item['id'] ?? 0);
            $qty = (int) ($item['qty'] ?? 1);
            $total += ($extraByProduct[$pid] ?? 0) * $qty;
        }

        return $total;
    }

    public static function isAllDigital(PDO $pdo, array $cartItems): bool
    {
        $productIds = self::getProductIds($cartItems);
        if (empty($productIds)) {
            return false;
        }

        $placeholders = implode(',', array_fill(0, count($productIds), '?'));
        $stmt = $pdo->prepare("SELECT id, product_type FROM products WHERE id IN ($placeholders)");
        $stmt->execute($productIds);
        $types = $stmt->fetchAll(PDO::FETCH_KEY_PAIR);

        foreach ($productIds as $productId) {
            if (($types[$productId] ?? '') !== 'digital') {
                return false;
            }
        }

        return true;
    }
}
