<?php
// app/Helpers/SeoHelper.php
declare(strict_types=1);

final class SeoHelper
{
    private static ?array $pageData = null;
    private static array $defaults = [];

    /**
     * Set page-level SEO data coming from the page_registry table (admin managed).
     */
    public static function setPageData(array $pageData): void
    {
        self::$pageData = $pageData;
    }

    /**
     * Set controller/view fallback defaults.
     * Keys: title, description, keywords, og_image, canonical
     */
    public static function setDefaults(array $defaults): void
    {
        // Merge so repeated calls do not wipe previously set values
        self::$defaults = array_merge(self::$defaults, array_filter(
            $defaults,
            static fn($v) => $v !== null && $v !== ''
        ));
    }

    public static function reset(): void
    {
        self::$pageData = null;
        self::$defaults = [];
    }

    public static function getMetaTitle(): string
    {
        global $site_settings;
        $title = '';

        if (self::$pageData && !empty(self::$pageData['meta_title'])) {
            $title = self::$pageData['meta_title'];
        } elseif (self::$pageData && !empty(self::$pageData['title'])) {
            $title = self::$pageData['title'];
        } elseif (!empty(self::$defaults['title'])) {
            $title = self::$defaults['title'];
        } elseif (self::$pageData && !empty(self::$pageData['h1_title'])) {
            $title = self::$pageData['h1_title'];
        } elseif (self::$pageData && !empty(self::$pageData['page_name'])) {
            $title = self::$pageData['page_name'];
        } elseif (isset($GLOBALS['meta_title']) && $GLOBALS['meta_title'] !== '') {
            $title = $GLOBALS['meta_title'];
        } elseif (isset($GLOBALS['page_title']) && $GLOBALS['page_title'] !== '') {
            $title = $GLOBALS['page_title'];
        } else {
            $title = $site_settings['site_name'] ?? 'Khati Raj';
        }

        $suffix = $site_settings['global_meta_title_suffix'] ?? '';
        if ($suffix !== '' && strpos($title, $suffix) === false) {
            $title .= ' ' . $suffix;
        }

        return $title;
    }

    public static function getMetaDescription(): string
    {
        global $site_settings;

        if (self::$pageData && !empty(self::$pageData['meta_description'])) {
            return self::$pageData['meta_description'];
        }
        if (!empty(self::$defaults['description'])) {
            return self::$defaults['description'];
        }
        if (isset($GLOBALS['meta_description']) && $GLOBALS['meta_description'] !== '') {
            return $GLOBALS['meta_description'];
        }
        return $site_settings['global_meta_description'] ?? '';
    }

    public static function getMetaKeywords(): string
    {
        global $site_settings;

        if (self::$pageData && !empty(self::$pageData['meta_keywords'])) {
            return self::$pageData['meta_keywords'];
        }
        if (!empty(self::$defaults['keywords'])) {
            return self::$defaults['keywords'];
        }
        if (isset($GLOBALS['meta_keywords']) && $GLOBALS['meta_keywords'] !== '') {
            return $GLOBALS['meta_keywords'];
        }
        return $site_settings['global_meta_keywords'] ?? '';
    }

    public static function getOgImage(): string
    {
        global $site_settings;

        if (self::$pageData && !empty(self::$pageData['og_image'])) {
            return SITE_URL . '/' . ltrim(self::$pageData['og_image'], '/');
        }
        if (isset($GLOBALS['product']['image']) && $GLOBALS['product']['image'] !== '') {
            return SITE_URL . '/' . ltrim($GLOBALS['product']['image'], '/');
        }
        if (!empty(self::$defaults['og_image'])) {
            return SITE_URL . '/' . ltrim(self::$defaults['og_image'], '/');
        }
        if (isset($GLOBALS['og_image']) && $GLOBALS['og_image'] !== '') {
            return SITE_URL . '/' . ltrim($GLOBALS['og_image'], '/');
        }
        if (!empty($site_settings['global_og_image'])) {
            return SITE_URL . '/' . ltrim($site_settings['global_og_image'], '/');
        }
        if (!empty($site_settings['site_logo'])) {
            return SITE_URL . '/' . ltrim($site_settings['site_logo'], '/');
        }
        return '';
    }

    /**
     * Resolve canonical URL. Uses admin override when present, otherwise the
     * current request URL with the query string stripped.
     */
    public static function getCanonical(): string
    {
        if (self::$pageData && !empty(self::$pageData['canonical_override'])) {
            return self::$pageData['canonical_override'];
        }
        if (!empty(self::$defaults['canonical'])) {
            return self::$defaults['canonical'];
        }
        $scheme = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on') ? 'https' : 'http';
        $host = $_SERVER['HTTP_HOST'] ?? 'localhost';
        $uri = $_SERVER['REQUEST_URI'] ?? '';
        return strtok($scheme . '://' . $host . $uri, '?');
    }
}
