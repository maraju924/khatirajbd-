<?php
// app/Helpers/LanguageHelper.php

class LanguageHelper {
    private static $translations = [];
    private static $current_lang = 'bn';

    public static function init() {
        if (!isset($_SESSION['lang'])) {
            // Auto detect from browser
            $browser_lang = $_SERVER['HTTP_ACCEPT_LANGUAGE'] ?? 'bn';
            if (strpos($browser_lang, 'en') !== false && strpos($browser_lang, 'en') < strpos($browser_lang, 'bn')) {
                $_SESSION['lang'] = 'en';
            } else {
                $_SESSION['lang'] = 'bn';
            }
        }

        // Handle manual override
        if (isset($_GET['lang']) && in_array($_GET['lang'], ['en', 'bn'])) {
            $_SESSION['lang'] = $_GET['lang'];
        }

        self::$current_lang = $_SESSION['lang'];
        $file = __DIR__ . '/../../languages/' . self::$current_lang . '.php';
        if (file_exists($file)) {
            self::$translations = include $file;
        }
    }

    public static function get($key) {
        return self::$translations[$key] ?? $key;
    }

    public static function getCurrentLang() {
        return self::$current_lang;
    }
}

function __($key) {
    return LanguageHelper::get($key);
}
