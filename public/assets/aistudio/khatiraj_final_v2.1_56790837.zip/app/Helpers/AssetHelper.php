<?php
// app/Helpers/AssetHelper.php

class AssetHelper
{
    public const VERSION = '2.7';

    private static ?string $root = null;

    private static function root(): string
    {
        if (self::$root === null) {
            self::$root = dirname(__DIR__, 2);
        }

        return self::$root;
    }

    public static function css(string $relativePath): string
    {
        $relativePath = ltrim($relativePath, '/');

        if ($relativePath === 'assets/css/style.css') {
            $bundle = 'assets/css/style.bundle.min.css';
            if (is_file(self::root() . '/' . $bundle)) {
                return BASE_URL . '/' . $bundle . '?v=' . self::VERSION;
            }
        }

        return self::url($relativePath);
    }

    public static function js(string $relativePath): string
    {
        return self::url($relativePath);
    }

    public static function url(string $relativePath): string
    {
        $relativePath = ltrim($relativePath, '/');
        $ext = pathinfo($relativePath, PATHINFO_EXTENSION);
        $minRelative = preg_replace('/\.' . preg_quote($ext, '/') . '$/', '.min.' . $ext, $relativePath);
        $usePath = is_file(self::root() . '/' . $minRelative) ? $minRelative : $relativePath;

        return BASE_URL . '/' . $usePath . '?v=' . self::VERSION;
    }
}
