<?php
// app/Helpers/ProductVariantHelper.php

class ProductVariantHelper
{
    private static function tableExists(PDO $pdo, string $table): bool
    {
        $stmt = $pdo->prepare('SHOW TABLES LIKE ?');
        $stmt->execute([$table]);
        return (bool) $stmt->fetchColumn();
    }

    private static function columnExists(PDO $pdo, string $table, string $column): bool
    {
        if (!self::tableExists($pdo, $table)) {
            return false;
        }
        $stmt = $pdo->prepare("SHOW COLUMNS FROM `$table` LIKE ?");
        $stmt->execute([$column]);
        return (bool) $stmt->fetch(PDO::FETCH_ASSOC);
    }

    public static function ensureTables(PDO $pdo): void
    {
        try {
            if (!self::tableExists($pdo, 'product_variant_attributes')) {
                $pdo->exec("CREATE TABLE IF NOT EXISTS product_variant_attributes (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    product_id INT NOT NULL,
                    name VARCHAR(100) NOT NULL,
                    display_type ENUM('button', 'color') DEFAULT 'button',
                    sort_order INT DEFAULT 0,
                    INDEX (product_id)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
            }

            if (!self::tableExists($pdo, 'product_variant_attribute_values')) {
                $pdo->exec("CREATE TABLE IF NOT EXISTS product_variant_attribute_values (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    attribute_id INT NOT NULL,
                    value VARCHAR(100) NOT NULL,
                    color_hex VARCHAR(7) NULL,
                    sort_order INT DEFAULT 0,
                    INDEX (attribute_id)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
            }

            if (!self::tableExists($pdo, 'product_variants')) {
                $pdo->exec("CREATE TABLE IF NOT EXISTS product_variants (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    product_id INT NOT NULL,
                    sku VARCHAR(100) NULL,
                    combination_json TEXT NOT NULL,
                    price DECIMAL(10,2) NULL,
                    offer_price DECIMAL(10,2) NULL,
                    quantity INT DEFAULT 0,
                    stock_status VARCHAR(50) DEFAULT 'In Stock',
                    sort_order INT DEFAULT 0,
                    INDEX (product_id)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
            }

            if (self::tableExists($pdo, 'order_items')) {
                if (!self::columnExists($pdo, 'order_items', 'variant_id')) {
                    $pdo->exec('ALTER TABLE order_items ADD COLUMN variant_id INT NULL DEFAULT NULL');
                }
                if (!self::columnExists($pdo, 'order_items', 'variant_label')) {
                    $pdo->exec('ALTER TABLE order_items ADD COLUMN variant_label VARCHAR(255) NULL DEFAULT NULL');
                }
            }
        } catch (PDOException $e) {
            // Shared hosting may block DDL — page should still load if tables exist.
        }
    }

    public static function loadForProduct(PDO $pdo, int $productId): array
    {
        if (!self::tableExists($pdo, 'product_variant_attributes')) {
            return ['enabled' => false, 'attributes' => [], 'variants' => []];
        }

        $stmt = $pdo->prepare("SELECT * FROM product_variant_attributes WHERE product_id = ? ORDER BY sort_order ASC, id ASC");
        $stmt->execute([$productId]);
        $attributes = $stmt->fetchAll(PDO::FETCH_ASSOC);

        $resultAttributes = [];
        $attributeIds = array_map(static fn($attr) => (int) $attr['id'], $attributes);
        $valuesByAttribute = [];

        if (!empty($attributeIds)) {
            $placeholders = implode(',', array_fill(0, count($attributeIds), '?'));
            $valueStmt = $pdo->prepare("SELECT * FROM product_variant_attribute_values WHERE attribute_id IN ($placeholders) ORDER BY sort_order ASC, id ASC");
            $valueStmt->execute($attributeIds);
            foreach ($valueStmt->fetchAll(PDO::FETCH_ASSOC) as $value) {
                $valuesByAttribute[(int) $value['attribute_id']][] = $value;
            }
        }

        foreach ($attributes as $attr) {
            $values = $valuesByAttribute[(int) $attr['id']] ?? [];
            $resultAttributes[] = [
                'id' => (int) $attr['id'],
                'name' => $attr['name'],
                'display_type' => $attr['display_type'] ?: 'button',
                'values' => array_map(static function ($value) {
                    return [
                        'id' => (int) $value['id'],
                        'value' => $value['value'],
                        'color_hex' => $value['color_hex'],
                    ];
                }, $values),
            ];
        }

        $variantStmt = $pdo->prepare("SELECT * FROM product_variants WHERE product_id = ? ORDER BY sort_order ASC, id ASC");
        $variantStmt->execute([$productId]);
        $variants = $variantStmt->fetchAll(PDO::FETCH_ASSOC);

        $resultVariants = [];
        foreach ($variants as $variant) {
            $combination = json_decode($variant['combination_json'], true);
            if (!is_array($combination)) {
                $combination = [];
            }

            $resultVariants[] = [
                'id' => (int) $variant['id'],
                'sku' => $variant['sku'],
                'combination' => $combination,
                'price' => $variant['price'] !== null ? (float) $variant['price'] : null,
                'offer_price' => $variant['offer_price'] !== null ? (float) $variant['offer_price'] : null,
                'quantity' => (int) $variant['quantity'],
                'stock_status' => $variant['stock_status'] ?: 'In Stock',
            ];
        }

        return [
            'enabled' => !empty($resultAttributes),
            'attributes' => $resultAttributes,
            'variants' => $resultVariants,
        ];
    }

    public static function getVariantById(PDO $pdo, int $variantId): ?array
    {
        if (!self::tableExists($pdo, 'product_variants')) {
            return null;
        }

        $stmt = $pdo->prepare("SELECT * FROM product_variants WHERE id = ?");
        $stmt->execute([$variantId]);
        $variant = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$variant) {
            return null;
        }

        $combination = json_decode($variant['combination_json'], true);
        if (!is_array($combination)) {
            $combination = [];
        }

        $variant['combination'] = $combination;
        $variant['label'] = self::formatCombinationLabel($combination);

        return $variant;
    }

    public static function formatCombinationLabel(array $combination): string
    {
        $parts = [];
        foreach ($combination as $name => $value) {
            $parts[] = $name . ': ' . $value;
        }

        return implode(', ', $parts);
    }

    public static function getOrderItemLabel(array $item): string
    {
        return trim((string) ($item['product_name'] ?? $item['name'] ?? ''));
    }

    public static function getOrderItemVariant(array $item): ?string
    {
        $label = trim((string) ($item['variant_label'] ?? ''));
        return $label !== '' ? $label : null;
    }

    public static function saveFromPost(PDO $pdo, int $productId, array $post): void
    {
        self::ensureTables($pdo);
        self::deleteForProduct($pdo, $productId);

        if (empty($post['enable_variants'])) {
            return;
        }

        if (empty($post['variant_attrs']) || !is_array($post['variant_attrs'])) {
            return;
        }

        $attrStmt = $pdo->prepare("INSERT INTO product_variant_attributes (product_id, name, display_type, sort_order) VALUES (?, ?, ?, ?)");
        $valueStmt = $pdo->prepare("INSERT INTO product_variant_attribute_values (attribute_id, value, color_hex, sort_order) VALUES (?, ?, ?, ?)");
        $variantStmt = $pdo->prepare("INSERT INTO product_variants (product_id, sku, combination_json, price, offer_price, quantity, stock_status, sort_order) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");

        $attrOrder = 1;
        foreach ($post['variant_attrs'] as $attr) {
            $attrName = trim($attr['name'] ?? '');
            if ($attrName === '') {
                continue;
            }

            $displayType = ($attr['display_type'] ?? 'button') === 'color' ? 'color' : 'button';
            $attrStmt->execute([$productId, $attrName, $displayType, $attrOrder++]);
            $attributeId = (int) $pdo->lastInsertId();

            if (empty($attr['values']) || !is_array($attr['values'])) {
                continue;
            }

            $valueOrder = 1;
            foreach ($attr['values'] as $idx => $value) {
                $value = trim($value);
                if ($value === '') {
                    continue;
                }

                $colorHex = null;
                if ($displayType === 'color' && !empty($attr['colors'][$idx])) {
                    $colorHex = trim($attr['colors'][$idx]);
                    if ($colorHex !== '' && $colorHex[0] !== '#') {
                        $colorHex = '#' . $colorHex;
                    }
                }

                $valueStmt->execute([$attributeId, $value, $colorHex, $valueOrder++]);
            }
        }

        if (empty($post['variants']) || !is_array($post['variants'])) {
            return;
        }

        $variantOrder = 1;
        foreach ($post['variants'] as $variant) {
            if (empty($variant['combination']) || !is_array($variant['combination'])) {
                continue;
            }

            $combination = [];
            foreach ($variant['combination'] as $attrName => $attrValue) {
                $attrName = trim((string) $attrName);
                $attrValue = trim((string) $attrValue);
                if ($attrName !== '' && $attrValue !== '') {
                    $combination[$attrName] = $attrValue;
                }
            }

            if (empty($combination)) {
                continue;
            }

            $price = isset($variant['price']) && $variant['price'] !== '' ? (float) $variant['price'] : null;
            $offerPrice = isset($variant['offer_price']) && $variant['offer_price'] !== '' ? (float) $variant['offer_price'] : null;
            $quantity = isset($variant['quantity']) && $variant['quantity'] !== '' ? (int) $variant['quantity'] : 0;
            $stockStatus = !empty($variant['stock_status']) ? $variant['stock_status'] : 'In Stock';
            $sku = !empty($variant['sku']) ? trim($variant['sku']) : null;

            $variantStmt->execute([
                $productId,
                $sku,
                json_encode($combination, JSON_UNESCAPED_UNICODE),
                $price,
                $offerPrice,
                $quantity,
                $stockStatus,
                $variantOrder++,
            ]);
        }
    }

    public static function deleteForProduct(PDO $pdo, int $productId): void
    {
        self::ensureTables($pdo);

        $attrIdsStmt = $pdo->prepare("SELECT id FROM product_variant_attributes WHERE product_id = ?");
        $attrIdsStmt->execute([$productId]);
        $attrIds = $attrIdsStmt->fetchAll(PDO::FETCH_COLUMN);

        if (!empty($attrIds)) {
            $placeholders = implode(',', array_fill(0, count($attrIds), '?'));
            $pdo->prepare("DELETE FROM product_variant_attribute_values WHERE attribute_id IN ($placeholders)")->execute($attrIds);
        }

        $pdo->prepare("DELETE FROM product_variant_attributes WHERE product_id = ?")->execute([$productId]);
        $pdo->prepare("DELETE FROM product_variants WHERE product_id = ?")->execute([$productId]);
    }

    public static function buildCartKey(int $productId, ?int $variantId = null): string
    {
        return $variantId ? ($productId . '_' . $variantId) : (string) $productId;
    }

    public static function parseCartKey(string $cartKey): array
    {
        if (strpos($cartKey, '_') !== false) {
            [$productId, $variantId] = explode('_', $cartKey, 2);
            return [(int) $productId, (int) $variantId];
        }

        return [(int) $cartKey, null];
    }
}
