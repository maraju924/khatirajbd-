<?php
// app/Helpers/CacheHelper.php

class CacheHelper
{
    private static function cacheDir(): string
    {
        $dir = dirname(__DIR__, 2) . '/storage/cache';
        if (!is_dir($dir)) {
            mkdir($dir, 0755, true);
        }
        return $dir;
    }

    private static function cacheFile(string $key): string
    {
        return self::cacheDir() . '/' . md5($key) . '.cache';
    }

    public static function get(string $key, int $ttl = 600)
    {
        $apcuKey = 'kr_' . $key;
        if (function_exists('apcu_fetch')) {
            $cached = apcu_fetch($apcuKey, $success);
            if ($success) {
                return $cached;
            }
        }

        $file = self::cacheFile($key);
        if (!is_file($file)) {
            return null;
        }

        $payload = @unserialize((string) file_get_contents($file));
        if (!is_array($payload) || !isset($payload['expires'], $payload['value'])) {
            @unlink($file);
            return null;
        }

        if ($payload['expires'] < time()) {
            @unlink($file);
            return null;
        }

        return $payload['value'];
    }

    public static function set(string $key, $value, int $ttl = 600): void
    {
        if (function_exists('apcu_store')) {
            apcu_store('kr_' . $key, $value, $ttl);
        }

        $payload = serialize([
            'expires' => time() + $ttl,
            'value' => $value,
        ]);
        file_put_contents(self::cacheFile($key), $payload, LOCK_EX);
    }

    public static function remember(string $key, int $ttl, callable $callback)
    {
        $cached = self::get($key, $ttl);
        if ($cached !== null) {
            return $cached;
        }

        $value = $callback();
        self::set($key, $value, $ttl);
        return $value;
    }

    public static function forget(string $key): void
    {
        if (function_exists('apcu_delete')) {
            apcu_delete('kr_' . $key);
        }
        $file = self::cacheFile($key);
        if (is_file($file)) {
            @unlink($file);
        }
    }

    public static function clearAll(): void
    {
        foreach (glob(self::cacheDir() . '/*.cache') ?: [] as $file) {
            @unlink($file);
        }
    }

    public static function invalidateSiteData(): void
    {
        self::forget('site_settings');
        self::forget('social_links');
        self::forget('menus_header');
        self::forget('tracking_settings');
        self::forget('home_top_products');
        self::forget('recent_sales_popup');
    }
}
