<?php
namespace App\Helpers;

class SmsHelper {
    private $pdo;
    private $enabled = false;
    private $provider = 'bulksmsbd';
    private $apiKey = '';
    private $senderId = '';

    public function __construct($pdo) {
        $this->pdo = $pdo;
        $this->loadSettings();
    }

    private function loadSettings() {
        $stmt = $this->pdo->query("SELECT key_name, value FROM settings WHERE key_name LIKE 'sms_%'");
        $settings = $stmt->fetchAll(\PDO::FETCH_KEY_PAIR);
        
        $this->enabled = ($settings['sms_enabled'] ?? '0') === '1';
        $this->provider = $settings['sms_provider'] ?? 'bulksmsbd';
        $this->apiKey = $settings['sms_api_key'] ?? '';
        $this->senderId = $settings['sms_sender_id'] ?? '';
    }

    public function isEnabled() {
        return $this->enabled && !empty($this->apiKey) && !empty($this->senderId);
    }

    public function sendSms($phone, $message) {
        if (!$this->isEnabled()) {
            return false;
        }

        // Clean phone number
        $phone = preg_replace('/[^0-9]/', '', $phone);
        if (strlen($phone) == 11 && str_starts_with($phone, '01')) {
            $phone = '88' . $phone;
        }

        if ($this->provider === 'bulksmsbd') {
            return $this->sendBulkSmsBd($phone, $message);
        }
        
        // Add more providers here if needed

        return false;
    }

    private function sendBulkSmsBd($number, $message) {
        $url = "http://66.45.237.70/api.php";
        $data = [
            'username' => $this->senderId, // For bulksmsbd, sender_id is often used as username or senderid depending on API
            'password' => $this->apiKey,   // and API key as password
            'number'   => $number,
            'message'  => $message
        ];

        // BulkSMSBD API uses url parameters
        $query = http_build_query($data);
        $finalUrl = $url . '?' . $query;

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $finalUrl);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_TIMEOUT, 10);
        $response = curl_exec($ch);
        curl_close($ch);

        return $response;
    }

    public function sendOrderPlacedSms($orderInfo) {
        if (!$this->isEnabled()) return false;
        
        $stmt = $this->pdo->prepare("SELECT value FROM settings WHERE key_name = 'sms_order_placed_text'");
        $stmt->execute();
        $template = $stmt->fetchColumn() ?: '';
        
        return $this->processAndSendTemplate($template, $orderInfo);
    }

    public function sendOrderStatusSms($orderInfo) {
        if (!$this->isEnabled()) return false;
        
        $status = strtolower($orderInfo['order_status'] ?? '');
        if (!in_array($status, ['shipped', 'delivered'])) {
            return false;
        }
        
        $key = "sms_order_{$status}_text";
        $stmt = $this->pdo->prepare("SELECT value FROM settings WHERE key_name = ?");
        $stmt->execute([$key]);
        $template = $stmt->fetchColumn() ?: '';
        
        return $this->processAndSendTemplate($template, $orderInfo);
    }

    private function processAndSendTemplate($template, $orderInfo) {
        if (empty($template) || empty($orderInfo['customer_phone'])) return false;

        $message = str_replace(
            ['{name}', '{order_id}', '{total}', '{tracking_id}'],
            [
                $orderInfo['customer_name'] ?? 'Customer',
                $orderInfo['id'] ?? '',
                $orderInfo['total_amount'] ?? '',
                $orderInfo['tracking_id'] ?? ''
            ],
            $template
        );

        return $this->sendSms($orderInfo['customer_phone'], $message);
    }

    public function sendAbandonedCartSms(array $cart, array $messageData) {
        if (!$this->isEnabled() || empty($cart['customer_phone'])) {
            return false;
        }

        $stmt = $this->pdo->prepare("SELECT value FROM settings WHERE key_name = 'abandoned_cart_sms_text'");
        $stmt->execute();
        $template = $stmt->fetchColumn() ?: '';

        if (empty($template)) {
            $template = 'হ্যালো {name}! {site_name}-এ আপনার কার্টে ৳{total} এর পণ্য ({products}) রয়েছে। অর্ডার করুন: {recovery_link}';
        }

        $message = str_replace(
            ['{name}', '{total}', '{products}', '{recovery_link}', '{site_name}', '{phone}'],
            [
                $messageData['name'] ?? 'Customer',
                $messageData['total'] ?? '',
                $messageData['products'] ?? '',
                $messageData['recovery_link'] ?? '',
                $messageData['site_name'] ?? '',
                $messageData['phone'] ?? '',
            ],
            $template
        );

        return $this->sendSms($cart['customer_phone'], $message);
    }
}
