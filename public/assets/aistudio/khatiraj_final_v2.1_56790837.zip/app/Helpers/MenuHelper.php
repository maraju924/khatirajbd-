<?php
// app/Helpers/MenuHelper.php

require_once __DIR__ . '/CacheHelper.php';

class MenuHelper
{
    public static function getHeaderTree(PDO $pdo): array
    {
        return CacheHelper::remember('menus_header', 900, static function () use ($pdo) {
            $rows = $pdo->query("SELECT * FROM menus WHERE status = 1 ORDER BY sort_order ASC, id ASC")->fetchAll(PDO::FETCH_ASSOC);

            $mainMenus = [];
            $subMenusByParent = [];

            foreach ($rows as $row) {
                if (!empty($row['parent_id'])) {
                    $subMenusByParent[(int) $row['parent_id']][] = $row;
                } else {
                    $mainMenus[] = $row;
                }
            }

            return [
                'main' => $mainMenus,
                'subs' => $subMenusByParent,
            ];
        });
    }

    public static function getFooterLinks(PDO $pdo): array
    {
        return CacheHelper::remember('menus_footer', 900, static function () use ($pdo) {
            return $pdo->query("SELECT * FROM menus WHERE location = 'footer' AND status = 1 ORDER BY sort_order ASC, id ASC")
                ->fetchAll(PDO::FETCH_ASSOC);
        });
    }
}
