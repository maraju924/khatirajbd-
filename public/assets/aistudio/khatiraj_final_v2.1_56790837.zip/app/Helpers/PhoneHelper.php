<?php
// app/Helpers/PhoneHelper.php

class PhoneHelper
{
    /**
     * Bangladesh mobile: 01XXXXXXXXX (11 digits).
     */
    public static function isValidBdPhone(?string $phone): bool
    {
        if ($phone === null || $phone === '') {
            return false;
        }
        $digits = preg_replace('/\D/', '', $phone);
        return (bool) preg_match('/^01\d{9}$/', $digits);
    }

    /**
     * Strip to digits; returns 11-digit local form when valid.
     */
    public static function normalizeBdPhone(?string $phone): ?string
    {
        if ($phone === null || $phone === '') {
            return null;
        }
        $digits = preg_replace('/\D/', '', $phone);
        if (strlen($digits) > 11 && str_starts_with($digits, '880')) {
            $digits = '0' . substr($digits, 3);
        }
        if (self::isValidBdPhone($digits)) {
            return $digits;
        }
        return null;
    }
}
