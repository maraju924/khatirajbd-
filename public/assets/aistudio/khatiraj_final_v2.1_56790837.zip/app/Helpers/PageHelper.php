<?php
// app/Helpers/PageHelper.php
declare(strict_types=1);

require_once __DIR__ . '/CacheHelper.php';

final class PageHelper
{
    private static ?array $currentPage = null;
    private static array $sections = [];

    /**
     * System/commerce/auth templates that are not editable in Page & SEO Manager.
     * SEO for these comes from page headers / entity-level fields (product, category, blog, etc.).
     */
    public const NON_MANAGEABLE_ROUTE_KEYS = [
        'shop',
        'category_list',
        'category_detail',
        'product_detail',
        'cart',
        'checkout',
        'payment_gateway',
        'order_summary_print',
        'login',
        'register',
        'forgot_password',
        'reset_password',
        'dashboard',
        'track_order',
        'blog_post',
        'landing_page',
        'not_found',
        // about / privacy_policy / terms_conditions / refund_policy / shipping_policy
        // are CMS content pages (seeded) — keep them manageable in Page & SEO Manager.
    ];

    public static function isManageable(string $routeKey): bool
    {
        return !in_array($routeKey, self::NON_MANAGEABLE_ROUTE_KEYS, true);
    }

    /**
     * Load a registered page by route key. Applies its SEO data to SeoHelper
     * and preloads its sections. Controller/view fallback SEO can be supplied
     * via $defaults (keys: title, description, keywords, og_image, canonical).
     */
    public static function load(string $routeKey, array $defaults = []): void
    {
        global $pdo;

        // Always register fallbacks first so they apply even if the page row is missing.
        if (!empty($defaults)) {
            SeoHelper::setDefaults($defaults);
        }

        $page = CacheHelper::remember("page_reg_{$routeKey}", 900, static function () use ($pdo, $routeKey) {
            try {
                $stmt = $pdo->prepare("SELECT * FROM page_registry WHERE route_key = ? AND status = 1");
                $stmt->execute([$routeKey]);
                return $stmt->fetch() ?: null;
            } catch (PDOException $e) {
                return null;
            }
        });

        if (!$page) {
            return;
        }

        self::$currentPage = $page;
        SeoHelper::setPageData($page);

        $pageId = (int)$page['id'];
        $sections = CacheHelper::remember("page_sections_{$pageId}", 900, static function () use ($pdo, $pageId) {
            try {
                $stmt = $pdo->prepare("SELECT * FROM page_sections WHERE page_id = ? AND status = 1 ORDER BY sort_order ASC");
                $stmt->execute([$pageId]);
                return $stmt->fetchAll();
            } catch (PDOException $e) {
                return [];
            }
        });

        self::$sections = [];
        foreach ($sections as $sec) {
            self::$sections[$sec['section_key']] = $sec;
        }
    }

    public static function getCurrentPage(): ?array
    {
        return self::$currentPage;
    }

    /**
     * Fetch a page registry row directly by route key (no SEO side effects).
     */
    public static function getByRouteKey(string $routeKey): ?array
    {
        global $pdo;
        return CacheHelper::remember("page_reg_{$routeKey}", 900, static function () use ($pdo, $routeKey) {
            try {
                $stmt = $pdo->prepare("SELECT * FROM page_registry WHERE route_key = ? AND status = 1");
                $stmt->execute([$routeKey]);
                return $stmt->fetch() ?: null;
            } catch (PDOException $e) {
                return null;
            }
        });
    }

    /**
     * Find a page by its public slug (used for custom CMS pages routing).
     */
    public static function getBySlug(string $slug): ?array
    {
        global $pdo;
        $slug = '/' . ltrim($slug, '/');
        return CacheHelper::remember("page_slug_" . md5($slug), 900, static function () use ($pdo, $slug) {
            try {
                $stmt = $pdo->prepare("SELECT * FROM page_registry WHERE slug = ? AND status = 1");
                $stmt->execute([$slug]);
                return $stmt->fetch() ?: null;
            } catch (PDOException $e) {
                return null;
            }
        });
    }

    public static function getSection(string $sectionKey): ?array
    {
        return self::$sections[$sectionKey] ?? null;
    }

    public static function getAllSections(): array
    {
        return self::$sections;
    }

    /**
     * Get a section text field with a fallback default.
     */
    public static function getText(string $sectionKey, string $field, string $default = ''): string
    {
        $section = self::getSection($sectionKey);
        if ($section && isset($section[$field]) && $section[$field] !== '' && $section[$field] !== null) {
            return (string)$section[$field];
        }
        return $default;
    }

    /**
     * Get a UI label stored inside a section's extra_json blob.
     */
    public static function getLabel(string $sectionKey, string $labelKey, string $default = ''): string
    {
        $section = self::getSection($sectionKey);
        if ($section && !empty($section['extra_json'])) {
            $data = json_decode($section['extra_json'], true);
            if (is_array($data) && isset($data[$labelKey]) && $data[$labelKey] !== '') {
                return (string)$data[$labelKey];
            }
        }
        return $default;
    }

    public static function routeExists(string $path): bool
    {
        return self::getBySlug($path) !== null;
    }
}
