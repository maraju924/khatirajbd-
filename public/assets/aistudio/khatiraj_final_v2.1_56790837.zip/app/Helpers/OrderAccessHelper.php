<?php
/**
 * Secure public access tokens for order thank-you & summary pages.
 */
class OrderAccessHelper
{
    public static function generateToken(): string
    {
        return bin2hex(random_bytes(32));
    }

    public static function thanksUrl(string $token, array $query = []): string
    {
        $url = BASE_URL . '/thanks/' . $token;
        if (!empty($query)) {
            $url .= '?' . http_build_query($query);
        }
        return $url;
    }

    public static function summaryUrl(string $token): string
    {
        return BASE_URL . '/order-summary/' . $token;
    }

    public static function thanksUrlForOrder(PDO $pdo, int $orderId, array $query = []): string
    {
        return self::thanksUrl(self::getOrCreateToken($pdo, $orderId), $query);
    }

    public static function summaryUrlForOrder(PDO $pdo, int $orderId): string
    {
        return self::summaryUrl(self::getOrCreateToken($pdo, $orderId));
    }

    public static function getOrCreateToken(PDO $pdo, int $orderId): string
    {
        $stmt = $pdo->prepare('SELECT access_token FROM orders WHERE id = ? LIMIT 1');
        $stmt->execute([$orderId]);
        $existing = $stmt->fetchColumn();
        if (is_string($existing) && $existing !== '') {
            return $existing;
        }

        $token = self::generateToken();
        $upd = $pdo->prepare('UPDATE orders SET access_token = ? WHERE id = ?');
        $upd->execute([$token, $orderId]);
        return $token;
    }

    public static function findByToken(PDO $pdo, string $token): ?array
    {
        if (!preg_match('/^[a-f0-9]{64}$/', $token)) {
            return null;
        }
        $stmt = $pdo->prepare('SELECT * FROM orders WHERE access_token = ? LIMIT 1');
        $stmt->execute([$token]);
        $order = $stmt->fetch(PDO::FETCH_ASSOC);
        return $order ?: null;
    }

    public static function resolveTokenFromRequest(): ?string
    {
        if (!empty($_GET['token']) && is_string($_GET['token'])) {
            return $_GET['token'];
        }
        return null;
    }
}
