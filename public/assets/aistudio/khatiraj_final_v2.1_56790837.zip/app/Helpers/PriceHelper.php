<?php
// app/Helpers/PriceHelper.php

class PriceHelper
{
    /**
     * True only when offer is a real discount: 0 < offer < price.
     */
    public static function hasDiscount($price, $offerPrice): bool
    {
        $price = (float) $price;
        if ($offerPrice === null || $offerPrice === '') {
            return false;
        }
        $offer = (float) $offerPrice;
        return $offer > 0 && $offer < $price;
    }

    /**
     * Selling price: use offer only when it is a valid discount.
     */
    public static function effectivePrice($price, $offerPrice): float
    {
        $price = (float) $price;
        if (self::hasDiscount($price, $offerPrice)) {
            return (float) $offerPrice;
        }
        return $price;
    }
}
