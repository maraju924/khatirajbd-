<?php
// app/Helpers/CsrfHelper.php

class CsrfHelper
{
    public const TOKEN_NAME = 'csrf_token';

    public static function token(): string
    {
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }
        if (empty($_SESSION[self::TOKEN_NAME]) || !is_string($_SESSION[self::TOKEN_NAME])) {
            $_SESSION[self::TOKEN_NAME] = bin2hex(random_bytes(32));
        }
        return $_SESSION[self::TOKEN_NAME];
    }

    public static function field(): string
    {
        $name = htmlspecialchars(self::TOKEN_NAME, ENT_QUOTES, 'UTF-8');
        $value = htmlspecialchars(self::token(), ENT_QUOTES, 'UTF-8');
        return '<input type="hidden" name="' . $name . '" value="' . $value . '">';
    }

    public static function validate(?string $token = null): bool
    {
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }
        if ($token === null) {
            $token = self::tokenFromRequest();
        }
        $session = $_SESSION[self::TOKEN_NAME] ?? '';
        return is_string($token)
            && $token !== ''
            && is_string($session)
            && $session !== ''
            && hash_equals($session, $token);
    }

    public static function tokenFromRequest(): string
    {
        if (isset($_POST[self::TOKEN_NAME]) && is_string($_POST[self::TOKEN_NAME])) {
            return $_POST[self::TOKEN_NAME];
        }
        $header = $_SERVER['HTTP_X_CSRF_TOKEN'] ?? '';
        if (is_string($header) && $header !== '') {
            return $header;
        }
        if (isset($_GET[self::TOKEN_NAME]) && is_string($_GET[self::TOKEN_NAME])) {
            return $_GET[self::TOKEN_NAME];
        }
        return '';
    }

    public static function requireValid(bool $json = false): void
    {
        if (self::validate()) {
            return;
        }
        if ($json) {
            header('Content-Type: application/json; charset=utf-8');
            http_response_code(403);
            echo json_encode(['success' => false, 'status' => 'error', 'message' => 'Invalid security token']);
            exit;
        }
        http_response_code(403);
        header('Content-Type: text/plain; charset=utf-8');
        echo 'Invalid security token. Please go back and try again.';
        exit;
    }
}
