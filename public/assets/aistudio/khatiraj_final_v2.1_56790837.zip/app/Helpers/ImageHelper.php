<?php

namespace App\Helpers;

class ImageHelper
{
    public const PRODUCT_SIZE = 600;
    public const PRODUCT_WEBP_QUALITY = 82;

    public static function isGdAvailable(): bool
    {
        return extension_loaded('gd') && function_exists('imagewebp');
    }

    /**
     * Resize to square (center crop) and save as WebP. Deletes source when paths differ.
     *
     * @return string|null Absolute path to saved WebP file
     */
    public static function processProductImage(
        string $sourcePath,
        ?string $destinationPath = null,
        int $size = self::PRODUCT_SIZE,
        int $quality = self::PRODUCT_WEBP_QUALITY
    ): ?string {
        if (!self::isGdAvailable() || !is_file($sourcePath)) {
            return null;
        }

        $info = @getimagesize($sourcePath);
        if (!$info) {
            return null;
        }

        $source = self::createImageResource($sourcePath, $info['mime']);
        if (!$source) {
            return null;
        }

        $srcW = imagesx($source);
        $srcH = imagesy($source);
        if ($srcW < 1 || $srcH < 1) {
            imagedestroy($source);
            return null;
        }

        $cropSize = min($srcW, $srcH);
        $srcX = (int) (($srcW - $cropSize) / 2);
        $srcY = (int) (($srcH - $cropSize) / 2);

        $cropped = imagecreatetruecolor($cropSize, $cropSize);
        if (!$cropped) {
            imagedestroy($source);
            return null;
        }

        self::preserveAlpha($cropped);
        imagecopy($cropped, $source, 0, 0, $srcX, $srcY, $cropSize, $cropSize);
        imagedestroy($source);

        $canvas = imagecreatetruecolor($size, $size);
        if (!$canvas) {
            imagedestroy($cropped);
            return null;
        }

        self::preserveAlpha($canvas);
        imagecopyresampled($canvas, $cropped, 0, 0, 0, 0, $size, $size, $cropSize, $cropSize);
        imagedestroy($cropped);

        if ($destinationPath === null) {
            $destinationPath = preg_replace('/\.[^.]+$/i', '.webp', $sourcePath);
        }

        $destinationDir = dirname($destinationPath);
        if (!is_dir($destinationDir) && !mkdir($destinationDir, 0777, true) && !is_dir($destinationDir)) {
            imagedestroy($canvas);
            return null;
        }

        $saved = imagewebp($canvas, $destinationPath, $quality);
        imagedestroy($canvas);

        if (!$saved) {
            return null;
        }

        if ($sourcePath !== $destinationPath && is_file($sourcePath)) {
            @unlink($sourcePath);
        }

        return $destinationPath;
    }

    /**
     * Convert uploaded temp file to WebP in uploads/products. Returns relative DB path.
     */
    public static function saveUploadedProductImage(string $tmpPath, string $originalName, string $productsDir): ?string
    {
        if (!is_dir($productsDir) && !mkdir($productsDir, 0777, true) && !is_dir($productsDir)) {
            return null;
        }

        $safeBase = preg_replace('/[^a-zA-Z0-9_-]/', '_', pathinfo($originalName, PATHINFO_FILENAME));
        $safeBase = trim($safeBase, '_') ?: 'product';
        $webpName = time() . '_' . $safeBase . '.webp';
        $webpAbs = rtrim(str_replace('\\', '/', $productsDir), '/') . '/' . $webpName;

        $saved = self::processProductImage($tmpPath, $webpAbs);
        if (!$saved) {
            @unlink($tmpPath);
            return null;
        }

        return 'uploads/products/' . $webpName;
    }

    /**
     * Ensure an existing uploads/products path is 600x600 WebP. Returns updated relative path.
     */
    public static function ensureProductWebp(string $relativePath, string $projectRoot): ?string
    {
        $relativePath = ltrim(str_replace('\\', '/', $relativePath), '/');
        if (strpos($relativePath, 'uploads/products/') !== 0) {
            return $relativePath;
        }

        if (strtolower(pathinfo($relativePath, PATHINFO_EXTENSION)) === 'webp') {
            return $relativePath;
        }

        $absolute = rtrim(str_replace('\\', '/', $projectRoot), '/') . '/' . $relativePath;
        if (!is_file($absolute)) {
            return $relativePath;
        }

        $webpRelative = preg_replace('/\.[^.]+$/i', '.webp', $relativePath);
        $webpAbsolute = rtrim(str_replace('\\', '/', $projectRoot), '/') . '/' . $webpRelative;

        $saved = self::processProductImage($absolute, $webpAbsolute);
        return $saved ? $webpRelative : $relativePath;
    }

    /** @deprecated Use processProductImage() for product uploads */
    public static function compressImage($sourcePath, $destinationPath, $quality = 80)
    {
        if (!extension_loaded('gd')) {
            return false;
        }

        $info = getimagesize($sourcePath);
        if (!$info) {
            return false;
        }

        if ($info['mime'] == 'image/jpeg') {
            $image = imagecreatefromjpeg($sourcePath);
            imagejpeg($image, $destinationPath, $quality);
        } elseif ($info['mime'] == 'image/png') {
            $image = imagecreatefrompng($sourcePath);
            $pngQuality = 9 - round(($quality / 100) * 9);
            imagepng($image, $destinationPath, $pngQuality);
        } elseif ($info['mime'] == 'image/gif') {
            $image = imagecreatefromgif($sourcePath);
            imagegif($image, $destinationPath);
        } else {
            return false;
        }

        imagedestroy($image);
        return true;
    }

    private static function createImageResource(string $path, string $mime)
    {
        switch ($mime) {
            case 'image/jpeg':
                return @imagecreatefromjpeg($path) ?: null;
            case 'image/png':
                return @imagecreatefrompng($path) ?: null;
            case 'image/gif':
                return @imagecreatefromgif($path) ?: null;
            case 'image/webp':
                return @imagecreatefromwebp($path) ?: null;
            default:
                return null;
        }
    }

    private static function preserveAlpha($image): void
    {
        imagealphablending($image, false);
        imagesavealpha($image, true);
        $transparent = imagecolorallocatealpha($image, 0, 0, 0, 127);
        imagefilledrectangle($image, 0, 0, imagesx($image), imagesy($image), $transparent);
        imagealphablending($image, true);
    }
}
