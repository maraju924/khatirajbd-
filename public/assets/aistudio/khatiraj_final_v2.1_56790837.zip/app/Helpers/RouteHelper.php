<?php
// app/Helpers/RouteHelper.php

class RouteHelper
{
    public static function getPath(): string
    {
        $uri = $_SERVER['REQUEST_URI'] ?? '/';
        $path = parse_url($uri, PHP_URL_PATH);
        if ($path === null || $path === false || $path === '') {
            $path = '/';
        }

        if (strpos($path, '/index.php') === 0) {
            $path = substr($path, strlen('/index.php')) ?: '/';
        }

        $base = defined('BASE_URL') ? BASE_URL : '';
        if ($base !== '' && strpos($path, $base) === 0) {
            $path = substr($path, strlen($base)) ?: '/';
        }

        if ($path === '' || $path[0] !== '/') {
            $path = '/' . ltrim($path, '/');
        }

        return $path;
    }
}
