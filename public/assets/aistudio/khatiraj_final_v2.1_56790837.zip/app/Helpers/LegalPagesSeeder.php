<?php
// app/Helpers/LegalPagesSeeder.php
declare(strict_types=1);

/**
 * Seeds About + legal CMS pages (BN+EN) and footer menu links.
 * Safe to re-run: skips existing route_key / menu URL rows.
 */
final class LegalPagesSeeder
{
    /**
     * @param list<string>|null $log Appendable migrate log (optional)
     */
    public static function seed(PDO $pdo, ?array &$log = null): void
    {
        $pages = self::pages();
        $select = $pdo->prepare('SELECT id FROM page_registry WHERE route_key = ?');
        $insert = $pdo->prepare(
            'INSERT INTO page_registry
                (route_key, slug, page_group, page_name, title, h1_title, subtitle,
                 meta_title, meta_description, template, content_mode, content_html, status, sort_order)
             VALUES (?, ?, \'content\', ?, ?, ?, ?, ?, ?, \'default\', \'sections\', ?, 1, ?)'
        );
        $updateHtml = $pdo->prepare(
            'UPDATE page_registry SET content_html = ?, h1_title = COALESCE(NULLIF(h1_title, \'\'), ?),
                meta_title = COALESCE(NULLIF(meta_title, \'\'), ?),
                meta_description = COALESCE(NULLIF(meta_description, \'\'), ?)
             WHERE id = ? AND (content_html IS NULL OR TRIM(content_html) = \'\')'
        );

        $added = 0;
        $filled = 0;
        $sortBase = 20;

        foreach ($pages as $i => $p) {
            $select->execute([$p['route_key']]);
            $existingId = $select->fetchColumn();
            if (!$existingId) {
                $insert->execute([
                    $p['route_key'],
                    $p['slug'],
                    $p['page_name'],
                    $p['title'],
                    $p['h1'],
                    $p['subtitle'],
                    $p['meta_title'],
                    $p['meta_description'],
                    $p['html'],
                    $sortBase + $i,
                ]);
                $added++;
            } else {
                $updateHtml->execute([
                    $p['html'],
                    $p['h1'],
                    $p['meta_title'],
                    $p['meta_description'],
                    (int)$existingId,
                ]);
                if ($updateHtml->rowCount() > 0) {
                    $filled++;
                }
            }
        }

        $menuAdded = self::seedFooterMenus($pdo);

        if (class_exists('CacheHelper')) {
            CacheHelper::clearAll();
        }

        if ($log !== null) {
            if ($added > 0) {
                $log[] = "[NEW] Seeded {$added} legal/about CMS pages";
            }
            if ($filled > 0) {
                $log[] = "[NEW] Filled content_html on {$filled} empty legal/about pages";
            }
            if ($menuAdded > 0) {
                $log[] = "[NEW] Seeded {$menuAdded} footer legal menu links";
            }
            if ($added === 0 && $filled === 0 && $menuAdded === 0) {
                $log[] = '[OK] Legal/about CMS pages already present';
            }
        }
    }

    /**
     * Render CMS HTML for the active UI language when bilingual markers exist.
     */
    public static function localizeHtml(string $html): string
    {
        if ($html === '' || stripos($html, 'data-legal-lang') === false) {
            return $html;
        }

        $lang = 'bn';
        if (class_exists('LanguageHelper')) {
            $lang = LanguageHelper::getCurrentLang();
        }
        if (!in_array($lang, ['bn', 'en'], true)) {
            $lang = 'bn';
        }

        if (!preg_match_all(
            '/<div\b([^>]*)\bdata-legal-lang=["\'](bn|en)["\']([^>]*)>([\s\S]*?)<\/div>/i',
            $html,
            $matches,
            PREG_SET_ORDER
        )) {
            return $html;
        }

        $parts = [];
        foreach ($matches as $m) {
            if (strtolower($m[2]) === $lang) {
                $parts[] = $m[4];
            }
        }

        return $parts !== [] ? implode("\n", $parts) : $html;
    }

    private static function seedFooterMenus(PDO $pdo): int
    {
        $links = [
            ['আমাদের সম্পর্কে', 'about', 10],
            ['প্রাইভেসি পলিসি', 'privacy-policy', 11],
            ['শর্তাবলী', 'terms-conditions', 12],
            ['রিফান্ড / রিটার্ন', 'refund-policy', 13],
            ['শিপিং পলিসি', 'shipping-policy', 14],
        ];

        $check = $pdo->prepare("SELECT id FROM menus WHERE location = 'footer' AND url = ? LIMIT 1");
        $ins = $pdo->prepare(
            "INSERT INTO menus (title, url, parent_id, sort_order, location, status) VALUES (?, ?, NULL, ?, 'footer', 1)"
        );
        $added = 0;
        foreach ($links as [$title, $url, $sort]) {
            $check->execute([$url]);
            if ($check->fetchColumn()) {
                continue;
            }
            $ins->execute([$title, $url, $sort]);
            $added++;
        }
        return $added;
    }

    private static function wrap(string $bn, string $en): string
    {
        return '<div data-legal-lang="bn">' . trim($bn) . '</div><div data-legal-lang="en">' . trim($en) . '</div>';
    }

    /**
     * @return list<array<string, mixed>>
     */
    private static function pages(): array
    {
        $site = 'Khati Raj BD';
        $updated = date('Y-m-d');

        return [
            [
                'route_key' => 'about',
                'slug' => '/about',
                'page_name' => 'আমাদের সম্পর্কে',
                'title' => 'About Us',
                'h1' => 'আমাদের সম্পর্কে',
                'subtitle' => 'About Khati Raj BD',
                'meta_title' => "আমাদের সম্পর্কে | {$site}",
                'meta_description' => 'Khati Raj BD — খাঁটি ও মানসম্পন্ন পণ্যের বিশ্বস্ত ই-কমার্স প্ল্যাটফর্ম।',
                'html' => self::wrap(
                    "
                        <p>{$site} বাংলাদেশের গ্রাহকদের জন্য খাঁটি, মানসম্পন্ন ও বিশ্বস্ত পণ্য সরবরাহে কাজ করে। আমরা অর্গানিক ও লোকাল ফুড, মধু, ঘি এবং নিত্যপ্রয়োজনীয় পণ্য সহজে ঘরে পৌঁছে দিতে চাই।</p>
                        <h5><i class=\"fas fa-bullseye\"></i> আমাদের লক্ষ্য</h5>
                        <p>স্বচ্ছ মূল্য, দ্রুত ডেলিভারি এবং নির্ভরযোগ্য কাস্টমার সাপোর্ট নিশ্চিত করে একটি বিশ্বস্ত অনলাইন কেনাকাটার অভিজ্ঞতা তৈরি করা।</p>
                        <h5><i class=\"fas fa-handshake\"></i> কেন আমাদের বেছে নেবেন</h5>
                        <p>মান যাচাই, সুরক্ষিত অর্ডার প্রক্রিয়া, এবং অর্ডার পরবর্তী সহায়তা — এগুলো আমাদের সেবার মূল ভিত্তি।</p>
                        <p class=\"last-updated\">সর্বশেষ আপডেট: {$updated}</p>
                    ",
                    "
                        <p>{$site} serves customers across Bangladesh with authentic, quality products — from organic and local foods to honey, ghee, and everyday essentials.</p>
                        <h5><i class=\"fas fa-bullseye\"></i> Our mission</h5>
                        <p>Deliver a trusted shopping experience with fair pricing, fast delivery, and reliable customer support.</p>
                        <h5><i class=\"fas fa-handshake\"></i> Why shop with us</h5>
                        <p>Quality checks, a secure order flow, and after-sales support are at the core of how we operate.</p>
                        <p class=\"last-updated\">Last updated: {$updated}</p>
                    "
                ),
            ],
            [
                'route_key' => 'privacy_policy',
                'slug' => '/privacy-policy',
                'page_name' => 'প্রাইভেসি পলিসি',
                'title' => 'Privacy Policy',
                'h1' => 'প্রাইভেসি পলিসি',
                'subtitle' => 'Privacy Policy',
                'meta_title' => "প্রাইভেসি পলিসি | {$site}",
                'meta_description' => 'Khati Raj BD-এ আপনার ব্যক্তিগত তথ্য কীভাবে সংগ্রহ, ব্যবহার ও সুরক্ষা করা হয়।',
                'html' => self::wrap(
                    "
                        <p>এই নীতিতে ব্যাখ্যা করা হয়েছে আমরা কীভাবে আপনার তথ্য সংগ্রহ ও ব্যবহার করি। সাইট ব্যবহার বা অর্ডার করার মাধ্যমে আপনি এই নীতির সাথে সম্মত হচ্ছেন।</p>
                        <h5><i class=\"fas fa-database\"></i> আমরা কী তথ্য সংগ্রহ করি</h5>
                        <p>নাম, ফোন, ইমেইল, ডেলিভারি ঠিকানা, অর্ডার বিবরণ এবং প্রয়োজনে পেমেন্ট সংক্রান্ত তথ্য (যেমন ট্রানজেকশন আইডি)। ওয়েবসাইট অ্যানালিটিক্স/অ্যাড পিক্সেল থেকেও সীমিত ব্যবহারের তথ্য সংগ্রহ হতে পারে।</p>
                        <h5><i class=\"fas fa-cogs\"></i> তথ্যের ব্যবহার</h5>
                        <p>অর্ডার প্রক্রিয়া, ডেলিভারি, কাস্টমার সাপোর্ট, প্রতারণা প্রতিরোধ, এবং (সম্মতি থাকলে) প্রোমোশনাল যোগাযোগের জন্য তথ্য ব্যবহার করা হয়।</p>
                        <h5><i class=\"fas fa-share-alt\"></i> তৃতীয় পক্ষ</h5>
                        <p>কুরিয়ার, পেমেন্ট গেটওয়ে, SMS/ইমেইল সেবা এবং বিজ্ঞাপন/অ্যানালিটিক্স পার্টনারদের সাথে শুধু প্রয়োজনীয় তথ্য শেয়ার করা হতে পারে।</p>
                        <h5><i class=\"fas fa-shield-alt\"></i> সুরক্ষা ও অধিকার</h5>
                        <p>আমরা যুক্তিসংগত প্রযুক্তিগত ও প্রশাসনিক ব্যবস্থা নিই। তথ্য সংশোধন বা মুছে ফেলার অনুরোধ সাপোর্ট চ্যানেলে জানাতে পারেন।</p>
                        <p class=\"last-updated\">সর্বশেষ আপডেট: {$updated}</p>
                    ",
                    "
                        <p>This policy explains how we collect and use your information. By using the site or placing an order, you agree to this policy.</p>
                        <h5><i class=\"fas fa-database\"></i> What we collect</h5>
                        <p>Name, phone, email, delivery address, order details, and where needed payment-related data (e.g. transaction IDs). Analytics/ad pixels may also collect limited usage data.</p>
                        <h5><i class=\"fas fa-cogs\"></i> How we use it</h5>
                        <p>To process orders, deliver products, provide support, prevent fraud, and (with consent) send promotional updates.</p>
                        <h5><i class=\"fas fa-share-alt\"></i> Third parties</h5>
                        <p>We may share necessary data with couriers, payment providers, SMS/email services, and analytics/advertising partners.</p>
                        <h5><i class=\"fas fa-shield-alt\"></i> Security & rights</h5>
                        <p>We apply reasonable technical and administrative safeguards. You may request correction or deletion via our support channels.</p>
                        <p class=\"last-updated\">Last updated: {$updated}</p>
                    "
                ),
            ],
            [
                'route_key' => 'terms_conditions',
                'slug' => '/terms-conditions',
                'page_name' => 'শর্তাবলী',
                'title' => 'Terms & Conditions',
                'h1' => 'শর্তাবলী',
                'subtitle' => 'Terms & Conditions',
                'meta_title' => "শর্তাবলী | {$site}",
                'meta_description' => 'Khati Raj BD ওয়েবসাইট ব্যবহার এবং অর্ডার/পেমেন্ট সংক্রান্ত শর্তাবলী।',
                'html' => self::wrap(
                    "
                        <p>{$site} ওয়েবসাইট ব্যবহার এবং অর্ডার করার সময় নিম্নোক্ত শর্তাবলী প্রযোজ্য।</p>
                        <h5><i class=\"fas fa-shopping-bag\"></i> অর্ডার</h5>
                        <p>অর্ডার কনফার্মেশন সাপেক্ষে গ্রহণযোগ্য। স্টক, মূল্য ভুল বা সন্দেহজনক অর্ডারের ক্ষেত্রে আমরা অর্ডার বাতিল বা সংশোধন করতে পারি।</p>
                        <h5><i class=\"fas fa-money-bill-wave\"></i> মূল্য ও পেমেন্ট</h5>
                        <p>প্রদর্শিত মূল্য টাকায় (BDT)। COD, ম্যানুয়াল মোবাইল ব্যাংকিং এবং অনলাইন গেটওয়ে (সক্রিয় থাকলে) গ্রহণযোগ্য। পেমেন্ট প্রমাণ জাল হলে অর্ডার বাতিল হতে পারে।</p>
                        <h5><i class=\"fas fa-user-check\"></i> গ্রাহকের দায়িত্ব</h5>
                        <p>সঠিক নাম, ফোন ও ঠিকানা প্রদান করতে হবে। ভুল তথ্যের কারণে বিলম্ব বা ব্যর্থ ডেলিভারির দায় গ্রাহকের।</p>
                        <h5><i class=\"fas fa-ban\"></i> নিষিদ্ধ ব্যবহার</h5>
                        <p>সাইটের অপব্যবহার, প্রতারণা বা সিস্টেমে অননুমোদিত প্রবেশ নিষিদ্ধ।</p>
                        <p class=\"last-updated\">সর্বশেষ আপডেট: {$updated}</p>
                    ",
                    "
                        <p>These terms apply when you use the {$site} website or place an order.</p>
                        <h5><i class=\"fas fa-shopping-bag\"></i> Orders</h5>
                        <p>Orders are accepted subject to confirmation. We may cancel or amend orders due to stock issues, pricing errors, or suspected fraud.</p>
                        <h5><i class=\"fas fa-money-bill-wave\"></i> Pricing & payment</h5>
                        <p>Prices are in BDT. COD, manual mobile banking, and online gateway (when enabled) are accepted. Fake payment proof may result in cancellation.</p>
                        <h5><i class=\"fas fa-user-check\"></i> Customer responsibility</h5>
                        <p>Provide accurate name, phone, and address. Delays or failed delivery caused by incorrect details are the customer’s responsibility.</p>
                        <h5><i class=\"fas fa-ban\"></i> Prohibited use</h5>
                        <p>Abuse, fraud, or unauthorized access to the system is prohibited.</p>
                        <p class=\"last-updated\">Last updated: {$updated}</p>
                    "
                ),
            ],
            [
                'route_key' => 'refund_policy',
                'slug' => '/refund-policy',
                'page_name' => 'রিফান্ড / রিটার্ন',
                'title' => 'Refund & Return Policy',
                'h1' => 'রিফান্ড ও রিটার্ন পলিসি',
                'subtitle' => 'Refund & Return Policy',
                'meta_title' => "রিফান্ড / রিটার্ন পলিসি | {$site}",
                'meta_description' => 'Khati Raj BD-এর এক্সচেঞ্জ, রিটার্ন ও রিফান্ড নীতিমালা।',
                'html' => self::wrap(
                    "
                        <p>পণ্যে সমস্যা হলে আমরা ন্যায্য সমাধান দিতে চাই। নিচের শর্ত সাপেক্ষে এক্সচেঞ্জ/রিটার্ন বিবেচনা করা হয়।</p>
                        <h5><i class=\"fas fa-clock\"></i> সময়সীমা</h5>
                        <p>ডেলিভারির পর সাধারণত ৭ দিনের মধ্যে ত্রুটি/ভুল পণ্যের অনুরোধ জানাতে হবে (পণ্যভেদে ভিন্ন হতে পারে)।</p>
                        <h5><i class=\"fas fa-box-open\"></i> যোগ্যতা</h5>
                        <p>ভুল পণ্য, ক্ষতিগ্রস্ত প্যাকেজিং বা উল্লেখযোগ্য মানগত ত্রুটি থাকলে এক্সচেঞ্জ/রিটার্ন যোগ্য হতে পারে। খোলা/ব্যবহৃত খাদ্যপণ্য সাধারণত ফেরতযোগ্য নয়, যদি না পণ্য ত্রুটিপূর্ণ প্রমাণিত হয়।</p>
                        <h5><i class=\"fas fa-undo\"></i> প্রক্রিয়া</h5>
                        <p>সাপোর্টে অর্ডার নম্বর, সমস্যার বিবরণ ও ছবি পাঠান। অনুমোদনের পর এক্সচেঞ্জ বা রিফান্ডের ধরন জানানো হবে।</p>
                        <h5><i class=\"fas fa-wallet\"></i> রিফান্ড</h5>
                        <p>অনুমোদিত রিফান্ড মূল পেমেন্ট পদ্ধতি বা মোবাইল ব্যাংকিং-এ ফেরত দেওয়া হতে পারে; প্রক্রিয়াকরণে কয়েক কার্যদিবস লাগতে পারে।</p>
                        <p class=\"last-updated\">সর্বশেষ আপডেট: {$updated}</p>
                    ",
                    "
                        <p>If something goes wrong with a product, we aim for a fair resolution. Exchanges/returns are considered under the terms below.</p>
                        <h5><i class=\"fas fa-clock\"></i> Timeframe</h5>
                        <p>Please report defective or incorrect items within about 7 days of delivery (may vary by product).</p>
                        <h5><i class=\"fas fa-box-open\"></i> Eligibility</h5>
                        <p>Wrong items, damaged packaging, or significant quality defects may qualify. Opened/used food items are generally not returnable unless the product is proven defective.</p>
                        <h5><i class=\"fas fa-undo\"></i> Process</h5>
                        <p>Contact support with your order number, a description, and photos. We will confirm exchange or refund options after review.</p>
                        <h5><i class=\"fas fa-wallet\"></i> Refunds</h5>
                        <p>Approved refunds may be issued via the original payment method or mobile banking and can take several business days.</p>
                        <p class=\"last-updated\">Last updated: {$updated}</p>
                    "
                ),
            ],
            [
                'route_key' => 'shipping_policy',
                'slug' => '/shipping-policy',
                'page_name' => 'শিপিং পলিসি',
                'title' => 'Shipping Policy',
                'h1' => 'শিপিং পলিসি',
                'subtitle' => 'Shipping Policy',
                'meta_title' => "শিপিং পলিসি | {$site}",
                'meta_description' => 'ঢাকা ও ঢাকার বাইরে ডেলিভারি চার্জ, সময় ও শিপিং নীতিমালা।',
                'html' => self::wrap(
                    "
                        <p>আমরা বাংলাদেশজুড়ে নির্ভরযোগ্য কুরিয়ার পার্টনারের মাধ্যমে ডেলিভারি করি।</p>
                        <h5><i class=\"fas fa-map-marker-alt\"></i> ডেলিভারি জোন</h5>
                        <p>সাধারণত ঢাকার ভিতরে ও ঢাকার বাইরে আলাদা শিপিং চার্জ প্রযোজ্য। চেকআউটে আপনার এলাকা অনুযায়ী চার্জ দেখা যাবে।</p>
                        <h5><i class=\"fas fa-truck\"></i> ডেলিভারি সময়</h5>
                        <p>সাধারণত ২–৫ কার্যদিবস (এলাকা ও কুরিয়ার পরিস্থিতিভেদে কম/বেশি হতে পারে)। উৎসব বা প্রতিকূল আবহাওয়ায় বিলম্ব হতে পারে।</p>
                        <h5><i class=\"fas fa-box\"></i> পার্সেল ট্র্যাকিং</h5>
                        <p>কুরিয়ারে হস্তান্তরের পর ট্র্যাকিং তথ্য SMS/ফোন বা সাইটের অর্ডার ট্র্যাক পেজে পাওয়া যেতে পারে।</p>
                        <h5><i class=\"fas fa-phone-alt\"></i> গ্রহণ না হলে</h5>
                        <p>বারবার কল মিস বা ভুল ঠিকানার কারণে ফেরত এলে পুনরায় পাঠানোর জন্য অতিরিক্ত চার্জ লাগতে পারে।</p>
                        <p class=\"last-updated\">সর্বশেষ আপডেট: {$updated}</p>
                    ",
                    "
                        <p>We deliver across Bangladesh through trusted courier partners.</p>
                        <h5><i class=\"fas fa-map-marker-alt\"></i> Delivery zones</h5>
                        <p>Shipping charges typically differ for Inside Dhaka and Outside Dhaka. Checkout shows the charge for your selected zone.</p>
                        <h5><i class=\"fas fa-truck\"></i> Delivery time</h5>
                        <p>Usually 2–5 business days depending on location and courier conditions. Festivals or weather may cause delays.</p>
                        <h5><i class=\"fas fa-box\"></i> Parcel tracking</h5>
                        <p>After handover to the courier, tracking details may be shared by SMS/phone or via the Track Order page.</p>
                        <h5><i class=\"fas fa-phone-alt\"></i> Failed delivery</h5>
                        <p>If a parcel returns due to missed calls or an incorrect address, re-shipping may incur an extra charge.</p>
                        <p class=\"last-updated\">Last updated: {$updated}</p>
                    "
                ),
            ],
        ];
    }
}
