<?php
// app/Helpers/MinifyHelper.php

class MinifyHelper
{
    public static function minifyCss(string $css): string
    {
        $css = preg_replace('!/\*[^*]*\*+([^/][^*]*\*+)*/!', '', $css);
        $css = preg_replace('/\s*([{}:;,>+~])\s*/', '$1', $css);
        $css = preg_replace('/;}/', '}', $css);
        $css = preg_replace('/\s+/', ' ', $css);

        return trim($css);
    }

    public static function minifyJs(string $js): string
    {
        $js = preg_replace('!/\*[\s\S]*?\*/!', '', $js);
        $js = preg_replace('/(?<!:)\/\/[^\n\r]*/', '', $js);
        $js = preg_replace('/\s*([{}();,:=+\-*\/<>!?&|])\s*/', '$1', $js);
        $js = preg_replace('/\s+/', ' ', $js);

        return trim($js);
    }

    public static function bundleCssImports(string $filePath): string
    {
        if (!is_file($filePath)) {
            throw new RuntimeException('CSS file not found: ' . $filePath);
        }

        $dir = dirname($filePath);
        $content = file_get_contents($filePath);

        return preg_replace_callback(
            '/@import\s+(?:url\([\'"]?([^\'")\s]+)[\'"]?\)|[\'"]([^\'"]+)[\'"])\s*;/i',
            static function (array $matches) use ($dir): string {
                $importUrl = $matches[1] ?: $matches[2];
                if (preg_match('/^https?:\/\//i', $importUrl)) {
                    return '@import url("' . $importUrl . '");';
                }

                $importFile = $dir . DIRECTORY_SEPARATOR . str_replace('/', DIRECTORY_SEPARATOR, $importUrl);
                if (!is_file($importFile)) {
                    return '/* missing import: ' . $importUrl . ' */';
                }

                return self::bundleCssImports($importFile) . "\n";
            },
            $content
        );
    }

    public static function writeMinifiedCss(string $sourcePath, ?string $destPath = null): string
    {
        $destPath = $destPath ?: preg_replace('/\.css$/', '.min.css', $sourcePath);
        $bundled = self::bundleCssImports($sourcePath);
        $minified = self::minifyCss($bundled);
        file_put_contents($destPath, $minified);

        return $destPath;
    }

    public static function writeMinifiedJs(string $sourcePath, ?string $destPath = null): string
    {
        $destPath = $destPath ?: preg_replace('/\.js$/', '.min.js', $sourcePath);
        $minified = self::minifyJs(file_get_contents($sourcePath));
        file_put_contents($destPath, $minified);

        return $destPath;
    }
}
