<?php
namespace App\Helpers;

class WhatsAppHelper {
    private $pdo;
    private $enabled = false;
    private $apiToken = '';
    private $phoneNumberId = '';
    private $businessNumber = '';

    public function __construct($pdo) {
        $this->pdo = $pdo;
        $this->loadSettings();
    }

    private function loadSettings(): void {
        $stmt = $this->pdo->query("SELECT key_name, value FROM settings WHERE key_name LIKE 'wa_%' OR key_name IN ('whatsapp_number', 'enable_whatsapp')");
        $settings = $stmt->fetchAll(\PDO::FETCH_KEY_PAIR);

        $this->enabled = ($settings['wa_api_enabled'] ?? '0') === '1';
        $this->apiToken = $settings['wa_api_token'] ?? '';
        $this->phoneNumberId = $settings['wa_phone_number_id'] ?? '';
        $this->businessNumber = $settings['whatsapp_number'] ?? '';
    }

    public function isApiEnabled(): bool {
        return $this->enabled && !empty($this->apiToken) && !empty($this->phoneNumberId);
    }

    public function getBusinessNumber(): string {
        return $this->businessNumber;
    }

    public function formatPhone(string $phone): string {
        $phone = preg_replace('/[^0-9]/', '', $phone);
        if (strlen($phone) === 11 && str_starts_with($phone, '01')) {
            return '88' . $phone;
        }
        if (strlen($phone) === 10 && str_starts_with($phone, '1')) {
            return '880' . $phone;
        }
        return $phone;
    }

    public function buildChatLink(string $customerPhone, string $message): string {
        $phone = $this->formatPhone($customerPhone);
        return 'https://wa.me/' . $phone . '?text=' . rawurlencode($message);
    }

    public function buildBusinessChatLink(string $message): string {
        if (empty($this->businessNumber)) {
            return '';
        }
        return 'https://wa.me/' . preg_replace('/[^0-9]/', '', $this->businessNumber) . '?text=' . rawurlencode($message);
    }

    public function sendMessage(string $phone, string $message): array {
        if (!$this->isApiEnabled()) {
            return ['success' => false, 'error' => 'WhatsApp API not configured'];
        }

        $to = $this->formatPhone($phone);
        $url = 'https://graph.facebook.com/v19.0/' . $this->phoneNumberId . '/messages';

        $payload = [
            'messaging_product' => 'whatsapp',
            'recipient_type' => 'individual',
            'to' => $to,
            'type' => 'text',
            'text' => ['preview_url' => true, 'body' => $message],
        ];

        $ch = curl_init();
        curl_setopt_array($ch, [
            CURLOPT_URL => $url,
            CURLOPT_POST => true,
            CURLOPT_POSTFIELDS => json_encode($payload),
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT => 15,
            CURLOPT_HTTPHEADER => [
                'Authorization: Bearer ' . $this->apiToken,
                'Content-Type: application/json',
            ],
        ]);

        $response = curl_exec($ch);
        $httpCode = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $curlError = curl_error($ch);
        curl_close($ch);

        if ($curlError) {
            return ['success' => false, 'error' => $curlError, 'http_code' => $httpCode];
        }

        $decoded = json_decode($response, true);
        if ($httpCode >= 200 && $httpCode < 300) {
            return ['success' => true, 'response' => $decoded, 'http_code' => $httpCode];
        }

        $errorMsg = $decoded['error']['message'] ?? $response;
        return ['success' => false, 'error' => $errorMsg, 'http_code' => $httpCode];
    }
}
