<?php
// sitemap.php
require_once 'config/database.php';

$base_url = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]" . BASE_URL;

header("Content-Type: application/xml; charset=utf-8");

echo '<?xml version="1.0" encoding="UTF-8"?>';
echo '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">';

// 1. Static Pages
$static_pages = ['', '/home', '/shop', '/checkout', '/cart', '/blog'];
foreach ($static_pages as $page) {
    echo '<url>';
    echo '<loc>' . $base_url . $page . '</loc>';
    echo '<lastmod>' . date('Y-m-d') . '</lastmod>';
    echo '<changefreq>daily</changefreq>';
    echo '<priority>0.8</priority>';
    echo '</url>';
}

// 2. Categories
$stmt = $pdo->query("SELECT id, name, slug FROM categories");
while ($row = $stmt->fetch()) {
    echo '<url>';
    echo '<loc>' . $base_url . '/category/' . $row['slug'] . '</loc>';
    echo '<changefreq>weekly</changefreq>';
    echo '<priority>0.6</priority>';
    echo '</url>';
}

// 3. Products
$stmt = $pdo->query("SELECT id, name, slug, created_at FROM products WHERE status = 1");
while ($row = $stmt->fetch()) {
    $lastmod = !empty($row['created_at']) ? date('Y-m-d', strtotime($row['created_at'])) : date('Y-m-d');
    echo '<url>';
    echo '<loc>' . $base_url . '/product/' . $row['slug'] . '</loc>';
    echo '<lastmod>' . $lastmod . '</lastmod>';
    echo '<changefreq>weekly</changefreq>';
    echo '<priority>0.9</priority>';
    echo '</url>';
}

// 4. Blog Posts
try {
    $stmt = $pdo->query("SELECT slug, created_at, updated_at FROM blog_posts WHERE status = 1");
    while ($row = $stmt->fetch()) {
        $lastmod = !empty($row['updated_at']) ? date('Y-m-d', strtotime($row['updated_at'])) : date('Y-m-d');
        echo '<url>';
        echo '<loc>' . $base_url . '/blog/' . $row['slug'] . '</loc>';
        echo '<lastmod>' . $lastmod . '</lastmod>';
        echo '<changefreq>weekly</changefreq>';
        echo '<priority>0.7</priority>';
        echo '</url>';
    }
} catch (PDOException $e) {
    // Skip if table doesn't exist yet
}

// 5. CMS / legal content pages (about, privacy, terms, refund, shipping, custom)
try {
    $skipSlugs = ['/', '/home', '/blog', '/shop', '/cart', '/checkout', '/thanks'];
    $stmt = $pdo->query(
        "SELECT slug, updated_at, created_at FROM page_registry
         WHERE status = 1 AND page_group = 'content'
           AND slug IS NOT NULL AND slug != '' AND slug != '/'"
    );
    while ($row = $stmt->fetch()) {
        $slug = '/' . ltrim((string)$row['slug'], '/');
        if (in_array($slug, $skipSlugs, true)) {
            continue;
        }
        $lastmod = !empty($row['updated_at'])
            ? date('Y-m-d', strtotime($row['updated_at']))
            : (!empty($row['created_at']) ? date('Y-m-d', strtotime($row['created_at'])) : date('Y-m-d'));
        echo '<url>';
        echo '<loc>' . htmlspecialchars($base_url . $slug) . '</loc>';
        echo '<lastmod>' . $lastmod . '</lastmod>';
        echo '<changefreq>monthly</changefreq>';
        echo '<priority>0.5</priority>';
        echo '</url>';
    }
} catch (PDOException $e) {
    // Skip if table doesn't exist yet
}

echo '</urlset>';
?>
