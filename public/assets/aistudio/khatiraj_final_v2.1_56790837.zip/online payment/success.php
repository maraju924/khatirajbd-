<?php
/**
 * Payment Success Page
 */

require_once __DIR__ . '/bootstrap.php';

$invoiceId = sanitize($_GET['invoice'] ?? $_SESSION['last_invoice'] ?? '');

// Initialize classes
$payment = new Payment();
$settings = $payment->getAllSettings();

$transaction = null;
if (!empty($invoiceId)) {
    $transaction = $payment->getTransactionByInvoice($invoiceId);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <title>Payment Successful - <?php echo htmlspecialchars($settings['site_name'] ?? 'Payment Gateway'); ?></title>
    <link rel="icon" href="<?php echo IMAGES_URL; ?>favicon.ico">
    
    <!-- Google Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    
    <!-- CSS -->
    <link rel="stylesheet" href="<?php echo CSS_URL; ?>payment.css">
</head>
<body>
    <div class="payment-container">
        <div class="payment-wrapper">
            <div class="status-page">
                <div class="status-icon success">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                        <polyline points="20 6 9 17 4 12"></polyline>
                    </svg>
                </div>
                <h1 class="status-title">Payment Submitted!</h1>
                <p class="status-message">
                    Your payment has been submitted successfully.<br>
                    We will verify your payment and notify you shortly.
                </p>

                <?php if ($transaction): ?>
                <div class="transaction-details" style="text-align: left; margin-bottom: 24px;">
                    <div class="transaction-header">Payment Details</div>
                    <div class="transaction-body">
                        <div class="transaction-row">
                            <span class="label">Invoice ID:</span>
                            <span class="value"><?php echo htmlspecialchars($transaction['invoice_id']); ?></span>
                        </div>
                        <div class="transaction-row">
                            <span class="label">Payment Method:</span>
                            <span class="value"><?php echo htmlspecialchars($transaction['method_name']); ?></span>
                        </div>
                        <div class="transaction-row">
                            <span class="label">Amount:</span>
                            <span class="value"><?php echo number_format($transaction['amount'], 2); ?> <?php echo $transaction['currency']; ?></span>
                        </div>
                        <div class="transaction-row">
                            <span class="label">Status:</span>
                            <span class="value" style="text-transform: capitalize; color: #d97706;">
                                <?php echo $transaction['status']; ?>
                            </span>
                        </div>
                        <div class="transaction-row">
                            <span class="label">Transaction ID:</span>
                            <span class="value"><?php echo htmlspecialchars($transaction['transaction_id'] ?? 'N/A'); ?></span>
                        </div>
                        <div class="transaction-row">
                            <span class="label">Date:</span>
                            <span class="value"><?php echo date('M d, Y h:i A', strtotime($transaction['created_at'])); ?></span>
                        </div>
                    </div>
                </div>
                <?php endif; ?>

                <div style="display: flex; gap: 12px; justify-content: center; flex-wrap: wrap;">
                    <a href="<?php echo BASE_URL; ?>" class="btn btn-primary">
                        Go to Homepage
                    </a>
                    <a href="checkout.php" class="btn btn-secondary">
                        Make Another Payment
                    </a>
                </div>

                <div style="margin-top: 32px; padding: 16px; background: var(--primary-light); border-radius: var(--radius-md);">
                    <p style="font-size: 0.875rem; color: var(--text-light); margin: 0;">
                        📧 A confirmation email will be sent to you once the payment is verified.<br>
                        📞 For any queries, contact us at <strong><?php echo htmlspecialchars($settings['support_phone'] ?? '01XXXXXXXXX'); ?></strong>
                    </p>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
