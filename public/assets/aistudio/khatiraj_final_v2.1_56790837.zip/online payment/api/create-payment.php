<?php
/**
 * Create Payment API
 * POST /api/create-payment.php
 * 
 * Request body:
 * - amount (required): Payment amount
 * - customer_name (required): Customer name
 * - customer_email (optional): Customer email
 * - customer_phone (required): Customer phone
 * - payment_method (required): Payment method slug
 * - success_url (optional): Redirect URL on success
 * - cancel_url (optional): Redirect URL on cancel
 * - metadata (optional): Additional JSON data
 */

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

require_once __DIR__ . '/../bootstrap.php';

// Only allow POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_response(['success' => false, 'message' => 'Method not allowed'], 405);
}

try {
    // Get JSON input
    $input = json_decode(file_get_contents('php://input'), true);
    
    if (!$input) {
        // Fall back to POST data
        $input = $_POST;
    }

    // Validate required fields
    $required = ['amount', 'customer_name', 'customer_phone', 'payment_method'];
    $missing = [];
    
    foreach ($required as $field) {
        if (empty($input[$field])) {
            $missing[] = $field;
        }
    }

    if (!empty($missing)) {
        json_response([
            'success' => false, 
            'message' => 'Missing required fields: ' . implode(', ', $missing)
        ], 400);
    }

    // Validate amount
    $amount = floatval($input['amount']);
    if ($amount <= 0) {
        json_response(['success' => false, 'message' => 'Invalid amount'], 400);
    }

    // Validate phone
    if (!validate_phone($input['customer_phone'])) {
        json_response(['success' => false, 'message' => 'Invalid phone number format'], 400);
    }

    // Validate email if provided
    if (!empty($input['customer_email']) && !validate_email($input['customer_email'])) {
        json_response(['success' => false, 'message' => 'Invalid email format'], 400);
    }

    // Initialize Payment class
    $payment = new Payment();
    
    // Get payment method
    $method = $payment->getMethodBySlug($input['payment_method']);
    if (!$method) {
        json_response(['success' => false, 'message' => 'Invalid payment method'], 400);
    }

    // Check amount limits
    if ($amount < $method['min_amount'] || $amount > $method['max_amount']) {
        json_response([
            'success' => false, 
            'message' => "Amount must be between {$method['min_amount']} and {$method['max_amount']}"
        ], 400);
    }

    // Create payment
    $transactionData = [
        'payment_method_id' => $method['id'],
        'customer_name' => sanitize($input['customer_name']),
        'customer_email' => sanitize($input['customer_email'] ?? ''),
        'customer_phone' => sanitize($input['customer_phone']),
        'amount' => $amount,
        'success_url' => $input['success_url'] ?? BASE_URL . 'success.php',
        'cancel_url' => $input['cancel_url'] ?? BASE_URL . 'failed.php',
        'metadata' => $input['metadata'] ?? null
    ];

    $result = $payment->createPayment($transactionData);

    // Generate checkout URL
    $checkoutUrl = BASE_URL . "pay.php?method={$method['slug']}&amount={$amount}&invoice={$result['invoice_id']}";

    json_response([
        'success' => true,
        'message' => 'Payment created successfully',
        'data' => [
            'invoice_id' => $result['invoice_id'],
            'amount' => $result['amount'],
            'charge' => $result['charge'],
            'total_amount' => $result['total_amount'],
            'checkout_url' => $checkoutUrl,
            'payment_method' => [
                'name' => $method['name'],
                'slug' => $method['slug'],
                'account_number' => $method['account_number']
            ]
        ]
    ]);

} catch (Exception $e) {
    log_message('Create payment API error: ' . $e->getMessage(), 'error');
    json_response(['success' => false, 'message' => 'An error occurred'], 500);
}
