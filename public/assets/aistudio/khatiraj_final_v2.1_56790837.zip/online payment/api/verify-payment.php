<?php
/**
 * Verify Payment API
 * POST /api/verify-payment.php
 * 
 * Request body:
 * - invoice_id (required): Invoice ID to verify
 */

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, GET');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

require_once __DIR__ . '/../bootstrap.php';

try {
    // Get invoice ID from request
    $invoiceId = null;
    
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $input = json_decode(file_get_contents('php://input'), true);
        $invoiceId = $input['invoice_id'] ?? $_POST['invoice_id'] ?? null;
    } else {
        $invoiceId = $_GET['invoice_id'] ?? null;
    }

    if (empty($invoiceId)) {
        json_response(['success' => false, 'message' => 'Invoice ID is required'], 400);
    }

    // Sanitize
    $invoiceId = sanitize($invoiceId);

    // Get transaction
    $payment = new Payment();
    $transaction = $payment->getTransactionByInvoice($invoiceId);

    if (!$transaction) {
        json_response(['success' => false, 'message' => 'Transaction not found'], 404);
    }

    // Return transaction status
    json_response([
        'success' => true,
        'data' => [
            'invoice_id' => $transaction['invoice_id'],
            'status' => $transaction['status'],
            'amount' => floatval($transaction['amount']),
            'charge' => floatval($transaction['charge']),
            'total_amount' => floatval($transaction['total_amount']),
            'currency' => $transaction['currency'],
            'payment_method' => [
                'name' => $transaction['method_name'],
                'slug' => $transaction['method_slug']
            ],
            'customer' => [
                'name' => $transaction['customer_name'],
                'email' => $transaction['customer_email'],
                'phone' => $transaction['customer_phone']
            ],
            'transaction_id' => $transaction['transaction_id'],
            'created_at' => $transaction['created_at'],
            'updated_at' => $transaction['updated_at']
        ]
    ]);

} catch (Exception $e) {
    log_message('Verify payment API error: ' . $e->getMessage(), 'error');
    json_response(['success' => false, 'message' => 'An error occurred'], 500);
}
