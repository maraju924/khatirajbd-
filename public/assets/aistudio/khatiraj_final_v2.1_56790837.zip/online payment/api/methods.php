<?php
/**
 * Get Payment Methods API
 * GET /api/methods.php
 * 
 * Returns list of available payment methods
 */

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET');

require_once __DIR__ . '/../bootstrap.php';

try {
    $type = sanitize($_GET['type'] ?? '');
    
    $payment = new Payment();
    
    $methods = [];
    
    if ($type === 'mobile_banking') {
        $methods = $payment->getMobileBankingMethods();
    } elseif ($type === 'bank_transfer') {
        $methods = $payment->getBankTransferMethods();
    } else {
        $methods = $payment->getPaymentMethods();
    }

    // Format response
    $formattedMethods = array_map(function($method) {
        return [
            'id' => $method['id'],
            'name' => $method['name'],
            'slug' => $method['slug'],
            'type' => $method['type'],
            'logo' => get_logo_url($method['logo']),
            'min_amount' => floatval($method['min_amount']),
            'max_amount' => floatval($method['max_amount']),
            'charge_type' => $method['charge_type'],
            'charge_amount' => floatval($method['charge_amount'])
        ];
    }, $methods);

    json_response([
        'success' => true,
        'data' => $formattedMethods
    ]);

} catch (Exception $e) {
    log_message('Get methods API error: ' . $e->getMessage(), 'error');
    json_response(['success' => false, 'message' => 'An error occurred'], 500);
}
