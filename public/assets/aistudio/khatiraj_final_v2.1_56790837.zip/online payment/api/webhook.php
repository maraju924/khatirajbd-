<?php
/**
 * Payment Webhook Handler
 * POST /api/webhook.php
 * 
 * Handles callbacks from payment providers
 */

header('Content-Type: application/json');

require_once __DIR__ . '/../bootstrap.php';

// Only allow POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_response(['success' => false, 'message' => 'Method not allowed'], 405);
}

try {
    // Get raw payload
    $rawPayload = file_get_contents('php://input');
    $payload = json_decode($rawPayload, true);

    // Log webhook
    log_message('Webhook received: ' . $rawPayload, 'webhook');

    // Get provider from query string or payload
    $provider = sanitize($_GET['provider'] ?? $payload['provider'] ?? '');

    if (empty($provider)) {
        json_response(['success' => false, 'message' => 'Provider not specified'], 400);
    }

    // Initialize classes
    $payment = new Payment();
    $transaction = new Transaction();

    // Handle based on provider
    switch (strtolower($provider)) {
        case 'bkash':
            handleBkashWebhook($payload, $payment, $transaction);
            break;
            
        case 'nagad':
            handleNagadWebhook($payload, $payment, $transaction);
            break;
            
        case 'manual':
            handleManualWebhook($payload, $payment, $transaction);
            break;
            
        default:
            // Generic handler
            handleGenericWebhook($payload, $payment, $transaction);
    }

    json_response(['success' => true, 'message' => 'Webhook processed']);

} catch (Exception $e) {
    log_message('Webhook error: ' . $e->getMessage(), 'error');
    json_response(['success' => false, 'message' => 'Webhook processing failed'], 500);
}

/**
 * Handle bKash webhook
 */
function handleBkashWebhook($payload, $payment, $transaction)
{
    // bKash specific handling
    $invoiceId = $payload['merchantInvoiceNumber'] ?? null;
    $trxId = $payload['trxID'] ?? null;
    $status = $payload['transactionStatus'] ?? null;

    if (!$invoiceId) {
        log_message('bKash webhook: Missing invoice ID', 'error');
        return;
    }

    $newStatus = STATUS_PENDING;
    
    if ($status === 'Completed') {
        $newStatus = STATUS_COMPLETED;
    } elseif ($status === 'Failed') {
        $newStatus = STATUS_FAILED;
    }

    $payment->updateStatus($invoiceId, $newStatus, $trxId);
    log_message("bKash webhook: Updated {$invoiceId} to {$newStatus}", 'info');
}

/**
 * Handle Nagad webhook
 */
function handleNagadWebhook($payload, $payment, $transaction)
{
    // Nagad specific handling
    $invoiceId = $payload['orderId'] ?? null;
    $trxId = $payload['paymentRefId'] ?? null;
    $status = $payload['status'] ?? null;

    if (!$invoiceId) {
        log_message('Nagad webhook: Missing invoice ID', 'error');
        return;
    }

    $newStatus = STATUS_PENDING;
    
    if ($status === 'Success') {
        $newStatus = STATUS_COMPLETED;
    } elseif ($status === 'Failed' || $status === 'Aborted') {
        $newStatus = STATUS_FAILED;
    }

    $payment->updateStatus($invoiceId, $newStatus, $trxId);
    log_message("Nagad webhook: Updated {$invoiceId} to {$newStatus}", 'info');
}

/**
 * Handle manual verification webhook (for admin approval)
 */
function handleManualWebhook($payload, $payment, $transaction)
{
    $invoiceId = $payload['invoice_id'] ?? null;
    $status = $payload['status'] ?? null;
    $adminNote = $payload['note'] ?? null;

    if (!$invoiceId || !$status) {
        log_message('Manual webhook: Missing required fields', 'error');
        return;
    }

    // Validate status
    $validStatuses = [STATUS_COMPLETED, STATUS_FAILED, STATUS_CANCELLED, STATUS_REFUNDED];
    if (!in_array($status, $validStatuses)) {
        log_message("Manual webhook: Invalid status {$status}", 'error');
        return;
    }

    $payment->updateStatus($invoiceId, $status);
    
    if ($adminNote) {
        // Update note
        $txn = $payment->getTransactionByInvoice($invoiceId);
        if ($txn) {
            $transaction->update($txn['id'], ['note' => $adminNote]);
        }
    }

    log_message("Manual webhook: Updated {$invoiceId} to {$status}", 'info');
}

/**
 * Handle generic webhook
 */
function handleGenericWebhook($payload, $payment, $transaction)
{
    $invoiceId = $payload['invoice_id'] ?? $payload['order_id'] ?? null;
    $status = $payload['status'] ?? null;
    $trxId = $payload['transaction_id'] ?? $payload['trx_id'] ?? null;

    if (!$invoiceId) {
        log_message('Generic webhook: Missing invoice ID', 'error');
        return;
    }

    if ($status) {
        // Map common status values
        $statusMap = [
            'success' => STATUS_COMPLETED,
            'completed' => STATUS_COMPLETED,
            'paid' => STATUS_COMPLETED,
            'failed' => STATUS_FAILED,
            'failure' => STATUS_FAILED,
            'cancelled' => STATUS_CANCELLED,
            'canceled' => STATUS_CANCELLED,
            'pending' => STATUS_PENDING,
            'processing' => STATUS_PROCESSING
        ];

        $newStatus = $statusMap[strtolower($status)] ?? $status;
        $payment->updateStatus($invoiceId, $newStatus, $trxId);
        log_message("Generic webhook: Updated {$invoiceId} to {$newStatus}", 'info');
    }
}
