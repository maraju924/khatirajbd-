<?php
/**
 * Zinipay Webhook Callback Handler
 * POST /online payment/api/zinipay-callback.php
 * 
 * This endpoint receives webhook notifications from Zinipay
 * when a payment status changes (completed, failed, etc.)
 * 
 * Zinipay sends a POST request with payment details after
 * the customer completes or cancels a payment.
 */

header('Content-Type: application/json');

// Only allow POST requests
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Method not allowed']);
    exit;
}

// Load database and services
require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../app/Services/PaymentGateway.php';

try {
    // Get webhook payload
    $rawInput = file_get_contents('php://input');
    $payload = json_decode($rawInput, true);

    // Log the webhook for debugging
    $logFile = __DIR__ . '/../../error_log';
    file_put_contents($logFile, "\n[" . date('Y-m-d H:i:s') . "] Zinipay Webhook: " . $rawInput . "\n", FILE_APPEND);

    if (!$payload) {
        http_response_code(400);
        echo json_encode(['success' => false, 'message' => 'Invalid payload']);
        exit;
    }

    $paymentGateway = new PaymentGateway($pdo);

    // Extract payment details from webhook
    $zinipayInvoiceId = $payload['invoiceId'] ?? $payload['invoice_id'] ?? null;
    $zinipayStatus = $payload['status'] ?? null;
    $zinipayTransactionId = $payload['transaction_id'] ?? $payload['transactionId'] ?? null;
    $amount = $payload['amount'] ?? null;
    $metadata = $payload['metadata'] ?? [];

    if (!$zinipayInvoiceId) {
        http_response_code(400);
        echo json_encode(['success' => false, 'message' => 'Missing invoiceId']);
        exit;
    }

    // Always verify the payment with Zinipay API (don't trust webhook data alone)
    try {
        $verifyResult = $paymentGateway->verifyZinipayPayment($zinipayInvoiceId);
        
        if ($verifyResult) {
            $zinipayStatus = $verifyResult['status'] ?? $zinipayStatus;
            $zinipayTransactionId = $verifyResult['transaction_id'] ?? $verifyResult['transactionId'] ?? $zinipayTransactionId;
        }
    } catch (Exception $e) {
        // If verification fails, we still process the webhook but log it
        file_put_contents($logFile, "\n[" . date('Y-m-d H:i:s') . "] Zinipay Verify Error: " . $e->getMessage() . "\n", FILE_APPEND);
    }

    // Find our internal transaction using the metadata
    $internalInvoiceId = $metadata['invoiceId'] ?? null;
    
    if (!$internalInvoiceId) {
        // Try to find by searching payment_transactions for Zinipay-related entries
        // The invoiceId in metadata was set during payment creation
        http_response_code(200);
        echo json_encode(['success' => true, 'message' => 'No matching internal invoice found, webhook acknowledged']);
        exit;
    }

    $transaction = $paymentGateway->getTransactionByInvoice($internalInvoiceId);

    if (!$transaction) {
        http_response_code(200);
        echo json_encode(['success' => true, 'message' => 'Transaction not found, webhook acknowledged']);
        exit;
    }

    // Map Zinipay status to our internal status
    $statusUpper = strtoupper($zinipayStatus ?? '');
    
    switch ($statusUpper) {
        case 'COMPLETED':
        case 'SUCCESS':
            // Update transaction ID from Zinipay
            if ($zinipayTransactionId) {
                $stmt = $pdo->prepare("UPDATE payment_transactions SET transaction_id = ? WHERE id = ?");
                $stmt->execute([$zinipayTransactionId, $transaction['id']]);
            }
            
            // Mark as completed (this also updates order payment_status and handles digital delivery)
            $paymentGateway->updateTransactionStatus(
                $transaction['id'], 
                'completed', 
                'Auto-verified via Zinipay webhook. TxID: ' . ($zinipayTransactionId ?? 'N/A')
            );
            break;

        case 'FAILED':
        case 'EXPIRED':
            $paymentGateway->updateTransactionStatus(
                $transaction['id'], 
                'failed', 
                'Payment failed/expired via Zinipay webhook. Status: ' . $zinipayStatus
            );
            break;

        case 'CANCELLED':
        case 'CANCELED':
            $paymentGateway->updateTransactionStatus(
                $transaction['id'], 
                'cancelled', 
                'Payment cancelled via Zinipay webhook'
            );
            break;

        case 'PENDING':
        case 'PROCESSING':
            $paymentGateway->updateTransactionStatus(
                $transaction['id'], 
                'processing', 
                'Zinipay webhook status: ' . $zinipayStatus
            );
            break;

        default:
            file_put_contents($logFile, "\n[" . date('Y-m-d H:i:s') . "] Zinipay Unknown Status: " . $zinipayStatus . "\n", FILE_APPEND);
            break;
    }

    // Respond with success to Zinipay
    http_response_code(200);
    echo json_encode(['success' => true, 'message' => 'Webhook processed successfully']);

} catch (Exception $e) {
    // Log the error
    file_put_contents(
        __DIR__ . '/../../error_log', 
        "\n[" . date('Y-m-d H:i:s') . "] Zinipay Webhook Error: " . $e->getMessage() . "\n", 
        FILE_APPEND
    );
    
    http_response_code(200); // Always return 200 to prevent Zinipay from retrying
    echo json_encode(['success' => false, 'message' => 'Internal error, but webhook acknowledged']);
}
