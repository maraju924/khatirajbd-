# Payment Gateway System

A complete payment gateway system for core PHP websites with mobile banking and bank transfer support.

## Features

- **Mobile Banking:** bKash, Nagad, Rocket, Upay, Cellfin, Tap, OkWallet, Ipay
- **Bank Transfer:** DBBL, City Bank, BRAC Bank
- **Modern UI:** Glassmorphism design, responsive, tab-based navigation
- **API Support:** RESTful APIs for integration
- **Secure:** CSRF protection, input validation, prepared statements

## Installation

### 1. Database Setup

1. Create a MySQL database named `payment_gateway`
2. Import the SQL schema:
   ```bash
   mysql -u root -p payment_gateway < payment_gateway.sql
   ```

### 2. Configuration

Edit `config/database.php` with your database credentials:
```php
define('DB_HOST', 'localhost');
define('DB_NAME', 'payment_gateway');
define('DB_USER', 'root');
define('DB_PASS', '');
```

Edit `config/constants.php` to set your base URL:
```php
define('BASE_URL', 'http://localhost/online%20payment/');
```

### 3. Payment Method Setup

Update the `payment_methods` table with your actual account numbers:
```sql
UPDATE payment_methods SET account_number = '01XXXXXXXXX' WHERE slug = 'bkash';
UPDATE payment_methods SET account_number = '01XXXXXXXXX' WHERE slug = 'nagad';
-- etc.
```

## Usage

### Basic Checkout
Access the checkout page at:
```
http://localhost/online%20payment/checkout.php
```

With parameters:
```
http://localhost/online%20payment/checkout.php?amount=1000&name=Customer%20Name
```

### API Integration

#### Create Payment
```bash
POST /api/create-payment.php
Content-Type: application/json

{
  "amount": 1000,
  "customer_name": "John Doe",
  "customer_phone": "01712345678",
  "payment_method": "bkash",
  "success_url": "https://yoursite.com/success",
  "cancel_url": "https://yoursite.com/cancel"
}
```

Response:
```json
{
  "success": true,
  "data": {
    "invoice_id": "INV-20260201-A1B2C3",
    "checkout_url": "http://localhost/pay.php?method=bkash&amount=1000"
  }
}
```

#### Verify Payment
```bash
GET /api/verify-payment.php?invoice_id=INV-20260201-A1B2C3
```

Response:
```json
{
  "success": true,
  "data": {
    "invoice_id": "INV-20260201-A1B2C3",
    "status": "completed",
    "amount": 1000
  }
}
```

#### Get Payment Methods
```bash
GET /api/methods.php?type=mobile_banking
```

### Webhook Integration

Configure your payment provider to send webhooks to:
```
POST /api/webhook.php?provider=bkash
```

## File Structure

```
online payment/
├── api/
│   ├── create-payment.php
│   ├── verify-payment.php
│   ├── webhook.php
│   └── methods.php
├── assets/
│   ├── css/
│   │   └── payment.css
│   ├── js/
│   │   └── payment.js
│   └── images/
│       └── (payment logos)
├── classes/
│   ├── Database.php
│   ├── Payment.php
│   └── Transaction.php
├── config/
│   ├── database.php
│   └── constants.php
├── includes/
│   └── helpers.php
├── bootstrap.php
├── checkout.php
├── pay.php
├── success.php
├── failed.php
├── index.php
├── payment_gateway.sql
└── README.md
```

## Adding Payment Logos

Place payment method logos in `assets/images/` directory:
- bkash.png
- nagad.png
- rocket.png
- upay.png
- cellfin.png
- tap.png
- okwallet.png
- ipay.png
- dbbl.png
- cbl.png
- bbl.png
- logo.png (your company logo)

## Security Notes

- Always use HTTPS in production
- Update CSRF token implementation for enhanced security
- Validate all webhook signatures from payment providers
- Store sensitive API credentials securely
- Implement rate limiting for API endpoints

## Support

For any issues or questions, contact your development team.

---

**Version:** 1.0.0  
**Created:** February 2026
