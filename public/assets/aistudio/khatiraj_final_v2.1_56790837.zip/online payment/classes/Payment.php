<?php
/**
 * Payment Class
 * Handles payment processing
 */

class Payment
{
    private $db;

    public function __construct()
    {
        $this->db = Database::getInstance();
    }

    /**
     * Get all active payment methods
     */
    public function getPaymentMethods($type = null)
    {
        $sql = "SELECT * FROM payment_methods WHERE is_active = 1";
        $params = [];

        if ($type) {
            $sql .= " AND type = :type";
            $params['type'] = $type;
        }

        $sql .= " ORDER BY sort_order ASC";

        return $this->db->fetchAll($sql, $params);
    }

    /**
     * Get mobile banking methods
     */
    public function getMobileBankingMethods()
    {
        return $this->getPaymentMethods(TYPE_MOBILE_BANKING);
    }

    /**
     * Get bank transfer methods
     */
    public function getBankTransferMethods()
    {
        return $this->getPaymentMethods(TYPE_BANK_TRANSFER);
    }

    /**
     * Get payment method by slug
     */
    public function getMethodBySlug($slug)
    {
        $sql = "SELECT * FROM payment_methods WHERE slug = :slug AND is_active = 1";
        return $this->db->fetch($sql, ['slug' => $slug]);
    }

    /**
     * Get payment method by ID
     */
    public function getMethodById($id)
    {
        $sql = "SELECT * FROM payment_methods WHERE id = :id";
        return $this->db->fetch($sql, ['id' => $id]);
    }

    /**
     * Create a new payment/transaction
     */
    public function createPayment($data)
    {
        // Generate unique invoice ID
        $invoiceId = $this->generateInvoiceId();

        // Get payment method
        $method = $this->getMethodById($data['payment_method_id']);
        if (!$method) {
            throw new Exception("Invalid payment method");
        }

        // Calculate charge
        $charge = $this->calculateCharge($method, $data['amount']);
        $totalAmount = $data['amount'] + $charge;

        // Prepare transaction data
        $transactionData = [
            'invoice_id' => $invoiceId,
            'payment_method_id' => $data['payment_method_id'],
            'customer_name' => $data['customer_name'],
            'customer_email' => $data['customer_email'] ?? null,
            'customer_phone' => $data['customer_phone'] ?? null,
            'amount' => $data['amount'],
            'charge' => $charge,
            'total_amount' => $totalAmount,
            'currency' => $data['currency'] ?? DEFAULT_CURRENCY,
            'callback_url' => $data['callback_url'] ?? null,
            'success_url' => $data['success_url'] ?? null,
            'cancel_url' => $data['cancel_url'] ?? null,
            'ip_address' => $_SERVER['REMOTE_ADDR'] ?? null,
            'user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? null,
            'metadata' => isset($data['metadata']) ? json_encode($data['metadata']) : null,
            'status' => STATUS_PENDING
        ];

        // Insert transaction
        $id = $this->db->insert('transactions', $transactionData);

        return [
            'id' => $id,
            'invoice_id' => $invoiceId,
            'amount' => $data['amount'],
            'charge' => $charge,
            'total_amount' => $totalAmount,
            'payment_method' => $method
        ];
    }

    /**
     * Calculate payment charge
     */
    private function calculateCharge($method, $amount)
    {
        if ($method['charge_type'] === 'percentage') {
            return round(($amount * $method['charge_amount']) / 100, 2);
        }
        return $method['charge_amount'];
    }

    /**
     * Generate unique invoice ID
     */
    private function generateInvoiceId()
    {
        return 'INV-' . date('Ymd') . '-' . strtoupper(substr(uniqid(), -6));
    }

    /**
     * Get transaction by invoice ID
     */
    public function getTransactionByInvoice($invoiceId)
    {
        $sql = "SELECT t.*, pm.name as method_name, pm.slug as method_slug, pm.logo as method_logo
                FROM transactions t
                JOIN payment_methods pm ON t.payment_method_id = pm.id
                WHERE t.invoice_id = :invoice_id";
        return $this->db->fetch($sql, ['invoice_id' => $invoiceId]);
    }

    /**
     * Update transaction status
     */
    public function updateStatus($invoiceId, $status, $transactionId = null)
    {
        $data = ['status' => $status];
        if ($transactionId) {
            $data['transaction_id'] = $transactionId;
        }

        return $this->db->update(
            'transactions',
            $data,
            'invoice_id = :invoice_id',
            ['invoice_id' => $invoiceId]
        );
    }

    /**
     * Verify payment (to be overridden for specific gateways)
     */
    public function verifyPayment($invoiceId, $data = [])
    {
        $transaction = $this->getTransactionByInvoice($invoiceId);
        
        if (!$transaction) {
            return ['success' => false, 'message' => 'Transaction not found'];
        }

        // Update with provided transaction ID
        if (isset($data['transaction_id']) && isset($data['sender_number'])) {
            $this->db->update(
                'transactions',
                [
                    'transaction_id' => $data['transaction_id'],
                    'sender_number' => $data['sender_number'],
                    'status' => STATUS_PROCESSING
                ],
                'invoice_id = :invoice_id',
                ['invoice_id' => $invoiceId]
            );

            return ['success' => true, 'message' => 'Payment submitted for verification'];
        }

        return ['success' => false, 'message' => 'Invalid verification data'];
    }

    /**
     * Get settings
     */
    public function getSetting($key)
    {
        $sql = "SELECT value FROM settings WHERE key_name = :key";
        $result = $this->db->fetch($sql, ['key' => $key]);
        return $result ? $result['value'] : null;
    }

    /**
     * Get all settings
     */
    public function getAllSettings()
    {
        $sql = "SELECT key_name, value FROM settings";
        $results = $this->db->fetchAll($sql);
        
        $settings = [];
        foreach ($results as $row) {
            $settings[$row['key_name']] = $row['value'];
        }
        return $settings;
    }
}
