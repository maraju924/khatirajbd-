<?php
/**
 * Transaction Class
 * Handles transaction operations
 */

class Transaction
{
    private $db;

    public function __construct()
    {
        $this->db = Database::getInstance();
    }

    /**
     * Get transaction by ID
     */
    public function getById($id)
    {
        $sql = "SELECT t.*, pm.name as method_name, pm.slug as method_slug, pm.logo as method_logo
                FROM transactions t
                JOIN payment_methods pm ON t.payment_method_id = pm.id
                WHERE t.id = :id";
        return $this->db->fetch($sql, ['id' => $id]);
    }

    /**
     * Get transaction by invoice ID
     */
    public function getByInvoice($invoiceId)
    {
        $sql = "SELECT t.*, pm.name as method_name, pm.slug as method_slug, pm.logo as method_logo
                FROM transactions t
                JOIN payment_methods pm ON t.payment_method_id = pm.id
                WHERE t.invoice_id = :invoice_id";
        return $this->db->fetch($sql, ['invoice_id' => $invoiceId]);
    }

    /**
     * Get all transactions
     */
    public function getAll($limit = 50, $offset = 0)
    {
        $sql = "SELECT t.*, pm.name as method_name, pm.slug as method_slug
                FROM transactions t
                JOIN payment_methods pm ON t.payment_method_id = pm.id
                ORDER BY t.created_at DESC
                LIMIT :limit OFFSET :offset";
        
        $stmt = $this->db->getConnection()->prepare($sql);
        $stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
        $stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
        $stmt->execute();
        
        return $stmt->fetchAll();
    }

    /**
     * Get transactions by status
     */
    public function getByStatus($status, $limit = 50)
    {
        $sql = "SELECT t.*, pm.name as method_name, pm.slug as method_slug
                FROM transactions t
                JOIN payment_methods pm ON t.payment_method_id = pm.id
                WHERE t.status = :status
                ORDER BY t.created_at DESC
                LIMIT :limit";
        
        $stmt = $this->db->getConnection()->prepare($sql);
        $stmt->bindValue(':status', $status, PDO::PARAM_STR);
        $stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
        $stmt->execute();
        
        return $stmt->fetchAll();
    }

    /**
     * Update transaction
     */
    public function update($id, $data)
    {
        return $this->db->update('transactions', $data, 'id = :id', ['id' => $id]);
    }

    /**
     * Update status
     */
    public function updateStatus($id, $status)
    {
        return $this->update($id, ['status' => $status]);
    }

    /**
     * Mark as completed
     */
    public function markAsCompleted($id, $transactionId = null)
    {
        $data = ['status' => STATUS_COMPLETED];
        if ($transactionId) {
            $data['transaction_id'] = $transactionId;
        }
        return $this->update($id, $data);
    }

    /**
     * Mark as failed
     */
    public function markAsFailed($id, $note = null)
    {
        $data = ['status' => STATUS_FAILED];
        if ($note) {
            $data['note'] = $note;
        }
        return $this->update($id, $data);
    }

    /**
     * Get transaction count
     */
    public function getCount($status = null)
    {
        $sql = "SELECT COUNT(*) as count FROM transactions";
        $params = [];

        if ($status) {
            $sql .= " WHERE status = :status";
            $params['status'] = $status;
        }

        $result = $this->db->fetch($sql, $params);
        return $result['count'];
    }

    /**
     * Get total amount
     */
    public function getTotalAmount($status = null)
    {
        $sql = "SELECT SUM(total_amount) as total FROM transactions";
        $params = [];

        if ($status) {
            $sql .= " WHERE status = :status";
            $params['status'] = $status;
        }

        $result = $this->db->fetch($sql, $params);
        return $result['total'] ?? 0;
    }

    /**
     * Search transactions
     */
    public function search($query, $limit = 50)
    {
        $sql = "SELECT t.*, pm.name as method_name, pm.slug as method_slug
                FROM transactions t
                JOIN payment_methods pm ON t.payment_method_id = pm.id
                WHERE t.invoice_id LIKE :query
                   OR t.customer_name LIKE :query
                   OR t.customer_phone LIKE :query
                   OR t.transaction_id LIKE :query
                ORDER BY t.created_at DESC
                LIMIT :limit";
        
        $stmt = $this->db->getConnection()->prepare($sql);
        $stmt->bindValue(':query', "%{$query}%", PDO::PARAM_STR);
        $stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
        $stmt->execute();
        
        return $stmt->fetchAll();
    }
}
