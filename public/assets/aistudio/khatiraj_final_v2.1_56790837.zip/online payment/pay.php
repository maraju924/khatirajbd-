<?php
/**
 * Payment Processing Page
 * Handle individual payment method flow
 */

require_once __DIR__ . '/bootstrap.php';

// Get payment method
$methodSlug = sanitize($_GET['method'] ?? '');
$type = sanitize($_GET['type'] ?? 'personal');
$amount = floatval($_GET['amount'] ?? 0);

if (empty($methodSlug)) {
    redirect('checkout.php');
}

// Initialize Payment class
$payment = new Payment();
$method = $payment->getMethodBySlug($methodSlug);

if (!$method) {
    set_flash('error', 'Invalid payment method');
    redirect('checkout.php');
}

// Get settings
$settings = $payment->getAllSettings();

// Handle form submission
if (is_post()) {
    // Verify CSRF
    if (!verify_csrf($_POST[CSRF_TOKEN_NAME] ?? '')) {
        if (is_ajax()) {
            json_response(['success' => false, 'message' => 'Invalid security token. Please refresh and try again.'], 400);
        }
        set_flash('error', 'Invalid security token');
        redirect($_SERVER['REQUEST_URI']);
    }

    // Validate input
    $senderNumber = sanitize($_POST['sender_number'] ?? '');
    $transactionId = sanitize($_POST['transaction_id'] ?? '');
    $customerName = sanitize($_POST['customer_name'] ?? '');
    $customerPhone = sanitize($_POST['customer_phone'] ?? '');
    $customerEmail = sanitize($_POST['customer_email'] ?? '');

    $errors = [];

    if (empty($senderNumber)) {
        $errors[] = 'Sender number is required';
    } elseif (!validate_phone($senderNumber)) {
        $errors[] = 'Invalid sender number format';
    }

    if (empty($transactionId)) {
        $errors[] = 'Transaction ID is required';
    }

    if (empty($customerName)) {
        $errors[] = 'Your name is required';
    }

    if (empty($customerPhone)) {
        $errors[] = 'Your phone number is required';
    } elseif (!validate_phone($customerPhone)) {
        $errors[] = 'Invalid phone number format';
    }

    if (!empty($customerEmail) && !validate_email($customerEmail)) {
        $errors[] = 'Invalid email format';
    }

    if (!empty($errors)) {
        if (is_ajax()) {
            json_response(['success' => false, 'message' => implode(', ', $errors)], 400);
        }
        set_flash('error', implode('<br>', $errors));
    } else {
        try {
            // Create transaction
            $transactionData = [
                'payment_method_id' => $method['id'],
                'customer_name' => $customerName,
                'customer_email' => $customerEmail,
                'customer_phone' => $customerPhone,
                'amount' => $amount,
                'success_url' => BASE_URL . 'success.php',
                'cancel_url' => BASE_URL . 'failed.php',
                'metadata' => [
                    'sender_number' => $senderNumber,
                    'provider_transaction_id' => $transactionId,
                    'payment_type' => $type
                ]
            ];

            $result = $payment->createPayment($transactionData);

            // Update with sender info
            $payment->verifyPayment($result['invoice_id'], [
                'transaction_id' => $transactionId,
                'sender_number' => $senderNumber
            ]);

            // Store invoice in session
            $_SESSION['last_invoice'] = $result['invoice_id'];

            if (is_ajax()) {
                json_response([
                    'success' => true, 
                    'message' => 'Payment submitted successfully! We will verify your payment shortly.',
                    'redirect' => BASE_URL . 'success.php?invoice=' . $result['invoice_id']
                ]);
            }

            redirect('success.php?invoice=' . $result['invoice_id']);

        } catch (Exception $e) {
            log_message('Payment error: ' . $e->getMessage(), 'error');
            
            if (is_ajax()) {
                json_response(['success' => false, 'message' => 'An error occurred. Please try again.'], 500);
            }
            set_flash('error', 'An error occurred. Please try again.');
        }
    }
}

// Get flash message
$flash = get_flash();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <title>Pay with <?php echo htmlspecialchars($method['name']); ?> - <?php echo htmlspecialchars($settings['site_name'] ?? 'Payment Gateway'); ?></title>
    <link rel="icon" href="<?php echo IMAGES_URL; ?>favicon.ico">
    
    <!-- Google Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    
    <!-- CSS -->
    <link rel="stylesheet" href="<?php echo CSS_URL; ?>payment.css">
    <style>
        .payment-info-box {
            background: var(--primary-light);
            border-radius: var(--radius-md);
            padding: 20px;
            margin-bottom: 24px;
            text-align: center;
        }
        .payment-method-logo {
            width: 120px;
            margin-bottom: 16px;
        }
        .payment-account {
            font-size: 1.5rem;
            font-weight: 600;
            color: var(--primary-color);
            margin-bottom: 8px;
        }
        .payment-account-type {
            color: var(--text-light);
            font-size: 0.875rem;
        }
        .copy-btn {
            background: var(--primary-color);
            color: #fff;
            border: none;
            padding: 6px 12px;
            border-radius: 4px;
            cursor: pointer;
            font-size: 0.75rem;
            margin-left: 8px;
        }
        .copy-btn:hover {
            background: var(--primary-dark);
        }
        .instructions {
            background: #fffbeb;
            border: 1px solid #fcd34d;
            border-radius: var(--radius-md);
            padding: 16px;
            margin-bottom: 24px;
        }
        .instructions h4 {
            color: #d97706;
            margin-bottom: 8px;
            font-size: 0.875rem;
        }
        .instructions ol {
            color: var(--text-dark);
            font-size: 0.875rem;
            padding-left: 20px;
            margin: 0;
        }
        .instructions li {
            margin-bottom: 4px;
        }
        .back-link {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            color: var(--primary-color);
            text-decoration: none;
            font-size: 0.875rem;
            margin-bottom: 16px;
        }
        .back-link:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <div class="payment-container">
        <div class="payment-wrapper">
            <!-- Back Link -->
            <a href="checkout.php" class="back-link">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <path d="M19 12H5M12 19l-7-7 7-7"/>
                </svg>
                Back to Payment Methods
            </a>

            <!-- Payment Method Info -->
            <div class="payment-info-box">
                <img src="<?php echo get_logo_url($method['logo']); ?>" alt="<?php echo htmlspecialchars($method['name']); ?>" class="payment-method-logo" onerror="this.src='https://via.placeholder.com/120x60?text=<?php echo urlencode($method['name']); ?>'">
                <div class="payment-account">
                    <?php echo htmlspecialchars($method['account_number']); ?>
                    <button class="copy-btn" onclick="copyToClipboard('<?php echo $method['account_number']; ?>', this)">Copy</button>
                </div>
                <div class="payment-account-type">
                    <?php echo ucfirst($type); ?> Account
                </div>
            </div>

            <!-- Instructions -->
            <div class="instructions">
                <h4>📋 Payment Instructions:</h4>
                <ol>
                    <li>Open your <?php echo htmlspecialchars($method['name']); ?> app</li>
                    <li>Send <strong><?php echo number_format($amount, 2); ?> BDT</strong> to the number above</li>
                    <li>Note down the Transaction ID from your <?php echo htmlspecialchars($method['name']); ?> confirmation</li>
                    <li>Fill in the form below with your payment details</li>
                    <li>Click "Submit Payment" to complete</li>
                </ol>
            </div>

            <?php if ($flash): ?>
            <div class="alert alert-<?php echo $flash['type']; ?>">
                <?php echo $flash['message']; ?>
            </div>
            <?php endif; ?>

            <!-- Payment Form -->
            <form action="" method="POST" class="payment-form">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="amount" value="<?php echo $amount; ?>">
                
                <div class="form-group">
                    <label class="form-label" for="customer_name">Your Name *</label>
                    <input type="text" id="customer_name" name="customer_name" class="form-input" placeholder="Enter your full name" required>
                </div>

                <div class="form-group">
                    <label class="form-label" for="customer_phone">Your Phone Number *</label>
                    <input type="tel" id="customer_phone" name="customer_phone" class="form-input" placeholder="01XXXXXXXXX" required>
                </div>

                <div class="form-group">
                    <label class="form-label" for="customer_email">Email Address (Optional)</label>
                    <input type="email" id="customer_email" name="customer_email" class="form-input" placeholder="your@email.com">
                </div>

                <div class="form-group">
                    <label class="form-label" for="sender_number"><?php echo htmlspecialchars($method['name']); ?> Number (From which you sent) *</label>
                    <input type="tel" id="sender_number" name="sender_number" class="form-input" placeholder="01XXXXXXXXX" required>
                </div>

                <div class="form-group">
                    <label class="form-label" for="transaction_id">Transaction ID (TrxID) *</label>
                    <input type="text" id="transaction_id" name="transaction_id" class="form-input" placeholder="Enter Transaction ID from <?php echo $method['name']; ?>" required>
                    <p class="form-helper">You can find this in your <?php echo htmlspecialchars($method['name']); ?> confirmation message</p>
                </div>

                <button type="submit" class="btn btn-primary btn-block btn-lg">
                    Submit Payment
                </button>
            </form>

            <!-- Amount Bar -->
            <div class="payment-amount-bar" style="position: static; margin-top: 24px;">
                Amount: <?php echo number_format($amount, 2); ?> BDT
            </div>
        </div>
    </div>

    <script src="<?php echo JS_URL; ?>payment.js"></script>
</body>
</html>
