<?php
/**
 * System Constants
 * Payment Gateway System
 */

// Base URL (change this to your domain)
define('BASE_URL', 'http://localhost/online%20payment/');

// Directory paths
define('ROOT_PATH', dirname(__DIR__) . '/');
define('CONFIG_PATH', ROOT_PATH . 'config/');
define('CLASSES_PATH', ROOT_PATH . 'classes/');
define('ASSETS_PATH', ROOT_PATH . 'assets/');
define('UPLOADS_PATH', ROOT_PATH . 'uploads/');

// Asset URLs
define('ASSETS_URL', BASE_URL . 'assets/');
define('IMAGES_URL', ASSETS_URL . 'images/');
define('CSS_URL', ASSETS_URL . 'css/');
define('JS_URL', ASSETS_URL . 'js/');

// Payment statuses
define('STATUS_PENDING', 'pending');
define('STATUS_PROCESSING', 'processing');
define('STATUS_COMPLETED', 'completed');
define('STATUS_FAILED', 'failed');
define('STATUS_CANCELLED', 'cancelled');
define('STATUS_REFUNDED', 'refunded');

// Payment types
define('TYPE_MOBILE_BANKING', 'mobile_banking');
define('TYPE_BANK_TRANSFER', 'bank_transfer');
define('TYPE_CARD', 'card');

// Currency
define('DEFAULT_CURRENCY', 'BDT');
define('CURRENCY_SYMBOL', '৳');

// Session settings
define('SESSION_NAME', 'PAYMENT_SESSION');
define('SESSION_LIFETIME', 3600); // 1 hour

// Security
define('CSRF_TOKEN_NAME', 'csrf_token');

// Timezone
date_default_timezone_set('Asia/Dhaka');

// Error reporting — hide details on live; show on localhost
$__is_local = (isset($_SERVER['HTTP_HOST']) && (
    str_contains($_SERVER['HTTP_HOST'], 'localhost')
    || str_contains($_SERVER['HTTP_HOST'], '127.0.0.1')
));
if ($__is_local) {
    error_reporting(E_ALL);
    ini_set('display_errors', '1');
} else {
    error_reporting(E_ALL & ~E_DEPRECATED & ~E_STRICT);
    ini_set('display_errors', '0');
    ini_set('log_errors', '1');
}
