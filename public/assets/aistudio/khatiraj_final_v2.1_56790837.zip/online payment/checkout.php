<?php
/**
 * Payment Checkout Page
 * Main payment gateway interface
 */

require_once __DIR__ . '/bootstrap.php';

// Initialize Payment class
$payment = new Payment();

// Get payment methods
$mobileBankingMethods = $payment->getMobileBankingMethods();
$bankTransferMethods = $payment->getBankTransferMethods();

// Get settings
$settings = $payment->getAllSettings();

// Sample transaction data (in production, this would come from your order/cart)
$transaction = [
    'customer_name' => $_GET['name'] ?? 'Customer Name',
    'amount' => floatval($_GET['amount'] ?? 1000),
    'currency' => $settings['currency'] ?? 'BDT'
];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <!-- Meta Tags -->
    <title>Secure Checkout - <?php echo htmlspecialchars($settings['site_name'] ?? 'Payment Gateway'); ?></title>
    <meta name="description" content="Secure payment checkout">
    <link rel="icon" href="<?php echo IMAGES_URL; ?>favicon.ico">
    
    <!-- Open Graph -->
    <meta property="og:type" content="website">
    <meta property="og:title" content="Secure Checkout">
    <meta property="og:description" content="Complete your payment securely">
    
    <!-- Google Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&family=Baloo+Da+2:wght@400;500;600;700&display=swap" rel="stylesheet">
    
    <!-- CSS -->
    <link rel="stylesheet" href="<?php echo CSS_URL; ?>payment.css">
</head>
<body>
    <!-- Page Loader -->
    <div id="pageOverlay" class="loading-overlay visible">
        <div class="loader"></div>
    </div>

    <!-- Main Container -->
    <div class="payment-container">
        <div class="payment-wrapper">
            <!-- Navigation -->
            <div class="payment-nav">
                <a href="<?php echo BASE_URL; ?>" class="nav-home" title="Home">
                    <svg viewBox="0 0 17 19" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M6 18V10H11V18" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                        <path d="M1 6.95L8.5 1L16 6.95V16.3C16 16.7509 15.8244 17.1833 15.5118 17.5021C15.1993 17.8209 14.7754 18 14.3333 18H2.66667C2.22464 18 1.80072 17.8209 1.48816 17.5021C1.17559 17.1833 1 16.7509 1 16.3V6.95Z" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                    </svg>
                </a>
                <div class="nav-actions">
                    <button class="nav-btn" id="languageToggle" title="Change Language">
                        <svg viewBox="0 0 19 19" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M5.397 7.973L4.88 9.5H3.563L5.774 3.563H7.298L9.5 9.5H8.114L7.598 7.973H5.397ZM7.338 7.099L6.531 4.698H6.473L5.667 7.099H7.338Z" fill="currentColor"/>
                            <path d="M0 2.375C0 1.745 0.25 1.141 0.696 0.696C1.141 0.25 1.745 0 2.375 0H10.688C11.317 0 11.921 0.25 12.367 0.696C12.812 1.141 13.063 1.745 13.063 2.375V5.938H16.625C17.255 5.938 17.859 6.188 18.304 6.633C18.75 7.079 19 7.683 19 8.313V16.625C19 17.255 18.75 17.859 18.304 18.304C17.859 18.75 17.255 19 16.625 19H8.313C7.683 19 7.079 18.75 6.633 18.304C6.188 17.859 5.938 17.255 5.938 16.625V13.063H2.375C1.745 13.063 1.141 12.812 0.696 12.367C0.25 11.921 0 11.317 0 10.688V2.375Z" fill="currentColor"/>
                        </svg>
                    </button>
                    <button class="nav-btn" onclick="window.close()" title="Cancel Payment">
                        <svg viewBox="0 0 14 14" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M13 1L1 13" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                            <path d="M1 1L13 13" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                        </svg>
                    </button>
                </div>
            </div>

            <!-- Profile Section -->
            <div class="profile-section">
                <img src="<?php echo IMAGES_URL; ?>logo.png" alt="<?php echo htmlspecialchars($settings['site_name'] ?? 'Payment Gateway'); ?>" class="profile-logo" onerror="this.src='https://via.placeholder.com/90x90?text=Logo'">
                <div class="profile-info">
                    <h3 class="profile-name"><?php echo htmlspecialchars($settings['site_name'] ?? 'Payment Gateway'); ?></h3>
                    <div class="profile-tabs">
                        <a href="#" class="profile-tab active" data-tab="methods_section">
                            <svg viewBox="0 0 24 23" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path d="M20.8 9.8C20.8 7.466 19.873 5.228 18.223 3.577C16.572 1.927 14.334 1 12 1C9.666 1 7.428 1.927 5.777 3.577C4.127 5.228 3.2 7.466 3.2 9.8" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                <path d="M20.8 17.5V18.05C20.8 18.634 20.568 19.193 20.156 19.606C19.743 20.018 19.184 20.25 18.6 20.25H14.75" stroke="currentColor" stroke-width="1.5"/>
                                <path d="M13.65 21.9H10.35C9.912 21.9 9.492 21.726 9.183 21.417C8.874 21.107 8.7 20.688 8.7 20.25C8.7 19.812 8.874 19.393 9.183 19.083C9.492 18.774 9.912 18.6 10.35 18.6H13.65C14.088 18.6 14.507 18.774 14.817 19.083C15.126 19.393 15.3 19.812 15.3 20.25C15.3 20.688 15.126 21.107 14.817 21.417C14.507 21.726 14.088 21.9 13.65 21.9Z" stroke="currentColor" stroke-width="1.5"/>
                            </svg>
                            <span>Support</span>
                        </a>
                        <a href="#" class="profile-tab" data-tab="faq_section">
                            <svg viewBox="0 0 23 23" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path d="M11.5 1C9.423 1 7.393 1.616 5.667 2.77C3.94 3.923 2.594 5.563 1.799 7.482C1.005 9.4 0.797 11.512 1.202 13.548C1.607 15.585 2.607 17.456 4.075 18.925C5.544 20.393 7.415 21.393 9.452 21.798C11.488 22.203 13.6 21.996 15.518 21.201C17.437 20.406 19.077 19.06 20.23 17.334C21.384 15.607 22 13.577 22 11.5C22 8.715 20.894 6.045 18.925 4.075C16.956 2.106 14.285 1 11.5 1Z" stroke="currentColor" stroke-width="1.5" stroke-miterlimit="10"/>
                                <path d="M8.159 8.296C8.159 8.296 8.209 7.252 9.327 6.353C9.99 5.819 10.784 5.664 11.5 5.653C12.152 5.645 12.734 5.753 13.083 5.919C13.679 6.203 14.841 6.896 14.841 8.37C14.841 9.921 13.827 10.626 12.671 11.401C11.516 12.176 11.202 13.017 11.202 13.886" stroke="currentColor" stroke-width="1.5" stroke-miterlimit="10" stroke-linecap="round"/>
                                <circle cx="11.142" cy="16.989" r="1.193" fill="currentColor"/>
                            </svg>
                            <span>FAQ</span>
                        </a>
                        <a href="#" class="profile-tab" data-tab="details_section">
                            <svg viewBox="0 0 23 23" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path d="M11.5 1C5.702 1 1 5.702 1 11.5C1 17.298 5.702 22 11.5 22C17.298 22 22 17.298 22 11.5C22 5.702 17.298 1 11.5 1Z" stroke="currentColor" stroke-width="1.5" stroke-miterlimit="10"/>
                                <path d="M10 10H12V17" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                <path d="M9 17H14" stroke="currentColor" stroke-width="1.5" stroke-miterlimit="10" stroke-linecap="round"/>
                                <circle cx="11.5" cy="6.5" r="1.5" fill="currentColor"/>
                            </svg>
                            <span>Details</span>
                        </a>
                    </div>
                </div>
            </div>

            <!-- Payment Type Tabs -->
            <div class="payment-type-tabs">
                <a href="#" class="type-tab active" data-tab="mobile_banking">Mobile Banking</a>
                <a href="#" class="type-tab" data-tab="bank_transfer">Bank Transfer</a>
            </div>

            <!-- Payment Content -->
            <div class="payment-content">
                
                <!-- Mobile Banking Section -->
                <div id="mobile_banking" class="payment-section active">
                    <div class="methods-grid">
                        <?php foreach ($mobileBankingMethods as $method): ?>
                        <a href="#" class="method-card" data-modal="modal_<?php echo $method['slug']; ?>">
                            <img src="<?php echo get_logo_url($method['logo']); ?>" alt="<?php echo htmlspecialchars($method['name']); ?>" onerror="this.src='https://via.placeholder.com/80x40?text=<?php echo urlencode($method['name']); ?>'">
                        </a>
                        <?php endforeach; ?>
                        
                        <?php if (empty($mobileBankingMethods)): ?>
                        <div class="alert alert-info" style="grid-column: 1/-1;">
                            No mobile banking methods available at the moment.
                        </div>
                        <?php endif; ?>
                    </div>
                </div>

                <!-- Bank Transfer Section -->
                <div id="bank_transfer" class="payment-section">
                    <div class="methods-grid">
                        <?php foreach ($bankTransferMethods as $method): ?>
                        <a href="pay.php?method=<?php echo $method['slug']; ?>&amount=<?php echo $transaction['amount']; ?>" class="method-card">
                            <img src="<?php echo get_logo_url($method['logo']); ?>" alt="<?php echo htmlspecialchars($method['name']); ?>" onerror="this.src='https://via.placeholder.com/80x40?text=<?php echo urlencode($method['name']); ?>'">
                        </a>
                        <?php endforeach; ?>
                        
                        <?php if (empty($bankTransferMethods)): ?>
                        <div class="alert alert-info" style="grid-column: 1/-1;">
                            No bank transfer methods available at the moment.
                        </div>
                        <?php endif; ?>
                    </div>
                </div>

                <!-- Support Section -->
                <div id="support_section" class="payment-section">
                    <div class="support-grid">
                        <?php if (!empty($settings['support_phone'])): ?>
                        <a href="tel:<?php echo $settings['support_phone']; ?>" class="support-card">
                            <img src="<?php echo IMAGES_URL; ?>phone.png" alt="Phone" onerror="this.innerHTML='📞'">
                            <span>Click here to Call us for support.</span>
                        </a>
                        <?php endif; ?>
                        
                        <?php if (!empty($settings['support_messenger'])): ?>
                        <a href="https://m.me/<?php echo $settings['support_messenger']; ?>" target="_blank" class="support-card">
                            <img src="<?php echo IMAGES_URL; ?>messenger.png" alt="Messenger" onerror="this.innerHTML='💬'">
                            <span>Click here for Messenger live chat.</span>
                        </a>
                        <?php endif; ?>
                        
                        <?php if (!empty($settings['support_whatsapp'])): ?>
                        <a href="https://wa.me/<?php echo $settings['support_whatsapp']; ?>" target="_blank" class="support-card">
                            <img src="<?php echo IMAGES_URL; ?>whatsapp.png" alt="WhatsApp" onerror="this.innerHTML='📱'">
                            <span>Click here for WhatsApp live support.</span>
                        </a>
                        <?php endif; ?>
                        
                        <?php if (!empty($settings['support_email'])): ?>
                        <a href="mailto:<?php echo $settings['support_email']; ?>" class="support-card">
                            <img src="<?php echo IMAGES_URL; ?>email.png" alt="Email" onerror="this.innerHTML='📧'">
                            <span>Click here to Email us for support.</span>
                        </a>
                        <?php endif; ?>
                    </div>
                </div>

                <!-- FAQ Section -->
                <div id="faq_section" class="payment-section">
                    <div class="faq-list">
                        <div class="faq-item">
                            <div class="faq-question">
                                <span>How do I complete my payment?</span>
                                <span class="icon">▼</span>
                            </div>
                            <div class="faq-answer">
                                <p>Select your preferred payment method (bKash, Nagad, Rocket, etc.), then follow the instructions to complete your payment. You'll receive a confirmation once the payment is successful.</p>
                            </div>
                        </div>
                        <div class="faq-item">
                            <div class="faq-question">
                                <span>Is my payment secure?</span>
                                <span class="icon">▼</span>
                            </div>
                            <div class="faq-answer">
                                <p>Yes, all payments are processed through secure and encrypted channels. We do not store your payment credentials.</p>
                            </div>
                        </div>
                        <div class="faq-item">
                            <div class="faq-question">
                                <span>What if my payment fails?</span>
                                <span class="icon">▼</span>
                            </div>
                            <div class="faq-answer">
                                <p>If your payment fails, please try again or choose a different payment method. If the issue persists, contact our support team for assistance.</p>
                            </div>
                        </div>
                        <div class="faq-item">
                            <div class="faq-question">
                                <span>How long does payment verification take?</span>
                                <span class="icon">▼</span>
                            </div>
                            <div class="faq-answer">
                                <p>Most payments are verified instantly. For manual verification, it may take 5-30 minutes during business hours.</p>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Transaction Details Section -->
                <div id="details_section" class="payment-section">
                    <div class="transaction-details">
                        <div class="transaction-header">Transaction Details</div>
                        <div class="transaction-body">
                            <div class="transaction-row">
                                <span class="label">Invoice To:</span>
                                <span class="value"><?php echo htmlspecialchars($transaction['customer_name']); ?></span>
                            </div>
                            <div class="transaction-row">
                                <span class="label">Amount:</span>
                                <span class="value"><?php echo number_format($transaction['amount'], 2); ?> <?php echo $transaction['currency']; ?></span>
                            </div>
                            <div class="transaction-row total">
                                <span class="label">Total Payable Amount:</span>
                                <span class="value"><?php echo number_format($transaction['amount'], 2); ?> <?php echo $transaction['currency']; ?></span>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Methods Section (Default) -->
                <div id="methods_section" class="payment-section">
                    <!-- This is handled by mobile_banking and bank_transfer tabs -->
                </div>

            </div>

            <!-- Payment Amount Bar (Desktop) -->
            <div class="payment-amount-bar" style="display: none;">
                Pay <?php echo number_format($transaction['amount'], 2); ?> <?php echo $transaction['currency']; ?>
            </div>
        </div>
    </div>

    <!-- Payment Amount Bar (Mobile - Fixed) -->
    <div class="payment-amount-bar">
        Pay <?php echo number_format($transaction['amount'], 2); ?> <?php echo $transaction['currency']; ?>
    </div>

    <!-- Modals for Payment Methods -->
    <?php foreach ($mobileBankingMethods as $method): ?>
    <div id="modal_<?php echo $method['slug']; ?>" class="modal-overlay">
        <div class="modal-content">
            <h3 class="modal-header">Select Payment Option</h3>
            <div class="modal-options">
                <a href="pay.php?method=<?php echo $method['slug']; ?>&type=personal&amount=<?php echo $transaction['amount']; ?>" class="modal-option">
                    <span><?php echo htmlspecialchars($method['name']); ?></span>
                    <span class="badge badge-personal">Personal</span>
                </a>
                <a href="pay.php?method=<?php echo $method['slug']; ?>&type=merchant&amount=<?php echo $transaction['amount']; ?>" class="modal-option">
                    <span><?php echo htmlspecialchars($method['name']); ?> Payment</span>
                    <span class="badge badge-live">Live</span>
                </a>
            </div>
            <button class="modal-close">Close</button>
        </div>
    </div>
    <?php endforeach; ?>

    <!-- JavaScript -->
    <script src="<?php echo JS_URL; ?>payment.js"></script>
    <script>
        // Show methods section by default when clicking profile tabs
        document.querySelectorAll('.profile-tab').forEach(tab => {
            tab.addEventListener('click', function(e) {
                const targetId = this.dataset.tab;
                const paymentTypeTabs = document.querySelector('.payment-type-tabs');
                
                if (targetId === 'methods_section') {
                    // Show payment type tabs and default to mobile banking
                    paymentTypeTabs.style.display = 'flex';
                    document.getElementById('mobile_banking').classList.add('active');
                    document.querySelector('.type-tab[data-tab="mobile_banking"]').classList.add('active');
                }
            });
        });

        // Initialize - show mobile banking by default
        document.addEventListener('DOMContentLoaded', function() {
            const mobileBanking = document.getElementById('mobile_banking');
            if (mobileBanking) {
                mobileBanking.classList.add('active');
            }
        });
    </script>
</body>
</html>
