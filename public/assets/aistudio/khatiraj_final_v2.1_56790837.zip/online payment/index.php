<?php
/**
 * Payment Gateway - Index
 * Redirects to checkout page
 */

// Redirect to checkout
header('Location: checkout.php');
exit;
