<?php
/**
 * Payment Failed Page
 */

require_once __DIR__ . '/bootstrap.php';

$reason = sanitize($_GET['reason'] ?? 'Unknown error');

// Get settings
$payment = new Payment();
$settings = $payment->getAllSettings();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <title>Payment Failed - <?php echo htmlspecialchars($settings['site_name'] ?? 'Payment Gateway'); ?></title>
    <link rel="icon" href="<?php echo IMAGES_URL; ?>favicon.ico">
    
    <!-- Google Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    
    <!-- CSS -->
    <link rel="stylesheet" href="<?php echo CSS_URL; ?>payment.css">
</head>
<body>
    <div class="payment-container">
        <div class="payment-wrapper">
            <div class="status-page">
                <div class="status-icon failed">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                        <line x1="18" y1="6" x2="6" y2="18"></line>
                        <line x1="6" y1="6" x2="18" y2="18"></line>
                    </svg>
                </div>
                <h1 class="status-title">Payment Failed</h1>
                <p class="status-message">
                    Unfortunately, your payment could not be processed.<br>
                    Please try again or choose a different payment method.
                </p>

                <?php if ($reason !== 'Unknown error'): ?>
                <div class="alert alert-error" style="margin-bottom: 24px;">
                    <strong>Reason:</strong> <?php echo htmlspecialchars($reason); ?>
                </div>
                <?php endif; ?>

                <div style="display: flex; gap: 12px; justify-content: center; flex-wrap: wrap;">
                    <a href="checkout.php" class="btn btn-primary">
                        Try Again
                    </a>
                    <a href="<?php echo BASE_URL; ?>" class="btn btn-secondary">
                        Go to Homepage
                    </a>
                </div>

                <div style="margin-top: 32px; padding: 16px; background: #fef2f2; border-radius: var(--radius-md); border: 1px solid #fecaca;">
                    <p style="font-size: 0.875rem; color: #dc2626; margin: 0;">
                        ⚠️ Common reasons for payment failures:<br>
                        • Insufficient balance<br>
                        • Incorrect transaction details<br>
                        • Network issues<br>
                        • Payment timeout
                    </p>
                </div>

                <div style="margin-top: 16px; padding: 16px; background: var(--primary-light); border-radius: var(--radius-md);">
                    <p style="font-size: 0.875rem; color: var(--text-light); margin: 0;">
                        📞 Need help? Contact us at <strong><?php echo htmlspecialchars($settings['support_phone'] ?? '01XXXXXXXXX'); ?></strong>
                    </p>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
