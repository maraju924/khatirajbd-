/**
 * Payment Gateway - JavaScript
 * Handles UI interactions and payment processing
 */

(function() {
    'use strict';

    // ========================================
    // DOM Ready
    // ========================================
    document.addEventListener('DOMContentLoaded', function() {
        initTabs();
        initModals();
        initForms();
        initLoading();
        hidePageLoader();
    });

    // ========================================
    // Tab Switching
    // ========================================
    function initTabs() {
        // Payment type tabs (Mobile Banking / Bank Transfer)
        const typeTabs = document.querySelectorAll('.type-tab');
        const paymentSections = document.querySelectorAll('.payment-section');

        typeTabs.forEach(tab => {
            tab.addEventListener('click', function(e) {
                e.preventDefault();
                
                const targetId = this.dataset.tab;
                
                // Update active tab
                typeTabs.forEach(t => t.classList.remove('active'));
                this.classList.add('active');
                
                // Show target section
                paymentSections.forEach(section => {
                    section.classList.remove('active');
                    if (section.id === targetId) {
                        section.classList.add('active');
                    }
                });
            });
        });

        // Profile tabs (Support / FAQ / Details)
        const profileTabs = document.querySelectorAll('.profile-tab');
        
        profileTabs.forEach(tab => {
            tab.addEventListener('click', function(e) {
                e.preventDefault();
                
                const targetId = this.dataset.tab;
                
                // Update active tab
                profileTabs.forEach(t => t.classList.remove('active'));
                this.classList.add('active');
                
                // Hide payment type tabs if showing other sections
                const paymentTypeTabs = document.querySelector('.payment-type-tabs');
                if (targetId !== 'methods_section') {
                    paymentTypeTabs.style.display = 'none';
                } else {
                    paymentTypeTabs.style.display = 'flex';
                }
                
                // Show target section
                paymentSections.forEach(section => {
                    section.classList.remove('active');
                    if (section.id === targetId) {
                        section.classList.add('active');
                    }
                });
            });
        });
    }

    // ========================================
    // Modal Handling
    // ========================================
    function initModals() {
        // Open modal buttons
        const modalTriggers = document.querySelectorAll('[data-modal]');
        
        modalTriggers.forEach(trigger => {
            trigger.addEventListener('click', function(e) {
                e.preventDefault();
                const modalId = this.dataset.modal;
                const modal = document.getElementById(modalId);
                if (modal) {
                    openModal(modal);
                }
            });
        });

        // Close modal buttons
        const closeButtons = document.querySelectorAll('.modal-close');
        
        closeButtons.forEach(btn => {
            btn.addEventListener('click', function() {
                const modal = this.closest('.modal-overlay');
                if (modal) {
                    closeModal(modal);
                }
            });
        });

        // Close on overlay click
        const modals = document.querySelectorAll('.modal-overlay');
        
        modals.forEach(modal => {
            modal.addEventListener('click', function(e) {
                if (e.target === this) {
                    closeModal(this);
                }
            });
        });

        // Close on Escape key
        document.addEventListener('keydown', function(e) {
            if (e.key === 'Escape') {
                const openModal = document.querySelector('.modal-overlay.show');
                if (openModal) {
                    closeModal(openModal);
                }
            }
        });
    }

    function openModal(modal) {
        modal.classList.add('show');
        document.body.style.overflow = 'hidden';
    }

    function closeModal(modal) {
        modal.classList.remove('show');
        document.body.style.overflow = '';
    }

    // ========================================
    // Form Handling
    // ========================================
    function initForms() {
        const paymentForms = document.querySelectorAll('.payment-form');
        
        paymentForms.forEach(form => {
            form.addEventListener('submit', function(e) {
                e.preventDefault();
                
                if (validateForm(this)) {
                    showLoading();
                    
                    // Submit form via AJAX
                    const formData = new FormData(this);
                    
                    fetch(this.action, {
                        method: 'POST',
                        body: formData
                    })
                    .then(response => response.json())
                    .then(data => {
                        hideLoading();
                        
                        if (data.success) {
                            if (data.redirect) {
                                window.location.href = data.redirect;
                            } else {
                                showAlert('success', data.message || 'Payment submitted successfully!');
                            }
                        } else {
                            showAlert('error', data.message || 'An error occurred. Please try again.');
                        }
                    })
                    .catch(error => {
                        hideLoading();
                        showAlert('error', 'Network error. Please check your connection and try again.');
                        console.error('Form submission error:', error);
                    });
                }
            });
        });
    }

    function validateForm(form) {
        let isValid = true;
        const inputs = form.querySelectorAll('[required]');
        
        // Clear previous errors
        form.querySelectorAll('.form-error').forEach(el => el.remove());
        form.querySelectorAll('.form-input.error').forEach(el => el.classList.remove('error'));
        
        inputs.forEach(input => {
            if (!input.value.trim()) {
                isValid = false;
                showFieldError(input, 'This field is required');
            } else if (input.type === 'email' && !isValidEmail(input.value)) {
                isValid = false;
                showFieldError(input, 'Please enter a valid email address');
            } else if (input.dataset.minLength && input.value.length < parseInt(input.dataset.minLength)) {
                isValid = false;
                showFieldError(input, `Minimum ${input.dataset.minLength} characters required`);
            }
        });
        
        return isValid;
    }

    function showFieldError(input, message) {
        input.classList.add('error');
        const error = document.createElement('div');
        error.className = 'form-error';
        error.textContent = message;
        input.parentNode.appendChild(error);
    }

    function isValidEmail(email) {
        return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
    }

    // ========================================
    // Loading Overlay
    // ========================================
    function initLoading() {
        // Create loading overlay if not exists
        if (!document.getElementById('loadingOverlay')) {
            const overlay = document.createElement('div');
            overlay.id = 'loadingOverlay';
            overlay.className = 'loading-overlay';
            overlay.innerHTML = '<div class="loader"></div>';
            document.body.appendChild(overlay);
        }
    }

    function showLoading() {
        const overlay = document.getElementById('loadingOverlay');
        if (overlay) {
            overlay.classList.add('show');
        }
    }

    function hideLoading() {
        const overlay = document.getElementById('loadingOverlay');
        if (overlay) {
            overlay.classList.remove('show');
        }
    }

    // ========================================
    // Page Loader
    // ========================================
    function hidePageLoader() {
        const pageOverlay = document.getElementById('pageOverlay');
        if (pageOverlay) {
            setTimeout(() => {
                pageOverlay.classList.remove('visible');
                setTimeout(() => {
                    pageOverlay.remove();
                }, 300);
            }, 500);
        }
    }

    // ========================================
    // Alerts
    // ========================================
    function showAlert(type, message, duration = 5000) {
        // Remove existing alerts
        document.querySelectorAll('.alert-toast').forEach(el => el.remove());
        
        const alert = document.createElement('div');
        alert.className = `alert alert-${type} alert-toast`;
        alert.style.cssText = `
            position: fixed;
            top: 20px;
            right: 20px;
            z-index: 3000;
            max-width: 400px;
            animation: slideIn 0.3s ease;
        `;
        alert.innerHTML = `
            <div style="display: flex; align-items: center; gap: 12px;">
                <span>${message}</span>
                <button onclick="this.parentElement.parentElement.remove()" style="background: none; border: none; cursor: pointer; font-size: 1.25rem; opacity: 0.7;">&times;</button>
            </div>
        `;
        
        document.body.appendChild(alert);
        
        // Auto remove
        if (duration > 0) {
            setTimeout(() => {
                if (alert.parentElement) {
                    alert.style.animation = 'slideOut 0.3s ease';
                    setTimeout(() => alert.remove(), 300);
                }
            }, duration);
        }
    }

    // Add CSS for alert animations
    const style = document.createElement('style');
    style.textContent = `
        @keyframes slideIn {
            from { opacity: 0; transform: translateX(100%); }
            to { opacity: 1; transform: translateX(0); }
        }
        @keyframes slideOut {
            from { opacity: 1; transform: translateX(0); }
            to { opacity: 0; transform: translateX(100%); }
        }
        .form-input.error {
            border-color: #ef4444 !important;
        }
    `;
    document.head.appendChild(style);

    // ========================================
    // FAQ Accordion
    // ========================================
    document.addEventListener('click', function(e) {
        if (e.target.closest('.faq-question')) {
            const faqItem = e.target.closest('.faq-item');
            faqItem.classList.toggle('open');
        }
    });

    // ========================================
    // Copy to Clipboard
    // ========================================
    window.copyToClipboard = function(text, button) {
        navigator.clipboard.writeText(text).then(() => {
            const originalText = button.textContent;
            button.textContent = 'Copied!';
            setTimeout(() => {
                button.textContent = originalText;
            }, 2000);
        }).catch(err => {
            console.error('Failed to copy:', err);
        });
    };

    // ========================================
    // Payment Method Selection
    // ========================================
    window.selectPaymentMethod = function(methodId, methodSlug) {
        // Store selected method
        sessionStorage.setItem('selectedPaymentMethod', methodId);
        sessionStorage.setItem('selectedPaymentSlug', methodSlug);
        
        // Redirect to payment page
        window.location.href = `pay.php?method=${methodSlug}`;
    };

    // ========================================
    // Format Currency
    // ========================================
    window.formatCurrency = function(amount, currency = 'BDT') {
        return new Intl.NumberFormat('en-BD', {
            style: 'decimal',
            minimumFractionDigits: 2,
            maximumFractionDigits: 2
        }).format(amount) + ' ' + currency;
    };

    // ========================================
    // Countdown Timer (for payment timeout)
    // ========================================
    window.startCountdown = function(elementId, seconds, onComplete) {
        const element = document.getElementById(elementId);
        if (!element) return;
        
        let remaining = seconds;
        
        const timer = setInterval(() => {
            const minutes = Math.floor(remaining / 60);
            const secs = remaining % 60;
            element.textContent = `${minutes.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
            
            if (remaining <= 0) {
                clearInterval(timer);
                if (typeof onComplete === 'function') {
                    onComplete();
                }
            }
            
            remaining--;
        }, 1000);
        
        return timer;
    };

})();
