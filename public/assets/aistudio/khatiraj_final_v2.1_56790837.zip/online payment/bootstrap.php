<?php
/**
 * Bootstrap File
 * Loads all required files
 */

// Load configuration
require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/config/constants.php';

// Load classes
require_once __DIR__ . '/classes/Database.php';
require_once __DIR__ . '/classes/Payment.php';
require_once __DIR__ . '/classes/Transaction.php';

// Load helpers
require_once __DIR__ . '/includes/helpers.php';

// Initialize application
init();
