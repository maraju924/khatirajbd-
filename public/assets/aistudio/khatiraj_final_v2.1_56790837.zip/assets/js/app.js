document.addEventListener('DOMContentLoaded', function () {
    const backToTopBtn = document.getElementById('kr-back-to-top');
    if (backToTopBtn) {
        window.addEventListener('scroll', () => {
            if (window.scrollY > 400) {
                backToTopBtn.classList.add('show');
            } else {
                backToTopBtn.classList.remove('show');
            }
        });
        backToTopBtn.addEventListener('click', () => {
            window.scrollTo({ top: 0, behavior: 'smooth' });
        });
    }

    document.addEventListener('click', function (e) {
        const button = e.target.closest('.kr-btn-add-cart, .kr-btn-order-now, .action-btn');
        if (!button) return;

        const ripple = document.createElement('span');
        const rect = button.getBoundingClientRect();
        const size = Math.max(rect.width, rect.height);

        ripple.style.width = ripple.style.height = size + 'px';
        ripple.style.left = (e.clientX - rect.left - size / 2) + 'px';
        ripple.style.top = (e.clientY - rect.top - size / 2) + 'px';
        ripple.style.position = 'absolute';
        ripple.style.borderRadius = '50%';
        ripple.style.background = 'rgba(255, 255, 255, 0.4)';
        ripple.style.transform = 'scale(0)';
        ripple.style.pointerEvents = 'none';
        ripple.style.animation = 'kr-ripple-effect 0.6s linear';

        if (!button.style.position || button.style.position === 'static') {
            button.style.position = 'relative';
        }
        button.style.overflow = 'hidden';
        button.appendChild(ripple);
        setTimeout(() => ripple.remove(), 600);
    });

    if (!document.getElementById('kr-ripple-style')) {
        const style = document.createElement('style');
        style.id = 'kr-ripple-style';
        style.innerHTML = '@keyframes kr-ripple-effect { to { transform: scale(4); opacity: 0; } }';
        document.head.appendChild(style);
    }

    if ('serviceWorker' in navigator) {
        window.addEventListener('load', () => {
            const base = (typeof BASE_URL !== 'undefined') ? BASE_URL : '';
            navigator.serviceWorker.register(base + '/service-worker.js').catch(() => {});
        });
    }
});
