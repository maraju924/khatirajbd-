(function () {
    'use strict';

    var cfg = window.KR_CART || {};

    if (!window.__krCustomAddToCart) {
        window.addToCart = function (productId, event) {
            if (event) {
                event.preventDefault();
            }

            var btn = event ? event.currentTarget : null;
            var originalContent = '';
            if (btn) {
                originalContent = btn.innerHTML;
                btn.innerHTML = '<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span>';
                btn.disabled = true;
            }

            fetch((cfg.baseUrl || '') + '/cart/add/' + productId, {
                headers: { 'X-Requested-With': 'XMLHttpRequest' }
            })
                .then(function (response) { return response.json(); })
                .then(function (data) {
                    if (btn) {
                        btn.innerHTML = originalContent;
                        btn.disabled = false;
                    }

                    if (data.status === 'success' || data.success) {
                        if (typeof window.updateCartBadge === 'function') {
                            window.updateCartBadge(data.cart_count);
                        } else {
                            var badge = document.getElementById('cart-count-badge');
                            if (badge) {
                                badge.innerText = data.cart_count;
                            }
                        }

                        if (window.AppTracking) {
                            window.AppTracking.track('AddToCart', {
                                content_ids: [productId],
                                value: data.item_price || 0,
                                currency: 'BDT',
                                quantity: 1
                            }, 'ac_' + productId + '_' + new Date().getTime());
                        }

                        showSuccessPopup();
                    }
                })
                .catch(function (error) {
                    console.error('Error:', error);
                    if (btn) {
                        btn.innerHTML = originalContent;
                        btn.disabled = false;
                    }
                });
        };
    }

    window.showSuccessPopup = function () {
        var existing = document.getElementById('cart-success-popup');
        if (existing) {
            existing.remove();
        }

        var overlay = document.createElement('div');
        overlay.id = 'cart-success-popup';
        overlay.style.cssText = 'position:fixed;top:0;left:0;width:100%;height:100%;background:rgba(0,0,0,0.5);display:flex;align-items:center;justify-content:center;z-index:10000;transition:0.3s;';

        var popup = document.createElement('div');
        popup.style.cssText = 'background:white;padding:30px;border-radius:15px;text-align:center;max-width:400px;width:90%;box-shadow:0 15px 30px rgba(0,0,0,0.3);transform:scale(0.8);transition:0.3s cubic-bezier(0.175,0.885,0.32,1.275);';

        popup.innerHTML =
            '<div class="mb-3"><div style="width:70px;height:70px;background:#f0fdf4;color:#15803d;border-radius:50%;display:inline-flex;align-items:center;justify-content:center;"><i class="fas fa-shopping-basket fa-2x"></i></div></div>' +
            '<h5 class="fw-bold mb-2">' + (cfg.itemAdded || 'Item added') + '</h5>' +
            '<p class="text-muted mb-4 small">' + (cfg.itemAddedDesc || '') + '</p>' +
            '<div class="d-grid gap-2">' +
            '<a href="' + (cfg.checkoutUrl || '/checkout') + '" class="btn btn-lg fw-bold py-3" style="background:#15803d;color:white;">' + (cfg.completeOrder || 'Complete order') + '</a>' +
            '<button type="button" class="btn btn-outline-secondary" data-kr-close-popup>' + (cfg.continueShopping || 'Continue shopping') + '</button>' +
            '</div>';

        overlay.appendChild(popup);
        document.body.appendChild(overlay);

        popup.querySelector('[data-kr-close-popup]').addEventListener('click', function () {
            overlay.remove();
        });

        setTimeout(function () {
            popup.style.transform = 'scale(1)';
        }, 10);
    };
})();
