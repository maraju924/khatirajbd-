/**
 * KhatiRaj Analytics Beacon — Lightweight client-side tracker
 * Sends time-on-page and screen resolution data back to server.
 * ~2KB, no dependencies, privacy-respecting.
 */
(function() {
    'use strict';

    var BEACON_URL = (window.SITE_URL || '') + '/api/analytics-beacon.php';
    var startTime = Date.now();
    var sent = false;

    /**
     * Send beacon data — time spent on page + screen info.
     * Uses navigator.sendBeacon for reliability during page unload.
     */
    function sendBeacon() {
        if (sent) return;
        sent = true;

        var timeOnPage = Math.round((Date.now() - startTime) / 1000);
        
        // Don't send if less than 1 second (accidental / bot)
        if (timeOnPage < 1) return;

        // Cap at 30 minutes to avoid unrealistic values
        if (timeOnPage > 1800) timeOnPage = 1800;

        var data = new FormData();
        data.append('time_on_page', timeOnPage);
        data.append('screen_resolution', screen.width + 'x' + screen.height);
        data.append('page_url', window.location.pathname);

        // Use sendBeacon API (works during unload) with fetch fallback
        if (navigator.sendBeacon) {
            navigator.sendBeacon(BEACON_URL, data);
        } else {
            // Fallback: synchronous XHR (last resort)
            try {
                var xhr = new XMLHttpRequest();
                xhr.open('POST', BEACON_URL, false); // synchronous
                xhr.send(data);
            } catch(e) {}
        }
    }

    // Send on page visibility change (tab switch / minimize)
    if (typeof document.addEventListener === 'function') {
        document.addEventListener('visibilitychange', function() {
            if (document.visibilityState === 'hidden') {
                sendBeacon();
                // Allow re-send if user comes back and leaves again
                setTimeout(function() { sent = false; startTime = Date.now(); }, 100);
            }
        });
    }

    // Send on page unload (fallback)
    window.addEventListener('beforeunload', sendBeacon);

    // Send after 5 minutes anyway (for long readers who don't navigate away)
    setTimeout(function() {
        if (!sent) sendBeacon();
    }, 300000);
})();
