<?php
/**
 * Minify all frontend CSS/JS assets.
 * Run: php scripts/minify-assets.php
 */

$root = dirname(__DIR__);
require_once $root . '/app/Helpers/MinifyHelper.php';

$cssFiles = [
    $root . '/assets/css/style.css',
    $root . '/assets/css/responsive.css',
    $root . '/assets/css/variables.css',
    $root . '/assets/css/base.css',
    $root . '/assets/css/layout.css',
    $root . '/assets/css/components.css',
    $root . '/assets/css/navbar.css',
    $root . '/assets/css/product.css',
    $root . '/assets/css/buttons.css',
    $root . '/assets/css/forms.css',
    $root . '/assets/css/footer.css',
    $root . '/assets/css/mobile.css',
    $root . '/assets/css/utilities.css',
    $root . '/assets/css/animations.css',
    $root . '/assets/css/pages/misc.css',
    $root . '/assets/css/pages/checkout.css',
    $root . '/assets/css/pages/blog.css',
    $root . '/assets/css/pages/auth.css',
    $root . '/assets/css/pages/cms.css',
    $root . '/assets/css/pages/dashboard.css',
    $root . '/admin/css/admin.css',
    $root . '/online payment/assets/css/payment.css',
];

$jsFiles = [
    $root . '/assets/js/app.js',
    $root . '/assets/js/cart-popup.js',
    $root . '/online payment/assets/js/payment.js',
];

$written = [];

foreach ($cssFiles as $file) {
    if (!is_file($file)) {
        echo "SKIP (missing): {$file}\n";
        continue;
    }
    $out = MinifyHelper::writeMinifiedCss($file);
    $written[] = $out;
    echo "CSS: {$out}\n";
}

$styleBundle = $root . '/assets/css/style.bundle.min.css';
$bundled = MinifyHelper::bundleCssImports($root . '/assets/css/style.css');
file_put_contents($styleBundle, MinifyHelper::minifyCss($bundled));
$written[] = $styleBundle;
echo "CSS bundle: {$styleBundle}\n";

foreach ($jsFiles as $file) {
    if (!is_file($file)) {
        echo "SKIP (missing): {$file}\n";
        continue;
    }
    $out = MinifyHelper::writeMinifiedJs($file);
    $written[] = $out;
    echo "JS: {$out}\n";
}

echo "\nDone. " . count($written) . " minified files written.\n";
