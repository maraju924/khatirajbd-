<?php
// One-time / CLI seed for About + legal CMS pages (also called from migrate.php).
// Usage: php scripts/seed-legal-pages.php
declare(strict_types=1);

$root = dirname(__DIR__);
require_once $root . '/config/database.php';
require_once $root . '/app/Helpers/LegalPagesSeeder.php';

$log = [];
LegalPagesSeeder::seed($pdo, $log);
echo implode(PHP_EOL, $log) . PHP_EOL;
echo "Done.\n";
