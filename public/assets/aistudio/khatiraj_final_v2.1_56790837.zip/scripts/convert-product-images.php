<?php
/**
 * Convert existing product images (main + gallery) to 600x600 WebP.
 * Run once after deploy: php scripts/convert-product-images.php
 */

require __DIR__ . '/../config/database.php';
require __DIR__ . '/../app/Helpers/ImageHelper.php';

use App\Helpers\ImageHelper;

if (!ImageHelper::isGdAvailable()) {
    fwrite(STDERR, "Enable PHP GD extension (extension=gd) first.\n");
    exit(1);
}

$projectRoot = realpath(__DIR__ . '/..');
$paths = [];

$products = $pdo->query("SELECT id, image FROM products WHERE image IS NOT NULL AND image != ''")->fetchAll(PDO::FETCH_ASSOC);
foreach ($products as $row) {
    $paths[$row['image']] = true;
}

$gallery = $pdo->query("SELECT image_path FROM product_images WHERE image_path IS NOT NULL AND image_path != ''")->fetchAll(PDO::FETCH_ASSOC);
foreach ($gallery as $row) {
    $paths[$row['image_path']] = true;
}

$converted = 0;
$skipped = 0;

foreach (array_keys($paths) as $relativePath) {
    $newPath = ImageHelper::ensureProductWebp($relativePath, $projectRoot);
    if ($newPath !== $relativePath) {
        $pdo->prepare('UPDATE products SET image = ? WHERE image = ?')->execute([$newPath, $relativePath]);
        $pdo->prepare('UPDATE product_images SET image_path = ? WHERE image_path = ?')->execute([$newPath, $relativePath]);
        echo "Converted: {$relativePath} -> {$newPath}\n";
        $converted++;
    } else {
        $skipped++;
    }
}

echo "\nDone. Converted: {$converted}, skipped: {$skipped}\n";
