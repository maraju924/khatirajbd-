<?php
// config/tracking_encryption.php
// AES-256-CBC Encryption helper for tracking API tokens

class TrackingEncryption {
    private static $cipher = 'aes-256-cbc';
    private static $key = null;

    /**
     * Get or generate the encryption key.
     * Looks for key in config/.tracking_key file.
     * Auto-generates if not found.
     */
    private static function getKey(): string {
        if (self::$key !== null) {
            return self::$key;
        }

        $key_file = __DIR__ . '/.tracking_key';

        if (file_exists($key_file)) {
            self::$key = file_get_contents($key_file);
        } else {
            // Generate a new 32-byte key
            self::$key = bin2hex(openssl_random_pseudo_bytes(32));
            file_put_contents($key_file, self::$key);
            // Protect the key file
            @chmod($key_file, 0600);
        }

        return self::$key;
    }

    /**
     * Encrypt a value using AES-256-CBC.
     * Returns base64-encoded string containing IV + ciphertext.
     */
    public static function encrypt(string $value): string {
        if (empty($value)) return '';

        $key = hex2bin(self::getKey());
        $iv = openssl_random_pseudo_bytes(openssl_cipher_iv_length(self::$cipher));
        $encrypted = openssl_encrypt($value, self::$cipher, $key, 0, $iv);

        // Store IV + encrypted data together
        return base64_encode($iv . '::' . $encrypted);
    }

    /**
     * Decrypt a value encrypted with encrypt().
     * Returns plain text string.
     */
    public static function decrypt(string $value): string {
        if (empty($value)) return '';

        $key = hex2bin(self::getKey());
        $data = base64_decode($value);
        $parts = explode('::', $data, 2);

        if (count($parts) !== 2) return '';

        list($iv, $encrypted) = $parts;
        $decrypted = openssl_decrypt($encrypted, self::$cipher, $key, 0, $iv);

        return $decrypted !== false ? $decrypted : '';
    }

    /**
     * Mask a token for display (show last 4 chars only).
     * e.g. "EAABxxxxxxx1234" → "••••••••1234"
     */
    public static function maskToken(string $token): string {
        if (empty($token)) return '';
        if (strlen($token) <= 4) return str_repeat('•', strlen($token));
        return str_repeat('•', 8) . substr($token, -4);
    }

    /**
     * SHA-256 hash for PII (email, phone, name) per Meta/TikTok specs.
     * Normalizes: lowercase, trim, remove spaces.
     */
    public static function hashPII(string $value): string {
        if (empty($value)) return '';
        $normalized = strtolower(trim($value));
        return hash('sha256', $normalized);
    }

    /**
     * Normalize phone number for hashing.
     * Removes spaces, dashes, parentheses. Ensures country code prefix.
     */
    public static function normalizePhone(string $phone, string $countryCode = '880'): string {
        if (empty($phone)) return '';
        // Remove all non-digit characters
        $phone = preg_replace('/[^0-9]/', '', $phone);
        // If starts with 0, replace with country code
        if (strpos($phone, '0') === 0) {
            $phone = $countryCode . substr($phone, 1);
        }
        // If doesn't start with country code, prepend it
        if (strpos($phone, $countryCode) !== 0) {
            $phone = $countryCode . $phone;
        }
        return $phone;
    }
}
