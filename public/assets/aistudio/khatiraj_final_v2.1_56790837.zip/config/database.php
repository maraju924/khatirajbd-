<?php
// config/database.php

// Dynamic Base URL Detection - Works on both localhost and live server
$web_root = str_replace('\\', '/', dirname(__DIR__));
$doc_root = str_replace('\\', '/', $_SERVER['DOCUMENT_ROOT'] ?? '');

// Lowercase the roots to compare safely (mostly for Windows drive letter casing)
$web_root_lower = strtolower($web_root);
$doc_root_lower = strtolower($doc_root);

$base_url = '';
if (!empty($doc_root) && strpos($web_root_lower, $doc_root_lower) === 0) {
    $base_url = substr($web_root, strlen($doc_root));
}
$base_url = '/' . ltrim($base_url, '/');
$base_url = rtrim($base_url, '/');

// If running from root domain, base_url should be empty
if ($base_url === '/' || $base_url === '') {
    $base_url = '';
}

// Define constants for use throughout the application
define('BASE_URL', $base_url);

$is_https = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off')
    || (isset($_SERVER['SERVER_PORT']) && (int) $_SERVER['SERVER_PORT'] === 443)
    || (isset($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] === 'https');
define('SITE_URL', ($is_https ? 'https://' : 'http://') . ($_SERVER['HTTP_HOST'] ?? 'localhost') . BASE_URL);

// Environment Detection for Database Connection
$is_localhost = false;
if (isset($_SERVER['HTTP_HOST'])) {
    $host_name = $_SERVER['HTTP_HOST'];
    if (strpos($host_name, 'localhost') !== false || strpos($host_name, '127.0.0.1') !== false || strpos($host_name, '[::1]') !== false) {
        $is_localhost = true;
    }
} else {
    // Default to localhost if running from command line (CLI)
    $is_localhost = true;
}

// Production error policy: never leak stack traces to the browser
if ($is_localhost) {
    error_reporting(E_ALL);
    ini_set('display_errors', '1');
    ini_set('log_errors', '1');
} else {
    error_reporting(E_ALL);
    ini_set('display_errors', '0');
    ini_set('log_errors', '1');
}

if ($is_localhost) {
    // Localhost Credentials (XAMPP)
    $host = getenv('DB_HOST') ?: 'localhost';
    $db_name = getenv('DB_NAME') ?: 'khatiraj';
    $username = getenv('DB_USER') ?: 'root';
    $password = getenv('DB_PASS') !== false ? getenv('DB_PASS') : '';
} else {
    // ─── LIVE SERVER — set these before deploy ───
    // Prefer environment variables (safer). Fallback values below are placeholders.
    $host = getenv('DB_HOST') ?: 'localhost';
    $db_name = getenv('DB_NAME') ?: 'YOUR_LIVE_DB_NAME';
    $username = getenv('DB_USER') ?: 'YOUR_LIVE_DB_USER';
    $password = getenv('DB_PASS') !== false ? getenv('DB_PASS') : 'YOUR_LIVE_DB_PASSWORD';
}

try {
    $pdo = new PDO("mysql:host=$host;dbname=$db_name;charset=utf8mb4", $username, $password);
    // Set PDO to throw exceptions on error
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    // Set default fetch mode to associative array
    $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
} catch(PDOException $e) {
    error_log('Database connection failed: ' . $e->getMessage());
    http_response_code(503);
    header('Content-Type: text/plain; charset=utf-8');
    die($is_localhost
        ? ('Connection failed: ' . $e->getMessage())
        : 'Service temporarily unavailable. Please try again later.');
}

require_once __DIR__ . '/../app/Helpers/CacheHelper.php';
require_once __DIR__ . '/../app/Helpers/SeoHelper.php';
require_once __DIR__ . '/../app/Helpers/PageHelper.php';
require_once __DIR__ . '/../app/Helpers/CsrfHelper.php';

// Global Site Settings
$site_settings = CacheHelper::remember('site_settings', 900, static function () use ($pdo) {
    $settings = [];
    try {
        $stmt = $pdo->query("SELECT key_name, value FROM settings");
        while ($row = $stmt->fetch()) {
            $settings[$row['key_name']] = $row['value'];
        }
    } catch (PDOException $e) {
        // Keep empty if table doesn't exist yet
    }
    return $settings;
});

// Global Social Links
$social_links = CacheHelper::remember('social_links', 900, static function () use ($pdo) {
    try {
        return $pdo->query("SELECT * FROM social_links WHERE status = 1 ORDER BY sort_order ASC")->fetchAll();
    } catch (PDOException $e) {
        return [];
    }
});
?>
