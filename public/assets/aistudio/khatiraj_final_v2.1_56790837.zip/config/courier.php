<?php
// config/courier.php
// Fallback only — prefer Settings → Courier (Steadfast) in admin panel.
// Leave empty on a fresh/live install; fill via admin or set here as last resort.

return [
    'steadfast' => [
        'api_key' => '',
        'secret_key' => '',
        'base_url' => 'https://portal.packzy.com/api/v1',
    ]
];
