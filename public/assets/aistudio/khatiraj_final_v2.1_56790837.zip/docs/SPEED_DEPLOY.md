# KhatiRaj BD — Live Speed Deploy Checklist

## Deploy前 (Before deploy)

1. Upload all changed files to production
2. Ensure `storage/cache/` folder exists and is writable (755)
3. Run database migration once:
   - CLI: `php migrate.php`
   - Web: `https://yoursite.com/migrate.php?key=YOUR_SECRET_KEY`
4. Delete or protect `migrate.php` on production after migration

## PHP / Hosting (cPanel)

Recommended `php.ini` or MultiPHP INI Editor values:

```
opcache.enable=1
opcache.memory_consumption=128
opcache.max_accelerated_files=10000
realpath_cache_size=4096K
```

## Cloudflare (Optional, free)

1. Add site to Cloudflare
2. Enable proxy (orange cloud)
3. Speed → Optimization:
   - Auto Minify: CSS, JavaScript
   - Brotli: ON
4. Caching → Browser Cache TTL: respect existing headers

## Asset minification (CSS/JS)

After editing any file in `assets/css/` or `assets/js/`, regenerate minified files:

```bash
php scripts/minify-assets.php
```

Production loads:
- `assets/css/style.bundle.min.css` (all design-system CSS in one file)
- `*.min.css` / `*.min.js` for page-specific and script assets

Bump `AssetHelper::VERSION` in `app/Helpers/AssetHelper.php` when deploying asset changes.

## Post-deploy verification

```bash
# Cache headers test
curl -I https://yoursite.com/assets/css/style.bundle.min.css

# Gzip test
curl -H "Accept-Encoding: gzip" -I https://yoursite.com/
```

### Functional tests

- [ ] Homepage loads under 3s on mobile (4G)
- [ ] Product details page opens
- [ ] Add to cart + checkout COD order works
- [ ] Admin settings save clears cache (logo/text updates visible)
- [ ] Meta/TikTok Events Manager shows PageView + Purchase (after test order)

### PageSpeed / GTmetrix

Test these URLs and record scores:

- [ ] `/home`
- [ ] `/product/{any-slug}`
- [ ] `/checkout` (with item in cart)

Target after optimization: Mobile PageSpeed 60–80+

## Cache invalidation (automatic)

Cache clears when:

- Admin saves **Settings** → site settings, social links, menus, tracking
- Admin saves **Menu** → menu tree
- Admin saves **Tracking settings** → tracking config
- Admin saves **Flash sale** → homepage banner
- Customer completes **Order** → top products + sales popup cache

## Manual cache clear

Delete files in `storage/cache/` or run:

```php
require 'app/Helpers/CacheHelper.php';
CacheHelper::clearAll();
```

## Troubleshooting

| Issue | Fix |
|-------|-----|
| CSS broken on product page | Ensure `misc.css` loads — check `/product/` route |
| Styles missing on checkout | `checkout.css` conditional load — verify cart/checkout URL |
| Old menu after admin edit | Clear `storage/cache/` or wait 15 min TTL |
| Tracking not firing | Check deferred scripts — test in Meta Events Manager after full page load |
