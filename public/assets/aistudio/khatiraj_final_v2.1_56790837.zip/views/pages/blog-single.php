<?php
// views/pages/blog-single.php
$read_time = max(1, round(str_word_count(strip_tags($post['content'])) / 200));
?>

<style>
    /* ===== BLOG SINGLE - PREMIUM DESIGN ===== */
    .blog-single-hero {
        background: linear-gradient(135deg, #0f172a 0%, #1e293b 40%, #15803d 100%);
        padding: 55px 0 70px;
        color: white;
        position: relative;
        overflow: hidden;
    }
    .blog-single-hero::before {
        content: '';
        position: absolute;
        top: -50%;
        right: -20%;
        width: 500px;
        height: 500px;
        background: radial-gradient(circle, rgba(134, 239, 172, 0.1) 0%, transparent 70%);
        border-radius: 50%;
    }
    .blog-single-hero .breadcrumb {
        background: none;
        margin-bottom: 20px;
    }
    .blog-single-hero .breadcrumb a {
        color: #86efac;
        text-decoration: none;
        font-weight: 500;
        transition: color 0.2s;
    }
    .blog-single-hero .breadcrumb a:hover { color: #fff; }
    .blog-single-hero .breadcrumb-item + .breadcrumb-item::before { color: rgba(255,255,255,0.4); }
    .blog-single-hero .breadcrumb-item.active { color: rgba(255,255,255,0.6); }
    .blog-single-hero h1 {
        font-size: 2.2rem;
        font-weight: 800;
        line-height: 1.35;
        max-width: 750px;
    }
    .blog-meta-pills {
        display: flex;
        gap: 12px;
        flex-wrap: wrap;
        margin-top: 20px;
    }
    .blog-meta-pills .meta-pill {
        display: inline-flex;
        align-items: center;
        gap: 6px;
        background: rgba(255,255,255,0.1);
        backdrop-filter: blur(10px);
        padding: 6px 14px;
        border-radius: 50px;
        font-size: 0.82rem;
        color: rgba(255,255,255,0.85);
        border: 1px solid rgba(255,255,255,0.08);
    }
    .blog-meta-pills .meta-pill i { color: #86efac; font-size: 0.75rem; }

    /* Main Content Area */
    .blog-main-content {
        margin-top: -40px;
        position: relative;
        z-index: 2;
    }
    .blog-article-card {
        background: #fff;
        border-radius: 20px;
        box-shadow: 0 8px 40px rgba(0,0,0,0.08);
        overflow: hidden;
    }
    .blog-featured-img {
        width: 100%;
        max-height: 480px;
        object-fit: cover;
        display: block;
    }
    .blog-article-body {
        padding: 45px 50px;
    }

    /* Typography for content */
    .blog-prose {
        font-size: 1.08rem;
        line-height: 2;
        color: #334155;
        font-family: 'SolaimanLipi', 'Noto Sans Bengali', sans-serif;
    }
    .blog-prose h2 {
        font-size: 1.5rem;
        font-weight: 800;
        color: #0f172a;
        margin: 35px 0 15px;
        padding-bottom: 10px;
        border-bottom: 2px solid #f0fdf4;
    }
    .blog-prose h3 {
        font-size: 1.25rem;
        font-weight: 700;
        color: #1e293b;
        margin: 28px 0 12px;
    }
    .blog-prose p { margin-bottom: 20px; }
    .blog-prose img {
        max-width: 100%;
        height: auto;
        border-radius: 14px;
        margin: 25px 0;
        box-shadow: 0 4px 15px rgba(0,0,0,0.08);
    }
    .blog-prose ul, .blog-prose ol {
        padding-left: 24px;
        margin-bottom: 20px;
    }
    .blog-prose li { margin-bottom: 8px; }
    .blog-prose blockquote {
        border-left: 4px solid #15803d;
        padding: 20px 25px;
        background: linear-gradient(135deg, #f0fdf4, #dcfce7);
        border-radius: 0 14px 14px 0;
        margin: 25px 0;
        font-style: italic;
        color: #475569;
        font-size: 1.1rem;
    }
    .blog-prose a { color: #15803d; font-weight: 600; }

    /* Tags/Keywords */
    .blog-tags { display: flex; flex-wrap: wrap; gap: 8px; margin-top: 30px; padding-top: 25px; border-top: 1px solid #f1f5f9; }
    .blog-tag {
        background: #f0fdf4;
        color: #15803d;
        padding: 5px 14px;
        border-radius: 50px;
        font-size: 0.8rem;
        font-weight: 600;
        border: 1px solid #dcfce7;
        transition: 0.2s;
    }
    .blog-tag:hover { background: #15803d; color: #fff; }

    /* Share Section */
    .blog-share-bar {
        display: flex;
        align-items: center;
        justify-content: space-between;
        padding: 25px 50px;
        background: #f8fafc;
        border-top: 1px solid #f1f5f9;
    }
    .share-buttons { display: flex; gap: 10px; }
    .share-btn {
        width: 42px;
        height: 42px;
        border-radius: 12px;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        color: white;
        text-decoration: none;
        font-size: 1rem;
        transition: all 0.25s ease;
        border: none;
    }
    .share-btn:hover { transform: translateY(-3px); color: white; box-shadow: 0 5px 15px rgba(0,0,0,0.15); }
    .share-btn.fb { background: #1877f2; }
    .share-btn.wa { background: #25d366; }
    .share-btn.tw { background: #0f1419; }
    .share-btn.ln { background: #0a66c2; }
    .share-btn.copy-link { background: #475569; cursor: pointer; }

    /* Sidebar */
    .blog-sidebar .sidebar-card {
        background: #fff;
        border-radius: 16px;
        box-shadow: 0 2px 12px rgba(0,0,0,0.05);
        padding: 25px;
        margin-bottom: 20px;
    }
    .sidebar-card h5 {
        font-size: 1rem;
        font-weight: 700;
        color: #0f172a;
        margin-bottom: 18px;
        padding-bottom: 12px;
        border-bottom: 2px solid #f0fdf4;
        display: flex;
        align-items: center;
        gap: 8px;
    }
    .sidebar-card h5 i { color: #15803d; }

    .sidebar-post-item {
        display: flex;
        gap: 12px;
        padding: 10px 0;
        border-bottom: 1px solid #f8fafc;
        text-decoration: none;
        transition: 0.2s;
    }
    .sidebar-post-item:last-child { border-bottom: none; }
    .sidebar-post-item:hover { padding-left: 5px; }
    .sidebar-post-item img {
        width: 65px;
        height: 50px;
        border-radius: 8px;
        object-fit: cover;
        flex-shrink: 0;
    }
    .sidebar-post-item .post-placeholder {
        width: 65px;
        height: 50px;
        border-radius: 8px;
        background: linear-gradient(135deg, #f0fdf4, #dcfce7);
        display: flex;
        align-items: center;
        justify-content: center;
        flex-shrink: 0;
    }
    .sidebar-post-item h6 {
        font-size: 0.85rem;
        font-weight: 600;
        color: #334155;
        margin: 0;
        display: -webkit-box;
        -webkit-line-clamp: 2;
        -webkit-box-orient: vertical;
        overflow: hidden;
        line-height: 1.4;
    }
    .sidebar-post-item small { color: #94a3b8; font-size: 0.75rem; }
    .sidebar-post-item:hover h6 { color: #15803d; }

    /* Author Card */
    .author-card { text-align: center; }
    .author-avatar {
        width: 70px;
        height: 70px;
        border-radius: 50%;
        background: linear-gradient(135deg, #15803d, #86efac);
        display: flex;
        align-items: center;
        justify-content: center;
        margin: 0 auto 12px;
        font-size: 1.5rem;
        color: white;
        font-weight: 800;
    }

    /* Navigation */
    .blog-nav-section {
        display: flex;
        gap: 15px;
        margin-top: 30px;
    }
    .blog-nav-btn {
        flex: 1;
        display: flex;
        align-items: center;
        gap: 12px;
        padding: 18px 20px;
        background: #fff;
        border-radius: 14px;
        box-shadow: 0 2px 8px rgba(0,0,0,0.04);
        text-decoration: none;
        color: #334155;
        transition: all 0.25s;
        border: 1px solid #f1f5f9;
    }
    .blog-nav-btn:hover { transform: translateY(-2px); box-shadow: 0 8px 20px rgba(0,0,0,0.08); color: #15803d; }
    .blog-nav-btn i { font-size: 1.2rem; color: #15803d; }
    .blog-nav-btn .nav-label { font-size: 0.75rem; color: #94a3b8; text-transform: uppercase; letter-spacing: 1px; }
    .blog-nav-btn .nav-title { font-weight: 600; font-size: 0.9rem; display: -webkit-box; -webkit-line-clamp: 1; -webkit-box-orient: vertical; overflow: hidden; }

    /* CTA Banner */
    .blog-cta-banner {
        background: linear-gradient(135deg, #0f172a 0%, #15803d 100%);
        border-radius: 20px;
        padding: 40px;
        text-align: center;
        color: white;
        margin-top: 40px;
        position: relative;
        overflow: hidden;
    }
    .blog-cta-banner::before {
        content: '';
        position: absolute;
        top: -50%;
        left: -30%;
        width: 300px;
        height: 300px;
        background: radial-gradient(circle, rgba(134, 239, 172, 0.15) 0%, transparent 70%);
        border-radius: 50%;
    }
    .blog-cta-banner h3 { font-weight: 800; position: relative; }
    .blog-cta-banner p { opacity: 0.85; position: relative; }

    @media (max-width: 991px) {
        .blog-sidebar { margin-top: 30px; }
    }
    @media (max-width: 768px) {
        .blog-single-hero { padding: 35px 0 50px; }
        .blog-single-hero h1 { font-size: 1.6rem; }
        .blog-article-body { padding: 25px 20px; }
        .blog-share-bar { padding: 20px; flex-direction: column; gap: 12px; }
        .blog-featured-img { max-height: 240px; }
        .blog-nav-section { flex-direction: column; }
    }
</style>

<!-- Hero -->
<div class="blog-single-hero">
    <div class="container">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb mb-0">
                <li class="breadcrumb-item"><a href="<?php echo BASE_URL; ?>/home"><i class="fas fa-home me-1"></i>হোম</a></li>
                <li class="breadcrumb-item"><a href="<?php echo BASE_URL; ?>/blog">ব্লগ</a></li>
                <li class="breadcrumb-item active"><?php echo htmlspecialchars(mb_substr($post['title'], 0, 45)); ?><?php echo mb_strlen($post['title']) > 45 ? '...' : ''; ?></li>
            </ol>
        </nav>
        <h1 class="mt-3"><?php echo htmlspecialchars($post['title']); ?></h1>
        <div class="blog-meta-pills">
            <span class="meta-pill"><i class="far fa-calendar-alt"></i> <?php echo date('d M, Y', strtotime($post['created_at'])); ?></span>
            <span class="meta-pill"><i class="far fa-eye"></i> <?php echo number_format($post['views']); ?> views</span>
            <span class="meta-pill"><i class="far fa-clock"></i> <?php echo $read_time; ?> মিনিট পড়া</span>
        </div>
    </div>
</div>

<div class="container pb-5">
    <div class="row blog-main-content">
        <!-- Main Column -->
        <div class="col-lg-8">
            <div class="blog-article-card">
                <?php if ($post['image']): ?>
                    <img src="<?php echo BASE_URL; ?>/<?php echo $post['image']; ?>" alt="<?php echo htmlspecialchars($post['title']); ?>" class="blog-featured-img" loading="lazy">
                <?php endif; ?>

                <div class="blog-article-body">
                    <div class="blog-prose">
                        <?php echo $post['content']; ?>
                    </div>

                    <?php if (!empty($post['meta_keywords'])): ?>
                    <div class="blog-tags">
                        <i class="fas fa-tags text-muted me-1"></i>
                        <?php foreach (explode(',', $post['meta_keywords']) as $tag): ?>
                            <span class="blog-tag"><?php echo htmlspecialchars(trim($tag)); ?></span>
                        <?php endforeach; ?>
                    </div>
                    <?php endif; ?>
                </div>

                <!-- Share Bar -->
                <?php
                $share_url = urlencode(SITE_URL . '/blog/' . $post['slug']);
                $share_title = urlencode($post['title']);
                ?>
                <div class="blog-share-bar">
                    <span class="fw-bold text-dark"><i class="fas fa-share-alt me-2" style="color: #15803d;"></i>শেয়ার করুন</span>
                    <div class="share-buttons">
                        <a href="https://www.facebook.com/sharer/sharer.php?u=<?php echo $share_url; ?>" target="_blank" class="share-btn fb" title="Facebook"><i class="fab fa-facebook-f"></i></a>
                        <a href="https://api.whatsapp.com/send?text=<?php echo $share_title . '%20' . $share_url; ?>" target="_blank" class="share-btn wa" title="WhatsApp"><i class="fab fa-whatsapp"></i></a>
                        <a href="https://twitter.com/intent/tweet?url=<?php echo $share_url; ?>&text=<?php echo $share_title; ?>" target="_blank" class="share-btn tw" title="Twitter"><i class="fab fa-x-twitter"></i></a>
                        <a href="https://www.linkedin.com/shareArticle?mini=true&url=<?php echo $share_url; ?>&title=<?php echo $share_title; ?>" target="_blank" class="share-btn ln" title="LinkedIn"><i class="fab fa-linkedin-in"></i></a>
                        <button class="share-btn copy-link" title="Copy Link" onclick="navigator.clipboard.writeText('<?php echo SITE_URL . '/blog/' . $post['slug']; ?>'); this.innerHTML='<i class=\'fas fa-check\'></i>'; setTimeout(() => this.innerHTML='<i class=\'fas fa-link\'></i>', 2000);">
                            <i class="fas fa-link"></i>
                        </button>
                    </div>
                </div>
            </div>

            <!-- Previous/Next Navigation -->
            <?php
            $prev_post = $pdo->prepare("SELECT title, slug FROM blog_posts WHERE id < ? AND status = 1 ORDER BY id DESC LIMIT 1");
            $prev_post->execute([$post['id']]);
            $prev_post = $prev_post->fetch();

            $next_post = $pdo->prepare("SELECT title, slug FROM blog_posts WHERE id > ? AND status = 1 ORDER BY id ASC LIMIT 1");
            $next_post->execute([$post['id']]);
            $next_post = $next_post->fetch();
            ?>
            <?php if ($prev_post || $next_post): ?>
            <div class="blog-nav-section">
                <?php if ($prev_post): ?>
                <a href="<?php echo BASE_URL; ?>/blog/<?php echo $prev_post['slug']; ?>" class="blog-nav-btn">
                    <i class="fas fa-arrow-left"></i>
                    <div>
                        <div class="nav-label">আগের পোস্ট</div>
                        <div class="nav-title"><?php echo htmlspecialchars($prev_post['title']); ?></div>
                    </div>
                </a>
                <?php endif; ?>
                <?php if ($next_post): ?>
                <a href="<?php echo BASE_URL; ?>/blog/<?php echo $next_post['slug']; ?>" class="blog-nav-btn" style="text-align: right; justify-content: flex-end;">
                    <div>
                        <div class="nav-label">পরের পোস্ট</div>
                        <div class="nav-title"><?php echo htmlspecialchars($next_post['title']); ?></div>
                    </div>
                    <i class="fas fa-arrow-right"></i>
                </a>
                <?php endif; ?>
            </div>
            <?php endif; ?>

            <!-- CTA Banner -->
            <div class="blog-cta-banner">
                <h3><i class="fas fa-shopping-bag me-2"></i>আমাদের পণ্য দেখুন</h3>
                <p class="mb-3">খাঁটি পণ্য, সেরা দাম, দ্রুত ডেলিভারি — সবকিছু এক জায়গায়।</p>
                <a href="<?php echo BASE_URL; ?>/shop" class="btn btn-light btn-lg px-4 py-2 fw-bold rounded-pill" style="color: #15803d;">
                    <i class="fas fa-arrow-right me-2"></i>এখনই কেনাকাটা করুন
                </a>
            </div>
        </div>

        <!-- Sidebar -->
        <div class="col-lg-4 blog-sidebar">
            <!-- Author Card -->
            <div class="sidebar-card author-card">
                <div class="author-avatar">
                    <i class="fas fa-pen-nib"></i>
                </div>
                <h6 class="fw-bold text-dark mb-1">KhatiRaj BD</h6>
                <small class="text-muted">অফিসিয়াল ব্লগ</small>
                <p class="small text-muted mt-2 mb-0">খাঁটি পণ্য, স্বাস্থ্য টিপস এবং দৈনন্দিন জীবনে কাজে আসবে এমন তথ্য।</p>
            </div>

            <!-- Related Posts -->
            <?php if (!empty($related_posts)): ?>
            <div class="sidebar-card">
                <h5><i class="fas fa-fire"></i> জনপ্রিয় পোস্ট</h5>
                <?php foreach ($related_posts as $rp): ?>
                <a href="<?php echo BASE_URL; ?>/blog/<?php echo $rp['slug']; ?>" class="sidebar-post-item">
                    <?php if ($rp['image']): ?>
                        <img src="<?php echo BASE_URL; ?>/<?php echo $rp['image']; ?>" alt="<?php echo htmlspecialchars($rp['title']); ?>" loading="lazy">
                    <?php else: ?>
                        <div class="post-placeholder"><i class="fas fa-blog" style="color: #86efac;"></i></div>
                    <?php endif; ?>
                    <div>
                        <h6><?php echo htmlspecialchars($rp['title']); ?></h6>
                        <small><i class="far fa-calendar-alt me-1"></i><?php echo date('d M, Y', strtotime($rp['created_at'])); ?></small>
                    </div>
                </a>
                <?php endforeach; ?>
            </div>
            <?php endif; ?>

            <!-- Newsletter / Shop CTA -->
            <div class="sidebar-card" style="background: linear-gradient(135deg, #f0fdf4, #dcfce7); border: 1px solid #bbf7d0;">
                <div class="text-center">
                    <i class="fas fa-leaf fa-2x mb-3" style="color: #15803d;"></i>
                    <h6 class="fw-bold text-dark">খাঁটি পণ্যের সন্ধানে?</h6>
                    <p class="small text-muted mb-3">আমাদের সকল প্রোডাক্ট ১০০% অরিজিনাল ও ভেজালমুক্ত</p>
                    <a href="<?php echo BASE_URL; ?>/shop" class="btn btn-sm fw-bold w-100 py-2" style="background: #15803d; color: white; border-radius: 10px;">
                        <i class="fas fa-shopping-bag me-1"></i> পণ্য দেখুন
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Article Schema JSON-LD -->
<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "Article",
  "headline": <?php echo json_encode($post['title']); ?>,
  "description": <?php echo json_encode(mb_substr(strip_tags($post['excerpt'] ?: $post['content']), 0, 200)); ?>,
  <?php if ($post['image']): ?>
  "image": "<?php echo SITE_URL . '/' . $post['image']; ?>",
  <?php endif; ?>
  "datePublished": "<?php echo date('c', strtotime($post['created_at'])); ?>",
  "dateModified": "<?php echo date('c', strtotime($post['updated_at'])); ?>",
  "author": {
    "@type": "Organization",
    "name": "KhatiRaj BD"
  },
  "publisher": {
    "@type": "Organization",
    "name": "KhatiRaj BD",
    "url": "<?php echo SITE_URL; ?>"
  },
  "mainEntityOfPage": {
    "@type": "WebPage",
    "@id": "<?php echo SITE_URL . '/blog/' . $post['slug']; ?>"
  }
}
</script>
