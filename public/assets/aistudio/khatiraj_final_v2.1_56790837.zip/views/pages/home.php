<?php
global $site_settings;
$fs_status = $site_settings['flash_sale_status'] ?? '0';
$fs_end_time = $site_settings['flash_sale_end_time'] ?? '';
$fs_message = $site_settings['flash_sale_message'] ?? 'Flash Sale ends in:';
$fs_discount = $site_settings['flash_sale_discount'] ?? 'UP TO 50% OFF!';
?>

<?php if ($fs_status == '1' && !empty($fs_end_time)): ?>
<div class="kr-liquid-glass-pane p-4 position-relative mb-5" id="flash-sale-banner" style="border-color: rgba(239, 68, 68, 0.4) !important; background: linear-gradient(135deg, rgba(254, 226, 226, 0.6) 0%, rgba(254, 242, 242, 0.4) 100%) !important;">
    <div class="kr-pane-header" style="background: linear-gradient(180deg, #ef4444 0%, #dc2626 100%) !important; border-color: #f87171 !important; box-shadow: 0 4px 15px rgba(239, 68, 68, 0.25) !important;">
        <h5 class="fw-bold mb-0 text-center text-white">
            <i class="fas fa-bolt flash-icon me-2"></i> <?php echo htmlspecialchars($fs_discount); ?>
        </h5>
    </div>
    <div class="row align-items-center mt-2">
        <div class="col-md-6 text-center text-md-start mb-2 mb-md-0">
            <span class="fw-bold text-danger h5 mb-0"><?php echo htmlspecialchars($fs_message); ?></span>
        </div>
        <div class="col-md-6 text-center text-md-end">
            <div id="flash-countdown" class="d-flex justify-content-center justify-content-md-end gap-2 fw-bold align-items-center">
                <div class="countdown-box bg-dark text-white rounded-pill px-3 py-1 d-inline-flex gap-1" style="font-family: monospace; font-size: 1.1rem; box-shadow: inset 0 2px 4px rgba(0,0,0,0.5);">
                    <span id="fs-hours">00</span>
                    <span class="separator">:</span>
                    <span id="fs-mins">00</span>
                    <span class="separator">:</span>
                    <span id="fs-secs">00</span>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    function updateCountdown() {
        const banner = document.getElementById('flash-sale-banner');
        if (!banner || banner.offsetParent === null) return;

        const endTime = new Date("<?php echo $fs_end_time; ?>").getTime();
        const now = new Date().getTime();
        const distance = endTime - now;

        if (distance < 0) {
            banner.style.display = 'none';
            return;
        }

        const hours = Math.floor((distance / (1000 * 60 * 60)));
        const minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
        const seconds = Math.floor((distance % (1000 * 60)) / 1000);

        document.getElementById("fs-hours").innerText = String(hours).padStart(2, '0');
        document.getElementById("fs-mins").innerText = String(minutes).padStart(2, '0');
        document.getElementById("fs-secs").innerText = String(seconds).padStart(2, '0');
    }
    setInterval(updateCountdown, 1000);
    updateCountdown();
</script>
<?php endif; ?>

<!-- Main Slider Section -->
<div id="heroCarousel" class="carousel slide kr-hero-carousel mb-5" data-bs-ride="carousel" style="border: 2px solid rgba(255,255,255,0.7); box-shadow: 0 15px 35px rgba(0,0,0,0.06); border-radius: 28px; overflow: hidden;">
    <div class="carousel-indicators">
        <?php foreach ($sliders as $index => $slider): ?>
            <button type="button" data-bs-target="#heroCarousel" data-bs-slide-to="<?php echo $index; ?>" class="<?php echo $index === 0 ? 'active' : ''; ?>" aria-current="true" aria-label="Slide <?php echo $index + 1; ?>"></button>
        <?php endforeach; ?>
    </div>
    <div class="carousel-inner">
        <?php if (empty($sliders)): ?>
            <!-- Fallback Static Hero if no sliders -->
            <div class="carousel-item active">
                <div class="hero-section text-white d-flex align-items-center justify-content-center" style="background: linear-gradient(rgba(0,0,0,0.4), rgba(0,0,0,0.4)), url('https://placehold.co/1200x480'); background-size: cover; background-position: center; height: 380px;">
                    <div class="text-center">
                        <h1 class="display-5 fw-bold">Best Deals in Bangladesh</h1>
                        <p class="fs-4">Shop the latest electronics, fashion, and more with cash on delivery anywhere in BD.</p>
                        <a href="<?php echo BASE_URL; ?>/shop" class="kr-btn-primary">Shop Now</a>
                    </div>
                </div>
            </div>
        <?php else: ?>
            <?php foreach ($sliders as $index => $slider): ?>
                <div class="carousel-item <?php echo $index === 0 ? 'active' : ''; ?>">
                    <?php 
                        $has_text = !empty($slider['title']) || !empty($slider['subtitle']);
                        $overlay = '';
                        if ($has_text) {
                            $color = $slider['overlay_color'] ?? '#000000';
                            $opacity = $slider['overlay_opacity'] ?? 0.40;
                            if (preg_match('/^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i', $color, $matches)) {
                                $r = hexdec($matches[1]);
                                $g = hexdec($matches[2]);
                                $b = hexdec($matches[3]);
                                $overlay = "linear-gradient(rgba($r,$g,$b,$opacity), rgba($r,$g,$b,$opacity)), ";
                            } else {
                                $overlay = "linear-gradient(rgba(0,0,0,$opacity), rgba(0,0,0,$opacity)), ";
                            }
                        }
                    ?>
                    <div class="hero-section text-white d-flex align-items-center kr-hero-slide" <?php if ($index === 0): ?>style="background: <?php echo $overlay; ?>url('<?php echo SITE_URL; ?>/<?php echo htmlspecialchars($slider['image']); ?>'); background-size: cover; background-position: center; height: 380px;"<?php else: ?>data-bg="<?php echo SITE_URL; ?>/<?php echo htmlspecialchars($slider['image']); ?>" data-overlay="<?php echo htmlspecialchars($overlay); ?>" style="background-size: cover; background-position: center; height: 380px; min-height: 380px;"<?php endif; ?>>
                        <div class="container py-4">
                            <div class="col-md-8 mx-auto text-center">
                                <?php if ($slider['title']): ?>
                                    <h1 class="display-5 fw-bold animate__animated animate__fadeInDown text-white" style="text-shadow: 0 4px 12px rgba(0,0,0,0.3);"><?php echo htmlspecialchars($slider['title']); ?></h1>
                                <?php endif; ?>
                                
                                <?php if ($slider['subtitle']): ?>
                                    <p class="fs-5 mb-4 animate__animated animate__fadeInUp" style="text-shadow: 0 2px 6px rgba(0,0,0,0.3);"><?php echo htmlspecialchars($slider['subtitle']); ?></p>
                                <?php endif; ?>
                                
                                <?php if ($slider['btn_text']): ?>
                                    <a href="<?php echo htmlspecialchars($slider['btn_link'] ?: '#'); ?>" class="btn px-4 py-3 fw-bold rounded-pill kr-glass-submit-btn">
                                        <?php echo htmlspecialchars($slider['btn_text']); ?>
                                    </a>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>
    <button class="carousel-control-prev" type="button" data-bs-target="#heroCarousel" data-bs-slide="prev">
        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
        <span class="visually-hidden">Previous</span>
    </button>
    <button class="carousel-control-next" type="button" data-bs-target="#heroCarousel" data-bs-slide="next">
        <span class="carousel-control-next-icon" aria-hidden="true"></span>
        <span class="visually-hidden">Next</span>
    </button>
</div>

<script>
document.addEventListener('DOMContentLoaded', function () {
    const lazySlides = document.querySelectorAll('.kr-hero-slide[data-bg]');
    if (!lazySlides.length) return;

    const loadSlideBg = (slide) => {
        if (slide.dataset.loaded === '1') return;
        const bg = slide.getAttribute('data-bg');
        const overlay = slide.getAttribute('data-overlay') || '';
        if (bg) {
            slide.style.background = overlay + "url('" + bg + "')";
            slide.dataset.loaded = '1';
        }
    };

    if ('IntersectionObserver' in window) {
        const observer = new IntersectionObserver((entries) => {
            entries.forEach((entry) => {
                if (entry.isIntersecting) {
                    loadSlideBg(entry.target);
                    observer.unobserve(entry.target);
                }
            });
        }, { rootMargin: '120px' });
        lazySlides.forEach((slide) => observer.observe(slide));
    } else {
        lazySlides.forEach(loadSlideBg);
    }

    const carousel = document.getElementById('heroCarousel');
    if (carousel) {
        carousel.addEventListener('slide.bs.carousel', (event) => {
            const nextSlide = event.relatedTarget;
            if (nextSlide) loadSlideBg(nextSlide);
        });
    }
});
</script>

<!-- Featured Categories (Liquid Glass Pane) -->
<div class="kr-liquid-glass-pane p-4 position-relative mb-5">
    <div class="kr-pane-header">
        <h5 class="fw-bold mb-0 text-center kr-pane-title">
            <i class="fas fa-th-large me-2" style="font-size: 0.9em;"></i><?php echo htmlspecialchars(PageHelper::getText('categories_heading', 'title', __('popular_categories'))); ?>
        </h5>
    </div>
    <div class="row row-cols-2 row-cols-md-3 row-cols-lg-6 g-4 mt-2">
      <?php foreach($categories as $cat): ?>
      <div class="col">
        <a href="<?php echo BASE_URL; ?>/category/<?php echo $cat['slug']; ?>" class="kr-category-card d-flex flex-column align-items-center">
            <?php if($cat['image']): ?>
                <img src="<?php echo SITE_URL; ?>/<?php echo $cat['image']; ?>" class="cat-icon img-fluid rounded-circle p-1 mb-2" alt="<?php echo htmlspecialchars($cat['name']); ?>" style="width: 60px; height: 60px; object-fit: cover; background: rgba(255,255,255,0.5); border: 1px solid rgba(255,255,255,0.8);">
            <?php else: ?>
                <div class="cat-icon-placeholder d-flex align-items-center justify-content-center rounded-circle mb-2" style="width: 60px; height: 60px; background: rgba(255,255,255,0.5); border: 1px solid rgba(255,255,255,0.8);">
                    <i class="fas fa-shopping-bag text-primary"></i>
                </div>
            <?php endif; ?>
            <h6 class="mb-0 fw-bold text-center text-dark" style="font-size: 0.85rem;"><?php echo htmlspecialchars($cat['name']); ?></h6>
        </a>
      </div>
      <?php endforeach; ?>
    </div>
</div>

<?php if (!empty($promo_sliders)): ?>
<!-- Promo Slider Section -->
<div id="promoCarousel" class="carousel slide mb-5" data-bs-ride="carousel" data-bs-interval="4000" style="border: 2px solid rgba(255,255,255,0.7); box-shadow: 0 10px 30px rgba(0,0,0,0.05); border-radius: 20px; overflow: hidden;">
    <?php if (count($promo_sliders) > 1): ?>
    <div class="carousel-indicators">
        <?php foreach ($promo_sliders as $pi => $ps): ?>
            <button type="button" data-bs-target="#promoCarousel" data-bs-slide-to="<?php echo $pi; ?>" class="<?php echo $pi === 0 ? 'active' : ''; ?>"></button>
        <?php endforeach; ?>
    </div>
    <?php endif; ?>
    <div class="carousel-inner">
        <?php foreach ($promo_sliders as $pi => $ps): ?>
            <div class="carousel-item <?php echo $pi === 0 ? 'active' : ''; ?>">
                <?php
                    $p_has_text = !empty($ps['title']) || !empty($ps['subtitle']);
                    $p_overlay = '';
                    if ($p_has_text) {
                        $p_color = $ps['overlay_color'] ?? '#000000';
                        $p_opacity = $ps['overlay_opacity'] ?? 0.40;
                        if (preg_match('/^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i', $p_color, $pm)) {
                            $p_overlay = "linear-gradient(rgba(".hexdec($pm[1]).",".hexdec($pm[2]).",".hexdec($pm[3]).",$p_opacity), rgba(".hexdec($pm[1]).",".hexdec($pm[2]).",".hexdec($pm[3]).",$p_opacity)), ";
                        } else {
                            $p_overlay = "linear-gradient(rgba(0,0,0,$p_opacity), rgba(0,0,0,$p_opacity)), ";
                        }
                    }
                ?>
                <div class="d-flex align-items-center justify-content-center text-white" style="background: <?php echo $p_overlay; ?>url('<?php echo SITE_URL; ?>/<?php echo htmlspecialchars($ps['image']); ?>'); background-size: cover; background-position: center; height: 220px;">
                    <div class="text-center px-3">
                        <?php if ($ps['title']): ?>
                            <h3 class="fw-bold mb-1" style="text-shadow: 0 2px 8px rgba(0,0,0,0.3);"><?php echo htmlspecialchars($ps['title']); ?></h3>
                        <?php endif; ?>
                        <?php if ($ps['subtitle']): ?>
                            <p class="mb-2" style="text-shadow: 0 1px 4px rgba(0,0,0,0.3);"><?php echo htmlspecialchars($ps['subtitle']); ?></p>
                        <?php endif; ?>
                        <?php if ($ps['btn_text']): ?>
                            <a href="<?php echo htmlspecialchars($ps['btn_link'] ?: '#'); ?>" class="btn btn-light btn-sm rounded-pill px-4 fw-bold shadow-sm"><?php echo htmlspecialchars($ps['btn_text']); ?></a>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
    <?php if (count($promo_sliders) > 1): ?>
    <button class="carousel-control-prev" type="button" data-bs-target="#promoCarousel" data-bs-slide="prev">
        <span class="carousel-control-prev-icon"></span>
    </button>
    <button class="carousel-control-next" type="button" data-bs-target="#promoCarousel" data-bs-slide="next">
        <span class="carousel-control-next-icon"></span>
    </button>
    <?php endif; ?>
</div>
<?php endif; ?>

<!-- Featured Products (Liquid Glass Pane) -->
<div class="kr-liquid-glass-pane p-4 position-relative mb-5">
    <div class="kr-pane-header d-flex align-items-center justify-content-between px-4 w-auto">
        <h5 class="fw-bold mb-0 text-center kr-pane-title">
            <i class="fas fa-shopping-bag me-2" style="font-size: 0.9em;"></i><?php echo htmlspecialchars(PageHelper::getText('products_heading', 'title', __('top_selling'))); ?>
        </h5>
        <a href="<?php echo BASE_URL; ?>/shop" class="kr-view-all text-primary fw-bold ms-3" style="font-size: 0.85rem; text-decoration: none;">
            <?php echo __('view_all'); ?> <i class="fas fa-arrow-right small"></i>
        </a>
    </div>

    <div class="row row-cols-2 row-cols-md-3 row-cols-lg-4 g-4 mt-2">
      <?php foreach($products as $prod): ?>
      <div class="col">
        <?php include __DIR__ . '/../partials/product-card.php'; ?>
      </div>
      <?php $loop_i = ($loop_i ?? 0) + 1; ?>
      <?php endforeach; ?>
    </div>

    <?php if(count($products) == 0): ?>
        <div class="alert alert-info text-center mt-3"><?php echo __('no_products'); ?></div>
    <?php endif; ?>
</div>

<?php if (!empty($middle_banners)): ?>
<!-- Middle Banner Section -->
<div id="middleBannerCarousel" class="carousel slide mb-5" data-bs-ride="carousel" data-bs-interval="5000" style="border-radius: 20px; overflow: hidden; box-shadow: 0 10px 40px rgba(0,0,0,0.08);">
    <div class="carousel-inner">
        <?php foreach ($middle_banners as $mi => $mb): ?>
            <div class="carousel-item <?php echo $mi === 0 ? 'active' : ''; ?>">
                <a href="<?php echo htmlspecialchars($mb['btn_link'] ?: '#'); ?>" class="d-block position-relative">
                    <img src="<?php echo SITE_URL; ?>/<?php echo htmlspecialchars($mb['image']); ?>" 
                         class="d-block w-100" 
                         alt="<?php echo htmlspecialchars($mb['title'] ?: 'Banner'); ?>" 
                         style="height: 180px; object-fit: cover;">
                    <?php if (!empty($mb['title']) || !empty($mb['subtitle'])): ?>
                        <?php
                            $m_color = $mb['overlay_color'] ?? '#000000';
                            $m_opacity = $mb['overlay_opacity'] ?? 0.35;
                            if (preg_match('/^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i', $m_color, $mm)) {
                                $m_bg = "rgba(".hexdec($mm[1]).",".hexdec($mm[2]).",".hexdec($mm[3]).",$m_opacity)";
                            } else {
                                $m_bg = "rgba(0,0,0,$m_opacity)";
                            }
                        ?>
                        <div class="position-absolute top-0 start-0 w-100 h-100 d-flex align-items-center justify-content-center" style="background: <?php echo $m_bg; ?>;">
                            <div class="text-center text-white px-3">
                                <?php if ($mb['title']): ?>
                                    <h4 class="fw-bold mb-1" style="text-shadow: 0 2px 6px rgba(0,0,0,0.3);"><?php echo htmlspecialchars($mb['title']); ?></h4>
                                <?php endif; ?>
                                <?php if ($mb['subtitle']): ?>
                                    <p class="mb-0 small" style="text-shadow: 0 1px 4px rgba(0,0,0,0.3);"><?php echo htmlspecialchars($mb['subtitle']); ?></p>
                                <?php endif; ?>
                            </div>
                        </div>
                    <?php endif; ?>
                </a>
            </div>
        <?php endforeach; ?>
    </div>
    <?php if (count($middle_banners) > 1): ?>
    <button class="carousel-control-prev" type="button" data-bs-target="#middleBannerCarousel" data-bs-slide="prev">
        <span class="carousel-control-prev-icon"></span>
    </button>
    <button class="carousel-control-next" type="button" data-bs-target="#middleBannerCarousel" data-bs-slide="next">
        <span class="carousel-control-next-icon"></span>
    </button>
    <?php endif; ?>
</div>
<?php endif; ?>

<!-- Why Choose Us Strip -->
<div class="kr-features-strip mb-5 mt-5">
    <div class="kr-feature-item">
        <div class="feature-icon"><i class="fas fa-shipping-fast"></i></div>
        <h6 class="fw-bold text-dark mt-2">Fast Delivery</h6>
        <p class="text-secondary small mb-0">Delivery within 2-3 days across Bangladesh</p>
    </div>
    <div class="kr-feature-item">
        <div class="feature-icon"><i class="fas fa-shield-alt"></i></div>
        <h6 class="fw-bold text-dark mt-2">100% Authentic</h6>
        <p class="text-secondary small mb-0">We source directly from premium farms & manufacturers</p>
    </div>
    <div class="kr-feature-item">
        <div class="feature-icon"><i class="fas fa-hand-holding-usd"></i></div>
        <h6 class="fw-bold text-dark mt-2">Cash On Delivery</h6>
        <p class="text-secondary small mb-0">Pay cash when you receive the product at your door</p>
    </div>
    <div class="kr-feature-item">
        <div class="feature-icon"><i class="fas fa-undo-alt"></i></div>
        <h6 class="fw-bold text-dark mt-2">Easy Return</h6>
        <p class="text-secondary small mb-0">Hassle-free 7-day exchange or return policy</p>
    </div>
</div>



