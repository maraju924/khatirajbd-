<?php
// views/pages/auth.php
?>
<div class="kr-auth-glass-wrapper my-4">
    <div class="kr-auth-glass-card">
        <div class="kr-auth-glass-header">
            <div class="auth-icon-bubble">
                <i class="fas fa-lock"></i>
            </div>
            <h3 class="fw-bold mb-1"><?php echo htmlspecialchars($site_settings['site_name'] ?? 'Khati Raj'); ?></h3>
            <p>Secure Member Access</p>
        </div>
        <div class="kr-auth-glass-body">
            <?php if(isset($_GET['error'])): ?>
                <div class="alert alert-danger small py-2"><?php echo htmlspecialchars($_GET['error']); ?></div>
            <?php endif; ?>
            <?php if(isset($_GET['success'])): ?>
                <div class="alert alert-success small py-2"><?php echo htmlspecialchars($_GET['success']); ?></div>
            <?php endif; ?>
            
            <!-- Nav Tabs -->
            <ul class="nav nav-pills kr-auth-glass-tabs" id="pills-tab" role="tablist">
                <li class="nav-item flex-fill" role="presentation">
                    <button class="nav-link w-100 active" id="pills-login-tab" data-bs-toggle="pill" data-bs-target="#pills-login" type="button" role="tab"><?php echo __('login'); ?></button>
                </li>
                <li class="nav-item flex-fill" role="presentation">
                    <button class="nav-link w-100" id="pills-register-tab" data-bs-toggle="pill" data-bs-target="#pills-register" type="button" role="tab"><?php echo __('register'); ?></button>
                </li>
            </ul>

            <div class="tab-content" id="pills-tabContent">
                <!-- Login Tab -->
                <div class="tab-pane fade show active" id="pills-login" role="tabpanel">
                    <form action="<?php echo BASE_URL; ?>/login-action" method="POST">
                        <?php echo CsrfHelper::field(); ?>
                        <input type="hidden" name="redirect" value="<?php echo htmlspecialchars($redirect ?? ''); ?>">
                        
                        <div class="kr-auth-glass-input-wrap">
                            <span class="input-icon"><i class="far fa-envelope"></i></span>
                            <input type="email" name="email" class="form-control kr-glass-input" required placeholder="example@mail.com">
                        </div>
                        
                        <div class="kr-auth-glass-input-wrap">
                            <div class="d-flex justify-content-between align-items-center mb-2">
                                <span style="font-size: 0.82rem; font-weight: 700; color: #334155;"><?php echo __('password'); ?></span>
                                <a href="<?php echo BASE_URL; ?>/forgot-password" class="small text-decoration-none" style="color: #15803d; font-weight: 600;">Forgot Password?</a>
                            </div>
                            <span class="input-icon" style="position: absolute; left: 14px; top: 42px; transform: translateY(-50%); color: #64748b; z-index: 3;"><i class="fas fa-lock"></i></span>
                            <input type="password" name="password" class="form-control kr-glass-input" style="padding-left: 42px !important;" required placeholder="Enter password">
                        </div>
                        
                        <button type="submit" class="kr-checkout-submit-btn w-100 py-3 fw-bold"><?php echo __('login'); ?> <i class="fas fa-arrow-right ms-2"></i></button>
                    </form>
                </div>
                
                <!-- Register Tab -->
                <div class="tab-pane fade" id="pills-register" role="tabpanel">
                    <form action="<?php echo BASE_URL; ?>/register-action" method="POST">
                        <?php echo CsrfHelper::field(); ?>
                        <div class="kr-auth-glass-input-wrap">
                            <span class="input-icon"><i class="fas fa-user"></i></span>
                            <input type="text" name="name" class="form-control kr-glass-input" required placeholder="<?php echo __('your_name'); ?>">
                        </div>
                        
                        <div class="kr-auth-glass-input-wrap">
                            <span class="input-icon"><i class="far fa-envelope"></i></span>
                            <input type="email" name="email" class="form-control kr-glass-input" required placeholder="example@mail.com">
                        </div>
                        
                        <div class="kr-auth-glass-input-wrap">
                            <span class="input-icon"><i class="fas fa-phone-alt"></i></span>
                            <input type="text" name="phone" class="form-control kr-glass-input" required placeholder="01XXXXXXXXX">
                        </div>
                        
                        <div class="kr-auth-glass-input-wrap">
                            <span class="input-icon" style="position: absolute; left: 14px; top: 16px; transform: translateY(-50%); color: #64748b; z-index: 3;"><i class="fas fa-lock"></i></span>
                            <input type="password" name="password" class="form-control kr-glass-input" style="padding-left: 42px !important;" required placeholder="Password (min 6 chars)" minlength="6">
                        </div>
                        
                        <button type="submit" class="kr-checkout-submit-btn w-100 py-3 fw-bold"><?php echo __('register'); ?> <i class="fas fa-user-plus ms-2"></i></button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
