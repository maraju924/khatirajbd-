<?php
// views/pages/cms-page.php
// Generic template that renders admin-managed WYSIWYG content from page_registry.
// Expects $cms (page_registry row) to be available; falls back to current page.
if (!isset($cms) || !$cms) {
    $cms = PageHelper::getCurrentPage();
}
$cms = $cms ?: [];
$cms_h1 = $cms['h1_title'] ?? ($cms['page_name'] ?? '');
$cms_subtitle = $cms['subtitle'] ?? '';
$cms_body = $cms['content_html'] ?? '';
require_once __DIR__ . '/../../app/Helpers/LegalPagesSeeder.php';
$cms_body = LegalPagesSeeder::localizeHtml((string)$cms_body);
include 'views/layouts/header.php';
?>

</div> <!-- Close header container for full-width layout -->

<div class="container">
    <div class="row justify-content-center mb-5">
        <div class="col-lg-10">
            <?php if (!empty($cms_h1)): ?>
                <h1 class="fw-bold text-dark mb-2 mt-4"><?php echo htmlspecialchars($cms_h1); ?></h1>
            <?php endif; ?>
            <?php if (!empty($cms_subtitle)): ?>
                <p class="lead text-secondary mb-4"><?php echo htmlspecialchars($cms_subtitle); ?></p>
            <?php endif; ?>
            <div class="kr-legal-content animate__animated animate__fadeInUp">
                <?php echo $cms_body; ?>
            </div>
        </div>
    </div>
</div>

<?php include 'views/layouts/footer.php'; ?>
