<?php
$total = 0;
foreach($cart_items as $item) {
    $total += $item['price'] * $item['qty'];
}

$is_all_digital = $is_all_digital ?? false;
?>

<div class="kr-checkout-page my-3 my-md-4">
    <div class="row justify-content-center">
        <div class="col-xl-11 col-lg-12">

            <?php if (isset($_GET['recovered'])): ?>
            <div class="kr-checkout-alert-glass mb-4">
                <span class="kr-item-icon-bubble green-theme"><i class="fas fa-check"></i></span>
                <span>আপনার কার্ট পুনরুদ্ধার করা হয়েছে! এখন অর্ডার সম্পূর্ণ করুন।</span>
            </div>
            <?php endif; ?>

            <form action="<?php echo BASE_URL; ?>/order-process" method="POST" id="checkoutForm">
                <?php echo CsrfHelper::field(); ?>
                <div class="row g-4 align-items-start">

                    <!-- Billing Details -->
                    <div class="col-lg-7">
                        <div class="kr-liquid-glass-pane kr-checkout-pane p-4 p-md-5 position-relative">
                            <div class="kr-pane-header">
                                <h5 class="fw-bold mb-0 kr-pane-title">
                                    <i class="fas fa-user-edit me-2" style="font-size: 0.9em;"></i><?php echo __('billing_info'); ?>
                                </h5>
                            </div>

                            <div class="kr-checkout-fields mt-4">
                                <div class="mb-3">
                                    <label class="kr-checkout-label"><?php echo __('your_name'); ?> *</label>
                                    <div class="kr-checkout-input-wrap">
                                        <span class="kr-checkout-input-icon"><i class="fas fa-user"></i></span>
                                        <input type="text" name="name" class="form-control kr-glass-input" placeholder="<?php echo __('your_name'); ?>" required value="<?php echo htmlspecialchars($_SESSION['user_name'] ?? ''); ?>">
                                    </div>
                                </div>

                                <div class="mb-3">
                                    <label class="kr-checkout-label"><?php echo __('your_phone'); ?> *</label>
                                    <div class="kr-checkout-input-wrap">
                                        <span class="kr-checkout-input-icon"><i class="fas fa-phone-alt"></i></span>
                                        <input type="text" name="phone" class="form-control kr-glass-input" placeholder="01XXXXXXXXX" required inputmode="numeric" pattern="01[0-9]{9}" maxlength="11" title="01 দিয়ে শুরু ১১ ডিজিটের মোবাইল নাম্বার">
                                    </div>
                                </div>

                                <div class="mb-3 <?php echo ($is_all_digital) ? '' : 'd-none'; ?>">
                                    <label class="kr-checkout-label">ইমেইল ঠিকানা <?php echo ($is_all_digital) ? '*' : '(ঐচ্ছিক)'; ?></label>
                                    <div class="kr-checkout-input-wrap">
                                        <span class="kr-checkout-input-icon"><i class="fas fa-envelope"></i></span>
                                        <input type="email" name="email" class="form-control kr-glass-input" placeholder="example@mail.com" <?php echo ($is_all_digital) ? 'required' : ''; ?>>
                                    </div>
                                    <?php if($is_all_digital): ?>
                                    <div class="kr-checkout-hint"><i class="fas fa-info-circle me-1"></i> এই ইমেইলে প্রোডাক্টের ডেলিভারি পাঠানো হবে।</div>
                                    <?php endif; ?>
                                </div>

                                <?php if($is_all_digital): ?>
                                <div class="kr-checkout-notice-glass mb-3">
                                    <span class="kr-item-icon-bubble blue-theme"><i class="fas fa-cloud-download-alt"></i></span>
                                    <div>
                                        <strong>ডিজিটাল প্রোডাক্ট</strong>
                                        <p>এটি একটি ডিজিটাল প্রোডাক্ট। ঠিকানা বা ডেলিভারি চার্জ প্রয়োজন নেই।</p>
                                    </div>
                                </div>
                                <input type="hidden" name="area" value="Digital Delivery">
                                <input type="hidden" name="address" value="Digital Product - No Shipping Required">
                                <input type="hidden" name="delivery_charge" value="0">
                                <?php else: ?>

                                <div class="mb-3">
                                    <label class="kr-checkout-label">থানা ও জেলার নাম লিখুন *</label>
                                    <div class="kr-checkout-input-wrap">
                                        <span class="kr-checkout-input-icon"><i class="fas fa-map"></i></span>
                                        <input type="text" name="area" class="form-control kr-glass-input" placeholder="যেমন: মিরপুর, ঢাকা" required>
                                    </div>
                                </div>

                                <div class="mb-3">
                                    <label class="kr-checkout-label"><?php echo __('full_address'); ?> *</label>
                                    <div class="kr-checkout-input-wrap">
                                        <span class="kr-checkout-input-icon"><i class="fas fa-map-marker-alt"></i></span>
                                        <input type="text" name="address" class="form-control kr-glass-input" placeholder="<?php echo __('full_address'); ?>" required>
                                    </div>
                                </div>

                                <div class="kr-checkout-section-title mt-4 mb-3">
                                    <span class="kr-item-icon-bubble green-theme"><i class="fas fa-truck"></i></span>
                                    <span><?php echo __('delivery_charge_select'); ?></span>
                                </div>

                                <?php
                                $extra_charge = $_SESSION['extra_shipping'] ?? 0;
                                foreach ($shipping_zones as $index => $zone):
                                    $is_first = ($index === 0);
                                    $total_zone_charge = $zone['charge'] + $extra_charge;
                                ?>
                                <div class="kr-checkout-glass-option delivery-option <?php echo $is_first ? 'active-charge' : ''; ?>"
                                     onclick="updateDelivery(<?php echo $total_zone_charge; ?>, <?php echo $zone['charge']; ?>, this)">
                                    <div class="form-check d-flex justify-content-between align-items-center w-100 mb-0">
                                        <div class="d-flex align-items-center">
                                            <input class="form-check-input kr-checkout-radio" type="radio" name="delivery_charge" id="zone_<?php echo $zone['id']; ?>"
                                                   value="<?php echo $total_zone_charge; ?>" <?php echo $is_first ? 'checked' : ''; ?>>
                                            <label class="form-check-label ms-3 mb-0" for="zone_<?php echo $zone['id']; ?>">
                                                <span class="kr-checkout-option-title"><?php echo htmlspecialchars($zone['name']); ?></span>
                                                <?php if($extra_charge > 0): ?>
                                                <span class="kr-checkout-option-sub">
                                                    <i class="fas fa-info-circle me-1"></i><?php echo __('base_charge'); ?>: ৳<?php echo number_format($zone['charge']); ?> + <?php echo __('extra_charge_heavy'); ?>: ৳<?php echo number_format($extra_charge); ?>
                                                </span>
                                                <?php endif; ?>
                                            </label>
                                        </div>
                                        <span class="kr-checkout-option-price">৳ <?php echo number_format($total_zone_charge); ?></span>
                                    </div>
                                </div>
                                <?php endforeach; ?>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>

                    <!-- Order Summary -->
                    <div class="col-lg-5">
                        <div class="kr-liquid-glass-pane kr-checkout-pane kr-checkout-summary-pane p-4 p-md-5 position-relative">
                            <div class="kr-pane-header">
                                <h5 class="fw-bold mb-0 kr-pane-title">
                                    <i class="fas fa-shopping-basket me-2" style="font-size: 0.9em;"></i><?php echo __('order_summary'); ?>
                                </h5>
                            </div>

                            <div class="mt-4">
                                <div class="kr-checkout-items-head">
                                    <span><?php echo __('product'); ?></span>
                                    <span><?php echo __('price'); ?></span>
                                </div>

                                <?php foreach($cart_items as $item): ?>
                                <div class="kr-checkout-item-glass">
                                    <div class="d-flex align-items-center">
                                        <img src="<?php echo BASE_URL; ?>/<?php echo $item['image']; ?>" width="48" height="48" class="kr-checkout-item-img" alt="" loading="lazy">
                                        <div class="kr-checkout-item-info">
                                            <div class="kr-checkout-item-name"><?php echo htmlspecialchars($item['name']); ?></div>
                                            <?php if (!empty($item['variant_label'])): ?>
                                            <div class="kr-checkout-item-variant"><i class="fas fa-layer-group me-1"></i><?php echo htmlspecialchars($item['variant_label']); ?></div>
                                            <?php endif; ?>
                                            <div class="kr-checkout-item-qty">× <?php echo $item['qty']; ?></div>
                                        </div>
                                    </div>
                                    <span class="kr-checkout-item-price">৳ <?php echo number_format($item['price'] * $item['qty']); ?></span>
                                </div>
                                <?php endforeach; ?>

                                <div class="kr-checkout-coupon mt-3">
                                    <div id="coupon-input-group" class="<?php echo isset($_SESSION['coupon']) ? 'd-none' : ''; ?>">
                                        <label class="kr-checkout-label">প্রোমো কোড (যদি থাকে)</label>
                                        <div class="d-flex gap-2">
                                            <input type="text" id="coupon_code" class="form-control kr-glass-input flex-grow-1" placeholder="যেমন: SAVE20">
                                            <button class="btn kr-checkout-coupon-btn" type="button" id="applyCouponBtn">Apply</button>
                                        </div>
                                    </div>
                                    <div id="applied-coupon" class="kr-checkout-applied-coupon <?php echo !isset($_SESSION['coupon']) ? 'd-none' : ''; ?>">
                                        <div>
                                            <span class="badge bg-success">Applied: <span id="applied_code"><?php echo $_SESSION['coupon']['code'] ?? ''; ?></span></span>
                                            <div class="small text-muted">- ৳ <span id="discount_amount_display"><?php echo number_format($_SESSION['coupon']['discount'] ?? 0); ?></span> off</div>
                                        </div>
                                        <button type="button" class="btn btn-sm btn-link text-danger" id="removeCouponBtn"><i class="fas fa-times"></i></button>
                                    </div>
                                </div>

                                <div class="kr-checkout-totals mt-4">
                                    <div class="kr-checkout-total-row">
                                        <span><?php echo __('subtotal'); ?></span>
                                        <span class="fw-bold">৳ <span id="subtotal"><?php echo number_format($total); ?></span></span>
                                    </div>
                                    <div class="kr-checkout-total-row kr-checkout-delivery-row <?php echo $is_all_digital ? 'd-none' : ''; ?>">
                                        <span><?php echo __('delivery_charge'); ?></span>
                                        <span class="fw-bold text-success">৳ <span id="delivery_charge_display"><?php
                                            if ($is_all_digital) {
                                                $first_zone_charge = 0;
                                                echo '0';
                                            } else {
                                                $first_zone_charge = !empty($shipping_zones) ? ($shipping_zones[0]['charge'] + $extra_charge) : 0;
                                                echo number_format($first_zone_charge);
                                            }
                                        ?></span></span>
                                    </div>
                                    <div id="discount-row" class="kr-checkout-total-row text-danger <?php echo !isset($_SESSION['coupon']) ? 'd-none' : ''; ?>">
                                        <span>ডিসকাউন্ট</span>
                                        <span class="fw-bold">- ৳ <span id="discount_display"><?php echo number_format($_SESSION['coupon']['discount'] ?? 0); ?></span></span>
                                    </div>
                                    <div class="kr-checkout-grand-total">
                                        <span><?php echo __('total'); ?></span>
                                        <span>৳ <span id="total_display"><?php
                                            $discount = $_SESSION['coupon']['discount'] ?? 0;
                                            echo number_format($total + $first_zone_charge - $discount);
                                        ?></span></span>
                                    </div>
                                </div>

                                <div class="kr-checkout-payment mt-4">
                                    <div class="kr-checkout-section-title mb-3">
                                        <span class="kr-item-icon-bubble blue-theme"><i class="fas fa-wallet"></i></span>
                                        <span>পেমেন্ট পদ্ধতি নির্বাচন করুন</span>
                                    </div>

                                    <?php if (!$allow_cod && empty($available_online_methods)): ?>
                                    <div class="kr-checkout-error-glass">
                                        <i class="fas fa-exclamation-triangle me-2"></i> দুঃখিত, এই পণ্যগুলোর জন্য কোনো কমন পেমেন্ট পদ্ধতি পাওয়া যায়নি।
                                    </div>
                                    <?php endif; ?>

                                    <div class="payment-methods-wrapper d-grid gap-2">
                                        <?php if ($allow_cod && !$is_all_digital): ?>
                                        <div class="kr-checkout-glass-option payment-method-option active-payment" onclick="selectPaymentMethod('COD', this)">
                                            <div class="form-check d-flex align-items-center mb-0">
                                                <input class="form-check-input kr-checkout-radio" type="radio" name="payment_method" id="payment_cod" value="COD" checked>
                                                <label class="form-check-label ms-3 d-flex align-items-center justify-content-between w-100" for="payment_cod">
                                                    <div class="d-flex align-items-center">
                                                        <span class="kr-item-icon-bubble green-theme me-3"><i class="fas fa-hand-holding-usd"></i></span>
                                                        <div>
                                                            <span class="kr-checkout-option-title d-block">ক্যাশ অন ডেলিভারি</span>
                                                            <small class="kr-checkout-option-sub">পণ্য হাতে পেয়ে মূল্য পরিশোধ করুন</small>
                                                        </div>
                                                    </div>
                                                    <i class="fas fa-check-circle check-icon text-success fs-5"></i>
                                                </label>
                                            </div>
                                        </div>
                                        <?php endif; ?>

                                        <?php if (!empty($available_online_methods)): ?>
                                        <div class="kr-checkout-glass-option payment-method-option <?php echo (!$allow_cod || $is_all_digital) ? 'active-payment' : ''; ?>" onclick="selectPaymentMethod('Online', this)">
                                            <div class="form-check d-flex align-items-center mb-0">
                                                <input class="form-check-input kr-checkout-radio" type="radio" name="payment_method" id="payment_online" value="Online" <?php echo (!$allow_cod || $is_all_digital) ? 'checked' : ''; ?>>
                                                <label class="form-check-label ms-3 d-flex align-items-center justify-content-between w-100" for="payment_online">
                                                    <div class="d-flex align-items-center">
                                                        <span class="kr-item-icon-bubble blue-theme me-3"><i class="fas fa-credit-card"></i></span>
                                                        <div>
                                                            <span class="kr-checkout-option-title d-block">অনলাইন পেমেন্ট</span>
                                                            <small class="kr-checkout-option-sub">বিকাশ, নগদ, রকেট ইত্যাদি</small>
                                                        </div>
                                                    </div>
                                                    <div class="d-flex align-items-center gap-2">
                                                        <div class="d-none d-sm-flex gap-1 me-2">
                                                            <?php foreach(array_slice($available_online_methods, 0, 3) as $am): ?>
                                                            <img src="<?php echo BASE_URL; ?>/assets/images/payments/<?php echo $am['logo']; ?>" alt="<?php echo $am['name']; ?>" class="kr-checkout-pay-logo" onerror="this.style.display='none'">
                                                            <?php endforeach; ?>
                                                        </div>
                                                        <i class="fas fa-check-circle check-icon text-success fs-5"></i>
                                                    </div>
                                                </label>
                                            </div>
                                        </div>
                                        <?php endif; ?>
                                    </div>
                                    <input type="hidden" name="selected_payment" id="selected_payment" value="<?php echo ($allow_cod && !$is_all_digital) ? 'COD' : 'Online'; ?>">
                                </div>

                                <p class="kr-checkout-privacy mt-3"><?php echo __('privacy_note'); ?></p>

                                <button type="submit" id="submitOrderBtn" class="btn w-100 fw-bold py-3 kr-checkout-submit-btn">
                                    <span id="btnText"><?php echo __('order_button_total'); ?> ৳ <span id="btn_total_display"><?php echo number_format($total + $first_zone_charge); ?></span></span>
                                    <span id="btnLoader" class="d-none"><i class="fas fa-spinner fa-spin"></i> Processing...</span>
                                </button>
                            </div>
                        </div>
                    </div>

                </div>
            </form>
        </div>
    </div>
</div>

<div id="loadingOverlay" class="kr-checkout-loading-overlay d-none">
    <div class="kr-checkout-loading-glass">
        <div class="spinner-border text-success mb-3" role="status" style="width: 3rem; height: 3rem;"></div>
        <h5 class="fw-bold mb-0">অর্ডার প্রসেস হচ্ছে...</h5>
        <p class="text-muted small mt-2 mb-0">দয়া করে কিছুক্ষণ অপেক্ষা করুন।</p>
    </div>
</div>

<script>
const subtotal = <?php echo $total; ?>;

function updateDelivery(totalCharge, baseCharge, element) {
    document.querySelectorAll('.delivery-option').forEach(opt => {
        opt.classList.remove('active-charge');
    });
    element.classList.add('active-charge');

    const radio = element.querySelector('input[type="radio"]');
    if (radio) radio.checked = true;

    updateTotal();
}

function updateTotal() {
    const selectedOption = document.querySelector('input[name="delivery_charge"]:checked');
    const deliveryCharge = selectedOption ? parseFloat(selectedOption.value) : 0;

    const discountEl = document.getElementById('discount_display');
    let discountVal = 0;
    if (discountEl) {
        const text = discountEl.innerText.replace(/,/g, '').trim();
        discountVal = parseFloat(text) || 0;
    }

    const total = subtotal + deliveryCharge - discountVal;

    const deliveryEl = document.getElementById('delivery_charge_display');
    const totalEl = document.getElementById('total_display');
    const btnTotalEl = document.getElementById('btn_total_display');

    if(deliveryEl) deliveryEl.innerText = deliveryCharge.toLocaleString();
    if(totalEl) totalEl.innerText = total.toLocaleString();
    if(btnTotalEl) btnTotalEl.innerText = total.toLocaleString();
}

const applyBtn = document.getElementById('applyCouponBtn');
const removeBtn = document.getElementById('removeCouponBtn');

if(applyBtn) {
    applyBtn.addEventListener('click', function() {
        const code = document.getElementById('coupon_code').value.trim();
        if(!code) return alert('Please enter coupon code');

        fetch('<?php echo BASE_URL; ?>/api/apply-coupon', {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: `code=${encodeURIComponent(code)}&subtotal=${subtotal}`
        })
        .then(res => res.json())
        .then(data => {
            if(data.status === 'success') {
                document.getElementById('applied_code').innerText = data.code;
                document.getElementById('discount_amount_display').innerText = data.discount.toLocaleString();
                document.getElementById('discount_display').innerText = data.discount.toLocaleString();

                document.getElementById('coupon-input-group').classList.add('d-none');
                document.getElementById('applied-coupon').classList.remove('d-none');
                document.getElementById('discount-row').classList.remove('d-none');

                updateTotal();
                alert(data.message);
            } else {
                alert(data.message);
            }
        });
    });
}

if(removeBtn) {
    removeBtn.addEventListener('click', function() {
        fetch('<?php echo BASE_URL; ?>/api/remove-coupon')
        .then(res => res.json())
        .then(data => {
            document.getElementById('coupon-input-group').classList.remove('d-none');
            document.getElementById('applied-coupon').classList.add('d-none');
            document.getElementById('discount-row').classList.add('d-none');
            document.getElementById('discount_display').innerText = '0';
            updateTotal();
        });
    });
}

document.getElementById('checkoutForm').addEventListener('submit', function(e) {
    e.preventDefault();

    const form = this;
    const btn = document.getElementById('submitOrderBtn');
    const overlay = document.getElementById('loadingOverlay');
    const phoneEl = form.querySelector('input[name="phone"]');
    const phoneDigits = (phoneEl?.value || '').replace(/\D/g, '');
    if (!/^01\d{9}$/.test(phoneDigits)) {
        alert('সঠিক মোবাইল নাম্বার দিন (01XXXXXXXXX)');
        if (phoneEl) phoneEl.focus();
        return;
    }
    if (phoneEl) phoneEl.value = phoneDigits;

    btn.disabled = true;
    document.getElementById('btnText').classList.add('d-none');
    document.getElementById('btnLoader').classList.remove('d-none');
    overlay.classList.remove('d-none');

    const formData = new FormData(form);

    fetch(form.action, {
        method: 'POST',
        headers: { 'X-Requested-With': 'XMLHttpRequest' },
        body: formData
    })
    .then(async res => {
        const text = await res.text();
        let data;
        try {
            data = JSON.parse(text);
        } catch (parseErr) {
            console.error('Non-JSON checkout response:', text.slice(0, 500));
            throw new Error('Invalid server response');
        }
        return data;
    })
    .then(data => {
        if (data.status === 'success') {
            window.location.href = data.redirect;
        } else {
            alert('Error: ' + data.message);
            btn.disabled = false;
            document.getElementById('btnText').classList.remove('d-none');
            document.getElementById('btnLoader').classList.add('d-none');
            overlay.classList.add('d-none');
        }
    })
    .catch(err => {
        console.error(err);
        alert('Server Error. Please try again.');
        btn.disabled = false;
        document.getElementById('btnText').classList.remove('d-none');
        document.getElementById('btnLoader').classList.add('d-none');
        overlay.classList.add('d-none');
    });
});

(function() {
    const checkoutForm = document.getElementById('checkoutForm');
    if (!checkoutForm) return;

    const nameInput = checkoutForm.querySelector('input[name="name"]');
    const phoneInput = checkoutForm.querySelector('input[name="phone"]');
    const emailInput = checkoutForm.querySelector('input[name="email"]');
    const areaInput = checkoutForm.querySelector('input[name="area"]');
    const addressInput = checkoutForm.querySelector('input[name="address"]');
    let saveTimer = null;

    function saveAbandonedCart() {
        const phone = (phoneInput?.value || '').replace(/\D/g, '');
        if (phone.length < 11) return;

        const formData = new FormData();
        formData.append('name', nameInput?.value || '');
        formData.append('phone', phoneInput?.value || '');
        formData.append('email', emailInput?.value || '');
        formData.append('area', areaInput?.value || '');
        formData.append('address', addressInput?.value || '');

        fetch('<?php echo BASE_URL; ?>/api/abandoned-cart/save', {
            method: 'POST',
            headers: { 'X-Requested-With': 'XMLHttpRequest' },
            body: formData
        }).catch(() => {});
    }

    function debouncedSave() {
        clearTimeout(saveTimer);
        saveTimer = setTimeout(saveAbandonedCart, 800);
    }

    [nameInput, phoneInput, emailInput, areaInput, addressInput].forEach(input => {
        if (input) {
            input.addEventListener('input', debouncedSave);
            input.addEventListener('blur', saveAbandonedCart);
        }
    });
})();

function selectPaymentMethod(method, element) {
    document.querySelectorAll('.payment-method-option').forEach(opt => {
        opt.classList.remove('active-payment');
    });
    element.classList.add('active-payment');

    const radio = element.querySelector('input[type="radio"]');
    if (radio) radio.checked = true;
    document.getElementById('selected_payment').value = method;

    if (window.AppTracking) {
        window.AppTracking.track('AddPaymentInfo', {
            value: <?php echo json_encode($total); ?>,
            currency: 'BDT'
        }, 'api_' + new Date().getTime());
    }
}

document.addEventListener('DOMContentLoaded', function() {
    <?php
    $checkout_items = [];
    foreach($cart_items as $item) {
        $checkout_items[] = $item['id'];
    }
    $checkout_event_id = 'ic_' . time();
    ?>
    if (window.AppTracking) {
        window.AppTracking.track('InitiateCheckout', {
            content_ids: <?php echo json_encode($checkout_items); ?>,
            content_type: 'product',
            value: <?php echo json_encode($total); ?>,
            currency: 'BDT',
            num_items: <?php echo count($cart_items); ?>
        }, <?php echo json_encode($checkout_event_id); ?>);
    }
});
</script>
