<!-- User Dashboard -->
<div class="container py-5">
    <div class="row">
        <!-- Sidebar -->
        <div class="col-md-3 mb-4">
            <div class="card shadow-sm border-0 rounded-3">
                <div class="card-body text-center p-4">
                    <div class="avatar-placeholder bg-light rounded-circle mx-auto mb-3 d-flex align-items-center justify-content-center" style="width: 80px; height: 80px;">
                        <i class="fas fa-user fa-2x text-primary"></i>
                    </div>
                    <h5 class="card-title fw-bold mb-1"><?php echo htmlspecialchars($user['name']); ?></h5>
                    <p class="text-muted small mb-0"><?php echo htmlspecialchars($user['email']); ?></p>
                </div>
                <div class="list-group list-group-flush border-top-0">
                    <a href="#profile" class="list-group-item list-group-item-action active border-0 py-3" data-bs-toggle="list">
                        <i class="fas fa-user-circle me-2"></i> My Profile
                    </a>
                    <a href="#orders" class="list-group-item list-group-item-action border-0 py-3" data-bs-toggle="list">
                        <i class="fas fa-shopping-bag me-2"></i> My Orders
                    </a>
                    <a href="<?php echo BASE_URL; ?>/logout-action" class="list-group-item list-group-item-action border-0 py-3 text-danger">
                        <i class="fas fa-sign-out-alt me-2"></i> Logout
                    </a>
                </div>
            </div>
        </div>
        
        <!-- Content -->
        <div class="col-md-9">
            <?php if(isset($_SESSION['success'])): ?>
                <div class="alert alert-success border-0 shadow-sm mb-4">
                    <i class="fas fa-check-circle me-2"></i> <?php echo $_SESSION['success']; unset($_SESSION['success']); ?>
                </div>
            <?php endif; ?>
            <?php if(isset($_SESSION['error'])): ?>
                <div class="alert alert-danger border-0 shadow-sm mb-4">
                    <i class="fas fa-exclamation-circle me-2"></i> <?php echo $_SESSION['error']; unset($_SESSION['error']); ?>
                </div>
            <?php endif; ?>

            <div class="tab-content">
                <!-- Profile Tab -->
                <div class="tab-pane fade show active" id="profile">
                    <div class="card shadow-sm border-0 rounded-3">
                        <div class="card-header bg-white border-0 py-3">
                            <h5 class="mb-0 fw-bold">Profile Details</h5>
                        </div>
                        <div class="card-body p-4">
                            <form action="<?php echo BASE_URL; ?>/profile-update" method="POST">
                                <div class="row g-3">
                                    <div class="col-md-6">
                                        <label class="form-label small text-muted">Full Name</label>
                                        <input type="text" name="name" class="form-control" value="<?php echo htmlspecialchars($user['name']); ?>" required>
                                    </div>
                                    <div class="col-md-6">
                                        <label class="form-label small text-muted">Phone Number</label>
                                        <input type="text" name="phone" class="form-control" value="<?php echo htmlspecialchars($user['phone']); ?>" required>
                                    </div>
                                    <div class="col-12">
                                        <label class="form-label small text-muted">Delivery Address</label>
                                        <textarea name="address" class="form-control" rows="2"><?php echo htmlspecialchars($user['address'] ?? ''); ?></textarea>
                                    </div>
                                    
                                    <div class="col-12 mt-4">
                                        <h6 class="fw-bold border-bottom pb-2 mb-3">Change Password <small class="fw-normal text-muted">(Optional)</small></h6>
                                    </div>
                                    
                                    <div class="col-md-6">
                                        <label class="form-label small text-muted">New Password</label>
                                        <input type="password" name="new_password" class="form-control">
                                    </div>
                                    <div class="col-md-6">
                                        <label class="form-label small text-muted">Current Password <span class="text-danger">*</span></label>
                                        <input type="password" name="current_password" class="form-control" required placeholder="Required to save changes">
                                    </div>
                                    
                                    <div class="col-12 mt-3 text-end">
                                        <button type="submit" class="btn btn-primary px-4 fw-bold">Save Changes</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
                
                <!-- Orders Tab -->
                <div class="tab-pane fade" id="orders">
                    <div class="card shadow-sm border-0 rounded-3">
                        <div class="card-header bg-white border-0 py-3">
                            <h5 class="mb-0 fw-bold">Order History</h5>
                        </div>
                        <div class="card-body p-0">
                            <div class="table-responsive">
                                <table class="table table-hover align-middle mb-0">
                                    <thead class="bg-light">
                                        <tr>
                                            <th class="ps-4">Order ID</th>
                                            <th>Date</th>
                                            <th>Status</th>
                                            <th>Total</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach($orders as $order): ?>
                                        <tr>
                                            <td class="ps-4 fw-bold">#<?php echo $order['tracking_id']; ?></td>
                                            <td><?php echo date('M d, Y', strtotime($order['created_at'])); ?></td>
                                            <td>
                                                <span class="badge rounded-pill bg-<?php echo match($order['order_status']) {'Pending'=>'warning', 'Processing'=>'info', 'Shipped'=>'primary', 'Delivered'=>'success', 'Cancelled'=>'danger', default=>'secondary'}; ?> px-3 py-2">
                                                    <?php echo $order['order_status']; ?>
                                                </span>
                                            </td>
                                            <td class="fw-bold">৳<?php echo number_format($order['total_amount']); ?></td>
                                            <td>
                                                <!-- Add view order detail logic later if needed -->
                                                <button class="btn btn-sm btn-outline-primary rounded-pill px-3">View</button>
                                            </td>
                                        </tr>
                                        <?php endforeach; ?>
                                        <?php if(empty($orders)): ?>
                                            <tr><td colspan="5" class="text-center py-5 text-muted">No orders found.</td></tr>
                                        <?php endif; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
// Activate tab based on hash
document.addEventListener("DOMContentLoaded", function() {
    var hash = window.location.hash;
    if (hash) {
        var trigger = document.querySelector(`a[href="${hash}"]`);
        if(trigger) {
            new bootstrap.Tab(trigger).show();
        }
    }
});
</script>
