<?php
/**
 * Professional Payment Gateway View
 * Redesigned to match mobile banking app aesthetics
 */
?>

<div class="payment-gateway-wrapper pb-5">
    <!-- Top Header -->
    <div class="payment-header-new bg-white shadow-sm py-3 mb-3">
        <div class="container">
            <div class="d-flex align-items-center bg-white p-3 rounded-4 border border-light shadow-sm">
                <div class="store-logo-wrapper me-3">
                    <?php if (!empty($site_settings['site_logo'])): ?>
                    <img src="<?php echo BASE_URL; ?>/<?php echo $site_settings['site_logo']; ?>" alt="Logo" class="rounded-3 shadow-sm" style="width: 60px; height: 60px; object-fit: cover;">
                    <?php else: ?>
                    <div class="bg-primary bg-opacity-10 rounded-3 d-flex align-items-center justify-content-center shadow-sm" style="width: 60px; height: 60px;">
                        <i class="fas fa-store text-primary fa-lg"></i>
                    </div>
                    <?php endif; ?>
                </div>
                <div>
                    <h5 class="fw-bold mb-0 text-dark"><?php echo htmlspecialchars($site_settings['site_name'] ?? 'E-Store'); ?></h5>
                    <div class="small text-muted mt-1">ইনভয়েস আইডিঃ</div>
                    <code class="text-primary fw-bold" style="font-size: 0.85rem; letter-spacing: 0.5px;"><?php echo htmlspecialchars($pending['tracking_id']); ?></code>
                </div>
            </div>
        </div>
    </div>

    <div class="container">
        <!-- Amount Bar -->
        <div class="amount-bar bg-white rounded-4 shadow-sm p-3 mb-4 d-flex justify-content-between align-items-center border border-light">
            <span class="fs-4 fw-bold text-dark">৳ <?php echo number_format($pending['amount']); ?></span>
            <span class="badge bg-light text-dark border rounded-pill px-3 py-2 small">Total Amount</span>
        </div>

        <?php if ($payment_error): ?>
        <div class="alert alert-danger border-0 rounded-4 shadow-sm mb-4 animate__animated animate__shakeX">
            <i class="fas fa-exclamation-triangle me-2"></i> <?php echo htmlspecialchars($payment_error); ?>
        </div>
        <?php endif; ?>

        <!-- Method Selection (Pills) -->
        <div class="card border-0 shadow-sm rounded-4 mb-4 overflow-hidden">
            <div class="card-body p-3">
                <h6 class="fw-bold mb-4 text-secondary small text-uppercase" style="letter-spacing: 0.5px;">পেমেন্ট মেথড নির্বাচন করুন</h6>
                <div class="methods-grid row g-3">
                    <?php 
                    $allMethods = $allOnlineMethods ?? array_merge($mobileBankingMethods, $bankTransferMethods);
                    foreach ($allMethods as $method): 
                        $brand_color = '#1a2b3c'; // Default
                        if (stripos($method['slug'], 'bkash') !== false) $brand_color = '#e2136e';
                        if (stripos($method['slug'], 'nagad') !== false) $brand_color = '#d12026';
                        if (stripos($method['slug'], 'rocket') !== false) $brand_color = '#8c3494';
                        if (stripos($method['slug'], 'upay') !== false) $brand_color = '#ffc40c';
                    ?>
                    <div class="col-6 col-md-3">
                        <div class="method-pill-item text-center position-relative w-100" 
                             data-method-id="<?php echo $method['id']; ?>"
                             data-method-name="<?php echo htmlspecialchars($method['name']); ?>"
                             data-account="<?php echo htmlspecialchars($method['account_number']); ?>"
                             data-instructions="<?php echo htmlspecialchars($method['instructions']); ?>"
                             data-color="<?php echo $brand_color; ?>"
                             onclick="selectMethod(this)"
                             style="--item-color: <?php echo $brand_color; ?>;">
                            <div class="pill-box rounded-4 p-2 mb-2 border shadow-sm d-flex align-items-center justify-content-center position-relative mx-auto" 
                                 style="aspect-ratio: 1/1; width: 100%; max-width: 85px; background: white; transition: 0.3s; border-color: #f1f5f9 !important;">
                                <img src="<?php echo BASE_URL; ?>/assets/images/payments/<?php echo $method['logo']; ?>" 
                                     style="width: 100%; height: 100%; object-fit: contain; transition: 0.3s;">
                                <div class="selection-check position-absolute bg-white rounded-circle shadow-sm d-flex align-items-center justify-content-center" 
                                     style="top: -6px; right: -6px; width: 20px; height: 20px; opacity: 0; transform: scale(0.5); transition: 0.3s; z-index: 2;">
                                    <i class="fas fa-check-circle" style="color: <?php echo $brand_color; ?>; font-size: 16px;"></i>
                                </div>
                            </div>
                            <span class="small fw-bold d-block text-dark opacity-75" style="font-size: 0.75rem; line-height: 1.2;"><?php echo htmlspecialchars($method['name']); ?></span>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>

        <!-- Instruction Logic -->
        <div id="payment-area" class="d-none">
            <form id="paymentForm">
                <?php echo CsrfHelper::field(); ?>
                <input type="hidden" name="order_id" value="<?php echo $order_id; ?>">
                <input type="hidden" name="payment_method_id" id="paymentMethodId" value="">
                <input type="hidden" name="lp" value="<?php echo isset($_GET['lp']) ? $_GET['lp'] : '0'; ?>">
                
                <!-- The Main Branded Card -->
                <div id="brand-card" class="rounded-4 shadow-lg p-4 mb-4 animate__animated animate__fadeInUp" style="background: #1a2b3c;">
                    <div class="text-center text-white mb-4">
                        <h5 class="fw-bold mb-3" id="trx-title-display">ট্রানজেকশন আইডি দিন</h5>
                        <div class="trx-input-wrapper position-relative">
                            <input type="text" name="transaction_id" id="transaction_id" class="form-control form-control-lg text-center fw-bold border-0 shadow-sm" 
                                   placeholder="ট্রানজেকশন আইডি দিন" style="border-radius: 12px; height: 60px; background: rgba(255,255,255,1);">
                        </div>
                    </div>

                    <div class="instructions-list text-white">
                        <div class="d-flex mb-3 align-items-start">
                            <span class="bullet mt-1 me-3"></span>
                            <p class="mb-0 fs-6">আপনার <span id="method-name-display">-</span> মেনু বা অ্যাপে যান।</p>
                        </div>
                        <div class="d-flex mb-3 align-items-start">
                            <span class="bullet mt-1 me-3"></span>
                            <p class="mb-0 fs-6">"Send Money" -এ ক্লিক করুন।</p>
                        </div>
                        <div class="d-flex mb-3 align-items-center p-2 rounded-3 bg-white bg-opacity-10">
                            <span class="bullet me-3"></span>
                            <div class="flex-grow-1">
                                <span class="small opacity-75 d-block text-white-50">প্রাপক নম্বর:</span>
                                <span class="fw-bold fs-4 text-white" id="accountNumberDisplay">01XXXXXXXXX</span>
                            </div>
                            <button type="button" class="btn btn-sm btn-light rounded-pill px-3 shadow-sm fw-bold border-0" onclick="copyNumber(event)">
                                <i class="fas fa-copy me-1"></i> Copy
                            </button>
                        </div>
                        <div class="d-flex mb-3 align-items-start mt-3">
                            <span class="bullet mt-1 me-3"></span>
                            <p class="mb-0 fs-6">টাকার পরিমাণঃ <span class="fw-bold fs-4 text-warning" style="text-shadow: 0 1px 2px rgba(0,0,0,0.1);">৳ <?php echo number_format($pending['amount']); ?></span></p>
                        </div>
                        <div class="d-flex mb-3 align-items-start">
                            <span class="bullet mt-1 me-3"></span>
                            <p class="mb-0 fs-6 small" id="methodInstructionsDisplay">-</p>
                        </div>
                        <div class="d-flex align-items-start">
                            <span class="bullet mt-1 me-3"></span>
                            <p class="mb-0 fs-6 small">এখন উপরের বক্সে আপনার Transaction ID দিন এবং নিচের VERIFY বাটন এ ক্লিক করুন।</p>
                        </div>
                    </div>

                    <!-- Hidden but required for existing backend -->
                    <div class="mt-4 p-3 rounded-4 bg-white bg-opacity-10 border border-white border-opacity-10">
                         <label class="form-label text-white small fw-bold">যে নম্বর থেকে টাকা পাঠিয়েছেন (ঐচ্ছিক)</label>
                         <input type="text" class="form-control bg-transparent text-white border-0 border-bottom rounded-0 px-0" 
                                name="sender_number" placeholder="01XXXXXXXXX" style="box-shadow: none;">
                    </div>
                </div>

                <!-- Verify Button -->
                <div class="verify-footer sticky-bottom py-3 bg-light">
                    <button type="submit" class="btn btn-lg w-100 fw-bold py-3 animate__animated animate__pulse animate__infinite" 
                            id="submitBtn" style="border-radius: 15px; background: #d12026; color: white; border: none; box-shadow: 0 10px 20px rgba(209, 32, 38, 0.3);">
                        <span id="submitBtnText">VERIFY</span>
                        <span id="submitBtnLoader" class="d-none"><i class="fas fa-spinner fa-spin me-2"></i>প্রসেসিং...</span>
                    </button>
                </div>
            </form>
        </div>

        <div id="initial-msg" class="text-center py-5">
            <i class="fas fa-wallet fa-3x text-secondary mb-3 opacity-25"></i>
            <h5 class="text-secondary">শুরু করতে একটি পেমেন্ট মেথড নির্বাচন করুন</h5>
        </div>
    </div>
</div>

<style>
.payment-gateway-wrapper {
    background-color: #f8fafc;
    min-height: 100vh;
}
.method-pill-item .pill-box img { 
    filter: grayscale(100%); 
    opacity: 0.7;
    transition: 0.3s;
}
.method-pill-item.active .pill-box img { 
    filter: grayscale(0%); 
    opacity: 1;
}

.method-pill-item .pill-box { border-color: #f1f5f9 !important; }
.method-pill-item:hover .pill-box { border-color: #cbd5e1 !important; transform: translateY(-2px); }
.method-pill-item.active .pill-box { border-color: var(--item-color) !important; background: #ffffff !important; transform: scale(1.05); }
.method-pill-item.active .selection-check { opacity: 1 !important; transform: scale(1) !important; }
.method-pill-item.active span { opacity: 1 !important; color: var(--item-color) !important; }

.bullet {
    width: 8px;
    height: 8px;
    background-color: white;
    border-radius: 50%;
    flex-shrink: 0;
}

#transaction_id::placeholder {
    opacity: 0.5;
    font-weight: normal;
}

.methods-grid::-webkit-scrollbar { display: none; }

.verify-footer {
    z-index: 1000;
}

#brand-card { transition: background-color 0.5s ease; }

@media (max-width: 576px) {
    .payment-header-new .store-logo-wrapper { width: 50px; height: 50px; }
}
</style>

<script>
let currentMethod = null;

function selectMethod(el) {
    document.querySelectorAll('.method-pill-item').forEach(p => p.classList.remove('active'));
    el.classList.add('active');
    
    const data = el.dataset;
    currentMethod = data.methodId;
    
    // Update Hidden Inputs
    document.getElementById('paymentMethodId').value = data.methodId;
    
    // Update Branded Card
    const card = document.getElementById('brand-card');
    const submitBtn = document.getElementById('submitBtn');
    
    card.style.backgroundColor = data.color;
    submitBtn.style.backgroundColor = data.color;
    submitBtn.style.boxShadow = `0 10px 20px ${data.color}4d`; // 30% opacity
    
    // Update Text
    document.getElementById('method-name-display').textContent = data.methodName;
    document.getElementById('accountNumberDisplay').textContent = data.account;
    document.getElementById('methodInstructionsDisplay').textContent = data.instructions;
    
    // Smooth transition
    document.getElementById('initial-msg').classList.add('d-none');
    document.getElementById('payment-area').classList.remove('d-none');
    
    // Scroll to form
    window.scrollTo({ top: card.offsetTop - 100, behavior: 'smooth' });
}

function copyNumber(event) {
    const num = document.getElementById('accountNumberDisplay').innerText;
    navigator.clipboard.writeText(num).then(() => {
        const btn = event.currentTarget;
        const originalText = btn.innerHTML;
        btn.innerHTML = '<i class="fas fa-check"></i> Copied';
        setTimeout(() => btn.innerHTML = originalText, 2000);
    });
}

document.getElementById('paymentForm').addEventListener('submit', function(e) {
    e.preventDefault();
    
    const btn = document.getElementById('submitBtn');
    const btnText = document.getElementById('submitBtnText');
    const btnLoader = document.getElementById('submitBtnLoader');
    
    btn.disabled = true;
    btnText.classList.add('d-none');
    btnLoader.classList.remove('d-none');
    
    const formData = new FormData(this);
    
    fetch('<?php echo BASE_URL; ?>/payment-submit', {
        method: 'POST',
        body: formData
    })
    .then(res => res.json())
    .then(data => {
        if (data.status === 'success') {
            window.location.href = data.redirect;
        } else {
            alert(data.message);
            btn.disabled = false;
            btnText.classList.remove('d-none');
            btnLoader.classList.add('d-none');
        }
    })
    .catch(err => {
        console.error(err);
        alert('ত্রুটি হয়েছে, অনুগ্রহ করে আবার চেষ্টা করুন।');
        btn.disabled = false;
        btnText.classList.remove('d-none');
        btnLoader.classList.add('d-none');
    });
});
</script>
