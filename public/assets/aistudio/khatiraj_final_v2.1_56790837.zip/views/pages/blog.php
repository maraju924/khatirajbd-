<?php
// views/pages/blog.php
?>

</div> <!-- Close header container for full-width layout -->

<div class="kr-page-hero mb-5">
    <div class="container text-center">
        <span class="hero-label">Healthy Tips & Organic Insights</span>
        <h1>บล็อก ও আর্টিকেল</h1>
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb justify-content-center">
                <li class="breadcrumb-item"><a href="<?php echo BASE_URL; ?>/">Home</a></li>
                <li class="breadcrumb-item active" aria-current="page">Blog</li>
            </ol>
        </nav>
    </div>
</div>

<div class="container"> <!-- Reopen container for blog content -->
    <?php if (!empty($posts)): ?>
    <div class="row g-4 mb-5">
        <?php foreach ($posts as $post): ?>
        <div class="col-md-6 col-lg-4">
            <div class="kr-blog-card">
                <div class="card-img-wrapper">
                    <?php if ($post['image']): ?>
                        <img src="<?php echo BASE_URL; ?>/<?php echo $post['image']; ?>" alt="<?php echo htmlspecialchars($post['title']); ?>" loading="lazy">
                    <?php else: ?>
                        <div class="d-flex align-items-center justify-content-center h-100 w-100 bg-light text-muted">
                            <i class="fas fa-image fa-3x"></i>
                        </div>
                    <?php endif; ?>
                </div>
                <div class="card-body">
                    <h3 class="card-title">
                        <a href="<?php echo BASE_URL; ?>/blog/<?php echo $post['slug']; ?>"><?php echo htmlspecialchars($post['title']); ?></a>
                    </h3>
                    <p class="card-text">
                        <?php echo htmlspecialchars($post['excerpt'] ?: mb_substr(strip_tags($post['content']), 0, 150)); ?>
                    </p>
                    <div class="card-footer-custom">
                        <span class="blog-date"><i class="far fa-calendar-alt me-1"></i><?php echo date('d M, Y', strtotime($post['created_at'])); ?></span>
                        <a href="<?php echo BASE_URL; ?>/blog/<?php echo $post['slug']; ?>" class="read-more-btn">
                            আরও পড়ুন <i class="fas fa-arrow-right"></i>
                        </a>
                    </div>
                </div>
            </div>
        </div>
        <?php endforeach; ?>
    </div>

    <!-- Pagination -->
    <?php if ($total_pages > 1): ?>
    <nav class="mt-5 d-flex justify-content-center mb-5">
        <ul class="pagination pagination-custom gap-1">
            <?php if ($current_page > 1): ?>
                <li class="page-item"><a class="page-link rounded bg-light border-0 text-dark" href="<?php echo BASE_URL; ?>/blog?p=<?php echo $current_page - 1; ?>"><i class="fas fa-chevron-left"></i></a></li>
            <?php endif; ?>
            <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                <li class="page-item <?php echo $i === $current_page ? 'active' : ''; ?>">
                    <a class="page-link rounded border-0 <?php echo $i === $current_page ? 'bg-success text-white' : 'bg-light text-dark'; ?>" href="<?php echo BASE_URL; ?>/blog?p=<?php echo $i; ?>"><?php echo $i; ?></a>
                </li>
            <?php endfor; ?>
            <?php if ($current_page < $total_pages): ?>
                <li class="page-item"><a class="page-link rounded bg-light border-0 text-dark" href="<?php echo BASE_URL; ?>/blog?p=<?php echo $current_page + 1; ?>"><i class="fas fa-chevron-right"></i></a></li>
            <?php endif; ?>
        </ul>
    </nav>
    <?php endif; ?>

    <?php else: ?>
    <div class="text-center py-5 my-5">
        <div class="mb-4 text-muted">
            <div class="mx-auto d-flex align-items-center justify-content-center bg-light rounded-circle mb-3" style="width: 100px; height: 100px;">
                <i class="fas fa-feather-alt fa-3x"></i>
            </div>
            <h3 class="fw-bold">শীঘ্রই আসছে!</h3>
            <p>আমরা খুব শীঘ্রই এখানে নতুন নতুন স্বাস্থ্য টিপস ও আর্টিকেল নিয়ে আসবো। আমাদের সাথেই থাকুন।</p>
        </div>
        <a href="<?php echo BASE_URL; ?>/shop" class="kr-btn-primary">
            <i class="fas fa-shopping-bag me-2"></i>পণ্য কিনুন
        </a>
    </div>
    <?php endif; ?>
</div>

<div class="container"> <!-- Reopen container for footer layout -->
