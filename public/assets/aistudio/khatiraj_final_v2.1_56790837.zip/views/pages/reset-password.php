<div class="row justify-content-center my-5">
    <div class="col-md-6 col-lg-5">
        <div class="kr-password-glass-card">
            <div class="text-center mb-4">
                <div class="auth-icon-bubble" style="width: 64px; height: 64px; border-radius: 50%; background: radial-gradient(circle at 35% 35%, rgba(255,255,255,0.95) 0%, rgba(224,242,254,0.5) 60%, rgba(186,230,253,0.2) 100%); box-shadow: 0 8px 20px rgba(0,0,0,0.04), inset 0 2px 4px rgba(255,255,255,0.9); border: 1.5px solid rgba(255,255,255,0.6); display: inline-flex; align-items: center; justify-content: center; margin-bottom: 12px; color: #15803d; font-size: 1.5rem;">
                    <i class="fas fa-lock"></i>
                </div>
                <h4 class="fw-bold">Reset Password</h4>
                <p>Please enter your new password below.</p>
            </div>
            
            <?php if(isset($_GET['error'])): ?>
                <div class="alert alert-danger small py-2"><?php echo htmlspecialchars($_GET['error']); ?></div>
            <?php endif; ?>

            <form action="<?php echo BASE_URL; ?>/update-password-action" method="POST">
                <?php echo CsrfHelper::field(); ?>
                <input type="hidden" name="token" value="<?php echo htmlspecialchars($_GET['token'] ?? ''); ?>">
                <div class="kr-auth-glass-input-wrap">
                    <span class="input-icon" style="position: absolute; left: 14px; top: 16px; transform: translateY(-50%);"><i class="fas fa-lock"></i></span>
                    <input type="password" name="password" class="form-control kr-glass-input" style="padding-left: 42px !important;" required placeholder="Min 6 characters" minlength="6">
                </div>
                <div class="kr-auth-glass-input-wrap">
                    <span class="input-icon" style="position: absolute; left: 14px; top: 16px; transform: translateY(-50%);"><i class="fas fa-check-circle"></i></span>
                    <input type="password" name="confirm_password" class="form-control kr-glass-input" style="padding-left: 42px !important;" required placeholder="Confirm your password">
                </div>
                <button type="submit" class="kr-checkout-submit-btn w-100 py-3 fw-bold">Update Password <i class="fas fa-arrow-right ms-2"></i></button>
            </form>
            
            <div class="mt-4 text-center">
                <a href="<?php echo BASE_URL; ?>/login" class="text-decoration-none" style="color: #15803d; font-weight: 600;"><i class="fas fa-arrow-left me-1"></i> Back to Login</a>
            </div>
        </div>
    </div>
</div>
