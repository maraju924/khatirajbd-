<?php
// views/pages/order-summary-print.php
$site_name = $site_settings['site_name'] ?? 'Khati Raj';
$site_logo = $site_settings['site_logo'] ?? '';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Order Summary - #<?php echo $order['tracking_id']; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body { background: #f8f9fa; font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; }
        .invoice-card { background: white; padding: 50px; border-radius: 0; box-shadow: 0 0 20px rgba(0,0,0,0.05); max-width: 900px; margin: 30px auto; }
        .invoice-header { border-bottom: 2px solid #f1f5f9; padding-bottom: 30px; margin-bottom: 30px; }
        .logo-img { max-height: 70px; }
        .table thead { background: #f8fafc; }
        .table th { border: none; text-transform: uppercase; font-size: 0.75rem; letter-spacing: 1px; color: #64748b; }
        .total-section { background: #f8fafc; padding: 20px; border-radius: 12px; }
        @media print {
            body { background: white; padding: 0; }
            .invoice-card { box-shadow: none; margin: 0; max-width: 100%; width: 100%; padding: 20px; }
            .no-print { display: none; }
        }
    </style>
</head>
<body>

<div class="container no-print mt-4 text-center">
    <button onclick="window.print()" class="btn btn-primary px-4 py-2 fw-bold rounded-pill">
        <i class="fas fa-print me-2"></i> Print or Save as PDF
    </button>
</div>

<div class="invoice-card">
    <div class="invoice-header d-flex justify-content-between align-items-center">
        <div>
            <?php if($site_logo): ?>
                <img src="<?php echo BASE_URL; ?>/<?php echo $site_logo; ?>" class="logo-img mb-3">
            <?php else: ?>
                <h2 class="fw-bold text-primary mb-1"><?php echo $site_name; ?></h2>
            <?php endif; ?>
            <p class="text-muted small mb-0"><?php echo nl2br(htmlspecialchars($site_settings['address'] ?? '')); ?></p>
            <p class="text-muted small mb-0">Phone: <?php echo htmlspecialchars($site_settings['support_phone'] ?? ''); ?></p>
        </div>
        <div class="text-end">
            <h1 class="h3 fw-bold mb-1">ORDER SUMMARY</h1>
            <p class="text-muted mb-1">Tracking ID: <?php echo $order['tracking_id']; ?></p>
            <p class="text-muted mb-0">Date: <?php echo date('M d, Y', strtotime($order['created_at'])); ?></p>
        </div>
    </div>

    <div class="row mb-5">
        <div class="col-6">
            <h6 class="text-muted text-uppercase small fw-bold mb-3">Customer Details:</h6>
            <h5 class="fw-bold mb-1"><?php echo htmlspecialchars($order['customer_name']); ?></h5>
            <p class="mb-1"><?php echo htmlspecialchars($order['customer_phone']); ?></p>
            <p class="text-muted small"><?php echo nl2br(htmlspecialchars($order['shipping_address'])); ?></p>
        </div>
        <div class="col-6 text-end">
            <h6 class="text-muted text-uppercase small fw-bold mb-3">Order Status:</h6>
            <h5 class="fw-bold text-success"><?php echo $order['order_status']; ?></h5>
            <p class="text-muted small">Payment Method: <?php echo $order['payment_method']; ?></p>
        </div>
    </div>

    <table class="table mb-5">
        <thead>
            <tr>
                <th class="ps-0">Item Description</th>
                <th class="text-center">Price</th>
                <th class="text-center">Qty</th>
                <th class="text-end pe-0">Total</th>
            </tr>
        </thead>
        <tbody>
            <?php 
            $subtotal = 0;
            foreach ($items as $item): 
                $item_total = $item['price'] * $item['qty'];
                $subtotal += $item_total;
            ?>
                <tr>
                    <td class="ps-0 py-3">
                        <span class="fw-bold d-block"><?php echo htmlspecialchars($item['product_name']); ?></span>
                        <?php if (!empty($item['variant_label'])): ?>
                        <small class="text-muted"><?php echo htmlspecialchars($item['variant_label']); ?></small>
                        <?php endif; ?>
                    </td>
                    <td class="text-center py-3">৳<?php echo number_format($item['price']); ?></td>
                    <td class="text-center py-3"><?php echo $item['qty']; ?></td>
                    <td class="text-end pe-0 py-3 fw-bold">৳<?php echo number_format($item_total); ?></td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>

    <div class="row justify-content-end">
        <div class="col-md-5">
            <div class="total-section">
                <div class="d-flex justify-content-between mb-2">
                    <span class="text-muted">Subtotal:</span>
                    <span class="fw-bold">৳<?php echo number_format($subtotal); ?></span>
                </div>
                <div class="d-flex justify-content-between mb-2">
                    <span class="text-muted">Delivery Charge:</span>
                    <?php 
                        $delivery = $order['total_amount'] - $subtotal + ($order['discount_amount'] ?? 0);
                    ?>
                    <span class="fw-bold">৳<?php echo number_format($delivery); ?></span>
                </div>
                <?php if (($order['discount_amount'] ?? 0) > 0): ?>
                    <div class="d-flex justify-content-between mb-2 text-danger">
                        <span>Discount (<?php echo $order['coupon_code']; ?>):</span>
                        <span class="fw-bold">-৳<?php echo number_format($order['discount_amount']); ?></span>
                    </div>
                <?php endif; ?>
                <hr class="my-3">
                <div class="d-flex justify-content-between align-items-center">
                    <h5 class="fw-bold mb-0">Total:</h5>
                    <h4 class="fw-bold text-primary mb-0">৳<?php echo number_format($order['total_amount']); ?></h4>
                </div>
            </div>
        </div>
    </div>

    <div class="mt-5 pt-5 border-top text-center text-muted small">
        <p>Thank you for shopping with <?php echo $site_name; ?>!</p>
        <p class="mb-0">This is a computer generated order summary.</p>
    </div>
</div>

<script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>
</body>
</html>
