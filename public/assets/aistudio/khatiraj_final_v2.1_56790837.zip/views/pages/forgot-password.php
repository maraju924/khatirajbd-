<div class="row justify-content-center my-5">
    <div class="col-md-6 col-lg-5">
        <div class="kr-password-glass-card">
            <div class="text-center mb-4">
                <div class="auth-icon-bubble" style="width: 64px; height: 64px; border-radius: 50%; background: radial-gradient(circle at 35% 35%, rgba(255,255,255,0.95) 0%, rgba(224,242,254,0.5) 60%, rgba(186,230,253,0.2) 100%); box-shadow: 0 8px 20px rgba(0,0,0,0.04), inset 0 2px 4px rgba(255,255,255,0.9); border: 1.5px solid rgba(255,255,255,0.6); display: inline-flex; align-items: center; justify-content: center; margin-bottom: 12px; color: #15803d; font-size: 1.5rem;">
                    <i class="fas fa-key"></i>
                </div>
                <h4 class="fw-bold">Forgot Password</h4>
                <p>Enter your email address and we'll send you a link to reset your password.</p>
            </div>
            
            <?php if(isset($_GET['error'])): ?>
                <div class="alert alert-danger small py-2"><?php echo htmlspecialchars($_GET['error']); ?></div>
            <?php endif; ?>
            <?php if(isset($_GET['success'])): ?>
                <div class="alert alert-success small py-2"><?php echo htmlspecialchars($_GET['success']); ?></div>
            <?php endif; ?>

            <form action="<?php echo BASE_URL; ?>/send-reset-link" method="POST">
                <?php echo CsrfHelper::field(); ?>
                <div class="kr-auth-glass-input-wrap">
                    <span class="input-icon"><i class="far fa-envelope"></i></span>
                    <input type="email" name="email" class="form-control kr-glass-input" required placeholder="example@mail.com">
                </div>
                <button type="submit" class="kr-checkout-submit-btn w-100 py-3 fw-bold">Send Reset Link <i class="fas fa-paper-plane ms-2"></i></button>
            </form>
            
            <div class="mt-4 text-center">
                <a href="<?php echo BASE_URL; ?>/login" class="text-decoration-none" style="color: #15803d; font-weight: 600;"><i class="fas fa-arrow-left me-1"></i> Back to Login</a>
            </div>
        </div>
    </div>
</div>
