<?php
// views/pages/cms-sections.php — Advanced page builder public renderer
if (!isset($cms) || !$cms) {
    $cms = PageHelper::getCurrentPage();
}
$cms = $cms ?: [];
$sections = PageHelper::getAllSections();

function kr_pb_extra(?string $json): array
{
    if (!$json) {
        return [];
    }
    $decoded = json_decode($json, true);
    return is_array($decoded) ? $decoded : [];
}

function kr_pb_btn_url(?string $link): string
{
    $link = trim((string)$link);
    if ($link === '' || $link === '#') {
        return '#';
    }
    if (preg_match('#^(https?:)?//#i', $link) || str_starts_with($link, 'mailto:') || str_starts_with($link, 'tel:')) {
        return $link;
    }
    return rtrim(BASE_URL, '/') . '/' . ltrim($link, '/');
}

function kr_pb_img_url(?string $path): string
{
    $path = trim((string)$path);
    if ($path === '') {
        return '';
    }
    if (preg_match('#^https?://#i', $path)) {
        return $path;
    }
    return rtrim(BASE_URL, '/') . '/' . ltrim($path, '/');
}

require_once __DIR__ . '/../../app/Helpers/LegalPagesSeeder.php';

include 'views/layouts/header.php';
?>

</div> <!-- Close header container for full-width layout -->

<link rel="stylesheet" href="<?php echo AssetHelper::css('assets/css/pages/cms.css'); ?>">

<div class="kr-pb-page">
    <?php if (empty($sections)): ?>
        <div class="container py-5">
            <div class="row justify-content-center">
                <div class="col-lg-10">
                    <?php if (!empty($cms['h1_title'])): ?>
                        <h1 class="fw-bold text-dark mb-3"><?php echo htmlspecialchars((string)$cms['h1_title']); ?></h1>
                    <?php endif; ?>
                    <?php if (!empty($cms['content_html'])): ?>
                        <div class="kr-legal-content"><?php echo LegalPagesSeeder::localizeHtml((string)$cms['content_html']); ?></div>
                    <?php else: ?>
                        <div class="alert alert-info rounded-4">This page has no content yet.</div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    <?php else: ?>
        <?php foreach ($sections as $sec): ?>
            <?php
            $type = (string)($sec['section_type'] ?? 'text');
            $extra = kr_pb_extra($sec['extra_json'] ?? null);
            $items = isset($extra['items']) && is_array($extra['items']) ? $extra['items'] : [];
            $cols = max(2, min(4, (int)($extra['columns'] ?? 3)));
            ?>

            <?php if ($type === 'hero'): ?>
                <section class="kr-pb-hero" <?php echo !empty($sec['image']) ? 'style="background-image:linear-gradient(135deg,rgba(15,23,42,.72),rgba(21,128,61,.55)),url(\'' . htmlspecialchars(kr_pb_img_url($sec['image'])) . '\')"' : ''; ?>>
                    <div class="container text-center">
                        <?php if (!empty($sec['title'])): ?><h1><?php echo htmlspecialchars((string)$sec['title']); ?></h1><?php endif; ?>
                        <?php if (!empty($sec['subtitle'])): ?><p class="lead"><?php echo htmlspecialchars((string)$sec['subtitle']); ?></p><?php endif; ?>
                        <?php if (!empty($sec['content'])): ?><div class="kr-pb-hero-body mx-auto"><?php echo $sec['content']; ?></div><?php endif; ?>
                        <?php if (!empty($sec['btn_text'])): ?>
                            <a class="btn btn-light text-success fw-bold rounded-pill px-4 mt-3" href="<?php echo htmlspecialchars(kr_pb_btn_url($sec['btn_link'] ?? '')); ?>">
                                <?php echo htmlspecialchars((string)$sec['btn_text']); ?>
                            </a>
                        <?php endif; ?>
                    </div>
                </section>

            <?php elseif ($type === 'cta'): ?>
                <section class="kr-pb-cta">
                    <div class="container text-center">
                        <?php if (!empty($sec['title'])): ?><h2><?php echo htmlspecialchars((string)$sec['title']); ?></h2><?php endif; ?>
                        <?php if (!empty($sec['content'])): ?><div class="kr-pb-cta-body"><?php echo $sec['content']; ?></div><?php endif; ?>
                        <?php if (!empty($sec['btn_text'])): ?>
                            <a class="btn btn-light text-success fw-bold rounded-pill px-4 mt-2" href="<?php echo htmlspecialchars(kr_pb_btn_url($sec['btn_link'] ?? '')); ?>">
                                <?php echo htmlspecialchars((string)$sec['btn_text']); ?>
                            </a>
                        <?php endif; ?>
                    </div>
                </section>

            <?php elseif ($type === 'image'): ?>
                <section class="kr-pb-image container my-4">
                    <?php if (!empty($sec['title']) || !empty($sec['subtitle'])): ?>
                        <div class="text-center mb-3">
                            <?php if (!empty($sec['title'])): ?><h2 class="fw-bold"><?php echo htmlspecialchars((string)$sec['title']); ?></h2><?php endif; ?>
                            <?php if (!empty($sec['subtitle'])): ?><p class="text-muted"><?php echo htmlspecialchars((string)$sec['subtitle']); ?></p><?php endif; ?>
                        </div>
                    <?php endif; ?>
                    <?php if (!empty($sec['image'])): ?>
                        <figure class="kr-pb-image-frame mb-0">
                            <img src="<?php echo htmlspecialchars(kr_pb_img_url($sec['image'])); ?>" alt="<?php echo htmlspecialchars((string)($sec['title'] ?? '')); ?>" loading="lazy">
                        </figure>
                    <?php endif; ?>
                    <?php if (!empty($sec['btn_text'])): ?>
                        <div class="text-center mt-3">
                            <a class="btn btn-success rounded-pill px-4" href="<?php echo htmlspecialchars(kr_pb_btn_url($sec['btn_link'] ?? '')); ?>">
                                <?php echo htmlspecialchars((string)$sec['btn_text']); ?>
                            </a>
                        </div>
                    <?php endif; ?>
                </section>

            <?php elseif ($type === 'features'): ?>
                <section class="kr-pb-features container my-5">
                    <div class="text-center mb-4">
                        <?php if (!empty($sec['title'])): ?><h2 class="fw-bold"><?php echo htmlspecialchars((string)$sec['title']); ?></h2><?php endif; ?>
                        <?php if (!empty($sec['subtitle'])): ?><p class="text-muted"><?php echo htmlspecialchars((string)$sec['subtitle']); ?></p><?php endif; ?>
                    </div>
                    <div class="row g-3">
                        <?php foreach ($items as $it): ?>
                            <div class="col-md-6 col-lg-<?php echo (int)(12 / $cols); ?>">
                                <div class="kr-pb-feature-card h-100">
                                    <?php if (!empty($it['icon'])): ?><div class="kr-pb-feature-icon"><i class="<?php echo htmlspecialchars((string)$it['icon']); ?>"></i></div><?php endif; ?>
                                    <?php if (!empty($it['title'])): ?><h5><?php echo htmlspecialchars((string)$it['title']); ?></h5><?php endif; ?>
                                    <?php if (!empty($it['text'])): ?><p><?php echo htmlspecialchars((string)$it['text']); ?></p><?php endif; ?>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </section>

            <?php elseif ($type === 'stats'): ?>
                <section class="kr-pb-stats my-4">
                    <div class="container">
                        <?php if (!empty($sec['title'])): ?><h2 class="fw-bold text-center text-white mb-4"><?php echo htmlspecialchars((string)$sec['title']); ?></h2><?php endif; ?>
                        <div class="row g-3 text-center">
                            <?php foreach ($items as $it): ?>
                                <div class="col-6 col-md-<?php echo (int)(12 / $cols); ?>">
                                    <div class="kr-pb-stat">
                                        <div class="kr-pb-stat-value"><?php echo htmlspecialchars((string)($it['value'] ?? '')); ?></div>
                                        <div class="kr-pb-stat-label"><?php echo htmlspecialchars((string)($it['title'] ?? '')); ?></div>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                </section>

            <?php elseif ($type === 'faq'): ?>
                <section class="kr-pb-faq container my-5">
                    <div class="text-center mb-4">
                        <?php if (!empty($sec['title'])): ?><h2 class="fw-bold"><?php echo htmlspecialchars((string)$sec['title']); ?></h2><?php endif; ?>
                        <?php if (!empty($sec['subtitle'])): ?><p class="text-muted"><?php echo htmlspecialchars((string)$sec['subtitle']); ?></p><?php endif; ?>
                    </div>
                    <div class="accordion kr-pb-accordion" id="faq-<?php echo (int)$sec['id']; ?>">
                        <?php foreach ($items as $i => $it): ?>
                            <div class="accordion-item">
                                <h2 class="accordion-header">
                                    <button class="accordion-button <?php echo $i ? 'collapsed' : ''; ?>" type="button" data-bs-toggle="collapse" data-bs-target="#faq-<?php echo (int)$sec['id']; ?>-<?php echo $i; ?>">
                                        <?php echo htmlspecialchars((string)($it['q'] ?? 'Question')); ?>
                                    </button>
                                </h2>
                                <div id="faq-<?php echo (int)$sec['id']; ?>-<?php echo $i; ?>" class="accordion-collapse collapse <?php echo $i ? '' : 'show'; ?>" data-bs-parent="#faq-<?php echo (int)$sec['id']; ?>">
                                    <div class="accordion-body"><?php echo nl2br(htmlspecialchars((string)($it['a'] ?? ''))); ?></div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </section>

            <?php elseif ($type === 'gallery'): ?>
                <section class="kr-pb-gallery container my-5">
                    <div class="text-center mb-4">
                        <?php if (!empty($sec['title'])): ?><h2 class="fw-bold"><?php echo htmlspecialchars((string)$sec['title']); ?></h2><?php endif; ?>
                        <?php if (!empty($sec['subtitle'])): ?><p class="text-muted"><?php echo htmlspecialchars((string)$sec['subtitle']); ?></p><?php endif; ?>
                    </div>
                    <div class="row g-3">
                        <?php foreach ($items as $it): ?>
                            <?php if (empty($it['image'])) continue; ?>
                            <div class="col-6 col-md-4 col-lg-3">
                                <figure class="kr-pb-gallery-item mb-0">
                                    <img src="<?php echo htmlspecialchars(kr_pb_img_url((string)$it['image'])); ?>" alt="<?php echo htmlspecialchars((string)($it['title'] ?? '')); ?>" loading="lazy">
                                    <?php if (!empty($it['title'])): ?><figcaption><?php echo htmlspecialchars((string)$it['title']); ?></figcaption><?php endif; ?>
                                </figure>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </section>

            <?php elseif ($type === 'columns'): ?>
                <section class="kr-pb-columns container my-5">
                    <?php if (!empty($sec['title'])): ?><h2 class="fw-bold text-center mb-4"><?php echo htmlspecialchars((string)$sec['title']); ?></h2><?php endif; ?>
                    <div class="row g-4">
                        <div class="col-md-6"><div class="kr-pb-col"><?php echo $extra['left'] ?? ''; ?></div></div>
                        <div class="col-md-6"><div class="kr-pb-col"><?php echo $extra['right'] ?? ''; ?></div></div>
                    </div>
                </section>

            <?php elseif ($type === 'spacer'): ?>
                <?php
                $size = (string)($extra['size'] ?? 'md');
                $map = ['sm' => 24, 'md' => 48, 'lg' => 80, 'xl' => 120];
                $px = $map[$size] ?? 48;
                ?>
                <div class="kr-pb-spacer" style="height:<?php echo (int)$px; ?>px" aria-hidden="true"></div>

            <?php elseif ($type === 'html'): ?>
                <section class="kr-pb-html container my-4"><?php echo LegalPagesSeeder::localizeHtml((string)($sec['content'] ?? '')); ?></section>

            <?php elseif ($type === 'labels'): ?>
                <?php /* UI labels only — not rendered publicly */ ?>

            <?php else: /* text / legacy */ ?>
                <section class="kr-pb-text container my-5">
                    <div class="row justify-content-center">
                        <div class="col-lg-10">
                            <?php if (!empty($sec['title'])): ?><h2 class="fw-bold text-dark mb-2"><?php echo htmlspecialchars((string)$sec['title']); ?></h2><?php endif; ?>
                            <?php if (!empty($sec['subtitle'])): ?><p class="text-muted"><?php echo htmlspecialchars((string)$sec['subtitle']); ?></p><?php endif; ?>
                            <?php if (!empty($sec['content'])): ?><div class="kr-pb-rich"><?php echo LegalPagesSeeder::localizeHtml((string)$sec['content']); ?></div><?php endif; ?>
                            <?php if (!empty($sec['btn_text'])): ?>
                                <a class="btn btn-success rounded-pill px-4 mt-3" href="<?php echo htmlspecialchars(kr_pb_btn_url($sec['btn_link'] ?? '')); ?>">
                                    <?php echo htmlspecialchars((string)$sec['btn_text']); ?>
                                </a>
                            <?php endif; ?>
                        </div>
                    </div>
                </section>
            <?php endif; ?>

        <?php endforeach; ?>
    <?php endif; ?>
</div>

<?php include 'views/layouts/footer.php'; ?>
