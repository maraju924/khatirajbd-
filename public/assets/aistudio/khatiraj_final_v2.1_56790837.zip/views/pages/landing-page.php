<?php
/**
 * Landing Page View Template
 * Professional landing page with checkout form
 */

if (!class_exists('PriceHelper')) {
    require_once __DIR__ . '/../../app/Helpers/PriceHelper.php';
}
$has_lp_discount = PriceHelper::hasDiscount($landing_page['price'], $landing_page['offer_price'] ?? null);
$product_price = PriceHelper::effectivePrice($landing_page['price'], $landing_page['offer_price'] ?? null);
$first_zone_charge = !empty($shipping_zones) ? $shipping_zones[0]['charge'] : 0;
?>

<!-- Custom CSS if defined -->
<?php if(!empty($landing_page['custom_css'])): ?>
<style><?php echo $landing_page['custom_css']; ?></style>
<?php endif; ?>

<?php if ($landing_page['template_type'] === 'custom'): ?>
    <?php
    // Custom Template Rendering
    $custom_html = $landing_page['custom_html'];
    
    // Replace [checkout_form] with the partial
    if (strpos($custom_html, '[checkout_form]') !== false) {
        ob_start();
        include 'views/partials/landing_page_form.php';
        $form_html = ob_get_clean();
        $custom_html = str_replace('[checkout_form]', $form_html, $custom_html);
    }
    
    echo $custom_html;
    ?>
    
    <!-- Custom JS if defined -->
    <?php if(!empty($landing_page['custom_js'])): ?>
    <script><?php echo $landing_page['custom_js']; ?></script>
    <?php endif; ?>

<?php else: ?>
    <!-- Default Template Rendering -->
    <div class="landing-page-wrapper">
        <!-- Hero Section -->
        <section class="hero-section position-relative overflow-hidden" style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); min-height: 80vh;">
            <div class="hero-overlay position-absolute top-0 start-0 w-100 h-100" style="background: rgba(0,0,0,0.3);"></div>
            <div class="container position-relative py-5">
                <div class="row align-items-center min-vh-75 g-5">
                    <div class="col-lg-6 text-white animate__animated animate__fadeInLeft">
                        <span class="badge bg-warning text-dark px-3 py-2 rounded-pill mb-4 shadow-sm animate__animated animate__bounceIn">
                            <i class="fas fa-fire me-1"></i> সীমিত সময়ের অফার!
                        </span>
                        <h1 class="display-4 fw-bold mb-4 text-shadow">
                            <?php echo htmlspecialchars($landing_page['hero_title'] ?: $landing_page['product_name']); ?>
                        </h1>
                        <?php if(!empty($landing_page['hero_subtitle'])): ?>
                        <p class="lead mb-4 opacity-90" style="font-size: 1.25rem;">
                            <?php echo nl2br(htmlspecialchars($landing_page['hero_subtitle'])); ?>
                        </p>
                        <?php endif; ?>
                        
                        <!-- Price Display -->
                        <div class="price-box d-inline-flex align-items-center bg-white bg-opacity-20 backdrop-blur rounded-4 px-4 py-3 mb-4 shadow-lg">
                            <?php if ($has_lp_discount): ?>
                                <span class="text-decoration-line-through opacity-75 me-3 fs-4">৳<?php echo number_format($landing_page['price']); ?></span>
                                <span class="display-5 fw-bold text-warning">৳<?php echo number_format($product_price); ?></span>
                                <?php 
                                $discount = round((($landing_page['price'] - $product_price) / $landing_page['price']) * 100);
                                ?>
                                <span class="badge bg-danger ms-3 px-3 py-2"><?php echo $discount; ?>% OFF</span>
                            <?php else: ?>
                                <span class="display-5 fw-bold text-warning">৳<?php echo number_format($product_price); ?></span>
                            <?php endif; ?>
                        </div>
                        
                        <div class="d-flex gap-3 flex-wrap">
                            <a href="#order-section" class="btn btn-warning btn-lg px-5 py-3 fw-bold shadow-lg rounded-pill animate__animated animate__pulse animate__infinite">
                                <i class="fas fa-shopping-cart me-2"></i> <?php echo htmlspecialchars($landing_page['cta_text']); ?>
                            </a>
                            <a href="#benefits-section" class="btn btn-outline-light btn-lg px-4 py-3 rounded-pill">
                                <i class="fas fa-info-circle me-2"></i> বিস্তারিত দেখুন
                            </a>
                        </div>
                    </div>
                    
                    <div class="col-lg-6 text-center animate__animated animate__fadeInRight">
                        <div class="hero-image-wrapper position-relative">
                            <?php 
                            $hero_image = $landing_page['hero_image'] ?: $landing_page['product_image'];
                            ?>
                            <img src="<?php echo BASE_URL; ?>/<?php echo $hero_image; ?>" 
                                 alt="<?php echo htmlspecialchars($landing_page['product_name']); ?>" 
                                 class="img-fluid rounded-4 shadow-lg" 
                                 style="max-height: 500px; object-fit: cover; border: 5px solid rgba(255,255,255,0.3);">
                            
                            <!-- Floating Badge -->
                            <div class="position-absolute top-0 end-0 m-3">
                                <span class="badge bg-success px-3 py-2 rounded-pill shadow fs-6">
                                    <i class="fas fa-check-circle me-1"></i> <?php echo $landing_page['stock_status'] ?? 'In Stock'; ?>
                                </span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Wave Divider -->
            <div class="wave-divider position-absolute bottom-0 start-0 w-100">
                <svg viewBox="0 0 1440 120" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M0,64L48,69.3C96,75,192,85,288,80C384,75,480,53,576,48C672,43,768,53,864,69.3C960,85,1056,107,1152,101.3C1248,96,1344,64,1392,48L1440,32L1440,120L1392,120C1344,120,1248,120,1152,120C1056,120,960,120,864,120C768,120,672,120,576,120C480,120,384,120,288,120C192,120,96,120,48,120L0,120Z" fill="#f8fafc"/>
                </svg>
            </div>
        </section>

        <!-- Benefits Section -->
        <section class="benefits-section py-5 bg-light" id="benefits-section">
            <div class="container py-5">
                <div class="text-center mb-5">
                    <h2 class="display-5 fw-bold text-dark mb-3">
                        <i class="fas fa-star text-warning me-2"></i>
                        <?php echo htmlspecialchars($landing_page['benefits_title']); ?>
                    </h2>
                    <div class="mx-auto" style="width: 80px; height: 4px; background: linear-gradient(90deg, #667eea, #764ba2); border-radius: 2px;"></div>
                </div>
                
                <div class="row justify-content-center">
                    <div class="col-lg-8">
                        <div class="card border-0 shadow-lg rounded-4 overflow-hidden">
                            <div class="card-body p-5">
                                <div class="benefits-content fs-5 text-secondary lh-lg">
                                    <?php 
                                    $benefits = $landing_page['benefits_content'] ?: $landing_page['product_benefits'];
                                    if(!empty($benefits)) {
                                        echo nl2br(htmlspecialchars($benefits));
                                    } else {
                                        echo "✅ ১০০% খাঁটি ও প্রাকৃতিক উপাদান<br>✅ কোনো প্রকার ভেজাল নেই<br>✅ গুনগত মান নিশ্চিত";
                                    }
                                    ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <!-- Video Section (if available) -->
        <?php 
        $video_url = $landing_page['hero_video_url'] ?: $landing_page['product_video'];
        if(!empty($video_url)): 
        ?>
        <section class="video-section py-5 bg-white">
            <div class="container py-4">
                <div class="text-center mb-5">
                    <h2 class="display-6 fw-bold text-dark mb-3">
                        <i class="fas fa-play-circle text-danger me-2"></i> ভিডিও দেখুন
                    </h2>
                </div>
                <div class="row justify-content-center">
                    <div class="col-lg-8">
                        <div class="ratio ratio-16x9 rounded-4 overflow-hidden shadow-lg">
                            <iframe src="<?php echo str_replace('watch?v=', 'embed/', $video_url); ?>" 
                                    title="Product Video" allowfullscreen></iframe>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <?php endif; ?>

        <!-- Trust Points Section -->
        <section class="trust-section py-5" style="background: linear-gradient(135deg, #1e3a5f 0%, #0f172a 100%);">
            <div class="container py-5">
                <div class="text-center mb-5">
                    <h2 class="display-5 fw-bold text-white mb-3">
                        <i class="fas fa-shield-alt text-warning me-2"></i>
                        <?php echo htmlspecialchars($landing_page['trust_title']); ?>
                    </h2>
                </div>
                
                <div class="row justify-content-center">
                    <div class="col-lg-8">
                        <div class="trust-content text-white fs-5 lh-lg text-center">
                            <?php 
                            $trust = $landing_page['trust_content'] ?: $landing_page['product_trust_points'];
                            if(!empty($trust)) {
                                echo nl2br(htmlspecialchars($trust));
                            } else {
                                echo "🍃 সারাদেশে হোম ডেলিভারি<br>🍃 সঠিক মাপ ও ওজনের নিশ্চয়তা<br>🍃 প্রিমিয়াম কোয়ালিটি নিশ্চিত";
                            }
                            ?>
                        </div>
                        
                        <!-- Trust Icons -->
                        <div class="row g-4 mt-5 text-center">
                            <div class="col-4">
                                <div class="trust-icon-box p-4 rounded-4 bg-white bg-opacity-10">
                                    <i class="fas fa-truck fa-3x text-warning mb-3"></i>
                                    <h6 class="text-white fw-bold">দ্রুত ডেলিভারি</h6>
                                </div>
                            </div>
                            <div class="col-4">
                                <div class="trust-icon-box p-4 rounded-4 bg-white bg-opacity-10">
                                    <i class="fas fa-headset fa-3x text-warning mb-3"></i>
                                    <h6 class="text-white fw-bold">২৪/৭ সাপোর্ট</h6>
                                </div>
                            </div>
                            <div class="col-4">
                                <div class="trust-icon-box p-4 rounded-4 bg-white bg-opacity-10">
                                    <i class="fas fa-medal fa-3x text-warning mb-3"></i>
                                    <h6 class="text-white fw-bold">প্রিমিয়াম কোয়ালিটি</h6>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <!-- Included Checkout Form Partial -->
        <?php include 'views/partials/landing_page_form.php'; ?>
        
    </div>

    <style>
    .landing-page-wrapper {
        --primary-gradient: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        width: 100%;
        max-width: 100%;
        margin: 0;
        padding: 0;
        overflow-x: hidden;
    }
    .landing-page-wrapper .container {
        --bs-gutter-x: 0 !important;
        max-width: 100% !important;
        padding-left: 0 !important;
        padding-right: 0 !important;
    }
    .text-shadow { text-shadow: 0 2px 4px rgba(0,0,0,0.3); }
    .min-vh-75 { min-height: 75vh; }
    .trust-icon-box {
        transition: transform 0.3s ease;
    }
    .trust-icon-box:hover {
        transform: translateY(-5px);
    }
    @media (max-width: 768px) {
        .hero-section {
            min-height: auto !important;
            padding: 60px 0 !important;
        }
        .display-4 { font-size: 2rem; }
        .display-5 { font-size: 1.5rem; }
    }
    </style>

    <script>
    // Smooth scroll to sections
    document.querySelectorAll('a[href="#order-section"], a[href="#benefits-section"]').forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            const target = document.querySelector(this.getAttribute('href'));
            if (target) {
                target.scrollIntoView({ behavior: 'smooth', block: 'start' });
            }
        });
    });
    </script>

<?php endif; ?>
