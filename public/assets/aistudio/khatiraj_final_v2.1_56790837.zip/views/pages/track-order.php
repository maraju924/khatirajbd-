<?php
// views/pages/track-order.php
$page_title = "অর্ডার ট্র্যাকিং - Khati Raj";
PageHelper::load('track_order', ['title' => $page_title]);
include 'views/layouts/header.php';

$order_status = null;
$error = null;

if (isset($_GET['tracking_id'])) {
    $tid = trim($_GET['tracking_id']);
    // Search by Tracking ID, Order ID, or Phone Number. Show the most recent one.
    $stmt = $pdo->prepare("SELECT * FROM orders WHERE tracking_id = ? OR id = ? OR customer_phone = ? ORDER BY created_at DESC LIMIT 1");
    $stmt->execute([$tid, $tid, $tid]);
    $order = $stmt->fetch();
    
    if ($order) {
        $order_status = $order;
    } else {
        $error = "দুঃখিত, এই তথ্য দিয়ে কোনো অর্ডার পাওয়া যায়নি। অনুগ্রহ করে সঠিক আইডি বা ফোন নম্বর দিন।";
    }
}
?>

</div> <!-- Close header container for full-width layout -->

<div class="container">

    <?php if (!$order_status): ?>
        <div class="row justify-content-center">
            <div class="col-lg-6 col-md-8">
                <div class="kr-track-glass-card mb-5">
                    <div class="track-icon-wrap">
                        <i class="fas fa-truck-fast"></i>
                    </div>
                    <h2 class="fw-bold mb-2">আপনার অর্ডার ট্র্যাক করুন</h2>
                    <p class="small mb-4">আপনার অর্ডার আইডি বা মোবাইল নম্বর দিয়ে বর্তমান অবস্থা জানুন</p>
                    
                    <div class="track-form-wrap">
                        <form action="<?php echo BASE_URL; ?>/track-order" method="GET" class="mb-2">
                            <div class="d-flex gap-2">
                                <input type="text" name="tracking_id" class="form-control kr-glass-input" placeholder="অর্ডার আইডি বা মোবাইল নম্বর দিন" required value="<?php echo htmlspecialchars($_GET['tracking_id'] ?? ''); ?>">
                                <button class="kr-checkout-submit-btn px-4 fw-bold" type="submit" style="white-space: nowrap;">ট্র্যাক করুন <i class="fas fa-search ms-2"></i></button>
                            </div>
                        </form>
                        
                        <?php if ($error): ?>
                            <div class="alert alert-danger text-center mb-0 mt-4 small">
                                <i class="fas fa-exclamation-circle me-2"></i> <?php echo $error; ?>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    <?php endif; ?>

    <?php if ($order_status): ?>
        <div class="row justify-content-center mb-5">
            <div class="col-lg-8 col-md-10">
                <div class="kr-track-result-card">
                    <div class="d-flex align-items-center justify-content-between pb-4 mb-4 flex-wrap gap-2" style="border-bottom: 1px solid rgba(226, 232, 240, 0.5);">
                        <div>
                            <span class="small d-block" style="color: #64748b;">ORDER ID</span>
                            <h4 class="fw-bold mb-0" style="color: #0f172a;">#<?php echo $order_status['id']; ?></h4>
                        </div>
                        <div>
                            <span class="small d-block" style="color: #64748b;">TRACKING ID</span>
                            <span class="fw-bold fs-5" style="color: #15803d;"><?php echo $order_status['tracking_id']; ?></span>
                        </div>
                    </div>
                    
                    <!-- Timeline/Stepper component -->
                    <ul class="kr-order-timeline mb-4">
                        <?php
                        $current_status = $order_status['order_status'];
                        $stages = ['Pending', 'Processing', 'Shipped', 'Delivered'];
                        
                        if ($current_status === 'Cancelled') {
                            $stages = ['Pending', 'Cancelled'];
                        }
                        
                        $currentIndex = array_search($current_status, $stages);
                        if ($currentIndex === false) {
                            $currentIndex = -1;
                        }
                        
                        foreach ($stages as $index => $stage) {
                            $isCompleted = $index < $currentIndex;
                            $isActive = $index === $currentIndex;
                            
                            $statusClass = '';
                            if ($isCompleted) {
                                $statusClass = 'completed';
                            } elseif ($isActive) {
                                $statusClass = 'active';
                            }
                            
                            $stageLabel = $stage;
                            $stageDesc = '';
                            if ($stage === 'Pending') {
                                $stageLabel = 'অর্ডার পেন্ডিং';
                                $stageDesc = 'আমরা আপনার অর্ডারটি পেয়েছি এবং পর্যালোচনার জন্য অপেক্ষা করছে।';
                            } elseif ($stage === 'Processing') {
                                $stageLabel = 'অর্ডার প্রসেসিং';
                                $stageDesc = 'আপনার অর্ডারটি প্রস্তুত করা হচ্ছে।';
                            } elseif ($stage === 'Shipped') {
                                $stageLabel = 'অর্ডার পাঠানো হয়েছে';
                                $stageDesc = 'আপনার পার্সেলটি কুরিয়ারে হস্তান্তর করা হয়েছে। কুরিয়ার শীঘ্রই যোগাযোগ করবে।';
                            } elseif ($stage === 'Delivered') {
                                $stageLabel = 'অর্ডার ডেলিভারড';
                                $stageDesc = 'অর্ডারটি সফলভাবে আপনার কাছে পৌঁছে দেওয়া হয়েছে। ধন্যবাদ!';
                            } elseif ($stage === 'Cancelled') {
                                $stageLabel = 'অর্ডার বাতিল';
                                $stageDesc = 'দুঃখিত, এই অর্ডারটি বাতিল করা হয়েছে। কোনো জিজ্ঞাসা থাকলে যোগাযোগ করুন।';
                            }
                        ?>
                            <li class="kr-timeline-item <?php echo $statusClass; ?>">
                                <div class="timeline-dot">
                                    <?php if ($isCompleted): ?>
                                        <i class="fas fa-check"></i>
                                    <?php elseif ($isActive): ?>
                                        <i class="fas fa-circle-notch fa-spin"></i>
                                    <?php else: ?>
                                        <i class="far fa-circle"></i>
                                    <?php endif; ?>
                                </div>
                                <div class="timeline-content">
                                    <h6 class="fw-bold mb-1"><?php echo $stageLabel; ?></h6>
                                    <p class="small mb-0" style="color: #64748b;"><?php echo $stageDesc; ?></p>
                                </div>
                            </li>
                        <?php } ?>
                    </ul>
                    
                    <div class="kr-thanks-glass-details mt-4">
                        <h6 class="fw-bold mb-3" style="color: #15803d;"><i class="fas fa-user-circle me-2"></i>গ্রাহকের বিবরণ:</h6>
                        <div class="row g-3 small">
                            <div class="col-sm-6">
                                <span style="color: #64748b;">নাম:</span>
                                <span class="fw-bold" style="color: #0f172a;"><?php echo htmlspecialchars($order_status['customer_name']); ?></span>
                            </div>
                            <div class="col-sm-6">
                                <span style="color: #64748b;">ফোন নম্বর:</span>
                                <span class="fw-bold" style="color: #0f172a;"><?php echo htmlspecialchars($order_status['customer_phone']); ?></span>
                            </div>
                            <div class="col-12">
                                <span style="color: #64748b;">ডেলিভারি ঠিকানা:</span>
                                <span class="fw-bold" style="color: #0f172a;"><?php echo htmlspecialchars($order_status['shipping_address']); ?></span>
                            </div>
                        </div>
                    </div>
                    
                    <div class="text-center mt-4 pt-3">
                        <a href="<?php echo BASE_URL; ?>/track-order" class="kr-btn-outline btn-sm px-4" style="font-size: 0.88rem;">
                            <i class="fas fa-arrow-left me-2"></i> অন্য অর্ডার ট্র্যাক করুন
                        </a>
                    </div>
                </div>
            </div>
        </div>
    <?php endif; ?>
</div>

<?php include 'views/layouts/footer.php'; ?>

