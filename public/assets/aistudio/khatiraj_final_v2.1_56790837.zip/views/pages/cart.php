<?php
// views/pages/cart.php
?>
<div class="container mt-4 kr-cart-page">
    
    <?php if(isset($_GET['success'])): ?>
        <div class="alert alert-success border-0 shadow-sm rounded-3 mb-4"><?php echo htmlspecialchars($_GET['success']); ?></div>
    <?php endif; ?>

    <?php if(!empty($cart_items)): ?>
        <div class="row g-4">
            <!-- Left Side: Cart Items -->
            <div class="col-lg-8">
                <div class="kr-cart-glass-pane mb-4">
                    <div class="kr-pane-header">
                        <span class="kr-pane-title"><i class="fas fa-shopping-basket me-2"></i><?php echo __('shopping_cart') ?? 'শপিং কার্ট'; ?></span>
                    </div>
                    
                    <div class="kr-cart-items-list">
                        <?php 
                        $total = 0;
                        foreach($cart_items as $cartKey => $item):
                            $itemKey = $item['cart_key'] ?? $cartKey;
                            $subtotal = $item['price'] * $item['qty'];
                            $total += $subtotal;
                        ?>
                        <div id="cart-item-<?php echo htmlspecialchars($itemKey); ?>" class="kr-cart-item-card transition-all">
                            <!-- Image Frame -->
                            <div class="kr-cart-item-image">
                                <img src="<?php echo BASE_URL; ?>/<?php echo $item['image']; ?>" loading="lazy" alt="<?php echo htmlspecialchars($item['name']); ?>">
                            </div>
                            
                            <!-- Details Info -->
                            <div class="kr-cart-item-details">
                                <div class="kr-cart-item-name-pill">
                                    <span class="item-name-text"><?php echo htmlspecialchars($item['name']); ?></span>
                                </div>
                                
                                <?php if (!empty($item['variant_label'])): ?>
                                    <div class="kr-cart-item-variant">
                                        <i class="fas fa-layer-group"></i>
                                        <span><?php echo htmlspecialchars($item['variant_label']); ?></span>
                                    </div>
                                <?php endif; ?>
                                
                                <div class="kr-cart-item-meta">
                                    <div class="kr-cart-item-price">
                                        <span class="price-currency">৳</span>
                                        <span class="item-price"><?php echo number_format($item['price']); ?></span>
                                    </div>
                                    <span class="kr-cart-item-multiply">×</span>
                                    <div class="kr-cart-item-subtotal">
                                        <span>৳</span>
                                        <span id="subtotal-<?php echo htmlspecialchars($itemKey); ?>"><?php echo number_format($subtotal); ?></span>
                                    </div>
                                </div>
                            </div>
                            
                            <!-- Controls Panel -->
                            <div class="kr-cart-item-controls">
                                <!-- Qty Selector -->
                                <div class="kr-cart-qty-glass">
                                    <button onclick="updateCart('<?php echo htmlspecialchars($itemKey); ?>', 'dec')" class="qty-btn" aria-label="Decrease"><i class="fas fa-minus"></i></button>
                                    <input type="text" id="qty-<?php echo htmlspecialchars($itemKey); ?>" class="qty-value" value="<?php echo $item['qty']; ?>" readonly>
                                    <button onclick="updateCart('<?php echo htmlspecialchars($itemKey); ?>', 'inc')" class="qty-btn" aria-label="Increase"><i class="fas fa-plus"></i></button>
                                </div>
                                
                                <!-- Delete Btn -->
                                <button onclick="removeItem('<?php echo htmlspecialchars($itemKey); ?>')" class="kr-cart-remove-btn" aria-label="Remove item">
                                    <i class="fas fa-trash-alt"></i>
                                </button>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                </div>
                
                <!-- Bottom Actions -->
                <div class="kr-cart-bottom-actions mb-4">
                    <a href="<?php echo BASE_URL; ?>/shop" class="kr-cart-back-btn">
                        <i class="fas fa-arrow-left"></i> <?php echo __('start_shopping'); ?>
                    </a>
                    <button onclick="clearCart()" class="kr-cart-clear-btn">
                        <i class="fas fa-trash-alt"></i> <?php echo __('clear_cart'); ?></button>
                </div>
            </div>
            
            <!-- Right Side: Order Summary -->
            <div class="col-lg-4">
                <div class="kr-cart-summary-pane sticky-top" style="top: 100px; z-index: 10;">
                    <div class="kr-pane-header">
                        <span class="kr-pane-title"><i class="fas fa-file-invoice-dollar me-2"></i><?php echo __('summary'); ?></span>
                    </div>
                    
                    <div class="kr-cart-summary-inner">
                        <!-- Subtotal -->
                        <div class="kr-summary-row">
                            <span class="row-label"><?php echo __('subtotal'); ?></span>
                            <span class="row-value">৳<span id="cart-subtotal"><?php echo number_format($total); ?></span></span>
                        </div>
                        
                        <!-- Delivery Charge Option -->
                        <div class="kr-cart-delivery-glass">
                            <span class="delivery-label"><?php echo __('delivery_charge_select'); ?></span>
                            <select id="delivery-selector" onchange="updateDeliveryCharge()">
                                <?php foreach ($shipping_zones as $zone): 
                                    $charge = $zone['charge'] + $extra_shipping;
                                ?>
                                    <option value="<?php echo $charge; ?>"><?php echo htmlspecialchars($zone['name']); ?> - ৳<?php echo number_format($charge); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>

                        <!-- Delivery Charge Display -->
                        <div class="kr-summary-row">
                            <span class="row-label"><?php echo __('delivery_charge'); ?></span>
                            <span class="row-value">৳<span id="cart-delivery-charge">0</span></span>
                        </div>

                        <!-- Coupon Code Applied or Form -->
                        <div class="kr-cart-coupon-glass">
                            <div id="coupon-input-group" class="<?php echo isset($_SESSION['coupon']) ? 'd-none' : ''; ?>">
                                <span class="coupon-label"><i class="fas fa-ticket-alt"></i> প্রোমো কোড</span>
                                <div class="kr-cart-coupon-input-wrap">
                                    <input type="text" id="coupon_code" placeholder="SAVE20">
                                    <button class="kr-coupon-apply-btn" type="button" id="applyCouponBtn">Apply</button>
                                </div>
                            </div>
                            
                            <div id="applied-coupon" class="kr-coupon-applied-glass <?php echo !isset($_SESSION['coupon']) ? 'd-none' : ''; ?>">
                                <div class="coupon-info">
                                    <span class="coupon-code-badge"><i class="fas fa-check-circle"></i> Applied: <span id="applied_code"><?php echo $_SESSION['coupon']['code'] ?? ''; ?></span></span>
                                    <div class="coupon-discount-text">- ৳ <span id="discount_amount_display"><?php echo number_format($_SESSION['coupon']['discount'] ?? 0); ?></span></div>
                                </div>
                                <button type="button" class="kr-coupon-remove-btn" id="removeCouponBtn" title="Remove Coupon"><i class="fas fa-times"></i></button>
                            </div>
                        </div>

                        <!-- Discount Row -->
                        <div id="discount-row" class="kr-summary-discount-row <?php echo !isset($_SESSION['coupon']) ? 'd-none' : ''; ?>">
                            <span class="row-label">ডিসকাউন্ট</span>
                            <span class="row-value">- ৳ <span id="discount_display"><?php echo number_format($_SESSION['coupon']['discount'] ?? 0); ?></span></span>
                        </div>
                        
                        <hr class="kr-cart-divider">
                        
                        <!-- Grand Total -->
                        <div class="kr-cart-total-glass">
                            <span class="total-label"><?php echo __('total'); ?></span>
                            <span class="total-value">৳<span id="cart-total"><?php echo number_format($total); ?></span></span>
                        </div>
                        
                        <!-- Proceed to Checkout -->
                        <a href="<?php echo BASE_URL; ?>/checkout" class="kr-cart-checkout-btn">
                            <span><?php echo __('proceed_to_checkout'); ?></span>
                            <i class="fas fa-arrow-right"></i>
                        </a>
                        
                        <!-- SSL Security -->
                        <div class="kr-cart-ssl-badge">
                            <i class="fas fa-lock"></i>
                            <span>SSL Secure Checkout</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    <?php else: ?>
        <div class="kr-cart-empty-glass">
            <div class="kr-cart-empty-icon">
                <i class="fas fa-shopping-basket"></i>
            </div>
            <h2><?php echo __('cart_empty'); ?></h2>
            <p><?php echo __('browse_products'); ?></p>
            <a href="<?php echo BASE_URL; ?>/shop" class="kr-cart-shop-btn">
                <span><?php echo __('start_shopping'); ?></span>
                <i class="fas fa-arrow-right"></i>
            </a>
        </div>
    <?php endif; ?>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    updateDeliveryCharge(); // Initialize on load
});

function updateDeliveryCharge() {
    const selector = document.getElementById('delivery-selector');
    const charge = selector ? parseInt(selector.value) : 0;
    const deliveryEl = document.getElementById('cart-delivery-charge');
    if (deliveryEl) deliveryEl.innerText = charge.toLocaleString();
    
    // Update Total
    const subtotalText = document.getElementById('cart-subtotal').innerText.replace(/,/g, '');
    const subtotal = parseInt(subtotalText);
    
    // Get discount
    const discountEl = document.getElementById('discount_display');
    let discountVal = 0;
    if (discountEl) {
        discountVal = parseFloat(discountEl.innerText.replace(/,/g, '')) || 0;
    }

    const total = subtotal + charge - discountVal;
    document.getElementById('cart-total').innerText = total.toLocaleString();
}

// Coupon Logic
document.addEventListener('click', function(e) {
    if (e.target.id === 'applyCouponBtn') {
        const code = document.getElementById('coupon_code').value.trim();
        const subtotal = parseInt(document.getElementById('cart-subtotal').innerText.replace(/,/g, ''));
        
        if(!code) {
            if (typeof showToast === 'function') {
                showToast('Error', 'Please enter coupon code', 'error');
            } else {
                alert('Please enter coupon code');
            }
            return;
        }

        fetch('<?php echo BASE_URL; ?>/api/apply-coupon', {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: `code=${encodeURIComponent(code)}&subtotal=${subtotal}`
        })
        .then(res => res.json())
        .then(data => {
            if(data.status === 'success') {
                document.getElementById('applied_code').innerText = data.code;
                document.getElementById('discount_amount_display').innerText = data.discount.toLocaleString();
                document.getElementById('discount_display').innerText = data.discount.toLocaleString();
                
                document.getElementById('coupon-input-group').classList.add('d-none');
                document.getElementById('applied-coupon').classList.remove('d-none');
                document.getElementById('discount-row').classList.remove('d-none');
                
                updateDeliveryCharge(); 
                if (typeof showToast === 'function') {
                    showToast('Success', data.message, 'success');
                } else {
                    alert(data.message);
                }
            } else {
                if (typeof showToast === 'function') {
                    showToast('Error', data.message, 'error');
                } else {
                    alert(data.message);
                }
            }
        });
    }

    if (e.target.closest('#removeCouponBtn')) {
        fetch('<?php echo BASE_URL; ?>/api/remove-coupon')
        .then(res => res.json())
        .then(data => {
            document.getElementById('coupon-input-group').classList.remove('d-none');
            document.getElementById('applied-coupon').classList.add('d-none');
            document.getElementById('discount-row').classList.add('d-none');
            document.getElementById('discount_display').innerText = '0';
            updateDeliveryCharge();
            if (typeof showToast === 'function') {
                showToast('Info', 'Coupon removed successfully', 'info');
            }
        });
    }
});

function updateCart(id, action) {
    fetch(`<?php echo BASE_URL; ?>/cart/update/${id}?action=${action}`, {
        headers: { 'X-Requested-With': 'XMLHttpRequest' }
    })
    .then(res => res.json())
    .then(data => {
        if (data.status === 'success') {
            document.getElementById(`qty-${id}`).value = data.item_qty;
            document.getElementById(`subtotal-${id}`).innerText = Number(data.item_subtotal).toLocaleString();
            updateGlobalTotals(data);
            if (typeof showToast === 'function') {
                showToast('Cart Updated', 'Quantity updated successfully', 'success');
            }
        }
    });
}

function removeItem(id) {
    if (!confirm('<?php echo __('remove_item_confirm'); ?>')) return;

    fetch(`<?php echo BASE_URL; ?>/cart/remove/${id}`, {
        headers: { 'X-Requested-With': 'XMLHttpRequest' }
    })
    .then(res => res.json())
    .then(data => {
        if (data.status === 'success') {
            const itemCard = document.getElementById(`cart-item-${id}`);
            if (itemCard) {
                itemCard.classList.add('removing');
                setTimeout(() => {
                    itemCard.remove();
                    updateGlobalTotals(data);
                    if (data.cart_count === 0) {
                        location.reload();
                    }
                }, 400);
            } else {
                updateGlobalTotals(data);
                if (data.cart_count === 0) location.reload();
            }
            if (typeof showToast === 'function') {
                showToast('Removed', 'Item removed from cart', 'success');
            }
        }
    });
}

function clearCart() {
    if (!confirm('Are you sure you want to clear the cart?')) return;
    
    fetch('<?php echo BASE_URL; ?>/cart/clear', {
        headers: { 'X-Requested-With': 'XMLHttpRequest' }
    })
    .then(res => res.json())
    .then(data => {
        if (data.status === 'success') {
            if (typeof showToast === 'function') {
                showToast('Cleared', 'Cart cleared successfully', 'success');
            }
            setTimeout(() => location.reload(), 1000);
        }
    });
}

function updateGlobalTotals(data) {
    const badge = document.getElementById('cart-count-badge');
    if (badge) badge.innerText = data.cart_count;
    
    if (typeof updateCartBadge === 'function') {
        updateCartBadge(data.cart_count);
    }
    
    const subtotal = document.getElementById('cart-subtotal');
    if (subtotal) subtotal.innerText = Number(data.total).toLocaleString();
    
    updateDeliveryCharge();
}
</script>

<?php if(!empty($cart_items)): ?>
<!-- Mobile Sticky Checkout Bar -->
<div class="kr-cart-sticky-glass d-lg-none" id="cart-sticky-bar">
    <div class="d-flex align-items-center justify-content-between gap-3 w-100">
        <div>
            <div class="text-muted small"><?php echo __('total'); ?></div>
            <div class="fw-bold fs-5 text-primary">৳<span id="cart-sticky-total"><?php echo number_format($total); ?></span></div>
        </div>
        <a href="<?php echo BASE_URL; ?>/checkout" class="kr-cart-checkout-btn py-3 px-4" style="width: auto;">
            <span><?php echo __('proceed_to_checkout'); ?></span>
            <i class="fas fa-arrow-right ms-1"></i>
        </a>
    </div>
</div>

<script>
// Sync sticky cart bar total with main cart-total element
(function() {
    if (window.innerWidth > 768) return;
    document.body.classList.add('has-sticky-bar');

    const mainTotal = document.getElementById('cart-total');
    const stickyTotal = document.getElementById('cart-sticky-total');
    if (!mainTotal || !stickyTotal) return;

    // Mirror updates using MutationObserver
    const observer = new MutationObserver(() => {
        stickyTotal.innerText = mainTotal.innerText;
    });
    observer.observe(mainTotal, { childList: true, subtree: true, characterData: true });
})();
</script>
<?php endif; ?>
