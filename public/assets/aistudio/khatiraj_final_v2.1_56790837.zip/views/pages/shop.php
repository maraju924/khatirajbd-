<?php
// Fetch all categories for filter chips
$stmt_cats = $pdo->query("SELECT * FROM categories ORDER BY name ASC");
$all_categories = $stmt_cats->fetchAll();
?>

</div> <!-- Close header container for full-width layout -->

<div class="kr-shop-glass-pane position-relative mb-5">
    <div class="kr-pane-header">
        <h5 class="fw-bold mb-0 kr-pane-title">
            <i class="fas fa-store me-2" style="font-size: 0.9em;"></i><?php echo __('all_products'); ?>
        </h5>
    </div>

    <!-- Category Filter Chips -->
    <div class="row mb-4 align-items-center">
        <div class="col-md-8 text-center text-md-start mb-3 mb-md-0">
            <div class="d-flex flex-wrap gap-2 align-items-center kr-mobile-filter-scroll">
                <span class="small fw-bold text-uppercase me-2" style="color: #64748b;">Categories:</span>
                <a href="<?php echo BASE_URL; ?>/shop" class="kr-btn-ghost py-1 px-3 rounded-pill <?php echo !$category_slug ? 'active' : ''; ?>" style="font-size: 0.82rem; border: 1.5px solid rgba(255,255,255,0.6); background: rgba(255,255,255,0.35); color: var(--kr-text);">
                    All Products
                </a>
                <?php foreach ($all_categories as $cat): ?>
                    <a href="<?php echo BASE_URL; ?>/category/<?php echo $cat['slug']; ?>" class="kr-btn-ghost py-1 px-3 rounded-pill <?php echo $category_slug === $cat['slug'] ? 'active' : ''; ?>" style="font-size: 0.82rem; border: 1.5px solid rgba(255,255,255,0.6); background: rgba(255,255,255,0.35); color: var(--kr-text);">
                        <?php echo htmlspecialchars($cat['name']); ?>
                    </a>
                <?php endforeach; ?>
            </div>
        </div>
        <div class="col-md-4 text-center text-md-end text-muted small">
            Showing <?php echo count($products); ?> products
        </div>
    </div>

    <!-- Product Grid -->
    <div class="row row-cols-2 row-cols-md-3 row-cols-lg-4 g-4">
      <?php foreach($products as $prod): ?>
      <div class="col">
        <?php include __DIR__ . '/../partials/product-card.php'; ?>
      </div>
      <?php $loop_i = ($loop_i ?? 0) + 1; ?>
      <?php endforeach; ?>
    </div>

    <?php if (count($products) === 0): ?>
        <div class="kr-empty-state">
            <div class="empty-icon-wrap">
                <i class="fas fa-shopping-basket"></i>
            </div>
            <h3 class="fw-bold">No Products Found</h3>
            <p>We couldn't find any products in this category right now. Please check back later.</p>
            <a href="<?php echo BASE_URL; ?>/shop" class="kr-btn-primary">Browse All Products</a>
        </div>
    <?php endif; ?>
</div>

<div class="container"><!-- Reopen container -->

<script>
    document.addEventListener('DOMContentLoaded', function() {
        const urlParams = new URLSearchParams(window.location.search);
        const searchQuery = urlParams.get('q');
        if (searchQuery && window.AppTracking) {
            window.AppTracking.track('Search', {
                search_string: searchQuery
            }, 'sh_' + new Date().getTime());
        }
    });
</script>
