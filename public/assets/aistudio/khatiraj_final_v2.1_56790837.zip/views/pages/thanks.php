<?php
$tracking_id = $order['tracking_id'] ?? $order['id'];
$item_count = count($order_items ?? []);
$is_paid = ($order['payment_status'] ?? '') === 'Paid';
$is_online = ($order['payment_method'] ?? '') === 'Online';
$is_cod = !$is_online;
$payment_pending = $is_online && !$is_paid;

$digital_items = array_filter($order_items ?? [], fn($item) => ($item['product_type'] ?? '') === 'digital');
$physical_items = array_filter($order_items ?? [], fn($item) => ($item['product_type'] ?? '') !== 'digital');

$support_phone = $site_settings['support_phone'] ?? '';
$delivery_note = $is_cod
    ? 'আমাদের প্রতিনিধি শীঘ্রই আপনার সাথে যোগাযোগ করবেন। ২–৩ কার্যদিবসের মধ্যে ডেলিভারি হবে।'
    : ($payment_pending
        ? 'অনলাইন পেমেন্ট ভেরিফাই হলে অর্ডার প্রসেস শুরু হবে।'
        : 'আপনার পেমেন্ট নিশ্চিত হয়েছে। শীঘ্রই অর্ডার প্রসেস করা হবে।');
?>

<div class="kr-checkout-page kr-thanks-page my-3 my-md-4">
    <div class="row justify-content-center">
        <div class="col-xl-10 col-lg-11">

            <!-- Hero — Liquid Glass -->
            <div class="kr-liquid-glass-pane kr-thanks-glass-hero text-center p-4 p-md-5 mb-4 mb-md-5 position-relative">
                <div class="kr-thanks-success-ring mx-auto">
                    <span class="kr-item-icon-bubble green-theme kr-thanks-icon-bubble">
                        <i class="fas fa-check"></i>
                    </span>
                    <span class="kr-thanks-ring-pulse"></span>
                </div>
                <p class="kr-thanks-eyebrow mb-2">Order Confirmed</p>
                <h1 class="kr-thanks-title mb-2"><?php echo __('thanks'); ?></h1>
                <p class="kr-thanks-subtitle mb-0 mx-auto"><?php echo __('order_success'); ?></p>
                <span class="kr-thanks-tracking-chip mt-3 d-inline-flex align-items-center gap-2">
                    <i class="fas fa-hashtag"></i>#<?php echo htmlspecialchars($tracking_id); ?>
                </span>
            </div>

            <div class="row g-4 align-items-start">

                <!-- Order Summary -->
                <div class="col-lg-7">
                    <div class="kr-liquid-glass-pane kr-thanks-pane p-4 p-md-5 position-relative h-100">
                        <div class="kr-pane-header">
                            <h5 class="fw-bold mb-0 kr-pane-title">
                                <i class="fas fa-receipt me-2" style="font-size:0.9em;"></i>অর্ডার সারাংশ
                            </h5>
                        </div>

                        <div class="kr-thanks-detail-grid mt-4 pt-2">
                            <div class="kr-thanks-glass-tile">
                                <span class="label"><?php echo __('customer_name'); ?></span>
                                <span class="value"><?php echo htmlspecialchars($order['customer_name']); ?></span>
                            </div>
                            <div class="kr-thanks-glass-tile">
                                <span class="label"><?php echo __('total_amount'); ?></span>
                                <span class="value kr-thanks-amount">৳<?php echo number_format($order['total_amount']); ?></span>
                            </div>
                            <div class="kr-thanks-glass-tile">
                                <span class="label">পেমেন্ট মেথড</span>
                                <span class="kr-thanks-pill <?php echo $is_online ? 'pill-online' : 'pill-cod'; ?>">
                                    <?php echo $is_online ? 'অনলাইন পেমেন্ট' : 'ক্যাশ অন ডেলিভারি'; ?>
                                </span>
                            </div>
                            <?php if ($is_online): ?>
                            <div class="kr-thanks-glass-tile">
                                <span class="label">পেমেন্ট স্ট্যাটাস</span>
                                <?php if ($is_paid): ?>
                                    <span class="kr-thanks-pill pill-paid"><i class="fas fa-check-circle me-1"></i>পেইড</span>
                                <?php else: ?>
                                    <span class="kr-thanks-pill pill-pending"><i class="fas fa-clock me-1"></i>ভেরিফিকেশন পেন্ডিং</span>
                                <?php endif; ?>
                            </div>
                            <?php endif; ?>
                            <div class="kr-thanks-glass-tile">
                                <span class="label">মোট আইটেম</span>
                                <span class="value"><?php echo $item_count; ?>টি</span>
                            </div>
                            <?php if (!empty($order['customer_phone'])): ?>
                            <div class="kr-thanks-glass-tile">
                                <span class="label">মোবাইল</span>
                                <span class="value"><?php echo htmlspecialchars($order['customer_phone']); ?></span>
                            </div>
                            <?php endif; ?>
                        </div>

                        <?php if (!empty($order_items)): ?>
                        <div class="mt-4 pt-2">
                            <div class="kr-checkout-items-head px-1">
                                <span>অর্ডারকৃত পণ্য</span>
                                <span><?php echo $item_count; ?> Items</span>
                            </div>
                            <?php foreach ($order_items as $item): ?>
                            <div class="kr-checkout-item-glass">
                                <div class="d-flex align-items-center gap-3 flex-grow-1 min-w-0">
                                    <span class="kr-item-icon-bubble blue-theme" style="width:38px;height:38px;min-width:38px;">
                                        <i class="fas fa-box" style="font-size:0.85rem;"></i>
                                    </span>
                                    <div class="min-w-0">
                                        <div class="kr-checkout-item-name text-truncate"><?php echo htmlspecialchars($item['product_name']); ?></div>
                                        <div class="kr-checkout-item-variant">Qty: <?php echo (int)$item['qty']; ?> × ৳<?php echo number_format($item['price']); ?></div>
                                    </div>
                                </div>
                                <div class="kr-checkout-item-price">৳<?php echo number_format($item['qty'] * $item['price']); ?></div>
                            </div>
                            <?php endforeach; ?>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>

                <!-- Sidebar -->
                <div class="col-lg-5">

                    <!-- Timeline -->
                    <div class="kr-liquid-glass-pane kr-thanks-pane p-4 p-md-5 position-relative mb-4">
                        <div class="kr-pane-header">
                            <h5 class="fw-bold mb-0 kr-pane-title">
                                <i class="fas fa-route me-2" style="font-size:0.9em;"></i>পরবর্তী ধাপ
                            </h5>
                        </div>
                        <ol class="kr-thanks-timeline mt-4 pt-2 mb-0">
                            <li class="done">
                                <span class="dot"><i class="fas fa-check"></i></span>
                                <div>
                                    <strong>অর্ডার গ্রহণ</strong>
                                    <p>আপনার অর্ডার সফলভাবে রেকর্ড হয়েছে</p>
                                </div>
                            </li>
                            <li class="<?php echo ($is_cod || $is_paid) ? 'active' : ''; ?>">
                                <span class="dot"><i class="fas fa-box"></i></span>
                                <div>
                                    <strong>প্রসেসিং</strong>
                                    <p><?php echo $payment_pending ? 'পেমেন্ট ভেরিফিকেশনের পর শুরু হবে' : 'অর্ডার প্রস্তুত করা হচ্ছে'; ?></p>
                                </div>
                            </li>
                            <li>
                                <span class="dot"><i class="fas fa-truck"></i></span>
                                <div>
                                    <strong>ডেলিভারি</strong>
                                    <p><?php echo empty($digital_items) && !empty($physical_items) ? '২–৩ কার্যদিবসের মধ্যে' : 'ডিজিটাল ডেলিভারি'; ?></p>
                                </div>
                            </li>
                        </ol>
                    </div>

                    <?php if ($payment_pending): ?>
                    <div class="kr-checkout-notice-glass mb-4">
                        <span class="kr-item-icon-bubble blue-theme"><i class="fas fa-info-circle"></i></span>
                        <div>
                            <strong>পেমেন্ট ভেরিফিকেশন</strong>
                            <p>আপনার পেমেন্ট এডমিন ভেরিফাই করলে অর্ডার প্রসেস শুরু হবে।</p>
                        </div>
                    </div>
                    <?php endif; ?>

                    <?php if (!empty($digital_items)): ?>
                    <div class="kr-liquid-glass-pane kr-thanks-pane p-4 p-md-5 position-relative mb-4">
                        <div class="kr-pane-header">
                            <h5 class="fw-bold mb-0 kr-pane-title">
                                <i class="fas fa-cloud-download-alt me-2" style="font-size:0.9em;"></i>ডিজিটাল ডাউনলোড
                            </h5>
                        </div>
                        <div class="mt-4 pt-2">
                            <?php foreach ($digital_items as $item): ?>
                            <div class="kr-checkout-item-glass">
                                <div class="min-w-0">
                                    <div class="kr-checkout-item-name"><?php echo htmlspecialchars($item['product_name']); ?></div>
                                    <div class="kr-checkout-item-variant">Digital Product</div>
                                </div>
                                <?php if ($is_paid && !empty($item['digital_file_url'])): ?>
                                    <a href="<?php echo htmlspecialchars($item['digital_file_url']); ?>" target="_blank" class="kr-checkout-submit-btn btn-sm px-3 py-2" style="font-size:0.8rem;white-space:nowrap;">
                                        <i class="fas fa-download me-1"></i>ডাউনলোড
                                    </a>
                                <?php else: ?>
                                    <span class="kr-thanks-pill pill-pending">পেমেন্টের পর</span>
                                <?php endif; ?>
                            </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                    <?php endif; ?>

                    <!-- Actions -->
                    <div class="kr-liquid-glass-pane kr-thanks-pane p-4 position-relative">
                        <div class="kr-pane-header">
                            <h5 class="fw-bold mb-0 kr-pane-title">
                                <i class="fas fa-bolt me-2" style="font-size:0.9em;"></i>Quick Actions
                            </h5>
                        </div>
                        <div class="d-flex flex-column gap-2 mt-4 pt-2">
                            <a href="<?php echo OrderAccessHelper::summaryUrlForOrder($pdo, (int)$order['id']); ?>" target="_blank" class="kr-checkout-glass-option d-flex align-items-center justify-content-between text-decoration-none mb-0 active-payment" data-no-pjax>
                                <div class="d-flex align-items-center gap-3">
                                    <span class="kr-item-icon-bubble green-theme"><i class="fas fa-file-download"></i></span>
                                    <span class="kr-checkout-option-title">Download Summary</span>
                                </div>
                                <i class="fas fa-chevron-right text-muted small"></i>
                            </a>
                            <a href="<?php echo BASE_URL; ?>/track-order?tracking_id=<?php echo urlencode($tracking_id); ?>" class="kr-checkout-glass-option d-flex align-items-center justify-content-between text-decoration-none mb-0">
                                <div class="d-flex align-items-center gap-3">
                                    <span class="kr-item-icon-bubble blue-theme"><i class="fas fa-search-location"></i></span>
                                    <span class="kr-checkout-option-title">অর্ডার ট্র্যাক করুন</span>
                                </div>
                                <i class="fas fa-chevron-right text-muted small"></i>
                            </a>
                            <?php if (!isset($lp) || !$lp): ?>
                            <a href="<?php echo BASE_URL; ?>/shop" class="kr-checkout-glass-option d-flex align-items-center justify-content-between text-decoration-none mb-0">
                                <div class="d-flex align-items-center gap-3">
                                    <span class="kr-item-icon-bubble green-theme"><i class="fas fa-shopping-bag"></i></span>
                                    <span class="kr-checkout-option-title"><?php echo __('more_shopping'); ?></span>
                                </div>
                                <i class="fas fa-chevron-right text-muted small"></i>
                            </a>
                            <a href="<?php echo BASE_URL; ?>/home" class="kr-checkout-glass-option d-flex align-items-center justify-content-between text-decoration-none mb-0">
                                <div class="d-flex align-items-center gap-3">
                                    <span class="kr-item-icon-bubble blue-theme"><i class="fas fa-home"></i></span>
                                    <span class="kr-checkout-option-title"><?php echo __('back_to_home'); ?></span>
                                </div>
                                <i class="fas fa-chevron-right text-muted small"></i>
                            </a>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Support Strip — Liquid Glass Dark -->
            <div class="kr-liquid-glass-pane kr-thanks-support-pane mt-4 mt-md-5 p-4 position-relative">
                <div class="kr-thanks-support-inner">
                    <div class="d-flex align-items-start gap-3 flex-grow-1">
                        <span class="kr-item-icon-bubble green-theme flex-shrink-0"><i class="fas fa-headset"></i></span>
                        <div class="kr-thanks-support-text"><?php echo htmlspecialchars($delivery_note); ?></div>
                    </div>
                    <?php if ($support_phone): ?>
                    <a href="tel:<?php echo preg_replace('/\D/', '', $support_phone); ?>" class="kr-thanks-support-phone">
                        <i class="fas fa-phone-alt me-1"></i><?php echo htmlspecialchars($support_phone); ?>
                    </a>
                    <?php endif; ?>
                </div>
            </div>

        </div>
    </div>
</div>

<?php
$purchase_items = array_column($order_items, 'product_id');
$purchase_event_id = 'pur_' . $order['id'];
?>
<script>
if (window.AppTracking) {
    window.AppTracking.track('Purchase', {
        content_ids: <?php echo json_encode($purchase_items); ?>,
        content_type: 'product',
        value: <?php echo json_encode((float)$order['total_amount']); ?>,
        currency: 'BDT',
        num_items: <?php echo $item_count; ?>
    }, <?php echo json_encode($purchase_event_id); ?>);
}
</script>
