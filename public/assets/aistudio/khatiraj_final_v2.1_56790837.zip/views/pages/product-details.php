<?php
// views/pages/product-details.php
// $product is available from the controller
?>

<div class="product-page-wrapper py-4">
    <div class="container">
        <!-- Breadcrumb -->
        <nav aria-label="breadcrumb" class="mb-4 d-none d-md-block">
            <ol class="breadcrumb mb-0">
                <li class="breadcrumb-item"><a href="<?php echo BASE_URL; ?>/home" class="text-decoration-none" style="color: var(--brand-color);"><?php echo __('home'); ?></a></li>
                <li class="breadcrumb-item active" aria-current="page"><?php echo htmlspecialchars($product['name']); ?></li>
            </ol>
        </nav>

        <div class="row g-4 mb-5">
            <!-- Left: Product Image & Gallery -->
            <div class="col-md-6 text-center">
                <div class="sticky-top" style="top: 100px; z-index: 10;">
                    <!-- Main Image Card -->
                    <div class="product-main-img-container position-relative shadow-sm bg-white rounded-4 overflow-hidden border mb-3">
                        <?php if($product['offer_price']): 
                            $discount = round((($product['price'] - $product['offer_price']) / $product['price']) * 100);
                        ?>
                            <span class="position-absolute top-0 end-0 m-3 badge rounded-pill bg-success px-3 py-2" style="z-index: 5; background: #15803d !important;">
                                -<?php echo $discount; ?>%
                            </span>
                        <?php endif; ?>
                        
                        <div class="main-image-wrapper p-2">
                            <img id="mainProductImage" src="<?php echo BASE_URL; ?>/<?php echo $product['image']; ?>" class="img-fluid rounded-3" alt="<?php echo htmlspecialchars($product['image_alt_text'] ?: $product['name']); ?>" fetchpriority="high" style="width: 100%; height: auto; transition: opacity 0.3s ease;">
                        </div>

                        <!-- Expand Button -->
                        <button class="position-absolute bottom-0 start-0 m-3 btn btn-light btn-sm rounded-circle shadow-sm d-flex align-items-center justify-content-center" style="width: 40px; height: 40px; z-index: 5;" onclick="expandImage()">
                            <i class="fas fa-expand-alt text-dark"></i>
                        </button>
                    </div>

                    <!-- Thumbnails Gallery -->
                    <?php if(!empty($gallery_images)): ?>
                    <div class="product-thumbnails d-flex justify-content-center gap-2 overflow-auto pb-2">
                        <!-- Primary Image Thumbnail -->
                        <div class="thumb-item active border rounded-3 overflow-hidden" onclick="changeMainImage('<?php echo BASE_URL; ?>/<?php echo $product['image']; ?>', this)" style="width: 80px; height: 80px; cursor: pointer; flex-shrink: 0;">
                            <img src="<?php echo BASE_URL; ?>/<?php echo $product['image']; ?>" class="w-100 h-100" style="object-fit: cover;" loading="lazy" alt="">
                        </div>
                        <?php foreach($gallery_images as $g_img): ?>
                        <div class="thumb-item border rounded-3 overflow-hidden" onclick="changeMainImage('<?php echo BASE_URL; ?>/<?php echo $g_img; ?>', this)" style="width: 80px; height: 80px; cursor: pointer; flex-shrink: 0;">
                            <img src="<?php echo BASE_URL; ?>/<?php echo $g_img; ?>" class="w-100 h-100" style="object-fit: cover;" loading="lazy" alt="">
                        </div>
                        <?php endforeach; ?>
                    </div>
                    <?php endif; ?>
                </div>
            </div>

            <script>
            function changeMainImage(src, thumb) {
                const mainImg = document.getElementById('mainProductImage');
                mainImg.style.opacity = '0';
                setTimeout(() => {
                    mainImg.src = src;
                    mainImg.style.opacity = '1';
                }, 300);

                // Update active state
                document.querySelectorAll('.thumb-item').forEach(el => el.classList.remove('active', 'border-primary'));
                thumb.classList.add('active', 'border-primary');
            }

            function expandImage() {
                const src = document.getElementById('mainProductImage').src;
                const modal = document.createElement('div');
                modal.style.cssText = 'position:fixed; top:0; left:0; width:100%; height:100%; background:rgba(0,0,0,0.9); z-index:99999; display:flex; align-items:center; justify-content:center; cursor:zoom-out;';
                modal.onclick = () => modal.remove();
                
                const img = document.createElement('img');
                img.src = src;
                img.style.cssText = 'max-width:95%; max-height:95%; object-fit:contain; border-radius:8px;';
                
                modal.appendChild(img);
                document.body.appendChild(modal);
            }
            </script>

            <style>
            .thumb-item { transition: all 0.2s; border-width: 2px !important; }
            .thumb-item.active { border-color: var(--brand-color) !important; transform: translateY(-2px); }
            .thumb-item:hover { border-color: #ddd; }
            .product-thumbnails::-webkit-scrollbar { height: 4px; }
            .product-thumbnails::-webkit-scrollbar-thumb { background: #ddd; border-radius: 10px; }
            </style>

            <!-- Right: Product Info -->
            <div class="col-md-6 pt-md-3">
                <div class="kr-liquid-glass-pane kr-pd-buybox p-4 position-relative mb-5">
                    <div class="kr-pane-header kr-product-name-plate">
                        <h1 class="fw-bold mb-0 text-center kr-pane-title"><?php echo htmlspecialchars($product['name']); ?></h1>
                    </div>

                    <div class="kr-pd-buy-inner">
                        <!-- Price + Stock -->
                        <div class="kr-pd-price-block" id="product-price-section">
                            <div class="kr-pd-price-values">
                                <?php if($product['offer_price']): ?>
                                    <span class="kr-pd-price" id="product-display-price">৳<?php echo number_format($product['offer_price']); ?></span>
                                    <span class="kr-pd-oldprice" id="product-display-original-price">৳<?php echo number_format($product['price']); ?></span>
                                <?php else: ?>
                                    <span class="kr-pd-price" id="product-display-price">৳<?php echo number_format($product['price']); ?></span>
                                    <span class="kr-pd-oldprice d-none" id="product-display-original-price"></span>
                                <?php endif; ?>
                            </div>
                            <span class="kr-pd-stock" id="product-stock-badge"><?php echo $product['stock_status'] ?? 'In Stock'; ?></span>
                        </div>

                        <?php if (!empty($product_variant_data['enabled']) && !empty($product_variant_data['variants'])): ?>
                        <div id="product-variants-picker" class="kr-pd-variants">
                            <?php foreach ($product_variant_data['attributes'] as $attr): ?>
                            <div class="kr-pd-variant-group">
                                <span class="kr-pd-field-label"><?php echo htmlspecialchars($attr['name']); ?></span>
                                <div class="kr-pd-variant-options">
                                    <?php foreach ($attr['values'] as $val): ?>
                                    <button type="button"
                                        class="kr-pd-variant-btn <?php echo ($attr['display_type'] === 'color' && !empty($val['color_hex'])) ? 'is-color' : ''; ?>"
                                        data-attribute="<?php echo htmlspecialchars($attr['name']); ?>"
                                        data-value="<?php echo htmlspecialchars($val['value']); ?>"
                                        <?php if ($attr['display_type'] === 'color' && !empty($val['color_hex'])): ?>
                                        data-color="<?php echo htmlspecialchars($val['color_hex']); ?>"
                                        <?php endif; ?>>
                                        <?php if ($attr['display_type'] === 'color' && !empty($val['color_hex'])): ?>
                                            <span class="kr-pd-variant-swatch" style="background: <?php echo htmlspecialchars($val['color_hex']); ?>;"></span>
                                        <?php endif; ?>
                                        <?php echo htmlspecialchars($val['value']); ?>
                                    </button>
                                    <?php endforeach; ?>
                                </div>
                            </div>
                            <?php endforeach; ?>
                            <input type="hidden" id="selected_variant_id" value="">
                        </div>
                        <?php endif; ?>

                        <!-- Quantity -->
                        <div class="kr-pd-qty-row">
                            <span class="kr-pd-field-label">পরিমাণ</span>
                            <div class="kr-pd-qty">
                                <button type="button" class="kr-pd-qty-btn" onclick="changeProductQty(-1)" aria-label="Decrease"><i class="fas fa-minus"></i></button>
                                <input type="number" id="product_detail_qty" value="1" min="1" class="kr-pd-qty-input" readonly>
                                <button type="button" class="kr-pd-qty-btn" onclick="changeProductQty(1)" aria-label="Increase"><i class="fas fa-plus"></i></button>
                            </div>
                        </div>

                        <!-- Action Buttons -->
                        <div class="kr-pd-actions">
                            <a href="#" class="kr-pd-btn kr-pd-btn-order" onclick="orderNow(<?php echo $product['id']; ?>, event)">
                                <i class="fas fa-bolt"></i> অর্ডার করুন
                            </a>
                            <button type="button" class="kr-pd-btn kr-pd-btn-cart" onclick="addToCart(<?php echo $product['id']; ?>, event)">
                                <i class="fas fa-cart-plus"></i> কার্টে যোগ করুন
                            </button>
                            <?php
                            global $site_settings;
                            $pd_whatsapp_enabled = ($site_settings['enable_whatsapp'] ?? '0') == '1';
                            $pd_whatsapp_number = preg_replace('/\D/', '', $site_settings['whatsapp_number'] ?? '');
                            if ($pd_whatsapp_enabled && !empty($pd_whatsapp_number)):
                            ?>
                            <a href="#" class="kr-pd-btn kr-pd-btn-whatsapp" onclick="orderViaWhatsApp(event)">
                                <i class="fab fa-whatsapp"></i> হোয়াটসঅ্যাপে মেসেজ করুন
                            </a>
                            <?php endif; ?>
                        </div>

                        <?php
                        $pd_share_url_raw = SITE_URL . '/product/' . $product['slug'];
                        $pd_share_url = urlencode($pd_share_url_raw);
                        $pd_share_title = urlencode($product['name']);
                        ?>
                        <div class="kr-pd-social-share">
                            <span class="kr-pd-share-label">শেয়ার করুন</span>
                            <div class="kr-pd-share-icons">
                                <a href="https://www.facebook.com/sharer/sharer.php?u=<?php echo $pd_share_url; ?>"
                                   target="_blank"
                                   rel="noopener noreferrer"
                                   class="kr-pd-share-btn kr-pd-share-fb"
                                   title="Facebook-এ শেয়ার করুন"
                                   aria-label="Facebook-এ শেয়ার করুন">
                                    <i class="fab fa-facebook-f"></i>
                                </a>
                                <button type="button"
                                        class="kr-pd-share-btn kr-pd-share-ig"
                                        title="Instagram-এ শেয়ার করুন"
                                        aria-label="Instagram-এ শেয়ার করুন"
                                        onclick="shareProductOnInstagram(event)">
                                    <i class="fab fa-instagram"></i>
                                </button>
                                <a href="https://twitter.com/intent/tweet?url=<?php echo $pd_share_url; ?>&text=<?php echo $pd_share_title; ?>"
                                   target="_blank"
                                   rel="noopener noreferrer"
                                   class="kr-pd-share-btn kr-pd-share-tw"
                                   title="Twitter-এ শেয়ার করুন"
                                   aria-label="Twitter-এ শেয়ার করুন">
                                    <i class="fab fa-x-twitter"></i>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>

                <hr class="my-4" style="opacity: 0.1;">

                <!-- Dynamic Premium Sections (Reference Image Design) -->
                <?php if (!empty($product_sections)): ?>
                    <?php
                    if (!function_exists('getPremiumItemIcon')) {
                        function getPremiumItemIcon($text, $sectionTitle) {
                            $text = mb_strtolower($text, 'UTF-8');
                            $sectionTitle = mb_strtolower($sectionTitle, 'UTF-8');
                            
                            $color = 'green';
                            if (strpos($sectionTitle, 'কেন আমাদের') !== false || strpos($sectionTitle, 'নিবেন') !== false || strpos($sectionTitle, 'আমাদের') !== false) {
                                $color = 'blue';
                            }
                            
                            if (strpos($text, 'খাঁটি') !== false || strpos($text, 'প্রাকৃতিক') !== false) {
                                $icon = 'fas fa-leaf';
                                $color = 'green';
                            } elseif (strpos($text, 'ভেজাল') !== false || strpos($text, 'মুক্ত') !== false) {
                                $icon = 'fas fa-ban';
                                $color = 'green';
                            } elseif (strpos($text, 'মান') !== false || strpos($text, 'নিশ্চিত') !== false) {
                                $icon = 'fas fa-shield-alt';
                                if (strpos($text, 'প্রিমিয়াম') !== false) {
                                    $icon = 'fas fa-gem';
                                    $color = 'blue';
                                }
                            } elseif (strpos($text, 'ডেলিভারি') !== false || strpos($text, 'ডেলিভারী') !== false) {
                                $icon = 'fas fa-shipping-fast';
                                $color = 'blue';
                            } elseif (strpos($text, 'ওজন') !== false || strpos($text, 'মাপ') !== false) {
                                $icon = 'fas fa-balance-scale';
                                $color = 'blue';
                            } elseif (strpos($text, 'প্রিমিয়াম') !== false || strpos($text, 'কোয়ালিটি') !== false) {
                                $icon = 'fas fa-gem';
                                $color = 'blue';
                            } else {
                                $icon = $color === 'green' ? 'fas fa-check-circle' : 'fas fa-info-circle';
                            }
                            
                            return ['icon' => $icon, 'color' => $color];
                        }
                    }
                    ?>
                    <div class="kr-pd-dynamic-sections d-flex flex-column gap-5 mb-5 pt-3">
                        <?php foreach ($product_sections as $sec): ?>
                            <div class="kr-liquid-glass-pane p-4 position-relative">
                                <div class="kr-pane-header">
                                    <h5 class="fw-bold mb-0 text-center kr-pane-title">
                                        <?php echo htmlspecialchars($sec['title']); ?>
                                    </h5>
                                </div>
                                <div class="kr-pane-list d-flex flex-column gap-2 mt-2">
                                    <?php foreach ($sec['items'] as $item): 
                                        $meta = getPremiumItemIcon($item['text_content'], $sec['title']);
                                    ?>
                                        <div class="kr-pane-item d-flex align-items-center p-2 rounded-pill shadow-sm">
                                            <div class="kr-item-icon-bubble d-flex align-items-center justify-content-center <?php echo $meta['color']; ?>-theme">
                                                <i class="<?php echo htmlspecialchars($meta['icon']); ?>"></i>
                                            </div>
                                            <div class="kr-item-divider"></div>
                                            <div class="kr-item-content">
                                                <span class="kr-item-text fw-bold"><?php echo htmlspecialchars($item['text_content']); ?></span>
                                            </div>
                                        </div>
                                    <?php endforeach; ?>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>

                <!-- 3. Video Section -->
                <?php if(!empty($product['video_url'])): ?>
                <div class="kr-liquid-glass-pane p-4 position-relative mb-5">
                    <div class="kr-pane-header">
                        <h5 class="fw-bold mb-0 text-center kr-pane-title">
                            <i class="fas fa-play-circle me-2" style="font-size: 0.9em;"></i>প্রোডাক্ট ভিডিও
                        </h5>
                    </div>
                    <div class="ratio ratio-16x9 rounded-4 overflow-hidden mt-2" style="box-shadow: 0 8px 30px rgba(0,0,0,0.08); border: 2px solid rgba(255,255,255,0.6);">
                        <iframe src="<?php echo str_replace('watch?v=', 'embed/', $product['video_url']); ?>" title="Product Video" allowfullscreen style="border-radius: 16px;"></iframe>
                    </div>
                </div>
                <?php endif; ?>

            <!-- 4. Detailed Description (Liquid Glass Pane) -->
                <div class="kr-liquid-glass-pane kr-desc-glass-pane p-4 position-relative mb-5">
                    <div class="kr-pane-header">
                        <h5 class="fw-bold mb-0 text-center kr-pane-title">
                            <i class="fas fa-file-alt me-2" style="font-size: 0.9em;"></i><?php echo htmlspecialchars($product['details_title'] ?? 'বিস্তারিত বিবরণ:'); ?>
                        </h5>
                    </div>
                    <div class="product-rich-content mt-3 lh-lg">
                        <?php 
                        $desc = $product['description'];
                        // Check if description contains HTML tags (from CKEditor)
                        if ($desc !== strip_tags($desc)) {
                            // Render HTML content with safe tags only
                            echo strip_tags($desc, '<p><br><strong><b><em><i><u><s><h2><h3><h4><ul><ol><li><a><blockquote><table><thead><tbody><tr><td><th><figure><figcaption><oembed>');
                        } else {
                            // Legacy plain text - render with nl2br
                            echo nl2br(htmlspecialchars($desc));
                        }
                        ?>
                    </div>
                </div>

            </div>
        <!-- Related Products Section -->
        <?php if(!empty($related_products)): ?>
        <div class="kr-liquid-glass-pane p-4 position-relative mt-5">
            <div class="kr-pane-header">
                <h5 class="fw-bold mb-0 text-center kr-pane-title">
                    <i class="fas fa-th-large me-2" style="font-size: 0.9em;"></i>আরও কিছু পণ্য দেখুন
                </h5>
            </div>

            <div class="row row-cols-2 row-cols-md-3 row-cols-lg-4 g-4 mb-5">
                <?php foreach($related_products as $rel_prod): ?>
                <div class="col">
                    <?php $prod = $rel_prod; include __DIR__ . '/../partials/product-card.php'; ?>
                </div>
                <?php $loop_i = ($loop_i ?? 0) + 1; ?>
                <?php endforeach; ?>
            </div>
        </div>
        <?php endif; ?>

        <!-- Product Reviews Section -->
        <div class="kr-reviews-wrapper mt-5" id="reviews-section">
            <div class="row g-4">
                <!-- Left: Review Summary & List -->
                <div class="col-lg-7">
                    <div class="kr-liquid-glass-pane p-4 position-relative">
                        <div class="kr-pane-header">
                            <h5 class="fw-bold mb-0 text-center kr-pane-title">
                                <i class="fas fa-comments me-2" style="font-size: 0.9em;"></i>কাস্টমার রিভিউ (<?php echo count($reviews); ?>)
                            </h5>
                        </div>
                        
                        <?php if (isset($_GET['review_success'])): ?>
                            <div class="alert alert-success border-0 shadow-sm mb-4 mt-3 rounded-pill text-center">
                                <i class="fas fa-check-circle me-1"></i> আপনার রিভিউটি সফলভাবে জমা হয়েছে। এডমিন অ্যাপ্রুভ করার পর এটি দেখা যাবে।
                            </div>
                        <?php endif; ?>

                        <?php if (empty($reviews)): ?>
                            <div class="text-center py-5 mt-2">
                                <div class="kr-item-icon-bubble green-theme mx-auto mb-3" style="width:60px; height:60px;">
                                    <i class="fas fa-comment-slash" style="font-size:1.4rem;"></i>
                                </div>
                                <p class="text-muted mb-0 fw-semibold">এখনো কোনো রিভিউ নেই। প্রথম রিভিউটি আপনিই দিন!</p>
                            </div>
                        <?php else: ?>
                            <div class="kr-pane-list d-flex flex-column gap-3 mt-3">
                                <?php foreach ($reviews as $review): ?>
                                    <div class="kr-review-glass-card p-3 rounded-4">
                                        <div class="d-flex align-items-center mb-2">
                                            <div class="kr-review-avatar d-flex align-items-center justify-content-center me-3">
                                                <i class="fas fa-user"></i>
                                            </div>
                                            <div>
                                                <h6 class="mb-0 fw-bold" style="color:#1e293b;"><?php echo htmlspecialchars($review['user_name']); ?></h6>
                                                <div class="text-warning" style="font-size:0.8rem;">
                                                    <?php for ($i = 1; $i <= 5; $i++): ?>
                                                        <i class="<?php echo $i <= $review['rating'] ? 'fas' : 'far'; ?> fa-star"></i>
                                                    <?php endfor; ?>
                                                </div>
                                            </div>
                                            <span class="ms-auto text-muted small"><i class="far fa-clock me-1"></i><?php echo date('d M, Y', strtotime($review['created_at'])); ?></span>
                                        </div>
                                        <p class="mb-0" style="color:#475569; line-height:1.7;"><?php echo nl2br(htmlspecialchars($review['comment'])); ?></p>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>

                <!-- Right: Review Form -->
                <div class="col-lg-5">
                    <div class="kr-liquid-glass-pane p-4 position-relative">
                        <div class="kr-pane-header">
                            <h5 class="fw-bold mb-0 text-center kr-pane-title">
                                <i class="fas fa-pen-fancy me-2" style="font-size: 0.9em;"></i>একটি রিভিউ দিন
                            </h5>
                        </div>
                        <form action="" method="POST" class="mt-3">
                            <div class="mb-3">
                                <label class="form-label fw-bold" style="color:#1e293b;">রেটিং *</label>
                                <div class="star-rating h4 text-warning">
                                    <input type="radio" name="rating" value="5" id="5-stars" required><label for="5-stars" class="star"><i class="fas fa-star"></i></label>
                                    <input type="radio" name="rating" value="4" id="4-stars"><label for="4-stars" class="star"><i class="fas fa-star"></i></label>
                                    <input type="radio" name="rating" value="3" id="3-stars"><label for="3-stars" class="star"><i class="fas fa-star"></i></label>
                                    <input type="radio" name="rating" value="2" id="2-stars"><label for="2-stars" class="star"><i class="fas fa-star"></i></label>
                                    <input type="radio" name="rating" value="1" id="1-star"><label for="1-star" class="star"><i class="fas fa-star"></i></label>
                                </div>
                            </div>
                            <div class="mb-3">
                                <label class="form-label fw-bold" style="color:#1e293b;">আপনার নাম *</label>
                                <input type="text" name="user_name" class="form-control kr-glass-input" placeholder="আপনার পুরো নাম" value="<?php echo $_SESSION['user_name'] ?? ''; ?>" required>
                            </div>
                            <div class="mb-3">
                                <label class="form-label fw-bold" style="color:#1e293b;">ইমেইল *</label>
                                <input type="email" name="user_email" class="form-control kr-glass-input" placeholder="example@email.com" value="<?php echo $_SESSION['user_email'] ?? ''; ?>" required>
                            </div>
                            <div class="mb-4">
                                <label class="form-label fw-bold" style="color:#1e293b;">মন্তব্য (অপশনাল)</label>
                                <textarea name="comment" class="form-control kr-glass-input" rows="4" placeholder="আপনার অভিজ্ঞতা শেয়ার করুন..."></textarea>
                            </div>
                            <button type="submit" name="submit_review" class="btn w-100 py-3 fw-bold rounded-pill kr-glass-submit-btn">
                                <i class="fas fa-paper-plane me-2"></i>রিভিউ জমা দিন
                            </button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
.star-rating { display: flex; flex-direction: row-reverse; justify-content: flex-end; gap: 5px; }
.star-rating input { display: none; }
.star-rating label { cursor: pointer; color: #ccc; transition: color 0.2s; }
.star-rating input:checked ~ label, .star-rating label:hover, .star-rating label:hover ~ label { color: #ffc107; }
</style>

<style>
.bg-label-success { background: #d1e7dd; color: #0f5132; font-weight: 500; }
.btn-orange:hover { transform: translateY(-2px); filter: brightness(1.1); transition: 0.3s; box-shadow: 0 10px 20px rgba(21, 128, 61, 0.3) !important; }
.btn-outline-success:hover { background-color: var(--brand-color); border-color: var(--brand-color); }

/* Related Products - Premium Card Styles */
.related-products .section-header {
    position: relative;
    margin-bottom: 2.5rem;
    display: flex;
    align-items: center;
    justify-content: space-between;
}
.related-products .section-title {
    font-size: 1.75rem;
    font-weight: 800;
    color: #2d3436;
    position: relative;
    padding-left: 15px;
}
.related-products .section-title::before {
    content: '';
    position: absolute;
    left: 0;
    top: 50%;
    transform: translateY(-50%);
    width: 4px;
    height: 70%;
    background: var(--brand-color, #15803d);
    border-radius: 2px;
}
.related-products .view-all-btn {
    color: var(--brand-color, #15803d);
    font-weight: 600;
    text-decoration: none;
    display: inline-flex;
    align-items: center;
    gap: 5px;
    transition: gap 0.2s;
}
.related-products .view-all-btn:hover { gap: 8px; }

/* Related product card overrides removed to inherit global kr-product-card styles */
.product-img-card:hover img { transform: scale(1.02); }
.product-benefits { background: #fdfdfd; padding: 20px; border-radius: 15px; border-left: 4px solid #25b672; }

.input-group-text { border-right: 0; }
.custom-radio { width: 1.25em; height: 1.25em; margin-top: 0.125em; }

@media (max-width: 768px) {
    .h1 { font-size: 1.6rem !important; }
    .btn-lg { padding: 0.8rem !important; font-size: 0.95rem !important; }
    .product-page-wrapper { padding-top: 1rem !important; }
    .breadcrumb { display: none !important; }
    .product-main-img-container { margin-bottom: 1rem !important; }
    .product-benefits, .trust-points { padding: 15px !important; margin-bottom: 1.5rem !important; }
    .benefits-list, .trust-points div, .product-desc-section div { font-size: 1rem !important; }
}
</style>

<script>
const productVariants = <?php echo json_encode($product_variant_data ?? ['enabled' => false, 'attributes' => [], 'variants' => []], JSON_UNESCAPED_UNICODE); ?>;
const baseProductPrice = {
    price: <?php echo json_encode((float) $product['price']); ?>,
    offer_price: <?php echo json_encode($product['offer_price'] ? (float) $product['offer_price'] : null); ?>
};
let selectedVariantOptions = {};

document.addEventListener('DOMContentLoaded', function() {
    initVariantPicker();
});

function initVariantPicker() {
    if (!productVariants.enabled || !productVariants.variants.length) return;

    document.querySelectorAll('.kr-pd-variant-group').forEach(group => {
        const firstBtn = group.querySelector('.kr-pd-variant-btn');
        if (firstBtn) {
            selectVariantOption(firstBtn);
        }
    });

    document.querySelectorAll('.kr-pd-variant-btn').forEach(btn => {
        btn.addEventListener('click', function() {
            selectVariantOption(this);
        });
    });
}

function selectVariantOption(btn) {
    const attribute = btn.dataset.attribute;
    const value = btn.dataset.value;
    selectedVariantOptions[attribute] = value;

    document.querySelectorAll('.kr-pd-variant-btn[data-attribute="' + attribute.replace(/"/g, '\\"') + '"]').forEach(item => {
        item.classList.remove('active');
    });
    btn.classList.add('active');

    updateSelectedVariant();
}

function getVariantDisplayPrices(variant) {
    let regular = baseProductPrice.price;
    let offer = baseProductPrice.offer_price;

    if (variant.price !== null && variant.price !== '') {
        regular = Number(variant.price);
        offer = null;
    }
    if (variant.offer_price !== null && variant.offer_price !== '') {
        offer = Number(variant.offer_price);
    }

    return { regular, offer };
}

function updatePriceDisplay(regular, offer) {
    const priceEl = document.getElementById('product-display-price');
    const originalEl = document.getElementById('product-display-original-price');
    if (!priceEl) return;

    if (offer) {
        priceEl.textContent = '৳' + Number(offer).toLocaleString('en-BD');
        if (originalEl) {
            originalEl.textContent = '৳' + Number(regular).toLocaleString('en-BD');
            originalEl.classList.remove('d-none');
        }
    } else {
        priceEl.textContent = '৳' + Number(regular).toLocaleString('en-BD');
        if (originalEl) {
            originalEl.classList.add('d-none');
        }
    }
}

function updateStockBadge(status) {
    const badge = document.getElementById('product-stock-badge');
    if (!badge) return;

    badge.textContent = status || 'In Stock';
    badge.classList.remove('is-out-of-stock');
    if ((status || '').toLowerCase() === 'out of stock') {
        badge.classList.add('is-out-of-stock');
    }
}

function updateSelectedVariant() {
    const hiddenInput = document.getElementById('selected_variant_id');
    if (!hiddenInput) return;

    const match = productVariants.variants.find(variant => {
        return Object.keys(variant.combination).every(key => selectedVariantOptions[key] === variant.combination[key]);
    });

    if (!match) {
        hiddenInput.value = '';
        return;
    }

    hiddenInput.value = match.id;
    const prices = getVariantDisplayPrices(match);
    updatePriceDisplay(prices.regular, prices.offer);
    updateStockBadge(match.stock_status);
}

function getSelectedVariantId() {
    const hiddenInput = document.getElementById('selected_variant_id');
    return hiddenInput ? hiddenInput.value : '';
}

function validateVariantSelection() {
    if (!productVariants.enabled || !productVariants.variants.length) return true;
    if (getSelectedVariantId()) return true;
    alert('অনুগ্রহ করে variant (Size/Color) নির্বাচন করুন।');
    return false;
}

function buildCartAddUrl(productId, qty, redirectCheckout = false) {
    let url = `<?php echo BASE_URL; ?>/cart/add/${productId}?qty=${qty}`;
    const variantId = getSelectedVariantId();
    if (variantId) {
        url += `&variant_id=${variantId}`;
    }
    if (redirectCheckout) {
        url += '&redirect=checkout';
    }
    return url;
}

function orderViaWhatsApp(event) {
    if (event) event.preventDefault();
    if (!validateVariantSelection()) return;

    const detailQty = document.getElementById('product_detail_qty');
    const mobileQty = document.getElementById('mobile_detail_qty');
    const qty = detailQty ? parseInt(detailQty.value, 10) : (mobileQty ? parseInt(mobileQty.value, 10) : 1);

    const productName = <?php echo json_encode($product['name'], JSON_UNESCAPED_UNICODE); ?>;
    const productUrl = <?php echo json_encode(SITE_URL . '/product/' . $product['slug']); ?>;
    const whatsappNumber = <?php echo json_encode($pd_whatsapp_number ?? ''); ?>;
    const priceEl = document.getElementById('product-display-price');
    const variantLabel = Object.entries(selectedVariantOptions).map(([k, v]) => k + ': ' + v).join(', ');

    const message = [
        'আমি এই পণ্যটি সম্পর্কে জানতে চাই / অর্ডার করতে চাই:',
        '',
        'পণ্য: ' + productName,
        variantLabel ? 'Variant: ' + variantLabel : '',
        'মূল্য: ' + (priceEl ? priceEl.textContent.trim() : ''),
        'পরিমাণ: ' + qty,
        'লিংক: ' + productUrl
    ].filter(Boolean).join('\n');

    window.open('https://wa.me/' + whatsappNumber + '?text=' + encodeURIComponent(message), '_blank');
}

const productShareUrl = <?php echo json_encode($pd_share_url_raw ?? (SITE_URL . '/product/' . $product['slug'])); ?>;
const productShareTitle = <?php echo json_encode($product['name'], JSON_UNESCAPED_UNICODE); ?>;

function shareProductOnInstagram(event) {
    if (event) event.preventDefault();

    const shareText = productShareTitle + '\n' + productShareUrl;

    if (navigator.share) {
        navigator.share({ title: productShareTitle, text: productShareTitle, url: productShareUrl }).catch(function() {});
        return;
    }

    if (navigator.clipboard && navigator.clipboard.writeText) {
        navigator.clipboard.writeText(shareText).then(function() {
            alert('লিংক কপি হয়েছে! Instagram app খুলে story বা bio-তে paste করুন।');
        }).catch(function() {
            window.prompt('এই লিংকটি কপি করে Instagram-এ শেয়ার করুন:', productShareUrl);
        });
        return;
    }

    window.prompt('এই লিংকটি কপি করে Instagram-এ শেয়ার করুন:', productShareUrl);
}

function addToCart(productId, event) {
    if(event) event.preventDefault();
    if (!validateVariantSelection()) return;
    
    const detailQty = document.getElementById('product_detail_qty');
    const mobileQty = document.getElementById('mobile_detail_qty');
    const qty = detailQty ? parseInt(detailQty.value) : (mobileQty ? parseInt(mobileQty.value) : 1);
    
    fetch(buildCartAddUrl(productId, qty), {
        method: 'POST',
        headers: {
            'X-Requested-With': 'XMLHttpRequest'
        }
    })
    .then(res => res.json())
    .then(data => {
        if (data.status === 'success' || data.success) {
            if (typeof updateCartBadge === 'function') {
                updateCartBadge(data.cart_count);
            } else {
                const badge = document.getElementById('cart-count-badge');
                if (badge) badge.innerText = data.cart_count;
            }
            
            if (window.AppTracking) {
                window.AppTracking.track('AddToCart', {
                    content_ids: [productId],
                    value: (data.item_price || 0) * qty,
                    currency: 'BDT',
                    quantity: qty
                }, 'ac_' + productId + '_' + new Date().getTime());
            }

            alert('Product added to cart!');
        }
    })
    .catch(err => console.error('Add to cart error:', err));
}
window.__krCustomAddToCart = true;
window.addToCart = addToCart;

function orderNow(productId, event) {
    if(event) event.preventDefault();
    if (!validateVariantSelection()) return;

    const detailQty = document.getElementById('product_detail_qty');
    const mobileQty = document.getElementById('mobile_detail_qty');
    const qty = detailQty ? parseInt(detailQty.value) : (mobileQty ? parseInt(mobileQty.value) : 1);

    window.location.href = buildCartAddUrl(productId, qty, true);
}

function mobileOrderNow(productId, event) {
    orderNow(productId, event);
}

function changeProductQty(delta) {
    const detailQty = document.getElementById('product_detail_qty');
    const mobileQty = document.getElementById('mobile_detail_qty');
    
    let currentVal = parseInt(detailQty ? detailQty.value : (mobileQty ? mobileQty.value : 1));
    let newVal = currentVal + delta;
    if (newVal < 1) newVal = 1;
    
    if (detailQty) detailQty.value = newVal;
    if (mobileQty) mobileQty.value = newVal;
}

// Track Product Clicks on Related Products
document.querySelectorAll('.related-products a').forEach(link => {
    link.addEventListener('click', function() {
        // Custom Product_Click removed to keep only standard events
    });
});


</script>

<!-- Product Schema JSON-LD -->
<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "Product",
  "name": "<?php echo htmlspecialchars($product['name']); ?>",
  "image": "<?php echo SITE_URL . '/' . $product['image']; ?>",
  "description": "<?php
    $schema_desc = strip_tags((string) ($product['description'] ?? ''));
    $schema_desc = function_exists('mb_substr') ? mb_substr($schema_desc, 0, 200, 'UTF-8') : substr($schema_desc, 0, 200);
    echo htmlspecialchars($schema_desc, ENT_QUOTES, 'UTF-8');
  ?>",
  "brand": {
    "@type": "Brand",
    "name": "<?php echo htmlspecialchars($product['brand'] ?: 'KhatiRaj BD'); ?>"
  },
  "sku": "<?php echo htmlspecialchars($product['sku'] ?? ''); ?>",
  <?php if(count($reviews) > 0): 
    $total_rating = array_sum(array_column($reviews, 'rating'));
    $avg_rating = $total_rating / count($reviews);
  ?>
  "aggregateRating": {
    "@type": "AggregateRating",
    "ratingValue": "<?php echo number_format($avg_rating, 1); ?>",
    "reviewCount": "<?php echo count($reviews); ?>"
  },
  <?php endif; ?>
  "offers": {
    "@type": "Offer",
    "url": "<?php echo SITE_URL . '/product/' . $product['slug']; ?>",
    "priceCurrency": "BDT",
    "price": "<?php echo $product['offer_price'] ?: $product['price']; ?>",
    "priceValidUntil": "<?php echo date('Y-12-31'); ?>",
    "availability": "https://schema.org/<?php echo ($product['stock_status'] == 'In Stock') ? 'InStock' : 'OutOfStock'; ?>",
    "itemCondition": "https://schema.org/NewCondition",
    "seller": {
      "@type": "Organization",
      "name": "KhatiRaj BD"
    }
  }
}
</script>

<!-- Tracking System: ViewContent -->
<?php
$vc_price = $product['offer_price'] ?: $product['price'];
$vc_product_id = $product['id'];
$vc_event_id = 'vc_' . $product['id'] . '_' . time();
?>
<script>
if (window.AppTracking) {
    window.AppTracking.track('ViewContent', {
        content_ids: [<?php echo json_encode($vc_product_id); ?>],
        content_type: 'product',
        value: <?php echo json_encode($vc_price); ?>,
        currency: 'BDT'
    }, <?php echo json_encode($vc_event_id); ?>);
}
</script>

<!-- Mobile Sticky Bottom Action Bar -->
<div class="kr-mobile-sticky-bar d-lg-none" id="product-sticky-bar">
    <div class="d-flex align-items-center justify-content-between w-100 gap-2">
        <!-- Quantity Selector inside sticky bar -->
        <div class="kr-mobile-qty-selector d-flex align-items-center rounded bg-light border" style="height: 40px; min-width: 95px; max-width: 105px;">
            <button type="button" class="btn btn-link text-dark p-0 px-2 h-100 d-flex align-items-center justify-content-center" onclick="changeProductQty(-1)" style="text-decoration: none;"><i class="fas fa-minus x-small" style="font-size: 0.8rem;"></i></button>
            <input type="number" id="mobile_detail_qty" value="1" min="1" class="form-control border-0 text-center fw-bold p-0 bg-transparent" style="width: 30px; font-size: 0.95rem; height: 100%; outline: none; box-shadow: none;" readonly>
            <button type="button" class="btn btn-link text-dark p-0 px-2 h-100 d-flex align-items-center justify-content-center" onclick="changeProductQty(1)" style="text-decoration: none;"><i class="fas fa-plus x-small" style="font-size: 0.8rem;"></i></button>
        </div>

        <!-- Add to Cart Button -->
        <button class="btn kr-mobile-btn-cart py-2 fw-bold d-flex align-items-center justify-content-center gap-1" 
                style="background: #e6f7ed; color: #16a34a; border: 1px solid rgba(22, 163, 74, 0.2); border-radius: 8px; font-size: 0.8rem; height: 40px; flex: 1;"
                onclick="addToCart(<?php echo $product['id']; ?>, event)">
            <i class="fas fa-cart-plus small"></i> কার্ট রাখুন
        </button>

        <!-- Order Now Button (Mobile) -->
        <a href="<?php echo BASE_URL; ?>/cart/add/<?php echo $product['id']; ?>?redirect=checkout" class="btn kr-mobile-btn-order py-2 fw-bold d-flex align-items-center justify-content-center gap-1" 
                style="background: #16a34a; color: #fff; border: 1px solid rgba(22, 163, 74, 0.3); border-radius: 8px; font-size: 0.8rem; height: 40px; flex: 1; text-decoration: none;"
                onclick="mobileOrderNow(<?php echo $product['id']; ?>, event)">
            <i class="fas fa-bolt small"></i> অর্ডার করুন
        </a>

    </div>
</div>

<script>
// Add has-sticky-bar class on mobile only for product detail page
if (window.innerWidth <= 768) {
    document.body.classList.add('has-sticky-bar');
}
</script>
