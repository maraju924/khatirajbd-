<?php
// views/components/whatsapp.php
$whatsapp_enabled = ($site_settings['enable_whatsapp'] ?? '0') == '1';
$whatsapp_number = $site_settings['whatsapp_number'] ?? '';
$whatsapp_msg = urlencode($site_settings['whatsapp_message'] ?? 'Hello, I want to order some products.');

if ($whatsapp_enabled && !empty($whatsapp_number)):
?>
<a href="https://wa.me/<?php echo $whatsapp_number; ?>?text=<?php echo $whatsapp_msg; ?>" class="kr-whatsapp-btn" target="_blank">
    <i class="fab fa-whatsapp"></i>
    <span class="kr-whatsapp-tooltip"><?php echo LanguageHelper::getCurrentLang() === 'bn' ? 'হোয়াটসঅ্যাপে চ্যাট করুন' : 'Chat on WhatsApp'; ?></span>
</a>
<?php endif; ?>
