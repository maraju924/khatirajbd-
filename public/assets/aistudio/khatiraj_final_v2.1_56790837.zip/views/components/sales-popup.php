<?php
// views/components/sales-popup.php
$sales_popup_enabled = ($site_settings['enable_sales_popup'] ?? '0') == '1';
if ($sales_popup_enabled):
?>

<div id="recent-sales-popup" class="kr-sales-popup">
    <button class="popup-close" onclick="closeSalesPopup()"><i class="fas fa-times"></i></button>
    <img id="sales-p-image" class="popup-image" src="" alt="Product">
    <div class="popup-body">
        <div id="sales-c-name" class="popup-name">Someone</div>
        <div id="sales-p-info" class="popup-product">Purchased Product</div>
        <div id="sales-time" class="popup-time">Just now</div>
    </div>
    <div id="sales-progress" class="popup-progress" style="width: 0%;"></div>
</div>

<script>
    let salesData = [];
    let salesIndex = 0;
    let popupTimeout = null;

    function closeSalesPopup() {
        const popup = document.getElementById('recent-sales-popup');
        if (popup) {
            popup.classList.remove('show');
        }
        clearTimeout(popupTimeout);
    }

    function showNextSale() {
        if (salesData.length === 0) return;
        
        const sale = salesData[salesIndex];
        const imgEl = document.getElementById('sales-p-image');
        const nameEl = document.getElementById('sales-c-name');
        const infoEl = document.getElementById('sales-p-info');
        const timeEl = document.getElementById('sales-time');
        
        if (imgEl) imgEl.src = '<?php echo BASE_URL; ?>/' + sale.image;
        if (nameEl) nameEl.innerText = sale.name + ' (' + sale.area + ')';
        if (infoEl) infoEl.innerText = 'Bought ' + sale.product;
        if (timeEl) timeEl.innerText = sale.time;
        
        const popup = document.getElementById('recent-sales-popup');
        const progress = document.getElementById('sales-progress');
        
        if (popup && progress) {
            // Reset progress bar
            progress.style.transition = 'none';
            progress.style.width = '100%';
            
            popup.classList.add('show');
            
            // Start progress shrink animation
            setTimeout(() => {
                progress.style.transition = 'width 5s linear';
                progress.style.width = '0%';
            }, 50);
        }
        
        salesIndex = (salesIndex + 1) % salesData.length;
        
        popupTimeout = setTimeout(closeSalesPopup, 5000); // Show for 5 seconds
    }

    // Fetch data and start loop
    fetch('<?php echo BASE_URL; ?>/api/recent-sales')
        .then(res => res.json())
        .then(data => {
            salesData = data;
            if (salesData.length > 0) {
                setTimeout(showNextSale, 3000); // Initial delay
                setInterval(showNextSale, 15000); // Show every 15 seconds
            }
        });
</script>
<?php endif; ?>
