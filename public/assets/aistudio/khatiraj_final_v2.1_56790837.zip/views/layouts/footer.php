</div> <!-- End Container -->
<?php global $pdo, $site_settings, $social_links; ?>

<?php if(!isset($hide_header_footer) || !$hide_header_footer): ?>
<footer class="kr-footer mt-5 d-none d-lg-block">
    <!-- Ambient Glass Blobs -->
    <div class="kr-footer-blob kr-footer-blob-1" aria-hidden="true"></div>
    <div class="kr-footer-blob kr-footer-blob-2" aria-hidden="true"></div>

    <div class="kr-footer-top container">
        <div class="row g-4">
            <div class="col-md-4 col-sm-12">
                <div class="kr-footer-brand mb-3">
                    <a href="<?php echo BASE_URL; ?>/" class="kr-footer-brand-link">
                        <?php if (!empty($site_settings['site_logo'])): ?>
                            <img src="<?php echo BASE_URL; ?>/<?php echo htmlspecialchars($site_settings['site_logo']); ?>" alt="<?php echo htmlspecialchars($site_settings['site_name'] ?? 'Khati Raj'); ?>" class="kr-footer-brand-logo">
                        <?php else: ?>
                            <span class="kr-footer-brand-name"><?php echo htmlspecialchars($site_settings['site_name'] ?? 'Khati Raj'); ?></span>
                        <?php endif; ?>
                    </a>
                </div>
                <p class="small mb-4">
                    <?php echo htmlspecialchars($site_settings['footer_about_text'] ?? 'Leading e-commerce platform in Bangladesh providing authentic products with fast delivery.'); ?>
                </p>
                <div class="kr-social-links">
                    <?php 
                    global $social_links;
                    foreach ($social_links as $slink): 
                    ?>
                        <a href="<?php echo htmlspecialchars($slink['url']); ?>" class="social-btn" title="<?php echo htmlspecialchars($slink['platform_name']); ?>">
                            <i class="<?php echo htmlspecialchars($slink['icon_class']); ?>"></i>
                        </a>
                    <?php endforeach; ?>
                </div>
            </div>
            <div class="col-md-4 col-sm-6">
                <h5 class="fw-bold mb-3 text-uppercase"><?php echo htmlspecialchars($site_settings['footer_col2_title'] ?? 'Quick Links'); ?></h5>
                <div class="row">
                    <div class="col-12">
                        <ul class="list-unstyled mb-0">
                            <?php 
                            require_once __DIR__ . '/../../app/Helpers/MenuHelper.php';
                            $footer_links = MenuHelper::getFooterLinks($pdo);
                            if (empty($footer_links)):
                            ?>
                                <li><a href="<?php echo BASE_URL; ?>/home" class="footer-link small">Home</a></li>
                                <li><a href="<?php echo BASE_URL; ?>/shop" class="footer-link small">Shop</a></li>
                                <li><a href="<?php echo BASE_URL; ?>/blog" class="footer-link small">Blog</a></li>
                            <?php else: ?>
                                <?php foreach ($footer_links as $link): ?>
                                    <li><a href="<?php echo BASE_URL; ?>/<?php echo htmlspecialchars($link['url']); ?>" class="footer-link small"><?php echo htmlspecialchars($link['title']); ?></a></li>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="col-md-4 col-sm-6">
                <h5 class="fw-bold mb-3 text-uppercase"><?php echo htmlspecialchars($site_settings['footer_col3_title'] ?? 'Contact Reach'); ?></h5>
                <div class="footer-contact-item">
                    <div class="footer-contact-icon">
                        <i class="fas fa-phone-alt"></i>
                    </div>
                    <div class="footer-contact-text">
                        <?php echo htmlspecialchars($site_settings['support_phone'] ?? ''); ?>
                    </div>
                </div>
                <div class="footer-contact-item">
                    <div class="footer-contact-icon">
                        <i class="fas fa-envelope"></i>
                    </div>
                    <div class="footer-contact-text">
                        <?php echo htmlspecialchars($site_settings['support_email'] ?? ''); ?>
                    </div>
                </div>
                <div class="footer-contact-item">
                    <div class="footer-contact-icon">
                        <i class="fas fa-map-marker-alt"></i>
                    </div>
                    <div class="footer-contact-text">
                        <?php echo htmlspecialchars($site_settings['address'] ?? ''); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="kr-footer-bottom">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-md-6 text-md-start mb-2 mb-md-0">
                    <small><?php echo htmlspecialchars($site_settings['footer_copyright'] ?? '© ' . date('Y') . ' Khati Raj. All rights reserved.'); ?></small>
                    <div class="kr-footer-legal mt-1">
                        <a href="<?php echo BASE_URL; ?>/about" class="footer-link small">আমাদের সম্পর্কে</a>
                        <span class="text-muted mx-1">·</span>
                        <a href="<?php echo BASE_URL; ?>/privacy-policy" class="footer-link small">প্রাইভেসি</a>
                        <span class="text-muted mx-1">·</span>
                        <a href="<?php echo BASE_URL; ?>/terms-conditions" class="footer-link small">শর্তাবলী</a>
                        <span class="text-muted mx-1">·</span>
                        <a href="<?php echo BASE_URL; ?>/refund-policy" class="footer-link small">রিফান্ড</a>
                        <span class="text-muted mx-1">·</span>
                        <a href="<?php echo BASE_URL; ?>/shipping-policy" class="footer-link small">শিপিং</a>
                    </div>
                </div>
                <div class="col-md-6 text-md-end">
                    <small><a href="https://www.facebook.com/9alamin" target="_blank">Powered by Al Amin</a></small>
                </div>
            </div>
        </div>
    </div>
</footer>

<!-- ===== MOBILE APP-STYLE FOOTER (visible only on mobile/tablet) ===== -->
<footer class="kr-mobile-footer d-lg-none">
    <!-- Decorative glow blobs -->
    <div class="kr-mf-blob kr-mf-blob-1"></div>
    <div class="kr-mf-blob kr-mf-blob-2"></div>

    <div class="kr-mf-inner">

        <!-- Brand Row -->
        <div class="kr-mf-brand">
            <?php if (!empty($site_settings['site_logo'])): ?>
            <img src="<?php echo BASE_URL; ?>/<?php echo htmlspecialchars($site_settings['site_logo']); ?>" alt="<?php echo htmlspecialchars($site_settings['site_name'] ?? 'Khati Raj BD'); ?>" class="kr-mf-brand-logo">
            <?php else: ?>
            <div class="kr-mf-logo-fallback">
                <?php echo strtoupper(substr($site_settings['site_name'] ?? 'KR', 0, 2)); ?>
            </div>
            <?php endif; ?>
            <div class="kr-mf-brand-text">
                <span class="kr-mf-site-name"><?php echo htmlspecialchars($site_settings['site_name'] ?? 'Khati Raj BD'); ?></span>
                <span class="kr-mf-tagline">Authentic Products · Fast Delivery</span>
            </div>
        </div>

        <!-- Quick Navigation Grid -->
        <div class="kr-mf-links-wrap">
            <a href="<?php echo BASE_URL; ?>/" class="kr-mf-link">
                <span class="kr-mf-link-icon"><i class="fas fa-home"></i></span>
                <span>হোম</span>
            </a>
            <a href="<?php echo BASE_URL; ?>/shop" class="kr-mf-link">
                <span class="kr-mf-link-icon"><i class="fas fa-store"></i></span>
                <span>শপ</span>
            </a>
            <a href="<?php echo BASE_URL; ?>/cart" class="kr-mf-link">
                <span class="kr-mf-link-icon"><i class="fas fa-shopping-cart"></i></span>
                <span>কার্ট</span>
            </a>
            <a href="<?php echo BASE_URL; ?>/dashboard" class="kr-mf-link">
                <span class="kr-mf-link-icon"><i class="fas fa-user"></i></span>
                <span>প্রোফাইল</span>
            </a>
            <a href="<?php echo BASE_URL; ?>/blog" class="kr-mf-link">
                <span class="kr-mf-link-icon"><i class="fas fa-newspaper"></i></span>
                <span>ব্লগ</span>
            </a>
            <a href="<?php echo BASE_URL; ?>/track-order" class="kr-mf-link">
                <span class="kr-mf-link-icon"><i class="fas fa-truck"></i></span>
                <span>অর্ডার ট্র্যাক</span>
            </a>
        </div>

        <!-- Contact Cards -->
        <div class="kr-mf-contact-row">
            <?php if(!empty($site_settings['support_phone'])): ?>
            <a href="tel:<?php echo htmlspecialchars($site_settings['support_phone']); ?>" class="kr-mf-contact-chip">
                <div class="kr-mf-chip-icon">
                    <i class="fas fa-phone-alt"></i>
                </div>
                <div class="kr-mf-chip-body">
                    <span class="kr-mf-chip-label">ফোন করুন</span>
                    <span class="kr-mf-chip-value"><?php echo htmlspecialchars($site_settings['support_phone']); ?></span>
                </div>
                <i class="fas fa-chevron-right kr-mf-chip-arrow"></i>
            </a>
            <?php endif; ?>
            <?php if(!empty($site_settings['support_email'])): ?>
            <a href="mailto:<?php echo htmlspecialchars($site_settings['support_email']); ?>" class="kr-mf-contact-chip">
                <div class="kr-mf-chip-icon" style="background:rgba(59,130,246,0.15);color:#60a5fa;">
                    <i class="fas fa-envelope"></i>
                </div>
                <div class="kr-mf-chip-body">
                    <span class="kr-mf-chip-label">ইমেইল করুন</span>
                    <span class="kr-mf-chip-value"><?php echo htmlspecialchars($site_settings['support_email']); ?></span>
                </div>
                <i class="fas fa-chevron-right kr-mf-chip-arrow"></i>
            </a>
            <?php endif; ?>
            <?php if(!empty($site_settings['address'])): ?>
            <div class="kr-mf-contact-chip kr-mf-address-chip" style="cursor:default;">
                <div class="kr-mf-chip-icon" style="background:rgba(168,85,247,0.15);color:#c084fc;">
                    <i class="fas fa-map-marker-alt"></i>
                </div>
                <div class="kr-mf-chip-body">
                    <span class="kr-mf-chip-label">ঠিকানা</span>
                    <span class="kr-mf-chip-value"><?php echo nl2br(htmlspecialchars($site_settings['address'])); ?></span>
                </div>
            </div>
            <?php endif; ?>
        </div>

        <!-- Social Links -->
        <?php if(!empty($social_links)): ?>
        <div class="kr-mf-social">
            <?php foreach ($social_links as $slink): ?>
            <a href="<?php echo htmlspecialchars($slink['url']); ?>" class="kr-mf-social-btn" title="<?php echo htmlspecialchars($slink['platform_name']); ?>" target="_blank" rel="noopener">
                <i class="<?php echo htmlspecialchars($slink['icon_class']); ?>"></i>
            </a>
            <?php endforeach; ?>
        </div>
        <?php endif; ?>

        <!-- Divider -->
        <div class="kr-mf-divider"></div>

        <!-- Copyright -->
        <div class="kr-mf-copyright">
            <span class="kr-mf-copy-text"><?php echo htmlspecialchars($site_settings['footer_copyright'] ?? '&copy; ' . date('Y') . ' Khati Raj BD. All rights reserved.'); ?></span>
            <div class="kr-mf-legal mt-2" style="display:flex;flex-wrap:wrap;gap:6px 10px;justify-content:center;font-size:0.75rem;">
                <a href="<?php echo BASE_URL; ?>/about">আমাদের সম্পর্কে</a>
                <a href="<?php echo BASE_URL; ?>/privacy-policy">প্রাইভেসি</a>
                <a href="<?php echo BASE_URL; ?>/terms-conditions">শর্তাবলী</a>
                <a href="<?php echo BASE_URL; ?>/refund-policy">রিফান্ড</a>
                <a href="<?php echo BASE_URL; ?>/shipping-policy">শিপিং</a>
            </div>
            <span class="kr-mf-dev-credit">Developed by <a href="https://www.facebook.com/9alamin" target="_blank" rel="noopener">Al Amin</a></span>
        </div>

    </div>
</footer>
<!-- ===== END MOBILE FOOTER ===== -->

<button class="kr-back-to-top" id="kr-back-to-top" title="Back to Top">
    <i class="fas fa-arrow-up"></i>
</button>

<?php 
// Include WhatsApp Button
include 'views/components/whatsapp.php'; 

// Include Recent Sales Popup
include 'views/components/sales-popup.php'; 
?>

<?php 
// Global mobile sticky bar is managed directly by product-details.php or cart.php to avoid conflicts with the bottom navigation bar.
?>

<?php endif; ?>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js" defer></script>
<?php require_once __DIR__ . '/../../app/Helpers/AssetHelper.php'; ?>
<script>
window.KR_CART = {
    baseUrl: '<?php echo BASE_URL; ?>',
    checkoutUrl: '<?php echo BASE_URL; ?>/checkout',
    itemAdded: <?php echo json_encode(__('item_added')); ?>,
    itemAddedDesc: <?php echo json_encode(__('item_added_desc')); ?>,
    completeOrder: <?php echo json_encode(__('complete_order')); ?>,
    continueShopping: <?php echo json_encode(__('continue_shopping')); ?>
};
</script>
<script src="<?php echo AssetHelper::js('assets/js/cart-popup.js'); ?>" defer></script>
<script src="<?php echo AssetHelper::js('assets/js/app.js'); ?>" defer></script>
</body>
</html>
