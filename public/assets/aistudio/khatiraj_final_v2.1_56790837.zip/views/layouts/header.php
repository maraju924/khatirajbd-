<!DOCTYPE html>
<?php 
global $pdo, $site_settings, $social_links; 
$count = 0;
if (isset($_SESSION['cart'])) {
    foreach ($_SESSION['cart'] as $item) {
        $count += $item['qty'];
    }
}
require_once __DIR__ . '/../../app/Services/VisitorTracker.php';
VisitorTracker::track();
?>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars(SeoHelper::getMetaTitle()); ?></title>
    <?php if (isset($site_settings['site_favicon']) && !empty($site_settings['site_favicon'])): ?>
        <link rel="icon" type="image/png" href="<?php echo BASE_URL . '/' . $site_settings['site_favicon']; ?>">
    <?php else: ?>
        <link rel="icon" type="image/png" href="<?php echo BASE_URL; ?>/assets/images/icons/khatiraj logo.webp">
    <?php endif; ?>
    <meta name="description" content="<?php echo htmlspecialchars(SeoHelper::getMetaDescription()); ?>">
    <meta name="keywords" content="<?php echo htmlspecialchars(SeoHelper::getMetaKeywords()); ?>">

    <?php
// Dynamic SEO Metadata
$current_url = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
$canonical_url = SeoHelper::getCanonical();
?>
    <link rel="canonical" href="<?php echo htmlspecialchars($canonical_url); ?>">

    <!-- Open Graph / Facebook -->
    <meta property="og:type" content="<?php echo isset($product) ? 'product' : 'website'; ?>">
    <meta property="og:url" content="<?php echo $current_url; ?>">
    <meta property="og:title" content="<?php echo htmlspecialchars(SeoHelper::getMetaTitle()); ?>">
    <meta property="og:description" content="<?php echo htmlspecialchars(SeoHelper::getMetaDescription()); ?>">
    <meta property="og:image" content="<?php echo htmlspecialchars(SeoHelper::getOgImage()); ?>">
    
    <?php if (isset($product)): ?>
    <meta property="product:price:amount" content="<?php echo $product['offer_price'] ?: $product['price']; ?>">
    <meta property="product:price:currency" content="BDT">
    <?php endif; ?>

    <!-- Twitter -->
    <meta name="twitter:card" content="summary_large_image">
    <meta name="twitter:url" content="<?php echo $current_url; ?>">
    <meta name="twitter:title" content="<?php echo htmlspecialchars(SeoHelper::getMetaTitle()); ?>">
    <meta name="twitter:description" content="<?php echo htmlspecialchars(SeoHelper::getMetaDescription()); ?>">
    <meta name="twitter:image" content="<?php echo htmlspecialchars(SeoHelper::getOgImage()); ?>">

    <!-- PWA Meta Tags -->
    <meta name="theme-color" content="#15803d">
    <link rel="manifest" href="<?php echo BASE_URL; ?>/manifest.json">
    <link rel="apple-touch-icon" href="<?php echo BASE_URL; ?>/assets/images/icons/icon-192x192.png">
    <meta name="mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">

    <?php
    require_once __DIR__ . '/../../app/Helpers/RouteHelper.php';
    require_once __DIR__ . '/../../app/Helpers/AssetHelper.php';
    $kr_request_path = RouteHelper::getPath();
    $kr_main_css = AssetHelper::css('assets/css/style.css');
    ?>

    <link rel="dns-prefetch" href="https://cdn.jsdelivr.net">
    <link rel="dns-prefetch" href="https://cdnjs.cloudflare.com">
    <link rel="preconnect" href="https://cdn.jsdelivr.net" crossorigin>
    <link rel="preconnect" href="https://cdnjs.cloudflare.com" crossorigin>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link rel="preload" href="<?php echo $kr_main_css; ?>" as="style">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap" media="print" onload="this.media='all'">
    <noscript><link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap"></noscript>

    <script>const BASE_URL = '<?php echo BASE_URL; ?>';</script>

    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <!-- Master CSS Design System (bundled + minified) -->
    <link rel="stylesheet" href="<?php echo $kr_main_css; ?>">
    <!-- Custom Responsive CSS -->
    <link rel="stylesheet" href="<?php echo AssetHelper::css('assets/css/responsive.css'); ?>">
    <?php
    if (strpos($kr_request_path, '/product/') === 0) {
        echo '<link rel="stylesheet" href="' . AssetHelper::css('assets/css/pages/misc.css') . '">' . "\n";
    }
    if (in_array($kr_request_path, ['/cart', '/checkout'], true)) {
        echo '<link rel="stylesheet" href="' . AssetHelper::css('assets/css/pages/checkout.css') . '">' . "\n";
    }
    if ($kr_request_path === '/cart') {
        echo '<link rel="stylesheet" href="' . AssetHelper::css('assets/css/pages/cart.css') . '">' . "\n";
    }
    if (strpos($kr_request_path, '/blog') === 0) {
        echo '<link rel="stylesheet" href="' . AssetHelper::css('assets/css/pages/blog.css') . '">' . "\n";
    }
    if (in_array($kr_request_path, ['/login', '/register', '/dashboard', '/orders', '/forgot-password', '/reset-password'], true)) {
        echo '<link rel="stylesheet" href="' . AssetHelper::css('assets/css/pages/auth.css') . '">' . "\n";
    }
    if ($kr_request_path === '/dashboard') {
        echo '<link rel="stylesheet" href="' . AssetHelper::css('assets/css/pages/dashboard.css') . '">' . "\n";
    }
    ?>
    <script>window.SITE_URL = '<?php echo SITE_URL; ?>';</script>
    <script src="<?php echo SITE_URL; ?>/assets/js/analytics-beacon.js" defer></script>
    <?php include_once __DIR__ . '/../partials/tracking_pixels.php'; ?>
</head>
<body<?php echo (!empty($hide_header_footer)) ? ' class="lp-fullbleed"' : ''; ?>>
<?php if (!empty($tracking_settings['google_tag_manager_id'])): ?>
<!-- Google Tag Manager (noscript) -->
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=<?php echo htmlspecialchars($tracking_settings['google_tag_manager_id']); ?>"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<!-- End Google Tag Manager (noscript) -->
<?php endif; ?>

<?php if (!isset($hide_header_footer) || !$hide_header_footer): ?>
<nav class="navbar navbar-expand-lg kr-navbar">
  <div class="container">
    <a class="navbar-brand fw-bold" href="<?php echo BASE_URL; ?>/">
        <?php if (isset($site_settings['site_logo'])): ?>
            <img src="<?php echo BASE_URL; ?>/<?php echo $site_settings['site_logo']; ?>" alt="<?php echo htmlspecialchars($site_settings['site_name'] ?? 'Khati Raj'); ?>">
        <?php else: ?>
            <?php echo htmlspecialchars($site_settings['site_name'] ?? 'Khati Raj'); ?>
        <?php endif; ?>
    </a>

    <!-- Mobile Actions (Always Visible) -->
    <div class="d-flex align-items-center d-lg-none ms-auto me-2 gap-2">
        <a href="<?php echo BASE_URL; ?>/track-order" class="kr-nav-btn" title="<?php echo __('track_parcel'); ?>">
            <i class="fas fa-truck-fast"></i>
        </a>
    </div>

    <!-- Hamburger menu button for offcanvas (Mobile only) -->
    <button class="navbar-toggler kr-mmg-toggler border-0 d-lg-none" type="button" id="mobileMenuToggler" data-bs-toggle="offcanvas" data-bs-target="#mobileOffcanvasMenu" aria-controls="mobileOffcanvasMenu" aria-label="Menu">
      <span class="kr-mmg-toggler-icon"><i class="fas fa-bars"></i></span>
    </button>

    <div class="collapse navbar-collapse" id="mainNav">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
        <?php
    require_once __DIR__ . '/../../app/Helpers/MenuHelper.php';
    $menuTree = MenuHelper::getHeaderTree($pdo);
    $main_menus = $menuTree['main'];
    $submenus_by_parent = $menuTree['subs'];

    foreach ($main_menus as $mmenu):
        $sub_menus = $submenus_by_parent[(int) $mmenu['id']] ?? [];

        if (count($sub_menus) > 0):
?>
            <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle" href="<?php echo htmlspecialchars($mmenu['url']); ?>" id="navbarDropdown<?php echo $mmenu['id']; ?>" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                    <?php echo htmlspecialchars($mmenu['title']); ?>
                </a>
                <ul class="dropdown-menu" aria-labelledby="navbarDropdown<?php echo $mmenu['id']; ?>">
                    <?php foreach ($sub_menus as $smenu): ?>
                        <li><a class="dropdown-item" href="<?php echo htmlspecialchars($smenu['url']); ?>"><?php echo htmlspecialchars($smenu['title']); ?></a></li>
                    <?php endforeach; ?>
                </ul>
            </li>
        <?php else: ?>
            <li class="nav-item">
                <a class="nav-link" href="<?php echo htmlspecialchars($mmenu['url']); ?>"><?php echo htmlspecialchars($mmenu['title']); ?></a>
            </li>
        <?php endif; ?>
    <?php endforeach; ?>
      </ul>
      
      <div class="kr-search-form d-none d-lg-block mx-lg-4">
        <form action="<?php echo BASE_URL; ?>/shop" method="GET">
          <span class="search-icon"><i class="fas fa-search"></i></span>
          <input id="frontend-search-input" name="q" class="form-control" type="search" placeholder="<?php echo __('search_placeholder'); ?>" autocomplete="off">
          <button class="search-btn" type="submit"><i class="fas fa-arrow-right"></i></button>
        </form>
        <div id="search-results-container"></div>
      </div>

      <div class="kr-nav-actions">
        <!-- Language Switcher (Desktop) -->
        <div class="dropdown d-none d-lg-block">
            <button class="kr-lang-btn dropdown-toggle" type="button" data-bs-toggle="dropdown">
                <i class="fas fa-globe me-1"></i> <?php echo LanguageHelper::getCurrentLang() === 'bn' ? 'বাংলা' : 'English'; ?>
            </button>
            <ul class="dropdown-menu dropdown-menu-end">
                <li><a class="dropdown-item" href="?lang=bn">বাংলা</a></li>
                <li><a class="dropdown-item" href="?lang=en">English</a></li>
            </ul>
        </div>

        <!-- Track Parcel (Desktop) -->
        <a href="<?php echo BASE_URL; ?>/track-order" class="kr-nav-btn d-none d-lg-inline-flex" title="<?php echo __('track_parcel'); ?>">
            <i class="fas fa-truck-fast"></i>
        </a>

        <!-- Cart (Desktop) -->
        <a href="<?php echo BASE_URL; ?>/cart" class="kr-nav-btn d-none d-lg-inline-flex position-relative" title="Cart">
            <i class="fas fa-shopping-cart"></i> 
            <span class="badge rounded-pill cart-count-global">
                <?php echo $count; ?>
            </span>
        </a>

        <!-- Profile/Login (All Devices) -->
        <?php if (isset($_SESSION['user_logged_in'])): ?>
            <div class="dropdown kr-user-dropdown ms-2">
                <button class="btn dropdown-toggle w-100" type="button" data-bs-toggle="dropdown">
                    <i class="fas fa-user-circle"></i> <span class="d-none d-sm-inline"><?php echo htmlspecialchars($_SESSION['user_name']); ?></span>
                </button>
                <ul class="dropdown-menu dropdown-menu-end">
                    <li class="d-lg-none"><a class="dropdown-item" href="?lang=bn">বাংলা</a></li>
                    <li class="d-lg-none"><a class="dropdown-item" href="?lang=en">English</a></li>
                    <li class="d-lg-none"><hr class="dropdown-divider"></li>
                    <li><a class="dropdown-item" href="<?php echo BASE_URL; ?>/dashboard"><?php echo __('my_profile'); ?></a></li>
                    <li><a class="dropdown-item" href="<?php echo BASE_URL; ?>/orders"><?php echo __('my_orders'); ?></a></li>
                    <li><hr class="dropdown-divider"></li>
                    <li><a class="dropdown-item" href="<?php echo BASE_URL; ?>/logout-action"><?php echo __('logout'); ?></a></li>
                </ul>
            </div>
        <?php else: ?>
            <a href="<?php echo BASE_URL; ?>/login" class="kr-login-btn ms-2"><?php echo __('login'); ?></a>
        <?php endif; ?>
      </div>
    </div>
  </div>
</nav>

<!-- Mobile Search Bar (Expandable) -->
<div id="mobile-search-bar" class="bg-white border-bottom p-2 d-lg-none" style="display: none;">
    <div class="container">
        <form class="d-flex" action="<?php echo BASE_URL; ?>/shop" method="GET">
            <input id="mobile-search-input" name="q" class="form-control me-2" type="search" placeholder="<?php echo __('search_placeholder'); ?>" autocomplete="off">
            <button class="btn btn-primary" type="submit"><i class="fas fa-search"></i></button>
        </form>
        <div id="mobile-search-results" class="position-absolute bg-white shadow-sm rounded-bottom w-100 start-0" style="z-index: 1060; max-height: 300px; overflow-y: auto;"></div>
    </div>
</div>
<?php
endif; ?>

<script>
function toggleMobileSearch() {
    const searchBar = document.getElementById('mobile-search-bar');
    const input = document.getElementById('mobile-search-input');
    if (searchBar.style.display === 'none' || searchBar.style.display === '') {
        searchBar.style.display = 'block';
        input.focus();
    } else {
        searchBar.style.display = 'none';
    }
}

// Consolidated Live Search Logic
document.addEventListener('DOMContentLoaded', function() {
    function handleLiveSearch(inputEl, resultsEl) {
        let timeout = null;
        inputEl.addEventListener('input', function() {
            const query = this.value.trim();
            clearTimeout(timeout);
            
            if (query.length < 2) {
                resultsEl.innerHTML = '';
                resultsEl.classList.remove('active');
                return;
            }

            timeout = setTimeout(() => {
                fetch(`<?php echo BASE_URL; ?>/api/search?q=${encodeURIComponent(query)}`)
                    .then(res => res.json())
                    .then(data => {
                        resultsEl.innerHTML = '';
                        if (data && data.length > 0) {
                            data.forEach(item => {
                                const a = document.createElement('a');
                                a.href = item.link;
                                a.className = 'search-item';
                                a.innerHTML = `
                                    <img src="<?php echo BASE_URL; ?>/${item.image}" alt="${item.title}" onerror="this.src='https://placehold.co/50x50?text=No+Image'">
                                    <div class="item-info">
                                        <div class="item-title">${item.title}</div>
                                        <div class="item-subtitle">${item.subtitle}</div>
                                    </div>
                                    <div class="item-type small text-muted">${item.type}</div>
                                `;
                                resultsEl.appendChild(a);
                            });
                            resultsEl.classList.add('active');
                        } else {
                            resultsEl.innerHTML = '<div class="p-3 text-center text-muted small">No products found</div>';
                            resultsEl.classList.add('active');
                        }
                    })
                    .catch(err => console.error('Search error:', err));
            }, 300);
        });

        // Close results when clicking outside
        document.addEventListener('click', function(e) {
            if (!inputEl.contains(e.target) && !resultsEl.contains(e.target)) {
                resultsEl.classList.remove('active');
            }
        });
    }

    // Init Desktop Search
    const dtInput = document.getElementById('frontend-search-input');
    const dtResults = document.getElementById('search-results-container');
    if (dtInput && dtResults) handleLiveSearch(dtInput, dtResults);

    // Init Mobile Search
    const mbInput = document.getElementById('mobile-search-input');
    const mbResults = document.getElementById('mobile-search-results');
    if (mbInput && mbResults) handleLiveSearch(mbInput, mbResults);

    // Init Mobile Search Overlay
    const overlayInput = document.getElementById('kr-mobile-search-overlay-input');
    const overlayResults = document.getElementById('kr-mobile-search-overlay-results');
    if (overlayInput && overlayResults) handleLiveSearch(overlayInput, overlayResults);

    // Global Cart Badge Utility
    window.updateCartBadge = function(newCount) {
        document.querySelectorAll('.cart-count-global').forEach(el => {
            el.innerText = newCount;
        });
    };

    // Global Toast Utility
    window.showToast = function(title, message, type = 'success') {
        let container = document.querySelector('.kr-toast-container');
        if (!container) {
            container = document.createElement('div');
            container.className = 'kr-toast-container';
            document.body.appendChild(container);
        }
        
        const toast = document.createElement('div');
        toast.className = `kr-toast ${type}`;
        
        let iconHtml = '<i class="fas fa-check"></i>';
        if (type === 'error') iconHtml = '<i class="fas fa-exclamation-triangle"></i>';
        if (type === 'warning') iconHtml = '<i class="fas fa-exclamation-circle"></i>';
        
        toast.innerHTML = `
            <div class="toast-icon">${iconHtml}</div>
            <div class="toast-body">
                <div class="toast-title">${title}</div>
                <div class="toast-message">${message}</div>
            </div>
            <button class="toast-close" onclick="this.parentElement.remove()">&times;</button>
            <div class="toast-progress"></div>
        `;
        
        container.appendChild(toast);
        
        setTimeout(() => {
            toast.remove();
        }, 3000);
    };
});

// Mobile search overlay triggers
function openMobileSearchOverlay() {
    const overlay = document.getElementById('kr-mobile-search-overlay');
    const input = document.getElementById('kr-mobile-search-overlay-input');
    if (overlay) {
        overlay.style.display = 'flex';
        document.body.style.overflow = 'hidden'; // prevent scroll behind
        if (input) {
            setTimeout(() => input.focus(), 100);
        }
    }
}
function closeMobileSearchOverlay() {
    const overlay = document.getElementById('kr-mobile-search-overlay');
    if (overlay) {
        overlay.style.display = 'none';
        document.body.style.overflow = '';
    }
}
</script>

<?php if (!isset($hide_header_footer) || !$hide_header_footer): ?>
<?php
// Active tab calculations
$req_uri = $_SERVER['REQUEST_URI'];
$is_home = (strpos($req_uri, '/home') !== false || $req_uri == '/' || substr($req_uri, -1) == '/' || strpos($req_uri, 'index.php') !== false) && strpos($req_uri, '/shop') === false && strpos($req_uri, '/cart') === false && strpos($req_uri, '/dashboard') === false && strpos($req_uri, '/login') === false;
$is_shop = strpos($req_uri, '/shop') !== false;
$is_cart = strpos($req_uri, '/cart') !== false;
$is_profile = strpos($req_uri, '/dashboard') !== false || strpos($req_uri, '/login') !== false || strpos($req_uri, '/register') !== false || strpos($req_uri, '/orders') !== false;
?>

<!-- Mobile Sticky Bottom Navigation (Android style) -->
<div class="kr-app-bottom-nav d-flex d-lg-none">
    <a href="<?php echo BASE_URL; ?>/" class="kr-bottom-nav-item <?php echo $is_home ? 'active' : ''; ?>">
        <i class="fas fa-home"></i>
        <span>হোম</span>
    </a>
    <a href="<?php echo BASE_URL; ?>/shop" class="kr-bottom-nav-item <?php echo $is_shop ? 'active' : ''; ?>">
        <i class="fas fa-shopping-bag"></i>
        <span>শপ</span>
    </a>
    <button class="kr-bottom-nav-item" onclick="openMobileSearchOverlay()">
        <i class="fas fa-search"></i>
        <span>সার্চ</span>
    </button>
    <a href="<?php echo BASE_URL; ?>/cart" class="kr-bottom-nav-item position-relative <?php echo $is_cart ? 'active' : ''; ?>">
        <i class="fas fa-shopping-cart"></i>
        <span class="badge rounded-pill cart-count-global"><?php echo $count; ?></span>
        <span>কার্ট</span>
    </a>
    <a href="<?php echo BASE_URL; ?>/dashboard" class="kr-bottom-nav-item <?php echo $is_profile ? 'active' : ''; ?>">
        <i class="fas fa-user"></i>
        <span>প্রোফাইল</span>
    </a>
</div>

<!-- Mobile Fullscreen Search Overlay -->
<div id="kr-mobile-search-overlay" class="kr-search-overlay">
    <div class="kr-search-overlay-header">
        <button class="kr-search-overlay-close" onclick="closeMobileSearchOverlay()">
            <i class="fas fa-arrow-left"></i>
        </button>
        <div class="kr-search-overlay-form">
            <form action="<?php echo BASE_URL; ?>/shop" method="GET">
                <span class="search-icon"><i class="fas fa-search"></i></span>
                <input id="kr-mobile-search-overlay-input" name="q" type="search" placeholder="<?php echo __('search_placeholder'); ?>" autocomplete="off">
            </form>
        </div>
    </div>
    <div class="kr-search-overlay-body">
        <div id="kr-mobile-search-overlay-results" class="search-results-overlay-list"></div>
    </div>
</div>

<style>
/* Style search overlay items similarly to global search results list */
.search-results-overlay-list {
    display: flex;
    flex-direction: column;
    gap: 8px;
}
.search-results-overlay-list .search-item {
    display: flex;
    align-items: center;
    gap: 12px;
    padding: 10px;
    background: var(--kr-surface);
    border: 1px solid var(--kr-border-light);
    border-radius: var(--kr-radius-md);
    text-decoration: none;
    color: var(--kr-dark);
    transition: var(--kr-transition-fast);
}
.search-results-overlay-list .search-item:hover {
    background: var(--kr-primary-surface);
    border-color: var(--kr-primary);
}
.search-results-overlay-list .search-item img {
    width: 48px;
    height: 48px;
    object-fit: cover;
    border-radius: var(--kr-radius-sm);
    background: white;
}
.search-results-overlay-list .search-item .item-info {
    flex-grow: 1;
}
.search-results-overlay-list .search-item .item-title {
    font-weight: 600;
    font-size: 0.88rem;
    line-height: 1.3;
    color: var(--kr-dark);
}
.search-results-overlay-list .search-item .item-subtitle {
    font-size: 0.78rem;
    color: var(--kr-text-secondary);
}
.search-results-overlay-list .search-item .item-type {
    font-size: 0.7rem;
    padding: 2px 6px;
    background: var(--kr-surface-alt);
    border-radius: var(--kr-radius-sm);
}
</style>

<!-- Mobile Drawer / Offcanvas Menu — 3D Liquid Glass -->
<?php
$kr_mmg_icon_themes = ['green-theme', 'blue-theme', 'green-theme', 'blue-theme'];
$kr_mmg_icon_map = [
    'home' => 'fa-home',
    'shop' => 'fa-shopping-bag',
    'about' => 'fa-info-circle',
    'contact' => 'fa-envelope',
    'blog' => 'fa-newspaper',
    'category' => 'fa-th-large',
    'cart' => 'fa-shopping-cart',
    'track' => 'fa-truck-fast',
    'login' => 'fa-sign-in-alt',
    'register' => 'fa-user-plus',
];
$kr_mmg_resolve_icon = function ($title, $url) use ($kr_mmg_icon_map) {
    $haystack = strtolower($title . ' ' . $url);
    foreach ($kr_mmg_icon_map as $keyword => $icon) {
        if (strpos($haystack, $keyword) !== false) {
            return $icon;
        }
    }
    return 'fa-circle-dot';
};
?>
<div class="offcanvas offcanvas-start kr-mobile-glass-menu" tabindex="-1" id="mobileOffcanvasMenu" aria-labelledby="mobileOffcanvasMenuLabel">
  <div class="kr-mmg-blob kr-mmg-blob-1" aria-hidden="true"></div>
  <div class="kr-mmg-blob kr-mmg-blob-2" aria-hidden="true"></div>
  <div class="kr-mmg-blob kr-mmg-blob-3" aria-hidden="true"></div>

  <div class="offcanvas-header kr-mmg-header">
    <div class="kr-mmg-brand-wrap">
      <?php if (!empty($site_settings['site_logo'])): ?>
        <img src="<?php echo BASE_URL; ?>/<?php echo $site_settings['site_logo']; ?>" alt="<?php echo htmlspecialchars($site_settings['site_name'] ?? 'Khati Raj'); ?>" class="kr-mmg-brand-logo">
      <?php endif; ?>
      <h5 class="offcanvas-title kr-mmg-brand-title" id="mobileOffcanvasMenuLabel">
        <?php echo htmlspecialchars($site_settings['site_name'] ?? 'Khati Raj'); ?>
      </h5>
    </div>
    <button type="button" class="kr-mmg-close-btn" data-bs-dismiss="offcanvas" aria-label="Close">
      <i class="fas fa-times"></i>
    </button>
  </div>

  <div class="offcanvas-body kr-mmg-body">
    <nav class="kr-mmg-nav-list" aria-label="Mobile navigation">
        <?php
        $mmg_index = 0;
        foreach ($main_menus as $mmenu):
            $sub_menus = $submenus_by_parent[(int) $mmenu['id']] ?? [];
            $menu_icon = $kr_mmg_resolve_icon($mmenu['title'], $mmenu['url']);
            $menu_theme = $kr_mmg_icon_themes[$mmg_index % count($kr_mmg_icon_themes)];
            $mmg_index++;

            if (count($sub_menus) > 0):
        ?>
                <div class="kr-mmg-item-wrap">
                    <a class="kr-mmg-item" data-bs-toggle="collapse" href="#subnav-<?php echo $mmenu['id']; ?>" role="button" aria-expanded="false" aria-controls="subnav-<?php echo $mmenu['id']; ?>">
                        <span class="kr-item-icon-bubble <?php echo $menu_theme; ?>">
                            <i class="fas <?php echo $menu_icon; ?>"></i>
                        </span>
                        <span class="kr-mmg-item-text"><?php echo htmlspecialchars($mmenu['title']); ?></span>
                        <span class="kr-mmg-chevron"><i class="fas fa-chevron-down"></i></span>
                    </a>
                    <div class="collapse kr-mmg-subnav" id="subnav-<?php echo $mmenu['id']; ?>">
                        <?php foreach ($sub_menus as $smenu): ?>
                            <a href="<?php echo htmlspecialchars($smenu['url']); ?>" class="kr-mmg-subitem">
                                <i class="fas fa-angle-right"></i>
                                <?php echo htmlspecialchars($smenu['title']); ?>
                            </a>
                        <?php endforeach; ?>
                    </div>
                </div>
        <?php else: ?>
                <a href="<?php echo htmlspecialchars($mmenu['url']); ?>" class="kr-mmg-item">
                    <span class="kr-item-icon-bubble <?php echo $menu_theme; ?>">
                        <i class="fas <?php echo $menu_icon; ?>"></i>
                    </span>
                    <span class="kr-mmg-item-text"><?php echo htmlspecialchars($mmenu['title']); ?></span>
                    <span class="kr-mmg-arrow"><i class="fas fa-arrow-right"></i></span>
                </a>
        <?php endif; ?>
        <?php endforeach; ?>
    </nav>

    <div class="kr-mmg-section-label">দ্রুত অ্যাক্সেস</div>
    <div class="kr-mmg-quick-grid">
        <a href="<?php echo BASE_URL; ?>/track-order" class="kr-mmg-quick-item">
            <span class="kr-item-icon-bubble blue-theme"><i class="fas fa-truck-fast"></i></span>
            <span><?php echo __('track_parcel'); ?></span>
        </a>
        <a href="<?php echo BASE_URL; ?>/cart" class="kr-mmg-quick-item">
            <span class="kr-item-icon-bubble green-theme"><i class="fas fa-shopping-cart"></i></span>
            <span>কার্ট</span>
        </a>
    </div>

    <?php if (!empty($site_settings['support_phone']) || !empty($site_settings['support_email'])): ?>
    <div class="kr-mmg-contact-glass">
        <div class="kr-mmg-contact-header">
            <i class="fas fa-headset"></i>
            <span>যোগাযোগ ও সহায়তা</span>
        </div>
        <?php if (!empty($site_settings['support_phone'])): ?>
            <a href="tel:<?php echo preg_replace('/\s+/', '', $site_settings['support_phone']); ?>" class="kr-mmg-contact-row">
                <span class="kr-item-icon-bubble green-theme"><i class="fas fa-phone-alt"></i></span>
                <?php echo htmlspecialchars($site_settings['support_phone']); ?>
            </a>
        <?php endif; ?>
        <?php if (!empty($site_settings['support_email'])): ?>
            <a href="mailto:<?php echo htmlspecialchars($site_settings['support_email']); ?>" class="kr-mmg-contact-row">
                <span class="kr-item-icon-bubble blue-theme"><i class="fas fa-envelope"></i></span>
                <?php echo htmlspecialchars($site_settings['support_email']); ?>
            </a>
        <?php endif; ?>
    </div>
    <?php endif; ?>
  </div>
</div>

<script>
// Fallback: If Bootstrap offcanvas data-api doesn't trigger, use JS API
document.addEventListener('DOMContentLoaded', function() {
    var toggler = document.getElementById('mobileMenuToggler');
    var offcanvasEl = document.getElementById('mobileOffcanvasMenu');
    if (toggler && offcanvasEl) {
        toggler.addEventListener('click', function(e) {
            // Only if Bootstrap hasn't already opened it
            if (!offcanvasEl.classList.contains('show') && !offcanvasEl.classList.contains('showing')) {
                try {
                    var bsOffcanvas = bootstrap.Offcanvas.getOrCreateInstance(offcanvasEl);
                    bsOffcanvas.toggle();
                } catch(err) {
                    console.warn('Offcanvas fallback error:', err);
                }
            }
        });
    }
});
</script>

<?php endif; ?>

<?php if (!empty($hide_header_footer)): ?>
<div class="lp-page-shell">
<style>
/* Landing/full-bleed pages: kill Bootstrap container gutters + fixed-nav body padding */
body.lp-fullbleed {
    padding-top: 0 !important;
    padding-bottom: 0 !important;
    margin: 0 !important;
}
body.lp-fullbleed .lp-page-shell {
    width: 100%;
    max-width: 100%;
    margin: 0;
    padding: 0;
}
body.lp-fullbleed .container,
body.lp-fullbleed .container-sm,
body.lp-fullbleed .container-md,
body.lp-fullbleed .container-lg,
body.lp-fullbleed .container-xl,
body.lp-fullbleed .container-xxl,
body.lp-fullbleed .container-fluid {
    --bs-gutter-x: 0 !important;
    max-width: 100% !important;
    width: 100% !important;
    padding-left: 0 !important;
    padding-right: 0 !important;
    margin-left: 0 !important;
    margin-right: 0 !important;
}
body.lp-fullbleed .kr-app-bottom-nav,
body.lp-fullbleed .kr-mobile-footer,
body.lp-fullbleed .kr-mobile-glass-menu,
body.lp-fullbleed #kr-mobile-search-overlay {
    display: none !important;
}
</style>
<?php else: ?>
<div class="container mt-4">
<?php endif; ?>