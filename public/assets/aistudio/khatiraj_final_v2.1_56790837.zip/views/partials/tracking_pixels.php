<?php
// views/partials/tracking_pixels.php
// Dynamically injects Meta Pixel & TikTok Pixel with Advanced Matching and test modes.

global $pdo;

require_once __DIR__ . '/../../app/Helpers/CacheHelper.php';

// Simple helper to safely output js strings
if (!function_exists('esc_js')) {
    function esc_js($string) {
        return htmlspecialchars($string, ENT_QUOTES, 'UTF-8');
    }
}

$tracking_settings = CacheHelper::remember('tracking_settings', 900, static function () use ($pdo) {
    try {
        $stmt = $pdo->query("SELECT * FROM tracking_settings WHERE id = 1");
        return $stmt->fetch(PDO::FETCH_ASSOC) ?: null;
    } catch (PDOException $e) {
        return null;
    }
});

if (!$tracking_settings) {
    return; // Silently skip if tracking is not configured
}

$meta_pixel_id = $tracking_settings['meta_pixel_id'] ?? '';
$tiktok_pixel_id = $tracking_settings['tiktok_pixel_id'] ?? '';
$google_verification_code = $tracking_settings['google_verification_code'] ?? '';
$google_analytics_id = $tracking_settings['google_analytics_id'] ?? '';
$google_tag_manager_id = $tracking_settings['google_tag_manager_id'] ?? '';
$enable_advanced_matching = (bool)($tracking_settings['enable_advanced_matching'] ?? false);
$is_test_mode = (bool)($tracking_settings['is_test_mode'] ?? false);
$meta_test_event_code = $tracking_settings['meta_test_event_code'] ?? '';

// Check if we have at least one tracking/verification method configured
if (empty($meta_pixel_id) && empty($tiktok_pixel_id) && empty($google_verification_code) && empty($google_analytics_id) && empty($google_tag_manager_id)) {
    return;
}

// Generate base user matching data if logged in
$meta_init_data = [];
$tiktok_user_data = [];

// Shared PageView event ID — used by the browser pixel AND the server relay
// so Meta deduplicates the two into a single event.
$pv_event_id = 'pv_' . bin2hex(random_bytes(8));

if ($enable_advanced_matching) {
    require_once __DIR__ . '/../../config/tracking_encryption.php';

    if (!empty($_SESSION['user_email'])) {
        $hashed_email = TrackingEncryption::hashPII($_SESSION['user_email']);
        $meta_init_data['em'] = $hashed_email;
        $tiktok_user_data['email'] = $hashed_email;
    }
    if (!empty($_SESSION['user_phone'])) {
        $normalized_phone = TrackingEncryption::normalizePhone($_SESSION['user_phone']);
        $hashed_phone = TrackingEncryption::hashPII($normalized_phone);
        $meta_init_data['ph'] = $hashed_phone;
        $tiktok_user_data['phone_number'] = $hashed_phone;
    }
    if (!empty($_SESSION['user_name'])) {
        $hashed_name = TrackingEncryption::hashPII($_SESSION['user_name']);
        $meta_init_data['fn'] = $hashed_name;
    }
}
?>

<!-- ========================================== -->
<!--           TRACKING SYSTEM START            -->
<!-- ========================================== -->

<!-- Google Search Console Verification -->
<?php if (!empty($google_verification_code)): ?>
<meta name="google-site-verification" content="<?php echo esc_js($google_verification_code); ?>" />
<?php endif; ?>

<!-- Google Tag Manager -->
<?php if (!empty($google_tag_manager_id)): ?>
<script>
document.addEventListener('DOMContentLoaded', function() {
(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','<?php echo esc_js($google_tag_manager_id); ?>');
});
</script>
<?php endif; ?>

<!-- Google Analytics (gtag.js) -->
<?php if (!empty($google_analytics_id)): ?>
<script>
document.addEventListener('DOMContentLoaded', function() {
  var gaScript = document.createElement('script');
  gaScript.async = true;
  gaScript.src = 'https://www.googletagmanager.com/gtag/js?id=<?php echo esc_js($google_analytics_id); ?>';
  document.head.appendChild(gaScript);
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  window.gtag = gtag;
  gtag('js', new Date());
  gtag('config', '<?php echo esc_js($google_analytics_id); ?>');
});
</script>
<?php endif; ?>

<!-- Meta Pixel Code -->
<?php if (!empty($meta_pixel_id)): ?>
<script>
document.addEventListener('DOMContentLoaded', function() {
!function(f,b,e,v,n,t,s)
{if(f.fbq)return;n=f.fbq=function(){n.callMethod?
n.callMethod.apply(n,arguments):n.queue.push(arguments)};
if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
n.queue=[];t=b.createElement(e);t.async=!0;
t.src=v;s=b.getElementsByTagName(e)[0];
s.parentNode.insertBefore(t,s)}(window, document,'script',
'https://connect.facebook.net/en_US/fbevents.js');

fbq('init', '<?php echo esc_js($meta_pixel_id); ?>', <?php echo json_encode($meta_init_data, JSON_UNESCAPED_SLASHES); ?>);
fbq('track', 'PageView', {}, {eventID: '<?php echo esc_js($pv_event_id); ?>'<?php echo ($is_test_mode && !empty($meta_test_event_code)) ? ", test_event_code: '" . esc_js($meta_test_event_code) . "'" : ""; ?>});
});
</script>
<noscript>
  <img height="1" width="1" style="display:none" src="https://www.facebook.com/tr?id=<?php echo urlencode($meta_pixel_id); ?>&ev=PageView&noscript=1<?php echo ($is_test_mode && !empty($meta_test_event_code)) ? "&test_event_code=" . urlencode($meta_test_event_code) : ""; ?>"/>
</noscript>
<?php endif; ?>
<!-- End Meta Pixel Code -->

<!-- TikTok Pixel Code Start -->
<?php if (!empty($tiktok_pixel_id)): ?>
<script>
document.addEventListener('DOMContentLoaded', function() {
!function (w, d, t) {
  w.TiktokAnalyticsObject=t;var ttq=w[t]=w[t]||[];ttq.methods=["page","track","identify","instances","debug","on","off","once","ready","alias","group","enableCookie","disableCookie","holdConsent","revokeConsent","grantConsent"],ttq.setAndDefer=function(t,e){t[e]=function(){t.push([e].concat(Array.prototype.slice.call(arguments,0)))}};for(var i=0;i<ttq.methods.length;i++)ttq.setAndDefer(ttq,ttq.methods[i]);ttq.instance=function(t){for(var e=ttq._i[t]||[],n=0;n<ttq.methods.length;n++)ttq.setAndDefer(e,ttq.methods[n]);return e};ttq.load=function(e,n){var r="https://analytics.tiktok.com/i18n/pixel/events.js",o=n&&n.mixpool;w[t]._i=w[t]._i||{},w[t]._i[e]=[],w[t]._i[e]._u=r,w[t]._t=w[t]._t||{},w[t]._t[e]=+new Date,w[t]._o=w[t]._o||{},w[t]._o[e]=n||{};var a=d.createElement("script");a.type="text/javascript",a.async=!0,a.src=r+"?sdkid="+e+"&lib="+t;var c=d.getElementsByTagName("script")[0];c.parentNode.insertBefore(a,c)};

  ttq.load('<?php echo esc_js($tiktok_pixel_id); ?>');
  <?php if (!empty($tiktok_user_data)): ?>
  ttq.identify(<?php echo json_encode($tiktok_user_data, JSON_UNESCAPED_SLASHES); ?>);
  <?php endif; ?>
  ttq.page();
}(window, document, 'ttq');
});
</script>
<?php endif; ?>
<!-- TikTok Pixel Code End -->

<!-- Unified Browser Tracking Facade -->
<script>
window.AppTracking = {
    metaPixelId: <?php echo json_encode($meta_pixel_id); ?>,
    tiktokPixelId: <?php echo json_encode($tiktok_pixel_id); ?>,
    enableAdvancedMatching: <?php echo json_encode($enable_advanced_matching); ?>,
    isTestMode: <?php echo json_encode($is_test_mode); ?>,
    metaTestEventCode: <?php echo json_encode($meta_test_event_code); ?>,
    trackEndpoint: <?php echo json_encode(BASE_URL . '/api/track'); ?>,
    pageViewEventId: <?php echo json_encode($pv_event_id); ?>,
    
    // Relay the event to the server so it is also sent via Conversions API
    // with the same event_id (Meta/TikTok deduplicate browser + server).
    relayToServer(eventName, customData = {}, eventId = null) {
        // Purchase & CompleteRegistration are already fired server-side directly
        if (eventName === 'Purchase' || eventName === 'CompleteRegistration') return;
        try {
            const payload = JSON.stringify({
                event: eventName,
                event_id: eventId,
                custom_data: customData,
                url: window.location.href
            });
            if (navigator.sendBeacon) {
                navigator.sendBeacon(this.trackEndpoint, new Blob([payload], { type: 'application/json' }));
            } else {
                fetch(this.trackEndpoint, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: payload,
                    keepalive: true
                }).catch(function() {});
            }
        } catch (e) {
            // Tracking must never break the page
        }
    },
    
    // Web Crypto API SHA-256 for browser-side hashing
    async sha256(message) {
        if (!message) return '';
        try {
            const msgBuffer = new TextEncoder().encode(message.trim().toLowerCase());
            const hashBuffer = await crypto.subtle.digest('SHA-256', msgBuffer);
            const hashArray = Array.from(new Uint8Array(hashBuffer));
            return hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
        } catch (e) {
            console.error('[Tracking] SHA-256 hashing failed:', e);
            return '';
        }
    },
    
    // Normalize phone numbers to include 880 prefix
    normalizePhone(phone) {
        if (!phone) return '';
        let cleaned = phone.replace(/[^0-9]/g, '');
        if (cleaned.startsWith('0')) {
            cleaned = '880' + cleaned.substring(1);
        } else if (!cleaned.startsWith('880') && cleaned.length > 0) {
            cleaned = '880' + cleaned;
        }
        return cleaned;
    },
    
    // Hashing guest checkout values & identifying them
    async identifyGuest(email, phone) {
        if (!this.enableAdvancedMatching) return;
        
        let emHashed = '';
        let phHashed = '';
        
        if (email) {
            emHashed = await this.sha256(email);
        }
        if (phone) {
            const normalized = this.normalizePhone(phone);
            phHashed = await this.sha256(normalized);
        }
        
        const matchingData = {};
        if (emHashed) matchingData.em = emHashed;
        if (phHashed) matchingData.ph = phHashed;
        
        if (Object.keys(matchingData).length > 0) {
            if (this.metaPixelId && window.fbq) {
                window.fbq('init', this.metaPixelId, matchingData);
            }
            if (this.tiktokPixelId && window.ttq) {
                const ttData = {};
                if (emHashed) ttData.email = emHashed;
                if (phHashed) ttData.phone_number = phHashed;
                window.ttq.identify(ttData);
            }
        }
    },
    
    // Unified track call for browser pixels
    track(eventName, customData = {}, eventId = null) {
        // Server-side CAPI relay (deduplicated via eventId)
        this.relayToServer(eventName, customData, eventId);
        
        // Track on Meta
        if (this.metaPixelId && window.fbq) {
            const options = eventId ? { eventID: eventId } : {};
            if (this.isTestMode && this.metaTestEventCode) {
                options.test_event_code = this.metaTestEventCode;
            }
            window.fbq('track', eventName, customData, options);
        }
        
        // Track on TikTok
        if (this.tiktokPixelId && window.ttq) {
            const ttEventName = this.mapToTikTokEvent(eventName);
            if (ttEventName) {
                const options = eventId ? { event_id: eventId } : {};
                
                // Construct properties matching TikTok specs
                const properties = {};
                if (customData.value !== undefined) properties.value = Number(customData.value);
                if (customData.currency !== undefined) properties.currency = customData.currency;
                
                if (customData.content_ids !== undefined) {
                    properties.contents = (Array.isArray(customData.content_ids) ? customData.content_ids : [customData.content_ids]).map(id => ({
                        content_id: String(id),
                        content_type: customData.content_type || 'product',
                        quantity: customData.quantity || 1
                    }));
                } else if (customData.content_id !== undefined) {
                    properties.contents = [{
                        content_id: String(customData.content_id),
                        content_type: customData.content_type || 'product',
                        quantity: customData.quantity || 1
                    }];
                }
                
                if (customData.search_string !== undefined) {
                    properties.query = customData.search_string;
                }
                
                window.ttq.track(ttEventName, properties, options);
            }
        }
    },
    
    // Map Meta to TikTok Event names
    mapToTikTokEvent(metaEventName) {
        const map = {
            'PageView': 'Pageview',
            'ViewContent': 'ViewContent',
            'Search': 'Search',
            'AddToCart': 'AddToCart',
            'AddToWishlist': null, // TikTok doesn't have wishlist event
            'InitiateCheckout': 'InitiateCheckout',
            'AddPaymentInfo': 'AddPaymentInfo',
            'Purchase': 'CompletePayment',
            'CompleteRegistration': 'CompleteRegistration'
        };
        return map[metaEventName] !== undefined ? map[metaEventName] : metaEventName;
    }
};

// Relay PageView to the server (same eventID as the browser pixel → deduplicated)
document.addEventListener('DOMContentLoaded', function() {
    if (window.AppTracking.metaPixelId || window.AppTracking.tiktokPixelId) {
        window.AppTracking.relayToServer('PageView', {}, window.AppTracking.pageViewEventId);
    }
});

// Auto-bind guest inputs for real-time advanced matching
document.addEventListener('DOMContentLoaded', function() {
    const emailInput = document.querySelector('input[name="email"], input[type="email"], #checkout-email');
    const phoneInput = document.querySelector('input[name="phone"], input[type="tel"], #checkout-phone');
    
    if (emailInput || phoneInput) {
        const handleGuestIdentify = () => {
            const emailVal = emailInput ? emailInput.value : '';
            const phoneVal = phoneInput ? phoneInput.value : '';
            window.AppTracking.identifyGuest(emailVal, phoneVal);
        };
        
        if (emailInput) {
            emailInput.addEventListener('blur', handleGuestIdentify);
            emailInput.addEventListener('change', handleGuestIdentify);
        }
        if (phoneInput) {
            phoneInput.addEventListener('blur', handleGuestIdentify);
            phoneInput.addEventListener('change', handleGuestIdentify);
        }
    }
});
</script>

<!-- ========================================== -->
<!--            TRACKING SYSTEM END             -->
<!-- ========================================== -->
