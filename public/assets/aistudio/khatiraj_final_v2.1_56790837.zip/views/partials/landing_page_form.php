<?php
/**
 * Partial: Landing Page Checkout Form — compact, mobile-first
 * Multi-product safe; designed for minimal scroll / one-screen checkout on phones.
 */
if (!class_exists('PriceHelper')) {
    require_once __DIR__ . '/../../app/Helpers/PriceHelper.php';
}
$product_price = PriceHelper::effectivePrice($landing_page['price'], $landing_page['offer_price'] ?? null);
$first_zone_charge = !empty($shipping_zones) ? $shipping_zones[0]['charge'] : 0;
$is_multi = isset($lp_products) && count($lp_products) > 1;
$is_digital = ($landing_page['product_type'] === 'digital');
$img_base = defined('SITE_URL') ? SITE_URL : BASE_URL;
?>

<section class="lp-checkout" id="order-section">
    <div class="lp-checkout-wrap">
        <div class="lp-checkout-head">
            <h2 class="lp-checkout-title"><i class="fas fa-bolt"></i> এখনই অর্ডার করুন</h2>
            <p class="lp-checkout-sub">মাত্র কয়েক সেকেন্ডে অর্ডার কনফার্ম করুন</p>
        </div>

        <form id="landingOrderForm" class="lp-checkout-card" action="<?php echo BASE_URL; ?>/lp/order-process" method="POST">
            <?php echo CsrfHelper::field(); ?>
            <?php if (!$is_multi): ?>
            <input type="hidden" name="product_id" value="<?php echo (int)$landing_page['product_id']; ?>">
            <?php endif; ?>
            <input type="hidden" name="lp_id" value="<?php echo (int)$landing_page['id']; ?>">

            <div class="lp-checkout-grid">
                <!-- LEFT: Customer + Delivery -->
                <div class="lp-checkout-col lp-checkout-fields">
                    <?php if ($is_digital): ?>
                    <div class="lp-note"><i class="fas fa-cloud-download-alt"></i> ডিজিটাল প্রোডাক্ট — শুধু নাম ও মোবাইল দিন</div>
                    <?php endif; ?>

                    <div class="lp-field">
                        <label>নাম *</label>
                        <input type="text" name="name" placeholder="আপনার নাম" required autocomplete="name">
                    </div>
                    <div class="lp-field">
                        <label>মোবাইল *</label>
                        <input type="tel" name="phone" placeholder="01XXXXXXXXX" required autocomplete="tel" inputmode="numeric" pattern="01[0-9]{9}" maxlength="11" title="01 দিয়ে শুরু ১১ ডিজিটের মোবাইল নাম্বার">
                    </div>

                    <div class="lp-field <?php echo $is_digital ? '' : 'd-none'; ?>">
                        <label>ইমেইল <?php echo $is_digital ? '*' : ''; ?></label>
                        <input type="email" name="email" placeholder="example@mail.com" <?php echo $is_digital ? 'required' : ''; ?> autocomplete="email">
                    </div>

                    <?php if (!$is_digital): ?>
                    <div class="lp-field">
                        <label>থানা / জেলা *</label>
                        <input type="text" name="area" placeholder="মিরপুর, ঢাকা" required autocomplete="address-level2">
                    </div>
                    <div class="lp-field">
                        <label>ঠিকানা *</label>
                        <input type="text" name="address" placeholder="বাড়ি, রোড, এলাকা" required autocomplete="street-address">
                    </div>

                    <div class="lp-block">
                        <div class="lp-block-label"><i class="fas fa-truck"></i> ডেলিভারি</div>
                        <div class="lp-chip-row" role="radiogroup" aria-label="Delivery area">
                            <?php foreach ($shipping_zones as $index => $zone):
                                $is_first = ($index === 0);
                            ?>
                            <label class="lp-chip delivery-option <?php echo $is_first ? 'active-charge' : ''; ?>"
                                   onclick="selectDelivery(<?php echo (float)$zone['charge']; ?>, this)">
                                <input type="radio" name="delivery_charge" id="zone_<?php echo (int)$zone['id']; ?>"
                                       value="<?php echo (float)$zone['charge']; ?>" <?php echo $is_first ? 'checked' : ''; ?>>
                                <span class="lp-chip-text"><?php echo htmlspecialchars($zone['name']); ?></span>
                                <span class="lp-chip-price">৳<?php echo number_format($zone['charge']); ?></span>
                            </label>
                            <?php endforeach; ?>
                        </div>
                    </div>
                    <?php else: ?>
                    <input type="hidden" name="area" value="Digital Delivery">
                    <input type="hidden" name="address" value="Digital Product - No Shipping Required">
                    <input type="hidden" name="delivery_charge" value="0">
                    <?php endif; ?>
                </div>

                <!-- RIGHT: Products + Totals + Pay + Submit -->
                <div class="lp-checkout-col lp-checkout-summary">
                    <div class="lp-block">
                        <div class="lp-block-label"><i class="fas fa-box"></i> প্রোডাক্ট</div>

                        <?php if ($is_multi): ?>
                        <div class="lp-products-list">
                            <?php foreach ($lp_products as $lp_prod):
                                $lp_prod_price = PriceHelper::effectivePrice($lp_prod['price'], $lp_prod['offer_price'] ?? null);
                                $is_primary = ((int)$lp_prod['id'] === (int)$landing_page['product_id']);
                            ?>
                            <div class="lp-prod-row lp-product-card <?php echo $is_primary ? 'active-product-card' : ''; ?>"
                                 onclick="toggleLPProduct(<?php echo (int)$lp_prod['id']; ?>, <?php echo (float)$lp_prod_price; ?>, this)">
                                <input class="lp-product-check" type="checkbox" name="product_ids[]"
                                       value="<?php echo (int)$lp_prod['id']; ?>" id="lp_prod_<?php echo (int)$lp_prod['id']; ?>"
                                       <?php echo $is_primary ? 'checked' : ''; ?>
                                       onclick="event.stopPropagation(); updateLPProductCheck(this);">
                                <img class="lp-prod-thumb" src="<?php echo $img_base; ?>/<?php echo htmlspecialchars($lp_prod['image']); ?>"
                                     alt="" loading="lazy" width="44" height="44">
                                <div class="lp-prod-meta">
                                    <div class="lp-prod-name" title="<?php echo htmlspecialchars($lp_prod['name']); ?>"><?php echo htmlspecialchars($lp_prod['name']); ?></div>
                                    <div class="lp-prod-price">৳<?php echo number_format($lp_prod_price); ?></div>
                                </div>
                                <div class="lp-qty" onclick="event.stopPropagation();">
                                    <button type="button" aria-label="Decrease" onclick="changeLPProductQty(<?php echo (int)$lp_prod['id']; ?>, -1)">−</button>
                                    <input type="number" name="qtys[<?php echo (int)$lp_prod['id']; ?>]" id="lp_prod_qty_<?php echo (int)$lp_prod['id']; ?>"
                                           value="1" min="1" readonly>
                                    <button type="button" aria-label="Increase" onclick="changeLPProductQty(<?php echo (int)$lp_prod['id']; ?>, 1)">+</button>
                                </div>
                            </div>
                            <?php endforeach; ?>
                        </div>
                        <?php else: ?>
                        <div class="lp-prod-row lp-prod-single">
                            <img class="lp-prod-thumb" src="<?php echo $img_base; ?>/<?php echo htmlspecialchars($landing_page['product_image']); ?>"
                                 alt="" loading="lazy" width="44" height="44">
                            <div class="lp-prod-meta">
                                <div class="lp-prod-name"><?php echo htmlspecialchars($landing_page['product_name']); ?></div>
                                <div class="lp-prod-price">৳<?php echo number_format($product_price); ?></div>
                            </div>
                            <div class="lp-qty">
                                <button type="button" aria-label="Decrease" onclick="changeQuantity(-1)">−</button>
                                <input type="number" name="qty" id="qty_input" value="1" min="1" readonly>
                                <button type="button" aria-label="Increase" onclick="changeQuantity(1)">+</button>
                            </div>
                        </div>
                        <?php endif; ?>
                    </div>

                    <div class="lp-totals">
                        <div class="lp-total-line"><span>সাবটোটাল</span><span>৳<span id="subtotal_display"><?php echo number_format($product_price); ?></span></span></div>
                        <div class="lp-total-line <?php echo $is_digital ? 'd-none' : ''; ?>">
                            <span>ডেলিভারি</span>
                            <span>৳<span id="delivery_display"><?php echo $is_digital ? '0' : number_format($first_zone_charge); ?></span></span>
                        </div>
                        <span id="lp_discount_display" class="d-none">0</span>
                        <div class="lp-total-line lp-grand">
                            <span>সর্বমোট</span>
                            <span>৳<span id="total_display"><?php echo $is_digital ? number_format($product_price) : number_format($product_price + $first_zone_charge); ?></span></span>
                        </div>
                    </div>

                    <div class="lp-block">
                        <div class="lp-block-label"><i class="fas fa-wallet"></i> পেমেন্ট</div>
                        <div class="lp-chip-row">
                            <?php if ($lp_allow_cod && !$is_digital): ?>
                            <label class="lp-chip payment-option active-payment" onclick="selectPayment('COD', this)">
                                <input type="radio" name="payment_method" id="lp_cod" value="COD" checked>
                                <span class="lp-chip-text"><i class="fas fa-hand-holding-usd"></i> COD</span>
                                <i class="fas fa-check-circle check-icon"></i>
                            </label>
                            <?php endif; ?>
                            <?php if (!empty($lp_payment_methods)): ?>
                            <label class="lp-chip payment-option <?php echo (!$lp_allow_cod || $is_digital) ? 'active-payment' : ''; ?>"
                                   onclick="selectPayment('Online', this)">
                                <input type="radio" name="payment_method" id="lp_online" value="Online"
                                       <?php echo (!$lp_allow_cod || $is_digital) ? 'checked' : ''; ?>>
                                <span class="lp-chip-text"><i class="fas fa-credit-card"></i> Online</span>
                                <i class="fas fa-check-circle check-icon"></i>
                            </label>
                            <?php endif; ?>
                        </div>
                    </div>

                    <div class="lp-submit-bar">
                        <button type="submit" id="submitBtn" class="lp-submit-btn">
                            <span id="btnText"><i class="fas fa-check-circle"></i> অর্ডার কনফার্ম · ৳<span id="submit_total_mirror"><?php echo $is_digital ? number_format($product_price) : number_format($product_price + $first_zone_charge); ?></span></span>
                            <span id="btnLoader" class="d-none"><i class="fas fa-spinner fa-spin"></i> প্রসেসিং...</span>
                        </button>
                        <p class="lp-secure"><i class="fas fa-lock"></i> নিরাপদ অর্ডার</p>
                    </div>
                </div>
            </div>
        </form>
    </div>
</section>

<style>
/* ── Landing Checkout: compact one-screen ── */
.lp-checkout {
    --lp-green: #15803d;
    --lp-green-soft: #f0fdf4;
    --lp-border: #e2e8f0;
    --lp-text: #0f172a;
    --lp-muted: #64748b;
    padding: 12px 0 18px;
    background: #f8fafc;
}
.lp-checkout-wrap {
    max-width: 920px;
    margin: 0 auto;
    padding: 0 10px;
    box-sizing: border-box;
}
.lp-checkout-head { text-align: center; margin-bottom: 10px; }
.lp-checkout-title {
    margin: 0;
    font-size: 1.15rem;
    font-weight: 800;
    color: var(--lp-text);
    display: inline-flex;
    align-items: center;
    gap: 8px;
}
.lp-checkout-title i { color: var(--lp-green); }
.lp-checkout-sub { margin: 2px 0 0; font-size: 0.78rem; color: var(--lp-muted); }

.lp-checkout-card {
    background: #fff;
    border: 1px solid var(--lp-border);
    border-radius: 16px;
    padding: 12px;
    box-shadow: 0 8px 24px rgba(15, 23, 42, 0.06);
}

.lp-checkout-grid {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 12px;
}
.lp-note {
    font-size: 0.72rem;
    background: #eff6ff;
    color: #1d4ed8;
    border-radius: 8px;
    padding: 6px 10px;
    margin-bottom: 8px;
    font-weight: 600;
}
.lp-field { margin-bottom: 8px; }
.lp-field label {
    display: block;
    font-size: 0.68rem;
    font-weight: 700;
    color: var(--lp-muted);
    margin-bottom: 3px;
    text-transform: uppercase;
    letter-spacing: 0.02em;
}
.lp-field input {
    width: 100%;
    border: 1.5px solid var(--lp-border);
    border-radius: 10px;
    padding: 9px 11px;
    font-size: 0.92rem;
    color: var(--lp-text);
    background: #fff;
    outline: none;
    transition: border-color 0.15s, box-shadow 0.15s;
}
.lp-field input:focus {
    border-color: var(--lp-green);
    box-shadow: 0 0 0 3px rgba(21, 128, 61, 0.12);
}

.lp-block { margin-bottom: 10px; }
.lp-block-label {
    font-size: 0.72rem;
    font-weight: 800;
    color: var(--lp-text);
    margin-bottom: 6px;
    display: flex;
    align-items: center;
    gap: 6px;
}
.lp-block-label i { color: var(--lp-green); font-size: 0.75rem; }

.lp-chip-row {
    display: flex;
    flex-wrap: wrap;
    gap: 6px;
}
.lp-chip {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    padding: 7px 10px;
    border-radius: 999px;
    border: 1.5px solid var(--lp-border);
    background: #fff;
    cursor: pointer;
    font-size: 0.78rem;
    font-weight: 700;
    color: var(--lp-text);
    margin: 0;
    user-select: none;
    transition: border-color 0.15s, background 0.15s;
}
.lp-chip input { position: absolute; opacity: 0; pointer-events: none; }
.lp-chip-price { color: var(--lp-green); }
.lp-chip .check-icon { font-size: 0.7rem; opacity: 0; color: var(--lp-green); }
.active-charge,
.active-payment {
    border-color: var(--lp-green) !important;
    background: var(--lp-green-soft) !important;
}
.active-payment .check-icon { opacity: 1; }

/* Compact product rows (multi + single) */
.lp-products-list {
    display: flex;
    flex-direction: column;
    gap: 6px;
    max-height: none;
    overflow: visible;
}
.lp-prod-row {
    display: grid;
    grid-template-columns: 18px 44px 1fr auto;
    align-items: center;
    gap: 8px;
    padding: 6px 8px;
    border: 1.5px solid var(--lp-border);
    border-radius: 12px;
    background: #fff;
    cursor: pointer;
    transition: border-color 0.15s, background 0.15s;
}
.lp-prod-single {
    grid-template-columns: 44px 1fr auto;
    cursor: default;
}
.lp-prod-row.active-product-card,
.lp-product-card.active-product-card {
    border-color: var(--lp-green);
    background: var(--lp-green-soft);
}
.lp-product-check {
    width: 16px;
    height: 16px;
    accent-color: var(--lp-green);
    margin: 0;
}
.lp-prod-thumb {
    width: 44px;
    height: 44px;
    border-radius: 8px;
    object-fit: cover;
    background: #f1f5f9;
}
.lp-prod-meta { min-width: 0; }
.lp-prod-name {
    font-size: 0.78rem;
    font-weight: 700;
    color: var(--lp-text);
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
    line-height: 1.25;
}
.lp-prod-price {
    font-size: 0.75rem;
    font-weight: 800;
    color: var(--lp-green);
}
.lp-qty {
    display: inline-flex;
    align-items: center;
    border: 1px solid var(--lp-border);
    border-radius: 8px;
    background: #fff;
    overflow: hidden;
}
.lp-qty button {
    width: 28px;
    height: 28px;
    border: 0;
    background: transparent;
    font-size: 1rem;
    font-weight: 700;
    color: var(--lp-text);
    line-height: 1;
    padding: 0;
}
.lp-qty input {
    width: 28px;
    border: 0;
    text-align: center;
    font-weight: 800;
    font-size: 0.85rem;
    padding: 0;
    background: transparent;
    -moz-appearance: textfield;
}
.lp-qty input::-webkit-outer-spin-button,
.lp-qty input::-webkit-inner-spin-button { -webkit-appearance: none; margin: 0; }

.lp-totals {
    background: #f8fafc;
    border-radius: 12px;
    padding: 8px 10px;
    margin-bottom: 10px;
}
.lp-total-line {
    display: flex;
    justify-content: space-between;
    font-size: 0.8rem;
    color: var(--lp-muted);
    margin-bottom: 4px;
}
.lp-total-line.lp-discount { color: #dc2626; }
.lp-total-line.lp-grand {
    margin-top: 4px;
    padding-top: 6px;
    border-top: 1px dashed var(--lp-border);
    font-size: 1rem;
    font-weight: 800;
    color: var(--lp-text);
}
.lp-total-line.lp-grand span:last-child { color: var(--lp-green); }

.lp-submit-bar { margin-top: 4px; }
.lp-submit-btn {
    width: 100%;
    border: 0;
    border-radius: 12px;
    padding: 12px 14px;
    font-size: 0.98rem;
    font-weight: 800;
    color: #fff;
    background: linear-gradient(135deg, #15803d 0%, #166534 100%);
    box-shadow: 0 8px 18px rgba(21, 128, 61, 0.28);
}
.lp-submit-btn:disabled { opacity: 0.7; }
.lp-secure {
    text-align: center;
    font-size: 0.68rem;
    color: var(--lp-muted);
    margin: 6px 0 0;
}

/* Mobile: denser, sticky submit, one-viewport feel */
@media (max-width: 767.98px) {
    .lp-checkout {
        padding: 8px 0 72px;
        min-height: auto;
    }
    .lp-checkout-head { margin-bottom: 6px; }
    .lp-checkout-title { font-size: 1.02rem; }
    .lp-checkout-sub { display: none; }
    .lp-checkout-card {
        padding: 10px;
        border-radius: 14px;
    }
    .lp-checkout-grid {
        grid-template-columns: 1fr;
        gap: 8px;
    }
    .lp-field { margin-bottom: 6px; }
    .lp-field label { font-size: 0.62rem; margin-bottom: 2px; }
    .lp-field input {
        padding: 8px 10px;
        font-size: 0.88rem;
        border-radius: 9px;
    }
    .lp-products-list {
        max-height: none;
        overflow: visible;
        gap: 5px;
    }
    .lp-prod-row {
        padding: 5px 6px;
        gap: 6px;
        border-radius: 10px;
    }
    .lp-prod-thumb { width: 36px; height: 36px; border-radius: 6px; }
    .lp-prod-name { font-size: 0.72rem; }
    .lp-prod-price { font-size: 0.7rem; }
    .lp-qty button, .lp-qty input { width: 26px; height: 26px; }
    .lp-totals { padding: 6px 8px; margin-bottom: 8px; }
    .lp-total-line { font-size: 0.75rem; margin-bottom: 2px; }
    .lp-total-line.lp-grand { font-size: 0.95rem; }
    .lp-chip { padding: 6px 9px; font-size: 0.72rem; }
    .lp-block { margin-bottom: 8px; }

    /* Sticky order bar — always visible without scrolling away */
    .lp-submit-bar {
        position: sticky;
        bottom: 8px;
        z-index: 20;
        margin: 0 -2px;
        padding: 6px 2px 0;
        background: linear-gradient(180deg, rgba(255,255,255,0) 0%, #fff 28%);
    }
    .lp-submit-btn {
        padding: 11px 12px;
        font-size: 0.92rem;
        border-radius: 12px;
    }
    .lp-secure { display: none; }
}

@media (min-width: 768px) {
    .lp-checkout { padding: 20px 0 28px; }
    .lp-checkout-wrap { padding: 0 16px; }
    .lp-checkout-card { padding: 16px; }
    .lp-checkout-summary {
        background: #f8fafc;
        border-radius: 14px;
        padding: 12px;
        border: 1px solid var(--lp-border);
    }
}
</style>

<script>
if (typeof productPrice === 'undefined') {
    var productPrice = <?php echo (float)$product_price; ?>;
}

var lpProducts = {
    <?php if (isset($lp_products)): ?>
    <?php foreach ($lp_products as $lp_prod):
        $lp_prod_price = PriceHelper::effectivePrice($lp_prod['price'], $lp_prod['offer_price'] ?? null);
    ?>
    '<?php echo (int)$lp_prod['id']; ?>': <?php echo (float)$lp_prod_price; ?>,
    <?php endforeach; ?>
    <?php endif; ?>
};

function toggleLPProduct(id, price, element) {
    const checkbox = element.querySelector('.lp-product-check');
    if (!checkbox) return;
    checkbox.checked = !checkbox.checked;
    element.classList.toggle('active-product-card', checkbox.checked);
    updateTotals();
}

function updateLPProductCheck(checkbox) {
    const card = checkbox.closest('.lp-product-card');
    if (card) card.classList.toggle('active-product-card', checkbox.checked);
    updateTotals();
}

function changeLPProductQty(id, delta) {
    const qtyInput = document.getElementById('lp_prod_qty_' + id);
    if (!qtyInput) return;
    let qty = parseInt(qtyInput.value) || 1;
    qty = Math.max(1, qty + delta);
    qtyInput.value = qty;

    const card = qtyInput.closest('.lp-product-card');
    const checkbox = card ? card.querySelector('.lp-product-check') : null;
    if (checkbox && !checkbox.checked) {
        checkbox.checked = true;
        if (card) card.classList.add('active-product-card');
    }
    updateTotals();
}

function changeQuantity(delta) {
    const qtyInput = document.getElementById('qty_input');
    if (!qtyInput) return;
    let qty = parseInt(qtyInput.value) || 1;
    qty = Math.max(1, qty + delta);
    qtyInput.value = qty;
    updateTotals();
}

function selectDelivery(charge, element) {
    document.querySelectorAll('.delivery-option').forEach(opt => opt.classList.remove('active-charge'));
    element.classList.add('active-charge');
    const radio = element.querySelector('input');
    if (radio) radio.checked = true;
    updateTotals();
}

function selectPayment(method, element) {
    document.querySelectorAll('.payment-option').forEach(opt => opt.classList.remove('active-payment'));
    element.classList.add('active-payment');
    const radio = element.querySelector('input');
    if (radio) radio.checked = true;

    if (window.AppTracking) {
        let subtotal = 0;
        const multChecks = document.querySelectorAll('.lp-product-check');
        if (multChecks.length > 0) {
            multChecks.forEach(check => {
                if (check.checked) {
                    const price = lpProducts[check.value];
                    const qty = parseInt(document.getElementById('lp_prod_qty_' + check.value).value) || 1;
                    subtotal += (price * qty);
                }
            });
        } else {
            const qtyEl = document.getElementById('qty_input');
            const qty = qtyEl ? (parseInt(qtyEl.value) || 1) : 1;
            subtotal = qty * productPrice;
        }
        const deliveryRadio = document.querySelector('input[name="delivery_charge"]:checked');
        const delivery = deliveryRadio ? parseInt(deliveryRadio.value) : 0;
        const discountEl = document.getElementById('lp_discount_display');
        let discountVal = discountEl ? (parseFloat(discountEl.innerText.replace(/,/g, '')) || 0) : 0;
        const total = subtotal + delivery - discountVal;

        window.AppTracking.track('AddPaymentInfo', {
            value: total,
            currency: 'BDT'
        }, 'api_' + new Date().getTime());
    }
}

function updateTotals() {
    let subtotal = 0;
    const multChecks = document.querySelectorAll('.lp-product-check');
    if (multChecks.length > 0) {
        multChecks.forEach(check => {
            if (check.checked) {
                const id = check.value;
                const price = lpProducts[id];
                const qty = parseInt(document.getElementById('lp_prod_qty_' + id).value) || 1;
                subtotal += (price * qty);
            }
        });
    } else {
        const qtyEl = document.getElementById('qty_input');
        const qty = qtyEl ? (parseInt(qtyEl.value) || 1) : 1;
        subtotal = qty * productPrice;
    }

    const deliveryRadio = document.querySelector('input[name="delivery_charge"]:checked');
    const deliveryHidden = document.querySelector('input[name="delivery_charge"][type="hidden"]');
    const delivery = deliveryRadio ? parseInt(deliveryRadio.value) : (deliveryHidden ? parseInt(deliveryHidden.value) : 0);

    const discountEl = document.getElementById('lp_discount_display');
    let discountVal = 0;
    if (discountEl) {
        discountVal = parseFloat(discountEl.innerText.replace(/,/g, '')) || 0;
    }

    const total = Math.max(0, subtotal + delivery - discountVal);

    const subEl = document.getElementById('subtotal_display');
    if (subEl) subEl.innerText = subtotal.toLocaleString();
    const delEl = document.getElementById('delivery_display');
    if (delEl) delEl.innerText = delivery.toLocaleString();
    const totEl = document.getElementById('total_display');
    if (totEl) totEl.innerText = total.toLocaleString();
    const mirror = document.getElementById('submit_total_mirror');
    if (mirror) mirror.innerText = total.toLocaleString();
}

document.getElementById('landingOrderForm').addEventListener('submit', function(e) {
    e.preventDefault();
    const btn = document.getElementById('submitBtn');
    const btnText = document.getElementById('btnText');
    const btnLoader = document.getElementById('btnLoader');

    const phoneEl = this.querySelector('input[name="phone"]');
    const phoneDigits = (phoneEl?.value || '').replace(/\D/g, '');
    if (!/^01\d{9}$/.test(phoneDigits)) {
        alert('সঠিক মোবাইল নাম্বার দিন (01XXXXXXXXX)');
        if (phoneEl) phoneEl.focus();
        return;
    }
    if (phoneEl) phoneEl.value = phoneDigits;

    const multChecks = document.querySelectorAll('.lp-product-check');
    if (multChecks.length > 0) {
        let any = false;
        multChecks.forEach(c => { if (c.checked) any = true; });
        if (!any) {
            alert('অনুগ্রহ করে কমপক্ষে একটি প্রোডাক্ট সিলেক্ট করুন');
            return;
        }
    }

    btn.disabled = true;
    btnText.classList.add('d-none');
    btnLoader.classList.remove('d-none');

    const formData = new FormData(this);
    fetch(this.action, {
        method: 'POST',
        body: formData,
        headers: { 'X-Requested-With': 'XMLHttpRequest' }
    })
    .then(res => res.json())
    .then(data => {
        if (data.success && data.redirect) {
            window.location.href = data.redirect;
        } else {
            alert(data.message || 'অর্ডার ব্যর্থ হয়েছে');
            btn.disabled = false;
            btnText.classList.remove('d-none');
            btnLoader.classList.add('d-none');
        }
    })
    .catch(err => {
        console.error(err);
        alert('সার্ভার ত্রুটি। অনুগ্রহ করে আবার চেষ্টা করুন।');
        btn.disabled = false;
        btnText.classList.remove('d-none');
        btnLoader.classList.add('d-none');
    });
});

let lpInitiateCheckoutFired = false;
function trackLPInitiateCheckout() {
    if (lpInitiateCheckoutFired) return;
    if (window.AppTracking) {
        let subtotal = 0;
        let contentIds = [];
        const multChecks = document.querySelectorAll('.lp-product-check');
        if (multChecks.length > 0) {
            multChecks.forEach(check => {
                if (check.checked) {
                    contentIds.push(String(check.value));
                    const price = lpProducts[check.value];
                    const qty = parseInt(document.getElementById('lp_prod_qty_' + check.value).value) || 1;
                    subtotal += (price * qty);
                }
            });
        } else {
            contentIds.push(<?php echo json_encode((string)$landing_page['product_id']); ?>);
            const qtyEl = document.getElementById('qty_input');
            const qty = qtyEl ? (parseInt(qtyEl.value) || 1) : 1;
            subtotal = qty * productPrice;
        }

        window.AppTracking.track('InitiateCheckout', {
            content_ids: contentIds,
            content_type: 'product',
            value: subtotal,
            currency: 'BDT',
            num_items: contentIds.length
        }, 'ic_' + new Date().getTime());
        lpInitiateCheckoutFired = true;
    }
}

document.addEventListener('DOMContentLoaded', function() {
    if (window.AppTracking) {
        window.AppTracking.track('ViewContent', {
            content_ids: [<?php echo json_encode((string)$landing_page['product_id']); ?>],
            content_name: <?php echo json_encode($landing_page['product_name']); ?>,
            content_type: 'product',
            value: <?php echo json_encode((float)$product_price); ?>,
            currency: 'BDT'
        }, 'vc_' + new Date().getTime());
    }

    const form = document.getElementById('landingOrderForm');
    if (form) {
        form.querySelectorAll('input, select, textarea').forEach(input => {
            input.addEventListener('focus', trackLPInitiateCheckout);
            input.addEventListener('click', trackLPInitiateCheckout);
        });
    }
    updateTotals();
});
</script>
