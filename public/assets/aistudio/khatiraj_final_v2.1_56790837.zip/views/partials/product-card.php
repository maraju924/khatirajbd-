<?php

/**

 * Unified product card — same name design as product details (kr-pane-header).

 * Expects $prod array with: id, slug, name, image, price, offer_price, image_alt_text (optional)

 */

$prod = $prod ?? [];

$slug = $prod['slug'] ?? '';

$name = $prod['name'] ?? '';

$image = $prod['image'] ?? '';

$price = (float)($prod['price'] ?? 0);

$offer_price = isset($prod['offer_price']) && $prod['offer_price'] !== '' && $prod['offer_price'] !== null

    ? (float)$prod['offer_price'] : null;

$alt = htmlspecialchars($prod['image_alt_text'] ?? $name);

$product_url = BASE_URL . '/product/' . rawurlencode($slug);

$img_base = defined('SITE_URL') ? SITE_URL : BASE_URL;

$has_discount = $offer_price && $offer_price > 0 && $offer_price < $price;

$discount_pct = $has_discount ? round((($price - $offer_price) / $price) * 100) : 0;

?>

<div class="kr-product-card">

    <div class="kr-pane-header kr-product-name-plate">

        <a href="<?php echo $product_url; ?>" class="text-decoration-none d-block">

            <h3 class="fw-bold mb-0 text-center kr-pane-title" title="<?php echo htmlspecialchars($name); ?>">

                <?php echo htmlspecialchars($name); ?>

            </h3>

        </a>

    </div>



    <div class="product-card-body">

        <div class="product-image-area">

            <?php if ($has_discount): ?>

                <span class="product-badge">-<?php echo $discount_pct; ?>%</span>

            <?php endif; ?>

            <div class="product-actions">

                <a href="<?php echo $product_url; ?>" class="action-btn" title="View Details">

                    <i class="fas fa-eye"></i>

                </a>

            </div>

            <a href="<?php echo $product_url; ?>" class="product-image-link d-block">

                <div class="product-image-wrapper">

                    <?php if ($image): ?>

                        <img src="<?php echo $img_base; ?>/<?php echo htmlspecialchars($image); ?>" alt="<?php echo $alt; ?>" loading="lazy">

                    <?php else: ?>

                        <div class="product-image-placeholder">

                            <i class="fas fa-image fa-2x"></i>

                        </div>

                    <?php endif; ?>

                </div>

            </a>

        </div>



        <div class="product-info">

            <div class="price-wrapper">

                <?php if ($has_discount): ?>

                    <span class="current-price text-danger">৳<?php echo number_format($offer_price); ?></span>

                    <span class="original-price">৳<?php echo number_format($price); ?></span>

                <?php else: ?>

                    <span class="current-price">৳<?php echo number_format($price); ?></span>

                <?php endif; ?>

            </div>

            <div class="d-grid gap-2 mt-auto product-card-actions">

                <button type="button" class="kr-btn-add-cart" onclick="addToCart(<?php echo (int)$prod['id']; ?>, event)">

                    <i class="fas fa-shopping-bag"></i> <?php echo __('add_to_cart'); ?>

                </button>

                <a href="<?php echo BASE_URL; ?>/cart/add/<?php echo (int)$prod['id']; ?>?redirect=checkout" class="kr-btn-order-now">

                    <i class="fas fa-bolt"></i> <?php echo __('order_now'); ?>

                </a>

            </div>

        </div>

    </div>

</div>


