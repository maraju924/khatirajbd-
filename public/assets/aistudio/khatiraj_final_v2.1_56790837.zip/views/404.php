<?php
$page_title = "404 Not Found - Khati Raj";
if (class_exists('PageHelper')) {
    PageHelper::load('not_found', ['title' => $page_title]);
}
include 'views/layouts/header.php';
?>

</div> <!-- Close header container for full-width layout -->

<div class="kr-404-page animate__animated animate__fadeIn">
    <div class="container">
        <div class="error-code">404</div>
        <h2 class="fw-bold text-dark">Page Not Found</h2>
        <p class="text-secondary">The page you are looking for does not exist, has been removed, or is temporarily unavailable.</p>
        <div class="d-flex justify-content-center gap-3 mt-4 flex-wrap">
            <a href="<?php echo BASE_URL; ?>/" class="btn btn-primary rounded-pill px-5 py-3 fw-bold shadow-sm transition-all hover-lift">
                <i class="fas fa-home me-2"></i> Back to Home
            </a>
            <a href="<?php echo BASE_URL; ?>/shop" class="btn btn-outline-primary rounded-pill px-5 py-3 fw-bold transition-all hover-lift">
                <i class="fas fa-shopping-bag me-2"></i> Shop Now
            </a>
        </div>
    </div>
</div>

<div class="container"> <!-- Reopen empty container for footer compatibility -->
<?php include 'views/layouts/footer.php'; ?>
