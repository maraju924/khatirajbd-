<?php
/**
 * Abandoned Cart Reminder Cron
 * Run every 15-30 minutes via Windows Task Scheduler or cPanel cron:
 * php "C:\xampp\htdocs\khatirajbd\cron\abandoned-cart-reminder.php"
 */
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../app/Services/AbandonedCartService.php';

$service = new AbandonedCartService($pdo);
$stats = $service->processReminders();

$line = sprintf(
    "[%s] Abandoned cart cron: processed=%d sms=%d whatsapp=%d\n",
    date('Y-m-d H:i:s'),
    $stats['processed'] ?? 0,
    $stats['sms_sent'] ?? 0,
    $stats['whatsapp_sent'] ?? 0
);

echo $line;

if (!empty($stats['errors'])) {
    foreach ($stats['errors'] as $err) {
        echo "  ERROR: $err\n";
    }
}
