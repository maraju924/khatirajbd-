<?php
// index.php
session_start();
require_once 'config/database.php';
require_once 'app/Helpers/LanguageHelper.php';
require_once 'app/Helpers/RouteHelper.php';
LanguageHelper::init();

// Simple Router
$path = RouteHelper::getPath();

// Route handling
switch ($path) {
    case '':
    case '/':
    case '/home':
        require_once 'app/Controllers/HomeController.php';
        break;
    
    case '/shop':
    case '/category':
        require_once 'app/Controllers/ProductController.php';
        break;
        
    case '/cart':
    case (preg_match('/^\/cart\/add\/[\d_]+$/', $path) ? true : false):
    case (preg_match('/^\/cart\/remove\/[\d_]+$/', $path) ? true : false):
    case (preg_match('/^\/cart\/update\/[\d_]+$/', $path) ? true : false):
    case '/cart/clear':
        require_once 'app/Controllers/CartController.php';
        break;
        
    case '/checkout':
    case '/order-process':
    case '/thanks':
    case (preg_match('#^/thanks/[a-f0-9]{64}$#', $path) ? true : false):
    case (preg_match('#^/order-summary/[a-f0-9]{64}$#', $path) ? true : false):
    case '/payment-gateway':
    case '/payment-submit':
    case '/zinipay-success':
    case '/zinipay-cancel':
        require_once 'app/Controllers/CheckoutController.php';
        break;
        
    case '/login':
    case '/register':
    case '/auth':
    case '/login-action':
    case '/register-action':
    case '/forgot-password':
    case '/send-reset-link':
    case '/reset-password':
    case '/update-password-action':
        require_once 'app/Controllers/AuthController.php';
        break;

    case '/dashboard':
    case '/orders':
    case '/profile-update':
    case '/logout-action':
        require_once 'app/Controllers/UserController.php';
        break;
        
    case '/api/search':
        require_once 'app/Controllers/SearchController.php';
        break;

    case '/api/track':
        require_once 'app/Controllers/TrackController.php';
        break;
        
    case '/track-order':
        require_once 'views/pages/track-order.php';
        break;

    case '/api/abandoned-cart/save':
    case '/cron/abandoned-cart':
    case (preg_match('#^/cart/recover/[a-f0-9]{32}$#', $path) ? true : false):
        require_once 'app/Controllers/AbandonedCartController.php';
        break;

    case '/blog':
        require_once 'app/Controllers/BlogController.php';
        $blog = new BlogController();
        $blog->index();
        break;



    case '/order-summary-public':
        require_once 'app/Controllers/CheckoutController.php';
        break;

    case '/api/apply-coupon':
    case '/api/remove-coupon':
        require_once 'app/Controllers/CouponController.php';
        break;

    case '/api/recent-sales':
        require_once 'app/Controllers/SalesPopupController.php';
        break;
    
    // Landing Pages
    case '/lp/order-process':
    case (strpos($path, '/lp/') === 0 ? $path : null):
        require_once 'app/Controllers/LandingPageController.php';
        break;
        
    default:
        // Check for dynamic routes
        if (strpos($path, '/product/') === 0) {
            $product_slug = rawurldecode(trim(substr($path, strlen('/product/')), '/'));
            $_GET['slug'] = $product_slug;
            require_once 'app/Controllers/ProductController.php';
        } elseif (strpos($path, '/category/') === 0) {
            $category_slug = rawurldecode(trim(substr($path, strlen('/category/')), '/'));
            $_GET['slug'] = $category_slug;
            require_once 'app/Controllers/ProductController.php';
        } elseif (strpos($path, '/blog/') === 0) {
            $blog_slug = substr($path, strlen('/blog/'));
            $blog_slug = trim($blog_slug, '/');
            if (!empty($blog_slug)) {
                require_once 'app/Controllers/BlogController.php';
                $blog = new BlogController();
                $blog->show($blog_slug);
            } else {
                require_once 'app/Controllers/BlogController.php';
                $blog = new BlogController();
                $blog->index();
            }
        } elseif (($cmsPage = PageHelper::getBySlug($path)) !== null) {
            // Admin-managed custom CMS page
            PageHelper::load($cmsPage['route_key']);
            $cms = PageHelper::getCurrentPage();
            if (($cms['content_mode'] ?? '') === 'sections') {
                require_once 'views/pages/cms-sections.php';
            } else {
                require_once 'views/pages/cms-page.php';
            }
        } else {
            http_response_code(404);
            require_once 'views/404.php';
        }
        break;
}
?>
