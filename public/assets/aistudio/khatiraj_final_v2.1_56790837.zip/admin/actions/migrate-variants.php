<?php
// admin/actions/migrate-variants.php
session_start();
require_once __DIR__ . '/../includes/auth-guard.php';
require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../app/Helpers/ProductVariantHelper.php';

$is_cli = php_sapi_name() === 'cli';
if (!$is_cli && (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true)) {
    header('Content-Type: application/json');
    echo json_encode(['success' => false, 'message' => 'Not authorized']);
    exit;
}

try {
    ProductVariantHelper::ensureTables($pdo);
    header('Content-Type: application/json');
    echo json_encode(['success' => true, 'message' => 'Product variant tables are ready.']);
} catch (Exception $e) {
    header('Content-Type: application/json');
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
}
