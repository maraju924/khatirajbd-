<?php
// admin/actions/blog-post-save.php
session_start();
require_once __DIR__ . '/../includes/auth-guard.php';
require_once '../../config/database.php';

header('Content-Type: application/json');

if (!isset($_SESSION['admin_logged_in'])) {
    echo json_encode(['status' => 'error', 'message' => 'Unauthorized']);
    exit;
}

$title = trim($_POST['title'] ?? '');
$excerpt = trim($_POST['excerpt'] ?? '');
$content = trim($_POST['content'] ?? '');
$image = trim($_POST['image'] ?? '');
$meta_title = trim($_POST['meta_title'] ?? '');
$meta_description = trim($_POST['meta_description'] ?? '');
$meta_keywords = trim($_POST['meta_keywords'] ?? '');
$status = intval($_POST['status'] ?? 0);

if (empty($title) || empty($content)) {
    echo json_encode(['status' => 'error', 'message' => 'Title and content are required.']);
    exit;
}

// Generate slug
$slug = strtolower(trim(preg_replace('/[^A-Za-z0-9-]+/', '-', $title), '-'));

// Ensure unique slug
$check = $pdo->prepare("SELECT COUNT(*) FROM blog_posts WHERE slug = ?");
$check->execute([$slug]);
if ($check->fetchColumn() > 0) {
    $slug .= '-' . time();
}

$author_id = $_SESSION['admin_id'] ?? null;

try {
    $stmt = $pdo->prepare("INSERT INTO blog_posts (title, slug, excerpt, content, image, meta_title, meta_description, meta_keywords, author_id, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->execute([$title, $slug, $excerpt, $content, $image, $meta_title, $meta_description, $meta_keywords, $author_id, $status]);

    echo json_encode([
        'status' => 'success',
        'message' => 'Blog post created successfully!',
        'id' => $pdo->lastInsertId()
    ]);
} catch (PDOException $e) {
    echo json_encode(['status' => 'error', 'message' => 'Database error: ' . $e->getMessage()]);
}
