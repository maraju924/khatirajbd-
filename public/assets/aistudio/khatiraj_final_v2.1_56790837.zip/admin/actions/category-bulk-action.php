<?php
// admin/actions/category-bulk-action.php
session_start();
require_once __DIR__ . '/../includes/auth-guard.php';
require_once '../../config/database.php';

header('Content-Type: application/json');

if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    echo json_encode(['status' => 'error', 'message' => 'Unauthorized']);
    exit();
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['status' => 'error', 'message' => 'Invalid request method']);
    exit();
}

$action = $_POST['action'] ?? '';
$ids = $_POST['ids'] ?? [];

if (empty($action) || empty($ids) || !is_array($ids)) {
    echo json_encode(['status' => 'error', 'message' => 'Invalid parameters']);
    exit();
}

$ids = array_map('intval', $ids);
$placeholders = implode(',', array_fill(0, count($ids), '?'));

try {
    if ($action === 'delete') {
        // Safe delete categories
        $stmt = $pdo->prepare("DELETE FROM categories WHERE id IN ($placeholders)");
        $stmt->execute($ids);
        $msg = 'Selected categories deleted successfully';
    } elseif ($action === 'active') {
        $stmt = $pdo->prepare("UPDATE categories SET status = 1 WHERE id IN ($placeholders)");
        $stmt->execute($ids);
        $msg = 'Selected categories activated';
    } elseif ($action === 'inactive') {
        $stmt = $pdo->prepare("UPDATE categories SET status = 0 WHERE id IN ($placeholders)");
        $stmt->execute($ids);
        $msg = 'Selected categories deactivated';
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Action not supported']);
        exit();
    }

    echo json_encode(['status' => 'success', 'message' => $msg]);
} catch (PDOException $e) {
    echo json_encode(['status' => 'error', 'message' => $e->getMessage()]);
}
exit();
