<?php
// admin/actions/blog-post-update.php
session_start();
require_once __DIR__ . '/../includes/auth-guard.php';
require_once '../../config/database.php';

header('Content-Type: application/json');

if (!isset($_SESSION['admin_logged_in'])) {
    echo json_encode(['status' => 'error', 'message' => 'Unauthorized']);
    exit;
}

$id = intval($_POST['id'] ?? 0);
$title = trim($_POST['title'] ?? '');
$excerpt = trim($_POST['excerpt'] ?? '');
$content = trim($_POST['content'] ?? '');
$image = trim($_POST['image'] ?? '');
$meta_title = trim($_POST['meta_title'] ?? '');
$meta_description = trim($_POST['meta_description'] ?? '');
$meta_keywords = trim($_POST['meta_keywords'] ?? '');
$status = intval($_POST['status'] ?? 0);

if (empty($title) || empty($content) || !$id) {
    echo json_encode(['status' => 'error', 'message' => 'Title, content, and ID are required.']);
    exit;
}

// Regenerate slug from title
$slug = strtolower(trim(preg_replace('/[^A-Za-z0-9-]+/', '-', $title), '-'));

// Ensure unique slug (excluding current post)
$check = $pdo->prepare("SELECT COUNT(*) FROM blog_posts WHERE slug = ? AND id != ?");
$check->execute([$slug, $id]);
if ($check->fetchColumn() > 0) {
    $slug .= '-' . time();
}

try {
    $stmt = $pdo->prepare("UPDATE blog_posts SET title = ?, slug = ?, excerpt = ?, content = ?, image = ?, meta_title = ?, meta_description = ?, meta_keywords = ?, status = ?, updated_at = NOW() WHERE id = ?");
    $stmt->execute([$title, $slug, $excerpt, $content, $image, $meta_title, $meta_description, $meta_keywords, $status, $id]);

    echo json_encode([
        'status' => 'success',
        'message' => 'Blog post updated successfully!'
    ]);
} catch (PDOException $e) {
    echo json_encode(['status' => 'error', 'message' => 'Database error: ' . $e->getMessage()]);
}
