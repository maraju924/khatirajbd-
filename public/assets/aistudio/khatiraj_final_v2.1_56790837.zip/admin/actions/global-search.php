<?php
// admin/actions/global-search.php
session_start();
require_once __DIR__ . '/../includes/auth-guard.php';
require_once '../../config/database.php';

header('Content-Type: application/json');

if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    echo json_encode(['status' => 'error', 'message' => 'Unauthorized']);
    exit();
}

$query = isset($_GET['q']) ? trim($_GET['q']) : '';

if (empty($query)) {
    echo json_encode([]);
    exit();
}

try {
    $results = [];

    // Search Products
    $stmt = $pdo->prepare("SELECT id, name, price, 'product' as type FROM products WHERE name LIKE ? OR slug LIKE ? LIMIT 5");
    $stmt->execute(["%$query%", "%$query%"]);
    $products = $stmt->fetchAll();
    foreach ($products as $p) {
        $results[] = [
            'title' => $p['name'],
            'subtitle' => '৳' . number_format($p['price']),
            'link' => 'index.php?page=edit-product&id=' . $p['id'],
            'type' => 'Product'
        ];
    }

    // Search Categories
    $stmt = $pdo->prepare("SELECT id, name, 'category' as type FROM categories WHERE name LIKE ? OR slug LIKE ? LIMIT 3");
    $stmt->execute(["%$query%", "%$query%"]);
    $categories = $stmt->fetchAll();
    foreach ($categories as $c) {
        $results[] = [
            'title' => $c['name'],
            'subtitle' => 'Category',
            'link' => 'index.php?page=categories', // Could be edit-category if implemented
            'type' => 'Category'
        ];
    }

    // Search Orders (by tracking ID)
    $stmt = $pdo->prepare("SELECT id, tracking_id, customer_phone, 'order' as type FROM orders WHERE tracking_id LIKE ? OR customer_phone LIKE ? LIMIT 3");
    $stmt->execute(["%$query%", "%$query%"]);
    $orders = $stmt->fetchAll();
    foreach ($orders as $o) {
        $results[] = [
            'title' => 'Order #' . $o['tracking_id'],
            'subtitle' => $o['customer_phone'],
            'link' => 'index.php?page=order-view&id=' . $o['id'],
            'type' => 'Order'
        ];
    }

    echo json_encode($results);

} catch (PDOException $e) {
    echo json_encode(['status' => 'error', 'message' => $e->getMessage()]);
}
?>
