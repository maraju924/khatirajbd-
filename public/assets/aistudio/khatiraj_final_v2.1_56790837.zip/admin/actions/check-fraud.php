<?php
// admin/actions/check-fraud.php
session_start();
require_once __DIR__ . '/../includes/auth-guard.php';
require_once '../../config/database.php';
require_once '../../app/Services/SteadfastService.php';

if (!isset($_SESSION['admin_logged_in'])) {
    exit(json_encode(['status' => 'error', 'message' => 'Unauthorized']));
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $phone = $_POST['phone'] ?? null;

    if (!$phone) {
        echo json_encode(['status' => 'error', 'message' => 'Phone number is required.']);
        exit;
    }

    // Sanitize phone number to 11 digits (remove non-digits, take last 11)
    $phone = preg_replace('/[^0-9]/', '', $phone);
    if (strlen($phone) > 11) {
        $phone = substr($phone, -11);
    }

    if (strlen($phone) !== 11) {
        echo json_encode(['status' => 'error', 'message' => 'Invalid phone number format. Must be 11 digits.']);
        exit;
    }

    try {
        $steadfast = new SteadfastService();
        $result = $steadfast->checkFraud($phone);

        // Some endpoints return status in JSON, others don't. 
        // We consider it success if we get any of the expected fraud fields or a explicit 200 status.
        $is_success = (isset($result['status']) && $result['status'] == 200) || 
                      isset($result['total_parcel']) || 
                      isset($result['total_delivered']) ||
                      isset($result['total_cancelled']);

        if ($is_success) {
            echo json_encode([
                'status' => 'success',
                'delivered' => $result['total_delivered'] ?? $result['delivered'] ?? 0,
                'cancelled' => $result['total_cancelled'] ?? $result['cancelled'] ?? 0,
                'total_order' => $result['total_parcel'] ?? $result['total_order'] ?? 0,
                'fraud_reports' => $result['total_fraud_reports'] ?? 0
            ]);
        } else {
            $error_msg = $result['error'] ?? 'API error';
            $http_status = $result['status'] ?? 'Unknown Status';
            $debug_info = isset($result['response']) ? ' (Raw: ' . $result['response'] . ')' : '';
            echo json_encode(['status' => 'error', 'message' => $error_msg . ' - HTTP ' . $http_status . $debug_info]);
        }
    } catch (Exception $e) {
        echo json_encode(['status' => 'error', 'message' => $e->getMessage()]);
    }
    exit;
}
