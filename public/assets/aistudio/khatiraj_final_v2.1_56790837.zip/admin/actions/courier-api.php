<?php
// admin/actions/courier-api.php
// AJAX bridge for the Courier (Steadfast) dashboard — live balance, payments,
// return requests and bulk status sync without leaving the admin panel.
session_start();
require_once __DIR__ . '/../includes/auth-guard.php';
require_once '../../config/database.php';
require_once '../../app/Services/SteadfastService.php';

header('Content-Type: application/json');

if (!isset($_SESSION['admin_logged_in']) || !in_array($_SESSION['admin_role'] ?? '', ['super_admin', 'moderator'])) {
    http_response_code(403);
    echo json_encode(['status' => 'error', 'message' => 'Unauthorized']);
    exit;
}

$action = $_GET['action'] ?? '';
$steadfast = new SteadfastService();

if (!$steadfast->isConfigured()) {
    echo json_encode(['status' => 'error', 'message' => 'Steadfast API key/secret not configured']);
    exit;
}

try {
    switch ($action) {
        case 'balance':
            $result = $steadfast->getBalance();
            if (isset($result['current_balance'])) {
                echo json_encode(['status' => 'success', 'balance' => (float) $result['current_balance']]);
            } else {
                echo json_encode(['status' => 'error', 'message' => $result['error'] ?? 'Failed to fetch balance']);
            }
            break;

        case 'payments':
            $result = $steadfast->getPayments();
            // API returns a paginated object or a plain list depending on account
            $payments = $result['data'] ?? (is_array($result) && isset($result[0]) ? $result : []);
            echo json_encode(['status' => 'success', 'payments' => $payments, 'raw_keys' => array_keys((array) $result)]);
            break;

        case 'payment_details':
            $paymentId = (int) ($_GET['id'] ?? 0);
            if ($paymentId <= 0) {
                echo json_encode(['status' => 'error', 'message' => 'Invalid payment ID']);
                break;
            }
            $result = $steadfast->getPaymentDetails($paymentId);
            echo json_encode(['status' => 'success', 'payment' => $result]);
            break;

        case 'returns':
            $result = $steadfast->getReturnRequests();
            $returns = $result['data'] ?? (is_array($result) && isset($result[0]) ? $result : []);
            echo json_encode(['status' => 'success', 'returns' => $returns]);
            break;

        case 'sync_all':
            if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
                http_response_code(405);
                echo json_encode(['status' => 'error', 'message' => 'POST required']);
                break;
            }

            // Sync statuses of consignments that are not in a final state yet
            $stmt = $pdo->query("
                SELECT id, tracking_id, courier_consignment_id, courier_status
                FROM orders
                WHERE courier_consignment_id IS NOT NULL
                  AND (courier_status IS NULL OR courier_status NOT IN ('delivered', 'cancelled'))
                ORDER BY id DESC
                LIMIT 30
            ");
            $orders = $stmt->fetchAll();

            $synced = 0;
            $changed = 0;
            $errors = 0;

            foreach ($orders as $order) {
                $result = !empty($order['courier_consignment_id'])
                    ? $steadfast->getStatusByConsignmentId($order['courier_consignment_id'])
                    : $steadfast->getStatusByTrackingCode($order['tracking_id']);

                if (!isset($result['status']) || $result['status'] != 200 || !isset($result['delivery_status'])) {
                    $errors++;
                    continue;
                }

                $newCourierStatus = $result['delivery_status'];
                $synced++;

                if ($newCourierStatus === $order['courier_status']) {
                    continue;
                }

                $newOrderStatus = match ($newCourierStatus) {
                    'pending', 'in_review', 'hold' => 'Processing',
                    'delivered', 'delivered_approval_pending' => 'Delivered',
                    'partial_delivered', 'partial_delivered_approval_pending' => 'Shipped',
                    'cancelled' => 'Cancelled',
                    default => null,
                };

                $sql = "UPDATE orders SET courier_status = ?";
                $params = [$newCourierStatus];
                if ($newOrderStatus) {
                    $sql .= ", order_status = ?";
                    $params[] = $newOrderStatus;
                }
                $sql .= " WHERE id = ?";
                $params[] = $order['id'];
                $pdo->prepare($sql)->execute($params);
                $changed++;
            }

            echo json_encode([
                'status' => 'success',
                'checked' => count($orders),
                'synced' => $synced,
                'changed' => $changed,
                'errors' => $errors,
            ]);
            break;

        default:
            http_response_code(400);
            echo json_encode(['status' => 'error', 'message' => 'Unknown action']);
    }
} catch (Throwable $e) {
    echo json_encode(['status' => 'error', 'message' => $e->getMessage()]);
}
