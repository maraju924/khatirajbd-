<?php
// admin/actions/coupon-actions.php
session_start();
require_once __DIR__ . '/../includes/auth-guard.php';
require_once '../../config/database.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    // Check if it's an AJAX request
    $is_ajax = !empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest';

    if ($action === 'add') {
        $code = strtoupper(trim($_POST['code']));
        $type = $_POST['type'];
        $value = $_POST['value'];
        $min_order_amount = $_POST['min_order_amount'] ?: 0;
        $start_date = $_POST['start_date'] ?: null;
        $end_date = $_POST['end_date'] ?: null;

        try {
            $stmt = $pdo->prepare("INSERT INTO coupons (code, type, value, min_order_amount, start_date, end_date) VALUES (?, ?, ?, ?, ?, ?)");
            $stmt->execute([$code, $type, $value, $min_order_amount, $start_date, $end_date]);
            
            if ($is_ajax) {
                header('Content-Type: application/json');
                echo json_encode(['success' => true, 'message' => 'Coupon created successfully']);
                exit;
            }
            header('Location: ../index.php?page=coupons&success=Coupon created successfully');
        } catch (PDOException $e) {
            if ($is_ajax) {
                header('Content-Type: application/json');
                echo json_encode(['success' => false, 'message' => $e->getMessage()]);
                exit;
            }
            header('Location: ../index.php?page=coupons&error=' . urlencode($e->getMessage()));
        }
    } elseif ($action === 'delete') {
        $id = $_POST['id'];
        try {
            $stmt = $pdo->prepare("DELETE FROM coupons WHERE id = ?");
            $stmt->execute([$id]);
            
            if ($is_ajax) {
                header('Content-Type: application/json');
                echo json_encode(['success' => true, 'message' => 'Coupon deleted successfully']);
                exit;
            }
            header('Location: ../index.php?page=coupons&success=Coupon deleted successfully');
        } catch (PDOException $e) {
            if ($is_ajax) {
                header('Content-Type: application/json');
                echo json_encode(['success' => false, 'message' => $e->getMessage()]);
                exit;
            }
            header('Location: ../index.php?page=coupons&error=' . urlencode($e->getMessage()));
        }
    }
}
exit();
?>
