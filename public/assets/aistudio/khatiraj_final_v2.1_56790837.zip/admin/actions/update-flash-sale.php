<?php
// admin/actions/update-flash-sale.php
session_start();
require_once __DIR__ . '/../includes/auth-guard.php';
require_once '../../config/database.php';

if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_role'] !== 'super_admin') {
    die(json_encode(['status' => 'error', 'message' => 'Unauthorized']));
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $status = $_POST['flash_sale_status'] ?? '0';
    $end_time = $_POST['flash_sale_end_time'] ?? '';
    $message = $_POST['flash_sale_message'] ?? '';
    $discount_text = $_POST['flash_sale_discount'] ?? '';

    $settings = [
        'flash_sale_status' => $status,
        'flash_sale_end_time' => $end_time,
        'flash_sale_message' => $message,
        'flash_sale_discount' => $discount_text
    ];

    try {
        $pdo->beginTransaction();
        foreach ($settings as $key => $value) {
            $stmt = $pdo->prepare("INSERT INTO settings (key_name, value) VALUES (?, ?) ON DUPLICATE KEY UPDATE value = ?");
            $stmt->execute([$key, $value, $value]);
        }
        $pdo->commit();
        require_once __DIR__ . '/../../app/Helpers/CacheHelper.php';
        CacheHelper::forget('site_settings');

        $_SESSION['success'] = "Flash Sale settings updated successfully.";
    } catch (Exception $e) {
        $pdo->rollBack();
        $_SESSION['error'] = "Error updating settings: " . $e->getMessage();
    }
}

header('Location: ../index.php?page=flash-sale');
exit;
