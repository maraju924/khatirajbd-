<?php
// admin/actions/social-actions.php
session_start();
require_once __DIR__ . '/../includes/auth-guard.php';
require_once '../../config/database.php';

// Check if admin is logged in
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header('Location: ../login.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    $id = (int)($_POST['id'] ?? 0);
    $platform_name = trim($_POST['platform_name'] ?? '');
    $icon_class = trim($_POST['icon_class'] ?? '');
    $url = trim($_POST['url'] ?? '');
    $status = (int)($_POST['status'] ?? 1);
    $sort_order = (int)($_POST['sort_order'] ?? 0);

    try {
        if ($action === 'add') {
            $stmt = $pdo->prepare("INSERT INTO social_links (platform_name, icon_class, url, status, sort_order) VALUES (?, ?, ?, ?, ?)");
            $stmt->execute([$platform_name, $icon_class, $url, $status, $sort_order]);
            $msg = "Social link added successfully";
        } elseif ($action === 'edit') {
            $stmt = $pdo->prepare("UPDATE social_links SET platform_name = ?, icon_class = ?, url = ?, status = ?, sort_order = ? WHERE id = ?");
            $stmt->execute([$platform_name, $icon_class, $url, $status, $sort_order, $id]);
            $msg = "Social link updated successfully";
        } elseif ($action === 'delete') {
            $stmt = $pdo->prepare("DELETE FROM social_links WHERE id = ?");
            $stmt->execute([$id]);
            $msg = "Social link deleted successfully";
        }
        header("Location: ../index.php?page=settings&success=" . urlencode($msg));
        exit();
    } catch (PDOException $e) {
        header("Location: ../index.php?page=settings&error=" . urlencode($e->getMessage()));
        exit();
    }
}
