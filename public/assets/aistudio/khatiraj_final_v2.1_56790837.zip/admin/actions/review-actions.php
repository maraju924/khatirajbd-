<?php
// admin/actions/review-actions.php
session_start();
require_once __DIR__ . '/../includes/auth-guard.php';
require_once '../../config/database.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    $id = $_POST['id'] ?? null;

    if ($action === 'add') {
        $product_id = $_POST['product_id'];
        $user_name = trim($_POST['user_name']);
        $user_email = trim($_POST['user_email']);
        $rating = $_POST['rating'];
        $comment = trim($_POST['comment']);
        $status = isset($_POST['status']) ? 1 : 0;

        try {
            $stmt = $pdo->prepare("INSERT INTO reviews (product_id, user_name, user_email, rating, comment, status) VALUES (?, ?, ?, ?, ?, ?)");
            $stmt->execute([$product_id, $user_name, $user_email, $rating, $comment, $status]);
            header('Location: ../index.php?page=reviews&success=Review added successfully');
        } catch (PDOException $e) {
            header('Location: ../index.php?page=reviews&error=' . urlencode($e->getMessage()));
        }
    } elseif ($action === 'update') {
        $product_id = $_POST['product_id'];
        $user_name = trim($_POST['user_name']);
        $user_email = trim($_POST['user_email']);
        $rating = $_POST['rating'];
        $comment = trim($_POST['comment']);
        $status = isset($_POST['status']) ? 1 : 0;

        try {
            $stmt = $pdo->prepare("UPDATE reviews SET product_id = ?, user_name = ?, user_email = ?, rating = ?, comment = ?, status = ? WHERE id = ?");
            $stmt->execute([$product_id, $user_name, $user_email, $rating, $comment, $status, $id]);
            header('Location: ../index.php?page=reviews&success=Review updated successfully');
        } catch (PDOException $e) {
            header('Location: ../index.php?page=reviews&error=' . urlencode($e->getMessage()));
        }
    } elseif ($action === 'approve') {
        $stmt = $pdo->prepare("UPDATE reviews SET status = 1 WHERE id = ?");
        $stmt->execute([$id]);
        header('Location: ../index.php?page=reviews&success=Review approved successfully');
    } elseif ($action === 'delete') {
        $stmt = $pdo->prepare("DELETE FROM reviews WHERE id = ?");
        $stmt->execute([$id]);
        header('Location: ../index.php?page=reviews&success=Review deleted successfully');
    }
}
?>
