<?php
// admin/actions/slider-duplicate.php
session_start();
require_once __DIR__ . '/../includes/auth-guard.php';
require_once '../../config/database.php';

header('Content-Type: application/json');

if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    echo json_encode(['success' => false, 'message' => 'Not authorized']);
    exit;
}

$id = $_GET['id'] ?? null;
if (!$id) {
    echo json_encode(['success' => false, 'message' => 'Slider ID required']);
    exit;
}

try {
    // 1. Fetch original slide
    $stmt = $pdo->prepare("SELECT * FROM sliders WHERE id = ?");
    $stmt->execute([$id]);
    $slide = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$slide) {
        echo json_encode(['success' => false, 'message' => 'Slider not found']);
        exit;
    }

    // 2. Clone it with modified details
    $new_title = $slide['title'] ? $slide['title'] . ' - Copy' : '';
    $new_order = $slide['sort_order'] + 1;

    $stmt_insert = $pdo->prepare("INSERT INTO sliders (title, subtitle, image, btn_text, btn_link, overlay_color, overlay_opacity, sort_order, status, position) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt_insert->execute([
        $new_title,
        $slide['subtitle'],
        $slide['image'],
        $slide['btn_text'],
        $slide['btn_link'],
        $slide['overlay_color'],
        $slide['overlay_opacity'],
        $new_order,
        0, // Set to inactive by default for draft safety
        $slide['position'] ?? 'main_hero'
    ]);

    echo json_encode(['success' => true, 'message' => 'Slider duplicated successfully']);
} catch (PDOException $e) {
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
}
exit;
