<?php
// admin/actions/category-save.php
session_start();
require_once __DIR__ . '/../includes/auth-guard.php';
require_once '../../config/database.php';

header('Content-Type: application/json');

if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    echo json_encode(['status' => 'error', 'message' => 'Unauthorized']);
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name']);
    $slug = !empty($_POST['slug']) ? trim($_POST['slug']) : $name;
    $slug = mb_strtolower($slug, 'UTF-8');
    $slug = preg_replace('/[^\w\x{0980}-\x{09FF}-]+/u', '-', $slug);
    $slug = preg_replace('/-+/', '-', $slug);
    $slug = trim($slug, '-');

    if (empty($slug)) {
        $slug = 'category-' . time();
    }

    $original_slug = $slug;
    $count = 1;
    while (true) {
        $stmt_check = $pdo->prepare("SELECT COUNT(*) FROM categories WHERE slug = ?");
        $stmt_check->execute([$slug]);
        if ($stmt_check->fetchColumn() == 0) {
            break;
        }
        $slug = $original_slug . '-' . $count;
        $count++;
    }
    
    if (empty($name)) {
        echo json_encode(['status' => 'error', 'message' => 'Name required']);
        exit;
    }

    // Image Handling (Media Manager or Upload)
    $imagePath = $_POST['image'] ?? NULL;
    
    // Fallback to legacy upload if file is actually sent
    if (isset($_FILES['image']) && $_FILES['image']['error'] == 0) {
        $targetDir = "../../uploads/categories/";
        if (!file_exists($targetDir)) mkdir($targetDir, 0777, true);
        
        $fileName = time() . '_' . basename($_FILES["image"]["name"]);
        $targetFilePath = $targetDir . $fileName;
        
        if (move_uploaded_file($_FILES["image"]["tmp_name"], $targetFilePath)) {
            $imagePath = "uploads/categories/" . $fileName;
        }
    }

    try {
        $stmt = $pdo->prepare("INSERT INTO categories (name, slug, image) VALUES (?, ?, ?)");
        $stmt->execute([$name, $slug, $imagePath]);
        $id = $pdo->lastInsertId();
        
        // Fetch the new category for UI update
        $new_category = $pdo->query("SELECT * FROM categories WHERE id = $id")->fetch();

        echo json_encode(['status' => 'success', 'message' => 'Category added successfully', 'data' => $new_category]);
    } catch (PDOException $e) {
        echo json_encode(['status' => 'error', 'message' => $e->getMessage()]);
    }
}
