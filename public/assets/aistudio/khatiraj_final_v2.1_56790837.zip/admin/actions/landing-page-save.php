<?php
/**
 * Admin Action - Save Landing Page
 */

session_start();
require_once __DIR__ . '/../includes/auth-guard.php';
require_once '../../config/database.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: ../index.php?page=landing-pages');
    exit;
}

try {
    // Validate required fields
    if (empty($_POST['product_id']) || empty($_POST['page_title']) || empty($_POST['slug'])) {
        header('Location: ../index.php?page=add-landing-page&error=' . urlencode('সকল প্রয়োজনীয় তথ্য পূরণ করুন'));
        exit;
    }
    
    // Sanitize slug
    $slug = strtolower(preg_replace('/[^a-z0-9-]/', '', $_POST['slug']));
    
    // Check if slug already exists
    $check_stmt = $pdo->prepare("SELECT id FROM landing_pages WHERE slug = ?");
    $check_stmt->execute([$slug]);
    if ($check_stmt->fetch()) {
        header('Location: ../index.php?page=add-landing-page&error=' . urlencode('এই স্লাগ ইতিমধ্যে ব্যবহৃত হয়েছে'));
        exit;
    }
    
    // Handle hero image upload
    $hero_image = null;
    if (!empty($_FILES['hero_image']['name'])) {
        $upload_dir = '../../uploads/landing-pages/';
        if (!is_dir($upload_dir)) {
            mkdir($upload_dir, 0755, true);
        }
        
        $file_ext = strtolower(pathinfo($_FILES['hero_image']['name'], PATHINFO_EXTENSION));
        $allowed_ext = ['jpg', 'jpeg', 'png', 'gif', 'webp'];
        
        if (in_array($file_ext, $allowed_ext)) {
            $new_filename = 'hero_' . time() . '_' . uniqid() . '.' . $file_ext;
            if (move_uploaded_file($_FILES['hero_image']['tmp_name'], $upload_dir . $new_filename)) {
                $hero_image = 'uploads/landing-pages/' . $new_filename;
            }
        }
    }
    
    // Get additional product_ids array from POST and convert to comma-separated string
    $product_ids = isset($_POST['product_ids']) && is_array($_POST['product_ids']) ? implode(',', array_map('intval', $_POST['product_ids'])) : null;

    // Get shipping config from POST and serialize to JSON
    $shipping_config = null;
    if (isset($_POST['shipping_zones']) && is_array($_POST['shipping_zones'])) {
        $config_data = [];
        foreach ($_POST['shipping_zones'] as $zone_id => $data) {
            if (!empty($data['enabled'])) {
                $config_data[(int)$zone_id] = [
                    'enabled' => true,
                    'charge' => ($data['charge'] !== '') ? (float)$data['charge'] : ''
                ];
            }
        }
        $shipping_config = !empty($config_data) ? json_encode($config_data, JSON_UNESCAPED_UNICODE) : null;
    }
    
    // Insert landing page
    $stmt = $pdo->prepare("
        INSERT INTO landing_pages (
            product_id, product_ids, slug, page_title, meta_description, 
            template_type, custom_html, custom_js,
            hero_title, hero_subtitle, hero_image, hero_video_url,
            benefits_title, benefits_content, trust_title, trust_content,
            cta_text, custom_css, shipping_config, status
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    ");
    
    $stmt->execute([
        (int)$_POST['product_id'],
        $product_ids,
        $slug,
        $_POST['page_title'],
        $_POST['meta_description'] ?? null,
        $_POST['template_type'] ?? 'default',
        $_POST['custom_html'] ?? null,
        $_POST['custom_js'] ?? null,
        $_POST['hero_title'] ?? null,
        $_POST['hero_subtitle'] ?? null,
        $hero_image,
        $_POST['hero_video_url'] ?? null,
        $_POST['benefits_title'] ?? 'এই প্রোডাক্টের উপকারিতা',
        $_POST['benefits_content'] ?? null,
        $_POST['trust_title'] ?? 'কেন আমাদের থেকে নিবেন?',
        $_POST['trust_content'] ?? null,
        $_POST['cta_text'] ?? 'এখনই অর্ডার করুন',
        $_POST['custom_css'] ?? null,
        $shipping_config,
        (int)($_POST['status'] ?? 1)
    ]);
    
    header('Location: ../index.php?page=landing-pages&success=created');
    exit;
    
} catch (PDOException $e) {
    header('Location: ../index.php?page=add-landing-page&error=' . urlencode('ডাটাবেস ত্রুটি: ' . $e->getMessage()));
    exit;
}
?>
