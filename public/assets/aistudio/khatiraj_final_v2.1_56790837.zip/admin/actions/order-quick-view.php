<?php
// admin/actions/order-quick-view.php
// Returns full order details as JSON for the quick-view modal on the orders list.
session_start();
require_once __DIR__ . '/../includes/auth-guard.php';
require_once '../../config/database.php';

header('Content-Type: application/json');

if (!isset($_SESSION['admin_logged_in']) || !in_array($_SESSION['admin_role'] ?? '', ['super_admin', 'moderator'])) {
    http_response_code(403);
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit;
}

$id = (int) ($_GET['id'] ?? 0);
if ($id <= 0) {
    echo json_encode(['success' => false, 'message' => 'Invalid order ID']);
    exit;
}

try {
    $stmt = $pdo->prepare("SELECT o.*, u.name AS user_name, u.email AS user_email FROM orders o LEFT JOIN users u ON o.user_id = u.id WHERE o.id = ?");
    $stmt->execute([$id]);
    $order = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$order) {
        echo json_encode(['success' => false, 'message' => 'Order not found']);
        exit;
    }

    $stmt = $pdo->prepare("
        SELECT oi.qty, oi.price, oi.variant_label, p.name, p.image, p.id AS product_id
        FROM order_items oi
        JOIN products p ON oi.product_id = p.id
        WHERE oi.order_id = ?
    ");
    $stmt->execute([$id]);
    $items = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Customer history by phone
    $history = ['total' => 0, 'delivered' => 0, 'cancelled' => 0, 'spent' => 0];
    if (!empty($order['customer_phone'])) {
        $stmt = $pdo->prepare("
            SELECT COUNT(*) AS total,
                   SUM(order_status = 'Delivered') AS delivered,
                   SUM(order_status = 'Cancelled') AS cancelled,
                   COALESCE(SUM(CASE WHEN order_status != 'Cancelled' THEN total_amount END), 0) AS spent
            FROM orders WHERE customer_phone = ?
        ");
        $stmt->execute([$order['customer_phone']]);
        $h = $stmt->fetch(PDO::FETCH_ASSOC) ?: [];
        $history = [
            'total' => (int) ($h['total'] ?? 0),
            'delivered' => (int) ($h['delivered'] ?? 0),
            'cancelled' => (int) ($h['cancelled'] ?? 0),
            'spent' => (float) ($h['spent'] ?? 0),
        ];
    }

    $subtotal = 0;
    foreach ($items as $item) {
        $subtotal += $item['price'] * $item['qty'];
    }

    echo json_encode([
        'success' => true,
        'order' => [
            'id' => (int) $order['id'],
            'tracking_id' => $order['tracking_id'],
            'customer_name' => $order['customer_name'] ?: ($order['user_name'] ?? 'Guest'),
            'customer_phone' => $order['customer_phone'],
            'customer_email' => $order['customer_email'] ?: ($order['user_email'] ?? ''),
            'shipping_address' => $order['shipping_address'],
            'order_status' => $order['order_status'],
            'payment_status' => $order['payment_status'],
            'payment_method' => $order['payment_method'],
            'coupon_code' => $order['coupon_code'],
            'discount_amount' => (float) $order['discount_amount'],
            'total_amount' => (float) $order['total_amount'],
            'subtotal' => (float) $subtotal,
            'courier_consignment_id' => $order['courier_consignment_id'],
            'courier_status' => $order['courier_status'],
            'created_at' => date('d M Y, h:i A', strtotime($order['created_at'])),
        ],
        'items' => array_map(function ($i) {
            return [
                'name' => $i['name'],
                'variant' => $i['variant_label'],
                'qty' => (int) $i['qty'],
                'price' => (float) $i['price'],
                'image' => $i['image'],
                'product_id' => (int) $i['product_id'],
            ];
        }, $items),
        'history' => $history,
    ], JSON_UNESCAPED_UNICODE);
} catch (Throwable $e) {
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
}
