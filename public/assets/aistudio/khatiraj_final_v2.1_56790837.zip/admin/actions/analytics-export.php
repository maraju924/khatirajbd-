<?php
// admin/actions/analytics-export.php
// Exports analytics tables (page_visits, orders, products) as CSV download. Protected by session check.

session_start();
require_once __DIR__ . '/../includes/auth-guard.php';
require_once '../../config/database.php';

if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header('Location: ../login.php');
    exit;
}

$type = $_GET['type'] ?? 'traffic';
$range = (int)($_GET['range'] ?? 7);

header('Content-Type: text/csv; charset=utf-8');
header('Content-Disposition: attachment; filename=khatiraj_' . $type . '_report_' . date('Ymd_His') . '.csv');

$output = fopen('php://output', 'w');

// Add UTF-8 BOM for Excel compatibility with Bengali text
fprintf($output, chr(0xEF).chr(0xBB).chr(0xBF));

try {
    if ($type === 'traffic') {
        // Export page visits
        fputcsv($output, ['ID', 'Session ID', 'User ID', 'Page URL', 'Referrer', 'Source', 'Medium', 'Campaign', 'Device', 'Browser', 'OS', 'IP Address', 'Time Spent (s)', 'Created At']);
        
        $stmt = $pdo->prepare("
            SELECT id, session_id, user_id, page_url, referrer, utm_source, utm_medium, utm_campaign, device_type, browser, os, ip_address, time_on_page, created_at
            FROM page_visits
            WHERE created_at >= NOW() - INTERVAL ? DAY
            ORDER BY id DESC
        ");
        $stmt->execute([$range]);
        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            fputcsv($output, $row);
        }
    } elseif ($type === 'revenue') {
        // Export order revenue
        fputcsv($output, ['Order ID', 'Customer Name', 'Phone', 'Email', 'Payment Method', 'Payment Status', 'Total Amount', 'Status', 'IP Address', 'Date']);
        
        $stmt = $pdo->prepare("
            SELECT tracking_id, customer_name, customer_phone, customer_email, payment_method, payment_status, total_amount, order_status, ip_address, created_at
            FROM orders
            WHERE created_at >= NOW() - INTERVAL ? DAY AND order_status != 'Cancelled'
            ORDER BY id DESC
        ");
        $stmt->execute([$range]);
        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            fputcsv($output, $row);
        }
    } elseif ($type === 'products') {
        // Export top products
        fputcsv($output, ['Product Name', 'Quantity Sold', 'Revenue Generated']);
        
        $stmt = $pdo->prepare("
            SELECT p.name, SUM(oi.qty) as total_qty, SUM(oi.qty * oi.price) as total_revenue
            FROM order_items oi
            JOIN products p ON oi.product_id = p.id
            JOIN orders o ON oi.order_id = o.id
            WHERE o.created_at >= NOW() - INTERVAL ? DAY AND o.order_status != 'Cancelled'
            GROUP BY p.id
            ORDER BY total_qty DESC
        ");
        $stmt->execute([$range]);
        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            fputcsv($output, $row);
        }
    } else {
        fputcsv($output, ['Invalid export type specified']);
    }
} catch (\Exception $e) {
    fputcsv($output, ['Error generating export', $e->getMessage()]);
}

fclose($output);
exit;
