<?php
// admin/actions/admin-delete.php
session_start();
require_once __DIR__ . '/../includes/auth-guard.php';
require_once '../../config/database.php';

// Security check: Only Super Admin can delete
// In a real app, check $_SESSION['admin_role'] === 'super_admin'

// Check if it's an AJAX request
$is_ajax = !empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest';

if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    if ($is_ajax) {
        header('Content-Type: application/json');
        echo json_encode(['success' => false, 'message' => 'Not authorized']);
        exit;
    }
    header('Location: ../login.php');
    exit;
}

if (isset($_GET['id'])) {
    $id = $_GET['id'];
    
    try {
        $stmt = $pdo->prepare("DELETE FROM admins WHERE id = ? AND email != ?");
        $stmt->execute([$id, $_SESSION['admin_email']]);
        
        if ($stmt->rowCount() > 0) {
            if ($is_ajax) {
                header('Content-Type: application/json');
                echo json_encode(['success' => true, 'message' => 'Admin deleted successfully']);
                exit;
            }
            header('Location: ../index.php?page=admins&success=Admin deleted');
        } else {
            if ($is_ajax) {
                header('Content-Type: application/json');
                echo json_encode(['success' => false, 'message' => 'Cannot delete yourself or admin not found']);
                exit;
            }
            header('Location: ../index.php?page=admins&error=Cannot delete yourself or admin not found');
        }
    } catch (PDOException $e) {
        if ($is_ajax) {
            header('Content-Type: application/json');
            echo json_encode(['success' => false, 'message' => $e->getMessage()]);
            exit;
        }
        header('Location: ../index.php?page=admins&error=' . urlencode($e->getMessage()));
    }
}
exit();
