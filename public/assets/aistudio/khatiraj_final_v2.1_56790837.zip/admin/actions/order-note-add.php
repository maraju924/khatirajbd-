<?php
// admin/actions/order-note-add.php
// Add an internal admin note to an order (table auto-created on first use).
session_start();
require_once __DIR__ . '/../includes/auth-guard.php';
require_once '../../config/database.php';

header('Content-Type: application/json');

if (!isset($_SESSION['admin_logged_in']) || !in_array($_SESSION['admin_role'] ?? '', ['super_admin', 'moderator'])) {
    http_response_code(403);
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'POST required']);
    exit;
}

$order_id = (int) ($_POST['order_id'] ?? 0);
$note = trim($_POST['note'] ?? '');

if ($order_id <= 0 || $note === '') {
    echo json_encode(['success' => false, 'message' => 'Order ID and note required']);
    exit;
}
if (mb_strlen($note) > 1000) {
    $note = mb_substr($note, 0, 1000);
}

try {
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS order_notes (
            id INT AUTO_INCREMENT PRIMARY KEY,
            order_id INT NOT NULL,
            admin_name VARCHAR(100) NOT NULL,
            note TEXT NOT NULL,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            KEY idx_order (order_id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    ");

    $admin_email = $_SESSION['admin_email'] ?? 'Admin';
    $admin_name = strpos($admin_email, '@') !== false ? substr($admin_email, 0, strpos($admin_email, '@')) : $admin_email;
    $stmt = $pdo->prepare("INSERT INTO order_notes (order_id, admin_name, note) VALUES (?, ?, ?)");
    $stmt->execute([$order_id, $admin_name, $note]);

    echo json_encode([
        'success' => true,
        'note' => [
            'admin_name' => $admin_name,
            'note' => $note,
            'created_at' => date('d M, h:i A'),
        ],
    ], JSON_UNESCAPED_UNICODE);
} catch (Throwable $e) {
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
}
