<?php
// admin/actions/section-save.php
declare(strict_types=1);

session_start();
require_once __DIR__ . '/../includes/auth-guard.php';
require_once '../../config/database.php';
require_once '../../app/Helpers/CacheHelper.php';
require_once '../../app/Helpers/PageHelper.php';

if (empty($_SESSION['admin_logged_in'])) {
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(['success' => false, 'message' => 'Unauthorized — please log in again']);
    exit;
}

$wantsJson = (
    (!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower((string)$_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest')
    || (isset($_POST['ajax']) && (string)$_POST['ajax'] === '1')
    || (isset($_GET['ajax']) && (string)$_GET['ajax'] === '1')
);

function sectionRespond(bool $ok, string $message, array $extra = [], bool $json = false, int $pageId = 0): void
{
    if ($json) {
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode(array_merge(['success' => $ok, 'message' => $message], $extra));
        exit;
    }
    $flag = $ok ? 'success' : 'error';
    header("Location: ../index.php?page=edit-page&id={$pageId}&tab=content&{$flag}=" . urlencode($message));
    exit;
}

function allowedSectionTypes(): array
{
    return ['hero', 'text', 'image', 'features', 'stats', 'cta', 'faq', 'gallery', 'spacer', 'html', 'columns', 'labels'];
}

function normalizeExtraJson(?string $raw): string
{
    $raw = trim((string)$raw);
    if ($raw === '') {
        return '';
    }
    $decoded = json_decode($raw, true);
    if (!is_array($decoded)) {
        return $raw; // keep as-is for labels/legacy
    }
    return json_encode($decoded, JSON_UNESCAPED_UNICODE);
}

function uniqueSectionKey(PDO $pdo, int $pageId, string $type): string
{
    $base = preg_replace('/[^a-z0-9_]+/', '_', strtolower($type)) ?: 'block';
    $key = $base . '_' . substr(bin2hex(random_bytes(3)), 0, 6);
    $stmt = $pdo->prepare('SELECT id FROM page_sections WHERE page_id = ? AND section_key = ?');
    $n = 0;
    while (true) {
        $candidate = $n === 0 ? $key : $base . '_' . substr(bin2hex(random_bytes(3)), 0, 6);
        $stmt->execute([$pageId, $candidate]);
        if (!$stmt->fetchColumn()) {
            return $candidate;
        }
        if (++$n > 20) {
            return $base . '_' . time();
        }
    }
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    sectionRespond(false, 'Invalid request', [], $wantsJson);
}

$action = isset($_POST['action']) ? trim((string)$_POST['action']) : '';
$page_id = isset($_POST['page_id']) ? (int)$_POST['page_id'] : 0;

if ($page_id <= 0) {
    sectionRespond(false, 'Invalid Page ID', [], $wantsJson, $page_id);
}

try {
    $pageStmt = $pdo->prepare('SELECT route_key FROM page_registry WHERE id = ?');
    $pageStmt->execute([$page_id]);
    $routeKey = (string)($pageStmt->fetchColumn() ?: '');
    if ($routeKey === '' || !PageHelper::isManageable($routeKey)) {
        sectionRespond(false, 'This page is not editable in Page & SEO Manager', [], $wantsJson, $page_id);
    }

    if ($action === 'add') {
        $section_type = isset($_POST['section_type']) ? trim((string)$_POST['section_type']) : 'text';
        if (!in_array($section_type, allowedSectionTypes(), true)) {
            $section_type = 'text';
        }

        $section_key = isset($_POST['section_key']) ? trim((string)$_POST['section_key']) : '';
        if ($section_key === '') {
            $section_key = uniqueSectionKey($pdo, $page_id, $section_type);
        } else {
            $section_key = preg_replace('/[^a-z0-9_\-]+/i', '_', $section_key) ?: uniqueSectionKey($pdo, $page_id, $section_type);
        }

        $title = isset($_POST['title']) ? trim((string)$_POST['title']) : '';
        $subtitle = isset($_POST['subtitle']) ? trim((string)$_POST['subtitle']) : '';
        $content = isset($_POST['content']) ? (string)$_POST['content'] : '';
        $image = isset($_POST['image']) ? trim((string)$_POST['image']) : '';
        $icon = isset($_POST['icon']) ? trim((string)$_POST['icon']) : '';
        $btn_text = isset($_POST['btn_text']) ? trim((string)$_POST['btn_text']) : '';
        $btn_link = isset($_POST['btn_link']) ? trim((string)$_POST['btn_link']) : '';
        $extra_json = normalizeExtraJson($_POST['extra_json'] ?? '');
        $status = isset($_POST['status']) ? (int)$_POST['status'] : 1;

        $sortStmt = $pdo->prepare('SELECT COALESCE(MAX(sort_order), 0) FROM page_sections WHERE page_id = ?');
        $sortStmt->execute([$page_id]);
        $sort_order = isset($_POST['sort_order']) && $_POST['sort_order'] !== ''
            ? (int)$_POST['sort_order']
            : ((int)$sortStmt->fetchColumn() + 1);

        $chk = $pdo->prepare('SELECT id FROM page_sections WHERE page_id = ? AND section_key = ?');
        $chk->execute([$page_id, $section_key]);
        if ($chk->fetch()) {
            $section_key = uniqueSectionKey($pdo, $page_id, $section_type);
        }

        $stmt_insert = $pdo->prepare(
            'INSERT INTO page_sections (page_id, section_key, section_type, title, subtitle, content, image, icon, btn_text, btn_link, extra_json, sort_order, status)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)'
        );
        $stmt_insert->execute([
            $page_id, $section_key, $section_type, $title, $subtitle, $content,
            $image, $icon, $btn_text, $btn_link, $extra_json, $sort_order, $status,
        ]);
        $newId = (int)$pdo->lastInsertId();

        CacheHelper::clearAll();
        sectionRespond(true, 'Block added', ['id' => $newId, 'section_key' => $section_key], $wantsJson, $page_id);

    } elseif ($action === 'edit') {
        $id = isset($_POST['id']) ? (int)$_POST['id'] : 0;
        if ($id <= 0) {
            sectionRespond(false, 'Invalid Section ID', [], $wantsJson, $page_id);
        }

        $section_type = isset($_POST['section_type']) ? trim((string)$_POST['section_type']) : 'text';
        if (!in_array($section_type, allowedSectionTypes(), true)) {
            $section_type = 'text';
        }

        $title = isset($_POST['title']) ? trim((string)$_POST['title']) : '';
        $subtitle = isset($_POST['subtitle']) ? trim((string)$_POST['subtitle']) : '';
        $content = isset($_POST['content']) ? (string)$_POST['content'] : '';
        $image = isset($_POST['image']) ? trim((string)$_POST['image']) : '';
        $icon = isset($_POST['icon']) ? trim((string)$_POST['icon']) : '';
        $btn_text = isset($_POST['btn_text']) ? trim((string)$_POST['btn_text']) : '';
        $btn_link = isset($_POST['btn_link']) ? trim((string)$_POST['btn_link']) : '';
        $extra_json = normalizeExtraJson($_POST['extra_json'] ?? '');
        $sort_order = isset($_POST['sort_order']) ? (int)$_POST['sort_order'] : 0;
        $status = isset($_POST['status']) ? (int)$_POST['status'] : 1;

        $stmt_update = $pdo->prepare(
            'UPDATE page_sections SET section_type = ?, title = ?, subtitle = ?, content = ?, image = ?, icon = ?, btn_text = ?, btn_link = ?, extra_json = ?, sort_order = ?, status = ?
             WHERE id = ? AND page_id = ?'
        );
        $stmt_update->execute([
            $section_type, $title, $subtitle, $content, $image, $icon, $btn_text, $btn_link,
            $extra_json, $sort_order, $status, $id, $page_id,
        ]);

        CacheHelper::clearAll();
        sectionRespond(true, 'Block updated', ['id' => $id], $wantsJson, $page_id);

    } elseif ($action === 'delete') {
        $id = isset($_POST['id']) ? (int)$_POST['id'] : 0;
        if ($id <= 0) {
            sectionRespond(false, 'Invalid Section ID', [], $wantsJson, $page_id);
        }
        $stmt_delete = $pdo->prepare('DELETE FROM page_sections WHERE id = ? AND page_id = ?');
        $stmt_delete->execute([$id, $page_id]);
        CacheHelper::clearAll();
        sectionRespond(true, 'Block deleted', ['id' => $id], $wantsJson, $page_id);

    } elseif ($action === 'toggle') {
        $id = isset($_POST['id']) ? (int)$_POST['id'] : 0;
        if ($id <= 0) {
            sectionRespond(false, 'Invalid Section ID', [], $wantsJson, $page_id);
        }
        $pdo->prepare('UPDATE page_sections SET status = IF(status = 1, 0, 1) WHERE id = ? AND page_id = ?')
            ->execute([$id, $page_id]);
        $st = $pdo->prepare('SELECT status FROM page_sections WHERE id = ? AND page_id = ?');
        $st->execute([$id, $page_id]);
        $status = (int)$st->fetchColumn();
        CacheHelper::clearAll();
        sectionRespond(true, 'Visibility updated', ['id' => $id, 'status' => $status], $wantsJson, $page_id);

    } elseif ($action === 'duplicate') {
        $id = isset($_POST['id']) ? (int)$_POST['id'] : 0;
        if ($id <= 0) {
            sectionRespond(false, 'Invalid Section ID', [], $wantsJson, $page_id);
        }
        $src = $pdo->prepare('SELECT * FROM page_sections WHERE id = ? AND page_id = ?');
        $src->execute([$id, $page_id]);
        $row = $src->fetch(PDO::FETCH_ASSOC);
        if (!$row) {
            sectionRespond(false, 'Section not found', [], $wantsJson, $page_id);
        }
        $newKey = uniqueSectionKey($pdo, $page_id, (string)$row['section_type']);
        $sortStmt = $pdo->prepare('SELECT COALESCE(MAX(sort_order), 0) FROM page_sections WHERE page_id = ?');
        $sortStmt->execute([$page_id]);
        $nextSort = (int)$sortStmt->fetchColumn() + 1;

        $ins = $pdo->prepare(
            'INSERT INTO page_sections (page_id, section_key, section_type, title, subtitle, content, image, icon, btn_text, btn_link, extra_json, sort_order, status)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)'
        );
        $ins->execute([
            $page_id, $newKey, $row['section_type'], $row['title'], $row['subtitle'], $row['content'],
            $row['image'], $row['icon'], $row['btn_text'], $row['btn_link'], $row['extra_json'],
            $nextSort, (int)$row['status'],
        ]);
        $newId = (int)$pdo->lastInsertId();
        CacheHelper::clearAll();
        sectionRespond(true, 'Block duplicated', ['id' => $newId, 'section_key' => $newKey], $wantsJson, $page_id);

    } elseif ($action === 'reorder') {
        $orderRaw = $_POST['order'] ?? '[]';
        if (is_string($orderRaw)) {
            $order = json_decode($orderRaw, true);
        } else {
            $order = $orderRaw;
        }
        if (!is_array($order)) {
            sectionRespond(false, 'Invalid order payload', [], $wantsJson, $page_id);
        }
        $upd = $pdo->prepare('UPDATE page_sections SET sort_order = ? WHERE id = ? AND page_id = ?');
        $i = 1;
        foreach ($order as $sid) {
            $sid = (int)$sid;
            if ($sid > 0) {
                $upd->execute([$i, $sid, $page_id]);
                $i++;
            }
        }
        CacheHelper::clearAll();
        sectionRespond(true, 'Order saved', [], $wantsJson, $page_id);

    } else {
        sectionRespond(false, 'Unknown action', [], $wantsJson, $page_id);
    }
} catch (PDOException $e) {
    sectionRespond(false, $e->getMessage(), [], $wantsJson, $page_id);
}
