<?php
// admin/actions/bulk-upload-action.php
session_start();
require_once __DIR__ . '/../includes/auth-guard.php';
require_once '../../config/database.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['csv_file'])) {
    $file = $_FILES['csv_file']['tmp_name'];
    
    if (($handle = fopen($file, "r")) !== FALSE) {
        // Skip Header Row
        $header = fgetcsv($handle, 1000, ",");
        
        $count = 0;
        try {
            $pdo->beginTransaction();
            
            while (($data = fgetcsv($handle, 1000, ",")) !== FALSE) {
                // CSV columns: name, slug, price, offer_price, category_id, quantity, status, image, description
                $name = $data[0] ?? '';
                $slug = $data[1] ?? '';
                $price = $data[2] ?? 0;
                $offer_price = $data[3] ?: null;
                $category_id = $data[4] ?? 1;
                $quantity = (int)($data[5] ?? 0);
                $status = $data[6] ?? 1;
                $image = $data[7] ?? '';
                $description = $data[8] ?? '';

                if (empty($slug) || empty($name)) continue;

                $stmt = $pdo->prepare("
                    INSERT INTO products (name, slug, price, offer_price, category_id, quantity, status, image, description) 
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                    ON DUPLICATE KEY UPDATE 
                        name = VALUES(name),
                        price = VALUES(price),
                        offer_price = VALUES(offer_price),
                        category_id = VALUES(category_id),
                        quantity = VALUES(quantity),
                        status = VALUES(status),
                        image = VALUES(image),
                        description = VALUES(description)
                ");
                $stmt->execute([$name, $slug, $price, $offer_price, $category_id, $quantity, $status, $image, $description]);
                $count++;
            }
            
            $pdo->commit();
            header('Location: ../index.php?page=bulk-upload&success=' . $count . ' products processed successfully.');
        } catch (Exception $e) {
            $pdo->rollBack();
            header('Location: ../index.php?page=bulk-upload&error=' . urlencode($e->getMessage()));
        }
        fclose($handle);
    } else {
        header('Location: ../index.php?page=bulk-upload&error=Could not open the file.');
    }
}
?>
