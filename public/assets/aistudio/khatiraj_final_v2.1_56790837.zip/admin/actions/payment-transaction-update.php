<?php
// admin/actions/payment-transaction-update.php
session_start();
require_once __DIR__ . '/../includes/auth-guard.php';
require_once '../../config/database.php';
require_once '../../app/Services/PaymentGateway.php';

if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header('Location: ../login.php');
    exit;
}

$paymentGateway = new PaymentGateway($pdo);
$id = intval($_POST['id'] ?? 0);
$status = $_POST['status'] ?? '';
$adminNote = $_POST['admin_note'] ?? null;

if (!$id || !in_array($status, ['pending', 'processing', 'completed', 'failed', 'cancelled', 'refunded'])) {
    header('Location: ../index.php?page=payment-transactions&error=Invalid request');
    exit;
}

try {
    $paymentGateway->updateTransactionStatus($id, $status, $adminNote);
    
    $message = 'Transaction status updated';
    if ($status === 'completed') {
        $message = 'Payment approved and order marked as Paid';
    } elseif ($status === 'failed') {
        $message = 'Payment rejected';
    }
    
    header('Location: ../index.php?page=payment-transactions&success=' . urlencode($message));
} catch (Exception $e) {
    header('Location: ../index.php?page=payment-transactions&error=' . urlencode($e->getMessage()));
}
exit;
