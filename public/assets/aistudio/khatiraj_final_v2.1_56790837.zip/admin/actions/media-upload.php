<?php
// admin/actions/media-upload.php
session_start();
require_once __DIR__ . '/../includes/auth-guard.php';
require_once '../../config/database.php';
require_once '../../app/Helpers/ImageHelper.php';

use App\Helpers\ImageHelper;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $folder = preg_replace('/[^a-z0-9_-]/i', '', $_POST['folder'] ?? '');
    $projectRoot = realpath(__DIR__ . '/../..');
    $redirectBase = '../index.php?page=media';

    if ($folder === '') {
        header('Location: ' . $redirectBase . '&error=' . urlencode('Invalid upload folder'));
        exit;
    }

    if (!isset($_FILES['image']) || $_FILES['image']['error'] !== UPLOAD_ERR_OK) {
        header('Location: ' . $redirectBase . '&error=' . urlencode('Please select a valid image'));
        exit;
    }

    if ($folder === 'products' && !ImageHelper::isGdAvailable()) {
        header('Location: ' . $redirectBase . '&error=' . urlencode('Enable PHP GD extension (extension=gd) for product WebP uploads'));
        exit;
    }

    $targetDir = $projectRoot . DIRECTORY_SEPARATOR . 'uploads' . DIRECTORY_SEPARATOR . $folder . DIRECTORY_SEPARATOR;
    if (!is_dir($targetDir) && !mkdir($targetDir, 0777, true) && !is_dir($targetDir)) {
        header('Location: ' . $redirectBase . '&error=' . urlencode('Could not create upload folder'));
        exit;
    }

    $tempPath = $targetDir . 'tmp_' . uniqid('', true);
    if (!move_uploaded_file($_FILES['image']['tmp_name'], $tempPath)) {
        header('Location: ' . $redirectBase . '&error=' . urlencode('Failed to move uploaded file'));
        exit;
    }

    if ($folder === 'products') {
        $saved = ImageHelper::saveUploadedProductImage($tempPath, $_FILES['image']['name'], $targetDir);
        if (!$saved) {
            @unlink($tempPath);
            header('Location: ' . $redirectBase . '&error=' . urlencode('Product image conversion failed'));
            exit;
        }
        header('Location: ' . $redirectBase . '&success=' . urlencode('Product image saved as 600x600 WebP'));
        exit;
    }

    $fileName = time() . '_' . basename($_FILES['image']['name']);
    $targetFilePath = $targetDir . $fileName;
    if (@rename($tempPath, $targetFilePath)) {
        header('Location: ' . $redirectBase . '&success=' . urlencode('File uploaded successfully'));
    } else {
        @unlink($tempPath);
        header('Location: ' . $redirectBase . '&error=' . urlencode('Failed to save uploaded file'));
    }
}
