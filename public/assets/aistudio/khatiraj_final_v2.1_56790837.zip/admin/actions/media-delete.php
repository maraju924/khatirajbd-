<?php
// admin/actions/media-delete.php
session_start();

require_once __DIR__ . '/../includes/auth-guard.php';
if (isset($_GET['path'])) {
    $path = $_GET['path'];
    $full_path = "../../" . $path;

    // Security check: Ensure we only delete from uploads folder
    if (strpos($path, 'uploads/') === 0 && file_exists($full_path)) {
        if (unlink($full_path)) {
            header('Location: ../index.php?page=media&success=File deleted');
        } else {
            header('Location: ../index.php?page=media&error=Execution failed');
        }
    } else {
        header('Location: ../index.php?page=media&error=Invalid file path');
    }
}
