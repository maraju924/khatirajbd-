<?php
// admin/actions/category-update.php
session_start();
require_once __DIR__ . '/../includes/auth-guard.php';
require_once '../../config/database.php';

header('Content-Type: application/json');

if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    echo json_encode(['status' => 'error', 'message' => 'Unauthorized']);
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = $_POST['id'];
    $name = trim($_POST['name']);
    $status = (int)$_POST['status'];
    $h1_title = trim($_POST['h1_title'] ?? '');
    $description = trim($_POST['description'] ?? '');
    $meta_title = trim($_POST['meta_title'] ?? '');
    $meta_description = trim($_POST['meta_description'] ?? '');
    $meta_keywords = trim($_POST['meta_keywords'] ?? '');
    
    // Update slug
    $slug = !empty($_POST['slug']) ? trim($_POST['slug']) : $name;
    $slug = mb_strtolower($slug, 'UTF-8');
    $slug = preg_replace('/[^\w\x{0980}-\x{09FF}-]+/u', '-', $slug);
    $slug = preg_replace('/-+/', '-', $slug);
    $slug = trim($slug, '-');

    if (empty($slug)) {
        $slug = 'category-' . $id;
    }

    $original_slug = $slug;
    $count = 1;
    while (true) {
        $stmt_check = $pdo->prepare("SELECT COUNT(*) FROM categories WHERE slug = ? AND id != ?");
        $stmt_check->execute([$slug, $id]);
        if ($stmt_check->fetchColumn() == 0) {
            break;
        }
        $slug = $original_slug . '-' . $count;
        $count++;
    }

    try {
        // Image Handling (Media Manager or Upload)
        $imagePath = $_POST['image'] ?? NULL;
        
        // Check for legacy upload
        if (isset($_FILES['image']) && $_FILES['image']['error'] == 0) {
            $targetDir = "../../uploads/categories/";
            if (!file_exists($targetDir)) mkdir($targetDir, 0777, true);
            
            $fileName = time() . '_' . basename($_FILES["image"]["name"]);
            $targetFilePath = $targetDir . $fileName;
            
            if (move_uploaded_file($_FILES["image"]["tmp_name"], $targetFilePath)) {
                $imagePath = "uploads/categories/" . $fileName;
            }
        }

        if ($imagePath !== NULL) {
            $stmt = $pdo->prepare("UPDATE categories SET name = ?, slug = ?, status = ?, image = ?, h1_title = ?, description = ?, meta_title = ?, meta_description = ?, meta_keywords = ? WHERE id = ?");
            $stmt->execute([$name, $slug, $status, $imagePath, $h1_title, $description, $meta_title, $meta_description, $meta_keywords, $id]);
        } else {
            // No image update
            $stmt = $pdo->prepare("UPDATE categories SET name = ?, slug = ?, status = ?, h1_title = ?, description = ?, meta_title = ?, meta_description = ?, meta_keywords = ? WHERE id = ?");
            $stmt->execute([$name, $slug, $status, $h1_title, $description, $meta_title, $meta_description, $meta_keywords, $id]);
        }
        
        // Fetch the updated category for UI update
        $stmt_fetch = $pdo->prepare("SELECT * FROM categories WHERE id = ?");
        $stmt_fetch->execute([$id]);
        $updated_category = $stmt_fetch->fetch();

        echo json_encode(['status' => 'success', 'message' => 'Category updated successfully', 'data' => $updated_category]);
    } catch (PDOException $e) {
        echo json_encode(['status' => 'error', 'message' => $e->getMessage()]);
    }
}
?>
