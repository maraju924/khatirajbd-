<?php
// admin/actions/category-toggle-status.php
session_start();
require_once __DIR__ . '/../includes/auth-guard.php';
require_once '../../config/database.php';

header('Content-Type: application/json');

if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    echo json_encode(['status' => 'error', 'message' => 'Unauthorized']);
    exit();
}

$id = $_GET['id'] ?? null;
if (!$id) {
    echo json_encode(['status' => 'error', 'message' => 'Category ID required']);
    exit();
}

try {
    $stmt = $pdo->prepare("SELECT status FROM categories WHERE id = ?");
    $stmt->execute([$id]);
    $current = $stmt->fetchColumn();

    if ($current === false) {
        echo json_encode(['status' => 'error', 'message' => 'Category not found']);
        exit();
    }

    $new_status = $current ? 0 : 1;
    $stmt_update = $pdo->prepare("UPDATE categories SET status = ? WHERE id = ?");
    $stmt_update->execute([$new_status, $id]);

    echo json_encode([
        'status' => 'success',
        'message' => $new_status ? 'Category activated successfully' : 'Category deactivated successfully',
        'new_status' => $new_status
    ]);
} catch (PDOException $e) {
    echo json_encode(['status' => 'error', 'message' => $e->getMessage()]);
}
exit();
