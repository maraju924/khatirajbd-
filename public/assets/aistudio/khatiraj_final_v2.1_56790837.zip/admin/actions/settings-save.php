<?php
// admin/actions/settings-save.php
session_start();
require_once __DIR__ . '/../includes/auth-guard.php';
require_once '../../config/database.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // List of allowed keys to update
    $allowed_keys = [
        'site_name', 'support_phone', 'support_email', 'address',
        'footer_about_text', 'footer_copyright', 'footer_col2_title', 'footer_col3_title',
        'facebook_url', 'youtube_url', 'instagram_url',
        'steadfast_api_key', 'steadfast_secret_key', 'steadfast_note',
        'site_logo', 'whatsapp_number', 'whatsapp_message', 'enable_whatsapp', 'enable_sticky_order', 'enable_sales_popup',
        'sms_enabled', 'sms_provider', 'sms_api_key', 'sms_sender_id',
        'sms_order_placed_text', 'sms_order_shipped_text', 'sms_order_delivered_text',
        'abandoned_cart_enabled', 'abandoned_cart_delay_minutes', 'abandoned_cart_max_reminders',
        'abandoned_cart_sms_text', 'abandoned_cart_whatsapp_text', 'abandoned_cart_whatsapp_enabled',
        'wa_api_enabled', 'wa_api_token', 'wa_phone_number_id',
        'email_enabled', 'smtp_host', 'smtp_port', 'smtp_user', 'smtp_pass', 'smtp_encryption', 'email_digital_delivery_text',
        'global_meta_title_suffix', 'global_meta_description', 'global_meta_keywords', 'global_og_image', 'site_favicon'
    ];

    try {
        $pdo->beginTransaction();

        foreach ($allowed_keys as $key) {
            if (isset($_POST[$key])) {
                $value = trim($_POST[$key]);
                
                // Use INSERT ... ON DUPLICATE KEY UPDATE logic
                $stmt = $pdo->prepare("INSERT INTO settings (key_name, value) VALUES (?, ?) ON DUPLICATE KEY UPDATE value = ?");
                $stmt->execute([$key, $value, $value]);
            }
        }

        // Handle Logo Upload
        if (isset($_FILES['site_logo']) && $_FILES['site_logo']['error'] === UPLOAD_ERR_OK) {
            $upload_dir = '../../uploads/logo/';
            if (!is_dir($upload_dir)) mkdir($upload_dir, 0777, true);

            $file_ext = strtolower(pathinfo($_FILES['site_logo']['name'], PATHINFO_EXTENSION));
            $new_name = 'logo_' . time() . '.' . $file_ext;
            $upload_path = $upload_dir . $new_name;
            $db_path = 'uploads/logo/' . $new_name;

            if (move_uploaded_file($_FILES['site_logo']['tmp_name'], $upload_path)) {
                // Get old logo to delete
                $stmt = $pdo->prepare("SELECT value FROM settings WHERE key_name = 'site_logo'");
                $stmt->execute();
                $old_logo = $stmt->fetchColumn();
                if ($old_logo && file_exists('../../' . $old_logo)) {
                    unlink('../../' . $old_logo);
                }

                $stmt = $pdo->prepare("INSERT INTO settings (key_name, value) VALUES ('site_logo', ?) ON DUPLICATE KEY UPDATE value = ?");
                $stmt->execute([$db_path, $db_path]);
            }
        }

        $pdo->commit();
        require_once __DIR__ . '/../../app/Helpers/CacheHelper.php';
        CacheHelper::invalidateSiteData();

        // Allow forms on other pages (e.g. courier dashboard) to return to themselves
        $redirect_page = 'settings';
        if (($_POST['redirect_to'] ?? '') === 'courier-dashboard&tab=settings') {
            $redirect_page = 'courier-dashboard&tab=settings';
        }
        header('Location: ../index.php?page=' . $redirect_page . '&success=Settings updated successfully');
        
    } catch (PDOException $e) {
        $pdo->rollBack();
        header('Location: ../index.php?page=settings&error=' . urlencode($e->getMessage()));
    }
}
