<?php
// admin/actions/menu-action.php
session_start();
require_once __DIR__ . '/../includes/auth-guard.php';
require_once '../../config/database.php';
require_once __DIR__ . '/../../app/Helpers/CacheHelper.php';

if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    echo json_encode(['status' => 'error', 'message' => 'Unauthorized']);
    exit();
}

$action = $_GET['action'] ?? '';
header('Content-Type: application/json');

if ($action == 'add' && $_SERVER['REQUEST_METHOD'] == 'POST') {
    $title = $_POST['title'];
    $url = $_POST['url'];
    $parent_id = !empty($_POST['parent_id']) ? $_POST['parent_id'] : null;
    $sort_order = !empty($_POST['sort_order']) ? (int)$_POST['sort_order'] : 0;

    $location = $_POST['location'] ?? 'header';

    try {
        $stmt = $pdo->prepare("INSERT INTO menus (title, url, parent_id, sort_order, location) VALUES (?, ?, ?, ?, ?)");
        $stmt->execute([$title, $url, $parent_id, $sort_order, $location]);
        $id = $pdo->lastInsertId();
        CacheHelper::forget('menus_header');
        CacheHelper::forget('menus_footer');
        
        // Fetch the new item with parent title for UI update
        $new_item = $pdo->query("SELECT m1.*, m2.title as parent_title 
                                FROM menus m1 
                                LEFT JOIN menus m2 ON m1.parent_id = m2.id 
                                WHERE m1.id = $id")->fetch();

        echo json_encode(['status' => 'success', 'message' => 'Menu item added successfully', 'data' => $new_item]);
    } catch (PDOException $e) {
        echo json_encode(['status' => 'error', 'message' => $e->getMessage()]);
    }
}

elseif ($action == 'edit' && $_SERVER['REQUEST_METHOD'] == 'POST') {
    $id = $_POST['id'];
    $title = $_POST['title'];
    $url = $_POST['url'];
    $parent_id = !empty($_POST['parent_id']) ? $_POST['parent_id'] : null;
    $sort_order = !empty($_POST['sort_order']) ? (int)$_POST['sort_order'] : 0;
    $status = $_POST['status'];
    $location = $_POST['location'] ?? 'header';

    try {
        $stmt = $pdo->prepare("UPDATE menus SET title = ?, url = ?, parent_id = ?, sort_order = ?, status = ?, location = ? WHERE id = ?");
        $stmt->execute([$title, $url, $parent_id, $sort_order, $status, $location, $id]);
        CacheHelper::forget('menus_header');
        CacheHelper::forget('menus_footer');
        
        // Fetch the updated item
        $updated_item = $pdo->query("SELECT m1.*, m2.title as parent_title 
                                   FROM menus m1 
                                   LEFT JOIN menus m2 ON m1.parent_id = m2.id 
                                   WHERE m1.id = $id")->fetch();

        echo json_encode(['status' => 'success', 'message' => 'Menu item updated successfully', 'data' => $updated_item]);
    } catch (PDOException $e) {
        echo json_encode(['status' => 'error', 'message' => $e->getMessage()]);
    }
}

elseif ($action == 'delete' && isset($_GET['id'])) {
    $id = $_GET['id'];
    try {
        $stmt = $pdo->prepare("DELETE FROM menus WHERE id = ?");
        $stmt->execute([$id]);
        CacheHelper::forget('menus_header');
        CacheHelper::forget('menus_footer');
        echo json_encode(['status' => 'success', 'message' => 'Menu item deleted successfully']);
    } catch (PDOException $e) {
        echo json_encode(['status' => 'error', 'message' => $e->getMessage()]);
    }
}

else {
    echo json_encode(['status' => 'error', 'message' => 'Invalid action']);
}
?>
