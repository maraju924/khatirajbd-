<?php
// admin/actions/product-update.php
session_start();
require_once __DIR__ . '/../includes/auth-guard.php';
require_once '../../config/database.php';
require_once '../../app/Helpers/ImageHelper.php';
use App\Helpers\ImageHelper;

// Check if it's an AJAX request
$is_ajax = !empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest';

if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    if ($is_ajax) {
        header('Content-Type: application/json');
        echo json_encode(['success' => false, 'message' => 'Not authorized']);
        exit;
    }
    header('Location: ../login.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = $_POST['id'];
    $name = $_POST['name'];
    $category_id = $_POST['category_id'];
    $price = $_POST['price'];
    $offer_price = !empty($_POST['offer_price']) ? $_POST['offer_price'] : NULL;
    if ($offer_price !== null && (float) $offer_price >= (float) $price) {
        $msg = 'Offer price must be less than regular price.';
        if ($is_ajax) {
            header('Content-Type: application/json');
            echo json_encode(['success' => false, 'message' => $msg]);
            exit;
        }
        header('Location: ../index.php?page=edit-product&id=' . urlencode($id) . '&error=' . urlencode($msg));
        exit;
    }
    $quantity = $_POST['quantity'];
    $description = $_POST['description'];
    $benefits_title = $_POST['benefits_title'] ?? 'উপকারিতা:';
    $benefits = $_POST['benefits'] ?? NULL;
    $trust_title = $_POST['trust_title'] ?? 'কেন আমাদের থেকে নিবেন?';
    $trust_points = $_POST['trust_points'] ?? NULL;
    $details_title = $_POST['details_title'] ?? 'বিস্তারিত বিবরণ:';
    $video_url = $_POST['video_url'] ?? NULL;
    $stock_status = $_POST['stock_status'] ?? 'In Stock';
    $shipping_class_id = !empty($_POST['shipping_class_id']) ? $_POST['shipping_class_id'] : NULL;

    // Slug generation & uniqueness check
    $slug = !empty($_POST['slug']) ? trim($_POST['slug']) : $name;
    $slug = mb_strtolower($slug, 'UTF-8');
    $slug = preg_replace('/[^\w\x{0980}-\x{09FF}-]+/u', '-', $slug);
    $slug = preg_replace('/-+/', '-', $slug);
    $slug = trim($slug, '-');

    if (empty($slug)) {
        $slug = 'product-' . $id;
    }

    $original_slug = $slug;
    $count = 1;
    while (true) {
        $stmt_check = $pdo->prepare("SELECT COUNT(*) FROM products WHERE slug = ? AND id != ?");
        $stmt_check->execute([$slug, $id]);
        if ($stmt_check->fetchColumn() == 0) {
            break;
        }
        $slug = $original_slug . '-' . $count;
        $count++;
    }

    // Image Handling (Media Manager or Upload)
    $imagePath = $_POST['image'] ?? NULL;
    $projectRoot = realpath(__DIR__ . '/../..');

    if (!ImageHelper::isGdAvailable() && (isset($_FILES['image']) || !empty($imagePath))) {
        $msg = 'PHP GD extension is required for product images. Enable extension=gd in php.ini and restart Apache.';
        if ($is_ajax) {
            header('Content-Type: application/json');
            echo json_encode(['success' => false, 'message' => $msg]);
            exit;
        }
        die($msg);
    }

    // Direct file upload → 600x600 WebP
    if (isset($_FILES['image']) && $_FILES['image']['error'] == 0) {
        $targetDir = $projectRoot . DIRECTORY_SEPARATOR . 'uploads' . DIRECTORY_SEPARATOR . 'products' . DIRECTORY_SEPARATOR;
        $tempPath = $targetDir . 'tmp_' . uniqid('', true);

        if (move_uploaded_file($_FILES['image']['tmp_name'], $tempPath)) {
            $converted = ImageHelper::saveUploadedProductImage($tempPath, $_FILES['image']['name'], $targetDir);
            if ($converted) {
                $imagePath = $converted;
            }
        }
    } elseif (!empty($imagePath)) {
        $imagePath = ImageHelper::ensureProductWebp($imagePath, $projectRoot);
    }

    $product_type = $_POST['product_type'] ?? 'physical';
    $digital_file_url = !empty($_POST['digital_file_url']) ? $_POST['digital_file_url'] : NULL;
    $show_on_website = isset($_POST['show_on_website']) ? 1 : 0;

    try {
        $meta_title = $_POST['meta_title'] ?? NULL;
        $meta_description = $_POST['meta_description'] ?? NULL;
        $brand = $_POST['brand'] ?? NULL;
        $sku = $_POST['sku'] ?? NULL;
        $meta_keywords = $_POST['meta_keywords'] ?? NULL;
        $focus_keyword = $_POST['focus_keyword'] ?? NULL;
        $image_alt_text = $_POST['image_alt_text'] ?? NULL;
        $weight = $_POST['weight'] ?? NULL;
        $dimensions = $_POST['dimensions'] ?? NULL;

        if ($imagePath) {
            $sql = "UPDATE products SET category_id=?, name=?, slug=?, brand=?, sku=?, product_type=?, digital_file_url=?, price=?, offer_price=?, quantity=?, weight=?, dimensions=?, description=?, image=?, image_alt_text=?, benefits_title=?, benefits=?, trust_title=?, trust_points=?, details_title=?, video_url=?, stock_status=?, shipping_class_id=?, meta_title=?, meta_description=?, meta_keywords=?, focus_keyword=?, show_on_website=? WHERE id=?";
            $params = [$category_id, $name, $slug, $brand, $sku, $product_type, $digital_file_url, $price, $offer_price, $quantity, $weight, $dimensions, $description, $imagePath, $image_alt_text, $benefits_title, $benefits, $trust_title, $trust_points, $details_title, $video_url, $stock_status, $shipping_class_id, $meta_title, $meta_description, $meta_keywords, $focus_keyword, $show_on_website, $id];
        } else {
            $sql = "UPDATE products SET category_id=?, name=?, slug=?, brand=?, sku=?, product_type=?, digital_file_url=?, price=?, offer_price=?, quantity=?, weight=?, dimensions=?, description=?, image_alt_text=?, benefits_title=?, benefits=?, trust_title=?, trust_points=?, details_title=?, video_url=?, stock_status=?, shipping_class_id=?, meta_title=?, meta_description=?, meta_keywords=?, focus_keyword=?, show_on_website=? WHERE id=?";
            $params = [$category_id, $name, $slug, $brand, $sku, $product_type, $digital_file_url, $price, $offer_price, $quantity, $weight, $dimensions, $description, $image_alt_text, $benefits_title, $benefits, $trust_title, $trust_points, $details_title, $video_url, $stock_status, $shipping_class_id, $meta_title, $meta_description, $meta_keywords, $focus_keyword, $show_on_website, $id];
        }

        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);

        // Handle Dynamic Product Sections Sync
        // Delete existing sections (which cascades to items)
        $pdo->prepare("DELETE FROM product_sections WHERE product_id = ?")->execute([$id]);
        
        if (isset($_POST['sections']) && is_array($_POST['sections'])) {
            $stmt_sec = $pdo->prepare("INSERT INTO product_sections (product_id, title, icon, sort_order) VALUES (?, ?, ?, ?)");
            $stmt_item = $pdo->prepare("INSERT INTO product_section_items (section_id, text_content, sort_order) VALUES (?, ?, ?)");
            
            $sec_order = 1;
            foreach ($_POST['sections'] as $sec) {
                if (empty(trim($sec['title']))) continue;
                
                $title = trim($sec['title']);
                $icon = !empty(trim($sec['icon'])) ? trim($sec['icon']) : 'fas fa-check-circle';
                
                $stmt_sec->execute([$id, $title, $icon, $sec_order++]);
                $section_id = $pdo->lastInsertId();
                
                if (isset($sec['items']) && is_array($sec['items'])) {
                    $item_order = 1;
                    foreach ($sec['items'] as $item_text) {
                        $item_text = trim($item_text);
                        if (empty($item_text)) continue;
                        $stmt_item->execute([$section_id, $item_text, $item_order++]);
                    }
                }
            }
        }

        // Handle Gallery Images Sync
        if (isset($_POST['gallery_images'])) {
            // Delete old gallery images
            $stmt_del = $pdo->prepare("DELETE FROM product_images WHERE product_id = ?");
            $stmt_del->execute([$id]);

            // Insert new gallery images
            $gallery = json_decode($_POST['gallery_images'], true);
            if (is_array($gallery)) {
                $stmt_ins = $pdo->prepare("INSERT INTO product_images (product_id, image_path) VALUES (?, ?)");
                foreach ($gallery as $img_p) {
                    $img_p = ImageHelper::ensureProductWebp($img_p, $projectRoot);
                    $stmt_ins->execute([$id, $img_p]);
                }
            }
        }

        // Handle Shipping Zones Sync
        if (isset($_POST['shipping_zones']) && is_array($_POST['shipping_zones'])) {
            // Delete old zones
            $stmt_sz_del = $pdo->prepare("DELETE FROM product_shipping_zones WHERE product_id = ?");
            $stmt_sz_del->execute([$id]);

            // Insert new zones
            $stmt_sz_ins = $pdo->prepare("INSERT INTO product_shipping_zones (product_id, shipping_zone_id) VALUES (?, ?)");
            foreach ($_POST['shipping_zones'] as $zone_id) {
                $stmt_sz_ins->execute([$id, $zone_id]);
            }
        }

        // Handle Payment Methods Sync
        $allow_cod = isset($_POST['payment_method_cod']) ? 1 : 0;
        $pdo->prepare("UPDATE products SET allow_cod = ? WHERE id = ?")->execute([$allow_cod, $id]);

        if (isset($_POST['payment_methods']) && is_array($_POST['payment_methods'])) {
            // Delete old methods
            $stmt_pm_del = $pdo->prepare("DELETE FROM product_payment_methods WHERE product_id = ?");
            $stmt_pm_del->execute([$id]);

            // Insert new methods
            $stmt_pm_ins = $pdo->prepare("INSERT INTO product_payment_methods (product_id, payment_method_id) VALUES (?, ?)");
            foreach ($_POST['payment_methods'] as $pm_id) {
                $stmt_pm_ins->execute([$id, $pm_id]);
            }
        }

        require_once __DIR__ . '/../../app/Helpers/ProductVariantHelper.php';
        ProductVariantHelper::saveFromPost($pdo, (int) $id, $_POST);
        
        if (!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest') {
            echo json_encode(['success' => true, 'message' => 'Product updated successfully']);
            exit;
        }

        header('Location: ../index.php?page=products&success=Product updated successfully');
    } catch (PDOException $e) {
        error_log('Product update error: ' . $e->getMessage());
        if (!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest') {
            echo json_encode(['success' => false, 'message' => 'Could not update product. Please try again.']);
            exit;
        }
        header('Location: ../index.php?page=products&error=' . urlencode('Could not update product. Please try again.'));
        exit;
    }
}
exit();
