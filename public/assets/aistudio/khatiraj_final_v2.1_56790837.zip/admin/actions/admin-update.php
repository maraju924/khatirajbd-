<?php
// admin/actions/admin-update.php
session_start();
require_once __DIR__ . '/../includes/auth-guard.php';
require_once '../../config/database.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = $_POST['id'];
    $name = trim($_POST['name']);
    $email = trim($_POST['email']);
    $role = $_POST['role'];
    $password = $_POST['password'] ?? '';

    // Check if it's an AJAX request
    $is_ajax = !empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest';

    if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
        if ($is_ajax) {
            header('Content-Type: application/json');
            echo json_encode(['success' => false, 'message' => 'Not authorized']);
            exit;
        }
        header('Location: ../login.php');
        exit;
    }

    // Validation
    if (empty($name) || empty($email)) {
        $error_msg = 'Name and Email are required';
        if ($is_ajax) {
            header('Content-Type: application/json');
            echo json_encode(['success' => false, 'message' => $error_msg]);
            exit;
        }
        header('Location: ../index.php?page=edit-admin&id='.$id.'&error=' . urlencode($error_msg));
        exit;
    }

    // Check email uniqueness (exclude current admin)
    $stmt_check = $pdo->prepare("SELECT id FROM admins WHERE email = ? AND id != ?");
    $stmt_check->execute([$email, $id]);
    if ($stmt_check->fetch()) {
        $error_msg = 'Email already exists for another admin';
        if ($is_ajax) {
            header('Content-Type: application/json');
            echo json_encode(['success' => false, 'message' => $error_msg]);
            exit;
        }
        header('Location: ../index.php?page=edit-admin&id='.$id.'&error=' . urlencode($error_msg));
        exit;
    }

    try {
        if (!empty($password)) {
            if (strlen($password) < 6) {
                $error_msg = 'Password must be at least 6 characters';
                if ($is_ajax) {
                    header('Content-Type: application/json');
                    echo json_encode(['success' => false, 'message' => $error_msg]);
                    exit;
                }
                header('Location: ../index.php?page=edit-admin&id='.$id.'&error=' . urlencode($error_msg));
                exit;
            }
            $hashed = password_hash($password, PASSWORD_BCRYPT);
            $stmt = $pdo->prepare("UPDATE admins SET name = ?, email = ?, role = ?, password = ? WHERE id = ?");
            $stmt->execute([$name, $email, $role, $hashed, $id]);
        } else {
            $stmt = $pdo->prepare("UPDATE admins SET name = ?, email = ?, role = ? WHERE id = ?");
            $stmt->execute([$name, $email, $role, $id]);
        }

        // If editing own account, update session
        if ($email === $_SESSION['admin_email'] || $id == ($_SESSION['admin_id'] ?? null)) {
            $_SESSION['admin_name'] = $name;
            $_SESSION['admin_email'] = $email;
            $_SESSION['admin_role'] = $role;
        }
        
        $success_msg = 'Admin updated successfully';
        if ($is_ajax) {
            header('Content-Type: application/json');
            echo json_encode(['success' => true, 'message' => $success_msg]);
            exit;
        }
        header('Location: ../index.php?page=admins&success=' . urlencode($success_msg));
    } catch (PDOException $e) {
        $error_msg = 'Database Error: ' . $e->getMessage();
        if ($is_ajax) {
            header('Content-Type: application/json');
            echo json_encode(['success' => false, 'message' => $error_msg]);
            exit;
        }
        header('Location: ../index.php?page=edit-admin&id='.$id.'&error=' . urlencode($error_msg));
    }
}
exit();
