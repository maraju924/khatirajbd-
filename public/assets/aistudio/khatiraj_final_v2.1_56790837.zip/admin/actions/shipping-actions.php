<?php
// admin/actions/shipping-actions.php
session_start();
require_once __DIR__ . '/../includes/auth-guard.php';
require_once '../../config/database.php';

// Check if admin is logged in
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header('Location: ../login.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    $type = $_POST['type'] ?? ''; // 'zone' or 'class'

    if ($type === 'zone') {
        $id = (int)($_POST['id'] ?? 0);
        $name = trim($_POST['name'] ?? '');
        $charge = (float)($_POST['charge'] ?? 0);
        $status = (int)($_POST['status'] ?? 1);

        try {
            if ($action === 'add') {
                $stmt = $pdo->prepare("INSERT INTO shipping_zones (name, charge, status) VALUES (?, ?, ?)");
                $stmt->execute([$name, $charge, $status]);
                $msg = "Zone added successfully";
            } elseif ($action === 'edit') {
                $stmt = $pdo->prepare("UPDATE shipping_zones SET name = ?, charge = ?, status = ? WHERE id = ?");
                $stmt->execute([$name, $charge, $status, $id]);
                $msg = "Zone updated successfully";
            } elseif ($action === 'delete') {
                $stmt = $pdo->prepare("DELETE FROM shipping_zones WHERE id = ?");
                $stmt->execute([$id]);
                $msg = "Zone deleted successfully";
            }
            header("Location: ../index.php?page=shipping&success=" . urlencode($msg));
            exit();
        } catch (PDOException $e) {
            header("Location: ../index.php?page=shipping&error=" . urlencode($e->getMessage()));
            exit();
        }
    } elseif ($type === 'class') {
        $id = (int)($_POST['id'] ?? 0);
        $name = trim($_POST['name'] ?? '');
        $extra_charge = (float)($_POST['extra_charge'] ?? 0);
        $status = (int)($_POST['status'] ?? 1);

        try {
            if ($action === 'add') {
                $stmt = $pdo->prepare("INSERT INTO shipping_classes (name, extra_charge, status) VALUES (?, ?, ?)");
                $stmt->execute([$name, $extra_charge, $status]);
                $msg = "Shipping class added successfully";
            } elseif ($action === 'edit') {
                $stmt = $pdo->prepare("UPDATE shipping_classes SET name = ?, extra_charge = ?, status = ? WHERE id = ?");
                $stmt->execute([$name, $extra_charge, $status, $id]);
                $msg = "Shipping class updated successfully";
            } elseif ($action === 'delete') {
                $stmt = $pdo->prepare("DELETE FROM shipping_classes WHERE id = ?");
                $stmt->execute([$id]);
                $msg = "Shipping class deleted successfully";
            }
            header("Location: ../index.php?page=shipping&success=" . urlencode($msg));
            exit();
        } catch (PDOException $e) {
            header("Location: ../index.php?page=shipping&error=" . urlencode($e->getMessage()));
            exit();
        }
    }
}
