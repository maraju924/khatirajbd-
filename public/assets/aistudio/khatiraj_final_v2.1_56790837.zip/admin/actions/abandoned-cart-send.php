<?php
session_start();
require_once __DIR__ . '/../includes/auth-guard.php';
require_once '../../config/database.php';
require_once '../../app/Services/AbandonedCartService.php';
require_once '../../app/Helpers/WhatsAppHelper.php';

if (!isset($_SESSION['admin_logged_in']) || !in_array($_SESSION['admin_role'] ?? '', ['super_admin', 'moderator'])) {
    header('Location: ../login.php');
    exit;
}

$id = (int) ($_GET['id'] ?? 0);
if ($id <= 0) {
    header('Location: ../index.php?page=abandoned-carts&error=Invalid+cart');
    exit;
}

$stmt = $pdo->prepare("SELECT * FROM abandoned_carts WHERE id = ? AND status = 'active'");
$stmt->execute([$id]);
$cart = $stmt->fetch();

if (!$cart || empty($cart['customer_phone'])) {
    header('Location: ../index.php?page=abandoned-carts&error=Cart+not+found+or+no+phone');
    exit;
}

$service = new AbandonedCartService($pdo);
$waHelper = new \App\Helpers\WhatsAppHelper($pdo);

// Get the rendered message template & create direct WhatsApp chat link
$waMessage = $service->getWhatsAppPreviewMessage($cart);
$waLink = $waHelper->buildChatLink($cart['customer_phone'], $waMessage);

// Update database recovery counters for this cart
$stmt = $pdo->prepare("
    UPDATE abandoned_carts SET
        whatsapp_sent_count = whatsapp_sent_count + 1,
        last_reminder_at = NOW()
    WHERE id = ?
");
$stmt->execute([$id]);

// Redirect admin directly to the customer's WhatsApp chat with the pre-filled message
header('Location: ' . $waLink);
exit;
