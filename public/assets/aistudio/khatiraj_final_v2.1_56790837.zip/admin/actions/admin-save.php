<?php
// admin/actions/admin-save.php
session_start();
require_once __DIR__ . '/../includes/auth-guard.php';
require_once '../../config/database.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name']);
    $email = trim($_POST['email']);
    $password = $_POST['password'];
    $role = $_POST['role'];

    // Check if it's an AJAX request
    $is_ajax = !empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest';

    if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
        if ($is_ajax) {
            header('Content-Type: application/json');
            echo json_encode(['success' => false, 'message' => 'Not authorized']);
            exit;
        }
        header('Location: ../login.php');
        exit;
    }

    // Basic Validation
    if (empty($name) || empty($email) || empty($password)) {
        if ($is_ajax) {
            header('Content-Type: application/json');
            echo json_encode(['success' => false, 'message' => 'All fields are required']);
            exit;
        }
        header('Location: ../index.php?page=add-admin&error=All fields are required');
        exit;
    }

    try {
        // Initials check if email exists
        $stmt = $pdo->prepare("SELECT id FROM admins WHERE email = ?");
        $stmt->execute([$email]);
        if ($stmt->rowCount() > 0) {
            if ($is_ajax) {
                header('Content-Type: application/json');
                echo json_encode(['success' => false, 'message' => 'Email already registered']);
                exit;
            }
            header('Location: ../index.php?page=add-admin&error=Email already registered');
            exit;
        }

        // Create Admin using the same logic as profile
        $hashed = password_hash($password, PASSWORD_BCRYPT);
        
        $stmt = $pdo->prepare("INSERT INTO admins (name, email, password, role) VALUES (?, ?, ?, ?)");
        $stmt->execute([$name, $email, $hashed, $role]);

        if ($is_ajax) {
            header('Content-Type: application/json');
            echo json_encode(['success' => true, 'message' => 'New admin created successfully']);
            exit;
        }
        header('Location: ../index.php?page=admins&success=New admin created');

    } catch (PDOException $e) {
        if ($is_ajax) {
            header('Content-Type: application/json');
            echo json_encode(['success' => false, 'message' => $e->getMessage()]);
            exit;
        }
        header('Location: ../index.php?page=add-admin&error=' . urlencode($e->getMessage()));
    }
}
