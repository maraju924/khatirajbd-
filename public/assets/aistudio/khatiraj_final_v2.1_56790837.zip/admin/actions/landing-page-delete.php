<?php
/**
 * Admin Action - Delete Landing Page
 */

session_start();
require_once __DIR__ . '/../includes/auth-guard.php';
require_once '../../config/database.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: ../index.php?page=landing-pages');
    exit;
}

try {
    $id = (int)$_POST['id'];
    
    // Get current landing page for image cleanup
    $current_stmt = $pdo->prepare("SELECT hero_image FROM landing_pages WHERE id = ?");
    $current_stmt->execute([$id]);
    $current = $current_stmt->fetch(PDO::FETCH_ASSOC);
    
    // Delete hero image if exists
    if (!empty($current['hero_image']) && file_exists('../../' . $current['hero_image'])) {
        unlink('../../' . $current['hero_image']);
    }
    
    // Check if it's an AJAX request
    $is_ajax = !empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest';

    // Delete landing page
    $stmt = $pdo->prepare("DELETE FROM landing_pages WHERE id = ?");
    $stmt->execute([$id]);
    
    if ($is_ajax) {
        header('Content-Type: application/json');
        echo json_encode(['success' => true, 'message' => 'deleted']);
        exit;
    }
    
    header('Location: ../index.php?page=landing-pages&success=deleted');
    exit;
    
} catch (PDOException $e) {
    if ($is_ajax) {
        header('Content-Type: application/json');
        echo json_encode(['success' => false, 'message' => 'ডিলিট করতে সমস্যা হয়েছে: ' . $e->getMessage()]);
        exit;
    }
    header('Location: ../index.php?page=landing-pages&error=' . urlencode('ডিলিট করতে সমস্যা হয়েছে'));
    exit;
}
?>
