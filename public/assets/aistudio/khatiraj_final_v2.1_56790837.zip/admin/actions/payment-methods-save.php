<?php
// admin/actions/payment-methods-save.php
session_start();
require_once __DIR__ . '/../includes/auth-guard.php';
require_once '../../config/database.php';
require_once '../../app/Services/PaymentGateway.php';

if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header('Location: ../login.php');
    exit;
}

$paymentGateway = new PaymentGateway($pdo);
$action = $_POST['action'] ?? '';
$id = intval($_POST['id'] ?? 0);

try {
    switch ($action) {
        case 'toggle':
            if ($id) {
                $paymentGateway->togglePaymentMethod($id);
                header('Location: ../index.php?page=payment-methods&success=Payment method status updated');
            }
            break;

        case 'update':
            if ($id) {
                $data = [
                    'account_number' => $_POST['account_number'] ?? '',
                    'account_name' => $_POST['account_name'] ?? '',
                    'logo' => $_POST['logo'] ?? '',
                    'charge_type' => $_POST['charge_type'] ?? 'fixed',
                    'charge_amount' => floatval($_POST['charge_amount'] ?? 0),
                    'instructions' => $_POST['instructions'] ?? ''
                ];
                
                // Handle API credentials for payment gateways (Zinipay etc.)
                if (!empty($_POST['api_key'])) {
                    $data['credentials'] = json_encode(['api_key' => $_POST['api_key']]);
                }
                
                $paymentGateway->updatePaymentMethod($id, $data);
                header('Location: ../index.php?page=payment-methods&success=Payment method updated successfully');
            }
            break;

        case 'add':
            $data = [
                'name' => $_POST['name'] ?? '',
                'slug' => $_POST['slug'] ?? '',
                'type' => $_POST['type'] ?? 'mobile_banking',
                'account_number' => $_POST['account_number'] ?? '',
                'account_name' => $_POST['account_name'] ?? '',
                'logo' => $_POST['logo'] ?? 'default.png',
                'charge_type' => $_POST['charge_type'] ?? 'fixed',
                'charge_amount' => floatval($_POST['charge_amount'] ?? 0),
                'instructions' => $_POST['instructions'] ?? '',
                'is_active' => 1
            ];
            
            // Handle API credentials for payment gateways (Zinipay etc.)
            if (!empty($_POST['api_key'])) {
                $data['credentials'] = json_encode(['api_key' => $_POST['api_key']]);
            }
            
            // Simple slug validation (check if exists)
            $existing = $paymentGateway->getMethodBySlug($data['slug']);
            if ($existing) {
                header('Location: ../index.php?page=payment-methods&error=Slug already exists');
                exit;
            }

            $paymentGateway->addPaymentMethod($data);
            header('Location: ../index.php?page=payment-methods&success=New payment method added');
            break;

        case 'delete':
            if ($id) {
                $paymentGateway->deletePaymentMethod($id);
                header('Location: ../index.php?page=payment-methods&success=Payment method deleted');
            }
            break;

        default:
            header('Location: ../index.php?page=payment-methods&error=Invalid action');
    }
} catch (Exception $e) {
    header('Location: ../index.php?page=payment-methods&error=' . urlencode($e->getMessage()));
}
exit;
