<?php
// admin/actions/add-user.php
session_start();
require_once __DIR__ . '/../includes/auth-guard.php';
require_once '../../config/database.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name']);
    $email = trim($_POST['email']);
    $phone = trim($_POST['phone']);
    $password = $_POST['password'];
    $address = trim($_POST['address']);

    // Check if it's an AJAX request
    $is_ajax = !empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest';

    if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
        if ($is_ajax) {
            header('Content-Type: application/json');
            echo json_encode(['success' => false, 'message' => 'Not authorized']);
            exit;
        }
        header('Location: ../login.php');
        exit;
    }

    // Validation
    if (empty($name) || empty($email) || empty($phone) || empty($password)) {
        if ($is_ajax) {
            header('Content-Type: application/json');
            echo json_encode(['success' => false, 'message' => 'All * marked fields are required.']);
            exit;
        }
        $_SESSION['error'] = "All * marked fields are required.";
        header("Location: ../index.php?page=add-user");
        exit;
    }

    // Check email/phone uniqueness
    $stmt = $pdo->prepare("SELECT id FROM users WHERE email = ? OR phone = ?");
    $stmt->execute([$email, $phone]);
    if ($stmt->fetch()) {
        if ($is_ajax) {
            header('Content-Type: application/json');
            echo json_encode(['success' => false, 'message' => 'User with this email or phone already exists.']);
            exit;
        }
        $_SESSION['error'] = "User with this email or phone already exists.";
        header("Location: ../index.php?page=add-user");
        exit;
    }

    try {
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);
        $stmt = $pdo->prepare("INSERT INTO users (name, email, phone, password, address) VALUES (?, ?, ?, ?, ?)");
        $stmt->execute([$name, $email, $phone, $hashed_password, $address]);

        if ($is_ajax) {
            header('Content-Type: application/json');
            echo json_encode(['success' => true, 'message' => 'User created successfully.']);
            exit;
        }
        $_SESSION['success'] = "User created successfully.";
        header("Location: ../index.php?page=customers");
    } catch (PDOException $e) {
        if ($is_ajax) {
            header('Content-Type: application/json');
            echo json_encode(['success' => false, 'message' => 'Database Error: ' . $e->getMessage()]);
            exit;
        }
        $_SESSION['error'] = "Database Error: " . $e->getMessage();
        header("Location: ../index.php?page=add-user");
    }
}
