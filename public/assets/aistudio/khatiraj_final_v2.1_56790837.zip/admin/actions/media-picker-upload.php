<?php
// admin/actions/media-picker-upload.php
session_start();
require_once __DIR__ . '/../includes/auth-guard.php';
require_once '../../config/database.php';
require_once '../../app/Helpers/ImageHelper.php';

use App\Helpers\ImageHelper;

header('Content-Type: application/json');

if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit;
}

if (!ImageHelper::isGdAvailable()) {
    echo json_encode(['success' => false, 'message' => 'PHP GD extension with WebP support is required. Enable extension=gd in php.ini.']);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !isset($_FILES['image']) || $_FILES['image']['error'] !== UPLOAD_ERR_OK) {
    echo json_encode(['success' => false, 'message' => 'Please select a valid image file.']);
    exit;
}

$folder = preg_replace('/[^a-z0-9_-]/i', '', $_POST['folder'] ?? 'products');
if ($folder === '') {
    $folder = 'products';
}

$projectRoot = realpath(__DIR__ . '/../..');
$targetDir = $projectRoot . DIRECTORY_SEPARATOR . 'uploads' . DIRECTORY_SEPARATOR . $folder . DIRECTORY_SEPARATOR;
if (!is_dir($targetDir) && !mkdir($targetDir, 0777, true) && !is_dir($targetDir)) {
    echo json_encode(['success' => false, 'message' => 'Could not create upload folder.']);
    exit;
}

$tempPath = $targetDir . 'tmp_' . uniqid('', true);
if (!move_uploaded_file($_FILES['image']['tmp_name'], $tempPath)) {
    echo json_encode(['success' => false, 'message' => 'Failed to save uploaded file.']);
    exit;
}

$relativePath = null;

if ($folder === 'products') {
    $relativePath = ImageHelper::saveUploadedProductImage($tempPath, $_FILES['image']['name'], $targetDir);
} else {
    $fileName = time() . '_' . basename($_FILES['image']['name']);
    $finalPath = $targetDir . $fileName;
    if (@rename($tempPath, $finalPath)) {
        $relativePath = 'uploads/' . $folder . '/' . $fileName;
    }
}

if (!$relativePath) {
    @unlink($tempPath);
    echo json_encode(['success' => false, 'message' => 'Image processing failed.']);
    exit;
}

echo json_encode([
    'success' => true,
    'message' => $folder === 'products' ? 'Product image saved as 600x600 WebP.' : 'File uploaded successfully.',
    'path' => str_replace('\\', '/', $relativePath),
]);
