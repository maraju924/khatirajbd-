<?php
// admin/actions/slider-bulk-action.php
session_start();
require_once __DIR__ . '/../includes/auth-guard.php';
require_once '../../config/database.php';

header('Content-Type: application/json');

if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    echo json_encode(['success' => false, 'message' => 'Not authorized']);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Invalid request method']);
    exit;
}

$action = $_POST['action'] ?? '';
$ids = $_POST['ids'] ?? [];

if (empty($action) || empty($ids) || !is_array($ids)) {
    echo json_encode(['success' => false, 'message' => 'Invalid parameters']);
    exit;
}

$ids = array_map('intval', $ids);
$placeholders = implode(',', array_fill(0, count($ids), '?'));

try {
    if ($action === 'delete') {
        // Delete files first
        $stmt_select = $pdo->prepare("SELECT image FROM sliders WHERE id IN ($placeholders)");
        $stmt_select->execute($ids);
        $images = $stmt_select->fetchAll(PDO::FETCH_COLUMN);
        
        foreach ($images as $img) {
            if (!empty($img) && file_exists('../../' . $img)) {
                unlink('../../' . $img);
            }
        }

        $stmt = $pdo->prepare("DELETE FROM sliders WHERE id IN ($placeholders)");
        $stmt->execute($ids);
        $msg = 'Selected sliders deleted successfully';
    } elseif ($action === 'active') {
        $stmt = $pdo->prepare("UPDATE sliders SET status = 1 WHERE id IN ($placeholders)");
        $stmt->execute($ids);
        $msg = 'Selected sliders activated';
    } elseif ($action === 'inactive') {
        $stmt = $pdo->prepare("UPDATE sliders SET status = 0 WHERE id IN ($placeholders)");
        $stmt->execute($ids);
        $msg = 'Selected sliders deactivated';
    } else {
        echo json_encode(['success' => false, 'message' => 'Action not supported']);
        exit;
    }

    echo json_encode(['success' => true, 'message' => $msg]);
} catch (PDOException $e) {
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
}
exit;
