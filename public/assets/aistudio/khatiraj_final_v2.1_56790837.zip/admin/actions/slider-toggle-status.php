<?php
// admin/actions/slider-toggle-status.php
session_start();
require_once __DIR__ . '/../includes/auth-guard.php';
require_once '../../config/database.php';

header('Content-Type: application/json');

if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    echo json_encode(['success' => false, 'message' => 'Not authorized']);
    exit;
}

$id = $_GET['id'] ?? null;
if (!$id) {
    echo json_encode(['success' => false, 'message' => 'Slider ID required']);
    exit;
}

try {
    $stmt = $pdo->prepare("SELECT status FROM sliders WHERE id = ?");
    $stmt->execute([$id]);
    $current = $stmt->fetchColumn();

    if ($current === false) {
        echo json_encode(['success' => false, 'message' => 'Slider not found']);
        exit;
    }

    $new_status = $current ? 0 : 1;
    $stmt_update = $pdo->prepare("UPDATE sliders SET status = ? WHERE id = ?");
    $stmt_update->execute([$new_status, $id]);

    echo json_encode([
        'success' => true,
        'message' => $new_status ? 'Slider activated successfully' : 'Slider deactivated successfully',
        'status' => $new_status
    ]);
} catch (PDOException $e) {
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
}
exit;
