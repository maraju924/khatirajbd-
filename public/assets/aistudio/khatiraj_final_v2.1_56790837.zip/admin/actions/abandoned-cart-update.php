<?php
// admin/actions/abandoned-cart-update.php
session_start();
require_once __DIR__ . '/../includes/auth-guard.php';
require_once '../../config/database.php';
require_once '../../app/Helpers/OrderAccessHelper.php';
require_once '../../app/Services/AbandonedCartService.php';

if (!isset($_SESSION['admin_logged_in']) || !in_array($_SESSION['admin_role'] ?? '', ['super_admin', 'moderator'])) {
    header('Location: ../login.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: ../index.php?page=abandoned-carts&error=Invalid+request+method');
    exit;
}

$id = (int) ($_POST['id'] ?? 0);
if ($id <= 0) {
    header('Location: ../index.php?page=abandoned-carts&error=Invalid+cart+ID');
    exit;
}

// Fetch the existing abandoned cart
$stmt = $pdo->prepare("SELECT * FROM abandoned_carts WHERE id = ?");
$stmt->execute([$id]);
$cart = $stmt->fetch();

if (!$cart) {
    header('Location: ../index.php?page=abandoned-carts&error=Cart+not+found');
    exit;
}

$name = trim($_POST['customer_name'] ?? '');
$phone = trim($_POST['customer_phone'] ?? '');
$email = trim($_POST['customer_email'] ?? '');
$area = trim($_POST['customer_area'] ?? '');
$address = trim($_POST['customer_address'] ?? '');
$status = trim($_POST['status'] ?? 'active');

// Parse items from the edit modal
$postedItems = $_POST['items'] ?? [];
$existingItems = json_decode($cart['cart_data'], true) ?: [];

// Re-map existing items — keyed by cart_key when available so two variants of
// the same product don't collapse into one row; fall back to product id.
$existingMap = [];
foreach ($existingItems as $item) {
    $key = !empty($item['cart_key']) ? (string) $item['cart_key'] : (string) ($item['id'] ?? '');
    if ($key !== '') {
        $existingMap[$key] = $item;
    }
}

$finalItems = [];
$total = 0.0;

// Update existing items or keep items from POST list
foreach ($postedItems as $pItem) {
    $itemId = (int) ($pItem['id'] ?? 0);
    $qty = (int) ($pItem['qty'] ?? 1);
    $price = (float) ($pItem['price'] ?? 0.0);
    $cartKey = trim((string) ($pItem['cart_key'] ?? ''));
    $lookupKey = $cartKey !== '' ? $cartKey : (string) $itemId;

    if ($itemId <= 0 || $qty <= 0) {
        continue; // Skip invalid or deleted items
    }

    if (isset($existingMap[$lookupKey])) {
        // Update price and quantity of the item while retaining original product details like name and image
        $item = $existingMap[$lookupKey];
        $item['qty'] = $qty;
        $item['price'] = $price;
        $finalItems[] = $item;
        $total += ($qty * $price);
    } else {
        // If it's a new item added via the "Add Product" dropdown
        $stmtProd = $pdo->prepare("SELECT id, name, price, offer_price, image FROM products WHERE id = ?");
        $stmtProd->execute([$itemId]);
        $prod = $stmtProd->fetch();

        if ($prod) {
            $finalItems[] = [
                'id' => $prod['id'],
                'name' => $prod['name'],
                'price' => $price ?: (float) ($prod['offer_price'] ?: $prod['price']),
                'qty' => $qty,
                'image' => $prod['image'],
            ];
            $total += ($qty * ($price ?: (float) ($prod['offer_price'] ?: $prod['price'])));
        }
    }
}

// Convert items to JSON
$cartJson = json_encode($finalItems, JSON_UNESCAPED_UNICODE);

// If action is convert to order
$isConvert = (($_POST['submit_action'] ?? '') === 'convert');

try {
    $pdo->beginTransaction();

    if ($isConvert) {
        // Convert to order: insert into orders table
        $tracking_id = "ORD-" . strtoupper(uniqid());
        $shipping_address = trim($area . "\n" . $address);

        // Check if any product is digital
        $digital_delivery_status = 'N/A';
        $product_ids = array_column($finalItems, 'id');
        if (!empty($product_ids)) {
            $placeholders = implode(',', array_fill(0, count($product_ids), '?'));
            $stmt_digital = $pdo->prepare("SELECT COUNT(*) FROM products WHERE id IN ($placeholders) AND product_type = 'digital'");
            $stmt_digital->execute($product_ids);
            if ($stmt_digital->fetchColumn() > 0) {
                $digital_delivery_status = 'Pending';
            }
        }

        $access_token = OrderAccessHelper::generateToken();

        // Insert order
        $stmtOrder = $pdo->prepare("
            INSERT INTO orders (
                user_id, customer_name, customer_phone, customer_email, 
                shipping_address, tracking_id, total_amount, discount_amount, 
                payment_method, payment_status, order_status, ip_address, 
                user_agent, digital_delivery_status, access_token
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'COD', 'Pending', 'Pending', ?, 'Admin Manual Conversion', ?, ?)
        ");
        $stmtOrder->execute([
            $cart['user_id'], $name, $phone, $email,
            $shipping_address, $tracking_id, $total, 0.0,
            $cart['ip_address'], $digital_delivery_status, $access_token
        ]);
        $orderId = (int) $pdo->lastInsertId();

        // Insert order items
        $stmtOrderItem = $pdo->prepare("
            INSERT INTO order_items (order_id, product_id, qty, price) 
            VALUES (?, ?, ?, ?)
        ");
        foreach ($finalItems as $item) {
            $stmtOrderItem->execute([$orderId, $item['id'], $item['qty'], $item['price']]);
        }

        // Update abandoned cart to recovered
        $stmtUpdateCart = $pdo->prepare("
            UPDATE abandoned_carts SET
                customer_name = ?,
                customer_phone = ?,
                customer_email = ?,
                customer_area = ?,
                customer_address = ?,
                cart_data = ?,
                cart_total = ?,
                status = 'recovered',
                recovered_at = NOW(),
                order_id = ?
            WHERE id = ?
        ");
        $stmtUpdateCart->execute([
            $name, $phone, $email, $area, $address,
            $cartJson, $total, $orderId, $id
        ]);

        $pdo->commit();
        header('Location: ../index.php?page=orders&success=Abandoned+cart+successfully+converted+to+Order+ID+' . $orderId);
        exit;
    } else {
        // Save only: update abandoned_carts table
        $stmtUpdateCart = $pdo->prepare("
            UPDATE abandoned_carts SET
                customer_name = ?,
                customer_phone = ?,
                customer_email = ?,
                customer_area = ?,
                customer_address = ?,
                cart_data = ?,
                cart_total = ?,
                status = ?
            WHERE id = ?
        ");
        $stmtUpdateCart->execute([
            $name, $phone, $email, $area, $address,
            $cartJson, $total, $status, $id
        ]);

        $pdo->commit();
        header('Location: ../index.php?page=abandoned-carts&filter=' . urlencode($status) . '&success=Cart+details+saved+successfully');
        exit;
    }
} catch (Exception $e) {
    $pdo->rollBack();
    header('Location: ../index.php?page=abandoned-carts&error=' . urlencode('Error processing cart: ' . $e->getMessage()));
    exit;
}
