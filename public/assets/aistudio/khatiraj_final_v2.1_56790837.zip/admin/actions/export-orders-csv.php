<?php
// admin/actions/export-orders-csv.php
session_start();
require_once __DIR__ . '/../includes/auth-guard.php';
require_once '../../config/database.php';

if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header('Location: ../login.php');
    exit;
}

// Fetch all orders
$stmt = $pdo->query("SELECT o.*, u.name as user_name FROM orders o LEFT JOIN users u ON o.user_id = u.id ORDER BY o.created_at DESC");
$orders = $stmt->fetchAll();

// Set headers for CSV download
$filename = 'orders_export_' . date('Y-m-d_H-i') . '.csv';
header('Content-Type: text/csv; charset=UTF-8');
header('Content-Disposition: attachment; filename="' . $filename . '"');
header('Pragma: no-cache');
header('Expires: 0');

// Open output stream
$output = fopen('php://output', 'w');
// Add BOM for proper Bengali character display in Excel
fprintf($output, chr(0xEF) . chr(0xBB) . chr(0xBF));

// Column headers
fputcsv($output, [
    'Order ID',
    'Tracking ID',
    'Customer Name',
    'Phone',
    'Shipping Address',
    'Total Amount',
    'Discount',
    'Coupon Code',
    'Payment Method',
    'Payment Status',
    'Order Status',
    'Courier Status',
    'Consignment ID',
    'Date'
]);

// Data rows
foreach ($orders as $order) {
    fputcsv($output, [
        $order['id'],
        $order['tracking_id'],
        $order['customer_name'] ?? $order['user_name'] ?? 'Guest',
        $order['customer_phone'],
        $order['shipping_address'],
        $order['total_amount'],
        $order['discount_amount'],
        $order['coupon_code'] ?? '',
        $order['payment_method'],
        $order['payment_status'],
        $order['order_status'],
        $order['courier_status'] ?? '',
        $order['courier_consignment_id'] ?? '',
        $order['created_at']
    ]);
}

fclose($output);
exit;
