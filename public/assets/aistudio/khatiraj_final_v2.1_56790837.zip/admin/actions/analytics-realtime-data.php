<?php
// admin/actions/analytics-realtime-data.php
// Returns JSON payload of real-time dashboard statistics. Protected by admin session check.

session_start();
require_once __DIR__ . '/../includes/auth-guard.php';
header('Content-Type: application/json');

if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit;
}

require_once '../../config/database.php';

try {
    // 1. Active visitors in last 5 minutes
    $active_visitors = (int) $pdo->query("SELECT COUNT(DISTINCT session_id) FROM page_visits WHERE created_at >= NOW() - INTERVAL 5 MINUTE AND is_bot = 0")->fetchColumn();

    // 2. Active pages in last 5 minutes
    $stmt_pages = $pdo->query("
        SELECT page_url, COUNT(*) as active_views, COUNT(DISTINCT session_id) as active_sessions
        FROM page_visits
        WHERE created_at >= NOW() - INTERVAL 5 MINUTE AND is_bot = 0
        GROUP BY page_url
        ORDER BY active_views DESC
        LIMIT 5
    ");
    $active_pages = $stmt_pages->fetchAll(PDO::FETCH_ASSOC);

    // 3. Live event logs
    $stmt_events = $pdo->query("
        SELECT platform, event_name, response_code, created_at
        FROM tracking_logs
        ORDER BY created_at DESC
        LIMIT 8
    ");
    $live_events = $stmt_events->fetchAll(PDO::FETCH_ASSOC);

    // 4. Live orders
    $stmt_orders = $pdo->query("
        SELECT customer_name, total_amount, created_at
        FROM orders
        ORDER BY created_at DESC
        LIMIT 5
    ");
    $live_orders = $stmt_orders->fetchAll(PDO::FETCH_ASSOC);

    echo json_encode([
        'success' => true,
        'active_visitors' => $active_visitors,
        'active_pages' => $active_pages,
        'live_events' => $live_events,
        'live_orders' => $live_orders
    ]);

} catch (\Exception $e) {
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
}
exit;
