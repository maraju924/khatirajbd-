<?php
// admin/actions/analytics-alerts.php
// Handle saving and configuration of alert rules. Protected by admin session check.

session_start();
require_once __DIR__ . '/../includes/auth-guard.php';
require_once '../../config/database.php';

if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header('Location: ../login.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    if ($action === 'add') {
        $title = trim($_POST['title'] ?? '');
        $alert_type = trim($_POST['alert_type'] ?? '');
        $threshold = (float)($_POST['threshold'] ?? 0);

        if (empty($title) || empty($alert_type)) {
            header('Location: ../index.php?page=tracking-settings&tab=overview&error=' . urlencode('Required fields are missing'));
            exit;
        }

        $condition = [
            'threshold' => $threshold,
            'metric' => $alert_type
        ];
        $condition_json = json_encode($condition);

        try {
            $stmt = $pdo->prepare("INSERT INTO analytics_alerts (title, alert_type, condition_json, is_active) VALUES (?, ?, ?, 1)");
            $stmt->execute([$title, $alert_type, $condition_json]);

            header('Location: ../index.php?page=tracking-settings&tab=overview&success=' . urlencode('Alert rule added successfully'));
            exit;
        } catch (\PDOException $e) {
            header('Location: ../index.php?page=tracking-settings&tab=overview&error=' . urlencode($e->getMessage()));
            exit;
        }
    }
}
header('Location: ../index.php?page=tracking-settings');
exit;
