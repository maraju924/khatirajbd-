<?php
// admin/actions/bulk-order-status.php
session_start();
require_once __DIR__ . '/../includes/auth-guard.php';
require_once '../../config/database.php';

header('Content-Type: application/json');

if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    echo json_encode(['success' => false, 'message' => 'Not authorized']);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $order_ids = $_POST['order_ids'] ?? [];
    $order_status = $_POST['order_status'] ?? '';
    
    $valid_statuses = ['Pending', 'Processing', 'Shipped', 'Delivered', 'Cancelled'];
    
    if (empty($order_ids) || !in_array($order_status, $valid_statuses)) {
        echo json_encode(['success' => false, 'message' => 'Invalid data']);
        exit;
    }
    
    try {
        $placeholders = implode(',', array_fill(0, count($order_ids), '?'));
        $params = array_merge([$order_status], $order_ids);
        $stmt = $pdo->prepare("UPDATE orders SET order_status = ? WHERE id IN ($placeholders)");
        $stmt->execute($params);
        
        $count = $stmt->rowCount();
        
        // --- SMS Notification ---
        try {
            require_once '../../app/Helpers/SmsHelper.php';
            $smsHelper = new \App\Helpers\SmsHelper($pdo);
            if ($smsHelper->isEnabled()) {
                $stmt = $pdo->prepare("SELECT * FROM orders WHERE id IN ($placeholders)");
                $stmt->execute($order_ids);
                $updated_orders = $stmt->fetchAll();
                foreach ($updated_orders as $order) {
                    $smsHelper->sendOrderStatusSms($order);
                }
            }
        } catch (Exception $e) { /* Silently fail */ }
        echo json_encode(['success' => true, 'message' => $count . ' order(s) updated to ' . $order_status]);
    } catch (PDOException $e) {
        echo json_encode(['success' => false, 'message' => $e->getMessage()]);
    }
} else {
    echo json_encode(['success' => false, 'message' => 'Invalid method']);
}
