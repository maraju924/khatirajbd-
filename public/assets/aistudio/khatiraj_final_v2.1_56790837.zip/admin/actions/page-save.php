<?php
// admin/actions/page-save.php
session_start();
require_once __DIR__ . '/../includes/auth-guard.php';
require_once '../../config/database.php';
require_once '../../app/Helpers/CacheHelper.php';
require_once '../../app/Helpers/PageHelper.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $page_id = isset($_POST['id']) ? (int)$_POST['id'] : 0;
    
    if ($page_id <= 0) {
        header('Location: ../index.php?page=page-manager&error=Invalid Page ID');
        exit;
    }

    try {
        // Fetch current page data to get the page group and check existence
        $stmt = $pdo->prepare("SELECT * FROM page_registry WHERE id = ?");
        $stmt->execute([$page_id]);
        $page = $stmt->fetch();

        if (!$page) {
            header('Location: ../index.php?page=page-manager&error=Page not found');
            exit;
        }

        if (!PageHelper::isManageable((string)$page['route_key'])) {
            header('Location: ../index.php?page=page-manager&error=' . urlencode('This page is not editable in Page & SEO Manager'));
            exit;
        }

        // Determine updates
        if (isset($_POST['update_content_html']) && $_POST['update_content_html'] == '1') {
            // Update Page Content
            $h1_title = isset($_POST['h1_title']) ? trim($_POST['h1_title']) : '';
            $subtitle = isset($_POST['subtitle']) ? trim($_POST['subtitle']) : '';
            $content_html = isset($_POST['content_html']) ? $_POST['content_html'] : '';

            $stmt_update = $pdo->prepare("UPDATE page_registry SET h1_title = ?, subtitle = ?, content_html = ? WHERE id = ?");
            $stmt_update->execute([$h1_title, $subtitle, $content_html, $page_id]);

            $active_tab = 'content';
        } else {
            // Update SEO and main settings
            $focus_keyword = isset($_POST['focus_keyword']) ? trim($_POST['focus_keyword']) : '';
            $meta_title = isset($_POST['meta_title']) ? trim($_POST['meta_title']) : '';
            $meta_description = isset($_POST['meta_description']) ? trim($_POST['meta_description']) : '';
            $meta_keywords = isset($_POST['meta_keywords']) ? trim($_POST['meta_keywords']) : '';
            $og_image = isset($_POST['og_image']) ? trim($_POST['og_image']) : '';
            $canonical_override = isset($_POST['canonical_override']) ? trim($_POST['canonical_override']) : '';
            $status = isset($_POST['status']) ? (int)$_POST['status'] : 1;
            $sort_order = isset($_POST['sort_order']) ? (int)$_POST['sort_order'] : 0;

            if ($page['page_group'] === 'content' && isset($_POST['slug'])) {
                // Allowed to edit custom slugs
                $slug = '/' . ltrim(trim($_POST['slug']), '/');
                $stmt_update = $pdo->prepare("UPDATE page_registry SET focus_keyword = ?, meta_title = ?, meta_description = ?, meta_keywords = ?, og_image = ?, canonical_override = ?, status = ?, sort_order = ?, slug = ? WHERE id = ?");
                $stmt_update->execute([$focus_keyword, $meta_title, $meta_description, $meta_keywords, $og_image, $canonical_override, $status, $sort_order, $slug, $page_id]);
            } else {
                // System routes have immutable slugs
                $stmt_update = $pdo->prepare("UPDATE page_registry SET focus_keyword = ?, meta_title = ?, meta_description = ?, meta_keywords = ?, og_image = ?, canonical_override = ?, status = ?, sort_order = ? WHERE id = ?");
                $stmt_update->execute([$focus_keyword, $meta_title, $meta_description, $meta_keywords, $og_image, $canonical_override, $status, $sort_order, $page_id]);
            }

            $active_tab = 'seo';
        }

        // Invalidate Cache
        CacheHelper::clearAll();

        header("Location: ../index.php?page=edit-page&id={$page_id}&tab={$active_tab}&success=" . urlencode("Page settings updated successfully"));
        exit;

    } catch (PDOException $e) {
        header("Location: ../index.php?page=edit-page&id={$page_id}&error=" . urlencode($e->getMessage()));
        exit;
    }
}
