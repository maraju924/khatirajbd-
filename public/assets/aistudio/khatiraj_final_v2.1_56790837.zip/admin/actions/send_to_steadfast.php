<?php
// admin/actions/send_to_steadfast.php
session_start();
require_once __DIR__ . '/../includes/auth-guard.php';
require_once '../../config/database.php';
require_once '../../app/Services/SteadfastService.php';

if (!isset($_SESSION['admin_logged_in'])) {
    exit(json_encode(['status' => 'error', 'message' => 'Unauthorized']));
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $order_id = $_POST['order_id'];

    try {
        // Fetch order details
        $stmt = $pdo->prepare("SELECT * FROM orders WHERE id = ?");
        $stmt->execute([$order_id]);
        $order = $stmt->fetch();

        if (!$order) {
            throw new Exception("Order not found.");
        }

        if (!empty($order['courier_consignment_id'])) {
            throw new Exception("Order already sent to Steadfast.");
        }

        // Fetch Order Items for description
        $stmt_items = $pdo->prepare("SELECT oi.*, p.name as product_name FROM order_items oi JOIN products p ON oi.product_id = p.id WHERE oi.order_id = ?");
        $stmt_items->execute([$order_id]);
        $order_items = $stmt_items->fetchAll();
        $item_list = [];
        foreach($order_items as $item) {
            $label = $item['product_name'];
            if (!empty($item['variant_label'])) {
                $label .= ' [' . $item['variant_label'] . ']';
            }
            $item_list[] = $label . ' (x' . $item['qty'] . ')';
        }
        $item_description = implode(', ', $item_list);

        // Fetch Note from settings
        $stmt_note = $pdo->prepare("SELECT value FROM settings WHERE key_name = 'steadfast_note'");
        $stmt_note->execute();
        $db_note = $stmt_note->fetchColumn();
        $note = $db_note ?: '”মাচেন্ট এর অনুমতি ব্যাতিত কোনো প্রোডাক্ট খুলবেন না। এবং সকল আপডেল মাচেন্টকে জানাবেন”';

        // Submit to Steadfast
        $steadfast = new SteadfastService();
        $courierResult = $steadfast->createOrder([
            'invoice' => $order['tracking_id'],
            'recipient_name' => $order['customer_name'],
            'recipient_phone' => $order['customer_phone'],
            'recipient_address' => $order['shipping_address'],
            'cod_amount' => $order['total_amount'],
            'note' => $note,
            'item_description' => $item_description
        ]);

        if ($courierResult && isset($courierResult['status']) && $courierResult['status'] == 200) {
            $consignment_id = $courierResult['consignment']['consignment_id'];
            $tracking_code = $courierResult['consignment']['tracking_code'];
            $courier_status = $courierResult['consignment']['status'];

            // Update local order
            $updateStmt = $pdo->prepare("UPDATE orders SET courier_consignment_id = ?, tracking_id = ?, courier_status = ? WHERE id = ?");
            $updateStmt->execute([$consignment_id, $tracking_code, $courier_status, $order_id]);

            if (!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest') {
                echo json_encode(['status' => 'success', 'tracking_code' => $tracking_code]);
                exit;
            }
            header("Location: ../index.php?page=order-view&id={$order_id}&success=Successfully sent to Steadfast");
            exit;
        } else {
            $error_msg = $courierResult['error'] ?? 'Steadfast API error';
            throw new Exception($error_msg);
        }

    } catch (Exception $e) {
        if (!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest') {
            echo json_encode(['status' => 'error', 'message' => $e->getMessage()]);
            exit;
        }
        header("Location: ../index.php?page=order-view&id={$order_id}&error=" . urlencode($e->getMessage()));
        exit;
    }
}
