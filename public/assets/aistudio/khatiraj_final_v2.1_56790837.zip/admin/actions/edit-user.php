<?php
// admin/actions/edit-user.php
session_start();
require_once __DIR__ . '/../includes/auth-guard.php';
require_once '../../config/database.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = $_POST['id'];
    $name = trim($_POST['name']);
    $email = trim($_POST['email']);
    $phone = trim($_POST['phone']);
    $password = $_POST['password'];
    $address = trim($_POST['address']);

    // Check if it's an AJAX request
    $is_ajax = !empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest';

    // Validation
    if (empty($name) || empty($email) || empty($phone)) {
        if ($is_ajax) {
            header('Content-Type: application/json');
            echo json_encode(['success' => false, 'message' => 'Name, Email, and Phone are required.']);
            exit;
        }
        $_SESSION['error'] = "Name, Email, and Phone are required.";
        header("Location: ../index.php?page=edit-user&id=$id");
        exit;
    }

    // Check uniqueness (exclude current user)
    $stmt = $pdo->prepare("SELECT id FROM users WHERE (email = ? OR phone = ?) AND id != ?");
    $stmt->execute([$email, $phone, $id]);
    if ($stmt->fetch()) {
        if ($is_ajax) {
            header('Content-Type: application/json');
            echo json_encode(['success' => false, 'message' => 'Email or Phone already exists for another user.']);
            exit;
        }
        $_SESSION['error'] = "Email or Phone already exists for another user.";
        header("Location: ../index.php?page=edit-user&id=$id");
        exit;
    }

    try {
        if (!empty($password)) {
            $hashed_password = password_hash($password, PASSWORD_DEFAULT);
            $stmt = $pdo->prepare("UPDATE users SET name = ?, email = ?, phone = ?, password = ?, address = ? WHERE id = ?");
            $stmt->execute([$name, $email, $phone, $hashed_password, $address, $id]);
        } else {
            $stmt = $pdo->prepare("UPDATE users SET name = ?, email = ?, phone = ?, address = ? WHERE id = ?");
            $stmt->execute([$name, $email, $phone, $address, $id]);
        }

        if ($is_ajax) {
            header('Content-Type: application/json');
            echo json_encode(['success' => true, 'message' => 'User updated successfully.']);
            exit;
        }
        $_SESSION['success'] = "User updated successfully.";
        header("Location: ../index.php?page=customers");
    } catch (PDOException $e) {
        if ($is_ajax) {
            header('Content-Type: application/json');
            echo json_encode(['success' => false, 'message' => 'Database Error: ' . $e->getMessage()]);
            exit;
        }
        $_SESSION['error'] = "Database Error: " . $e->getMessage();
        header("Location: ../index.php?page=edit-user&id=$id");
    }
}
exit();
