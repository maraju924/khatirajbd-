<?php
// admin/actions/order-delete.php
session_start();
require_once __DIR__ . '/../includes/auth-guard.php';
require_once '../../config/database.php';

// Check if it's an AJAX request
$is_ajax = !empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest';

if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    if ($is_ajax) {
        header('Content-Type: application/json');
        echo json_encode(['success' => false, 'message' => 'Not authorized']);
        exit;
    }
    header('Location: ../login.php');
    exit;
}

$id = $_GET['id'] ?? null;

if ($id) {
    try {
        $pdo->beginTransaction();

        // 1. Delete order items first
        $stmt_items = $pdo->prepare("DELETE FROM order_items WHERE order_id = ?");
        $stmt_items->execute([$id]);

        // 2. Delete the order
        $stmt_order = $pdo->prepare("DELETE FROM orders WHERE id = ?");
        $stmt_order->execute([$id]);

        $pdo->commit();
        
        if ($is_ajax) {
            header('Content-Type: application/json');
            echo json_encode(['success' => true, 'message' => 'Order deleted successfully']);
            exit;
        }
        header('Location: ../index.php?page=orders&success=Order deleted successfully');
    } catch (PDOException $e) {
        $pdo->rollBack();
        if ($is_ajax) {
            header('Content-Type: application/json');
            echo json_encode(['success' => false, 'message' => $e->getMessage()]);
            exit;
        }
        header('Location: ../index.php?page=orders&error=' . urlencode($e->getMessage()));
    }
} else {
    if ($is_ajax) {
        header('Content-Type: application/json');
        echo json_encode(['success' => false, 'message' => 'Invalid request']);
        exit;
    }
    header('Location: ../index.php?page=orders&error=Invalid request');
}
exit;
