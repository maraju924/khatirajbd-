<?php
// admin/actions/media-seo-save.php
session_start();
require_once __DIR__ . '/../includes/auth-guard.php';
require_once '../../config/database.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $old_path = $_POST['old_path'];
    $new_name = trim($_POST['new_name']);
    $alt_text = trim($_POST['alt_text']);
    $title_text = trim($_POST['title_text']);

    // 1. Handle Renaming on Disk
    $parts = explode('/', $old_path);
    $filename = array_pop($parts);
    $folder_path = implode('/', $parts); // e.g. uploads/products
    
    // Ensure extension remains same
    $ext = pathinfo($filename, PATHINFO_EXTENSION);
    if (!str_ends_with($new_name, '.' . $ext)) {
        $new_name .= '.' . $ext;
    }
    
    $new_path = $folder_path . "/" . $new_name;
    $final_path = $old_path;

    if ($new_name !== $filename) {
        $old_full = "../../" . $old_path;
        $new_full = "../../" . $new_path;
        
        if (file_exists($old_full) && !file_exists($new_full)) {
            if (rename($old_full, $new_full)) {
                $final_path = $new_path;
                
                // CRITICAL: Update DB tables that use this image (Products/Categories)
                // This is a simplified approach. Better would be a media ID system.
                $pdo->prepare("UPDATE products SET image = ? WHERE image = ?")->execute([$new_path, $old_path]);
                $pdo->prepare("UPDATE categories SET image = ? WHERE image = ?")->execute([$new_path, $old_path]);
            }
        }
    }

    // 2. Save Metadata to DB
    try {
        $stmt = $pdo->prepare("INSERT INTO media_metadata (file_path, alt_text, title_text) 
                               VALUES (?, ?, ?) 
                               ON DUPLICATE KEY UPDATE alt_text = ?, title_text = ?, file_path = ?");
        $stmt->execute([$final_path, $alt_text, $title_text, $alt_text, $title_text, $final_path]);

        header('Location: ../index.php?page=media&success=Media settings updated');
    } catch (PDOException $e) {
        header('Location: ../index.php?page=media&error=' . urlencode($e->getMessage()));
    }
}
