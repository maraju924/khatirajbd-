<?php
// admin/actions/slider-actions.php
session_start();
require_once __DIR__ . '/../includes/auth-guard.php';
require_once '../../config/database.php';

// Check if admin is logged in
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header('Location: ../login.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    if ($action === 'add' || $action === 'edit') {
        $title = trim($_POST['title']);
        $subtitle = trim($_POST['subtitle']);
        $btn_text = trim($_POST['btn_text']);
        $btn_link = trim($_POST['btn_link']);
        $overlay_color = $_POST['overlay_color'] ?? '#000000';
        $overlay_opacity = $_POST['overlay_opacity'] ?? 0.40;
        $sort_order = (int)$_POST['sort_order'];
        $status = (int)$_POST['status'];
        $id = isset($_POST['id']) ? (int)$_POST['id'] : 0;

        // Image Handling (Media Manager or Upload)
        $image = $_POST['image'] ?? '';
        $old_image = $_POST['old_image'] ?? '';
        $image_path = !empty($image) ? $image : $old_image;
        
        // Handle legacy upload
        if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
            $upload_dir = '../../uploads/sliders/';
            if (!is_dir($upload_dir)) mkdir($upload_dir, 0777, true);

            $file_ext = pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION);
            $file_name = time() . '_' . uniqid() . '.' . $file_ext;
            $target_file = $upload_dir . $file_name;

            if (move_uploaded_file($_FILES['image']['tmp_name'], $target_file)) {
                $image_path = 'uploads/sliders/' . $file_name;
            }
        }

        $position = trim($_POST['position'] ?? 'main_hero');

        // Check if it's an AJAX request
        $is_ajax = !empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest';

        try {
            if ($action === 'add') {
                if (empty($image_path)) {
                    if ($is_ajax) {
                        header('Content-Type: application/json');
                        echo json_encode(['success' => false, 'message' => 'Image upload failed']);
                        exit;
                    }
                    header("Location: ../index.php?page=sliders&error=" . urlencode("Image upload failed"));
                    exit();
                }
                $stmt = $pdo->prepare("INSERT INTO sliders (title, subtitle, image, btn_text, btn_link, overlay_color, overlay_opacity, sort_order, status, position) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
                $stmt->execute([$title, $subtitle, $image_path, $btn_text, $btn_link, $overlay_color, $overlay_opacity, $sort_order, $status, $position]);
                $msg = "Slider added successfully";
            } else {
                $stmt = $pdo->prepare("UPDATE sliders SET title = ?, subtitle = ?, image = ?, btn_text = ?, btn_link = ?, overlay_color = ?, overlay_opacity = ?, sort_order = ?, status = ?, position = ? WHERE id = ?");
                $stmt->execute([$title, $subtitle, $image_path, $btn_text, $btn_link, $overlay_color, $overlay_opacity, $sort_order, $status, $position, $id]);
                $msg = "Slider updated successfully";
            }
            if ($is_ajax) {
                header('Content-Type: application/json');
                echo json_encode(['success' => true, 'message' => $msg]);
                exit;
            }
            header("Location: ../index.php?page=sliders&success=" . urlencode($msg));
            exit();
        } catch (PDOException $e) {
            if ($is_ajax) {
                header('Content-Type: application/json');
                echo json_encode(['success' => false, 'message' => 'DB error: ' . $e->getMessage()]);
                exit;
            }
            header("Location: ../index.php?page=sliders&error=" . urlencode("DB error: " . $e->getMessage()));
            exit();
        }
    }

    if ($action === 'delete') {
        $id = (int)$_POST['id'];
        $is_ajax = !empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest';

        try {
            // First get the image path to delete the file
            $stmt = $pdo->prepare("SELECT image FROM sliders WHERE id = ?");
            $stmt->execute([$id]);
            $slider = $stmt->fetch();
            if ($slider && !empty($slider['image']) && file_exists('../../' . $slider['image'])) {
                unlink('../../' . $slider['image']);
            }

            $stmt = $pdo->prepare("DELETE FROM sliders WHERE id = ?");
            $stmt->execute([$id]);
            
            if ($is_ajax) {
                header('Content-Type: application/json');
                echo json_encode(['success' => true, 'message' => 'Slider deleted successfully']);
                exit;
            }
            header("Location: ../index.php?page=sliders&success=Slider deleted successfully");
            exit();
        } catch (PDOException $e) {
            if ($is_ajax) {
                header('Content-Type: application/json');
                echo json_encode(['success' => false, 'message' => 'Error deleting slider: ' . $e->getMessage()]);
                exit;
            }
            header("Location: ../index.php?page=sliders&error=" . urlencode("Error deleting slider: " . $e->getMessage()));
            exit();
        }
    }
}
