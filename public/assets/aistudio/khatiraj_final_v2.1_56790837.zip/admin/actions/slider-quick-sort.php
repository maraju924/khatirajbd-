<?php
// admin/actions/slider-quick-sort.php
session_start();
require_once __DIR__ . '/../includes/auth-guard.php';
require_once '../../config/database.php';

header('Content-Type: application/json');

if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    echo json_encode(['success' => false, 'message' => 'Not authorized']);
    exit;
}

$id = $_GET['id'] ?? null;
$direction = $_GET['dir'] ?? null; // 'up' or 'down'

if (!$id || !$direction) {
    echo json_encode(['success' => false, 'message' => 'Parameters missing']);
    exit;
}

try {
    // Get current sort order
    $stmt = $pdo->prepare("SELECT sort_order FROM sliders WHERE id = ?");
    $stmt->execute([$id]);
    $current_order = $stmt->fetchColumn();

    if ($current_order === false) {
        echo json_encode(['success' => false, 'message' => 'Slider not found']);
        exit;
    }

    $new_order = ($direction === 'up') ? $current_order - 1 : $current_order + 1;
    if ($new_order < 0) {
        $new_order = 0;
    }

    $stmt_update = $pdo->prepare("UPDATE sliders SET sort_order = ? WHERE id = ?");
    $stmt_update->execute([$new_order, $id]);

    echo json_encode([
        'success' => true,
        'message' => 'Slider sort order updated successfully',
        'sort_order' => $new_order
    ]);
} catch (PDOException $e) {
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
}
exit;
