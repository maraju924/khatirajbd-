<?php
// admin/actions/migrate-sections.php
session_start();

require_once __DIR__ . '/../includes/auth-guard.php';
error_reporting(E_ALL);
ini_set('display_errors', '0');
ini_set('log_errors', '1');

require_once __DIR__ . '/../../config/database.php';

// Check authorization
$is_cli = php_sapi_name() === 'cli';
if (!$is_cli && (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true)) {
    header('Content-Type: application/json');
    echo json_encode(['success' => false, 'message' => 'Not authorized']);
    exit;
}

try {
    // 1. Create product_sections table if it doesn't exist
    $pdo->exec("CREATE TABLE IF NOT EXISTS product_sections (
        id INT AUTO_INCREMENT PRIMARY KEY,
        product_id INT NOT NULL,
        title VARCHAR(255) NOT NULL,
        icon VARCHAR(50) DEFAULT 'fas fa-check-circle',
        sort_order INT DEFAULT 0,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        INDEX (product_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;");

    // 2. Create product_section_items table if it doesn't exist
    $pdo->exec("CREATE TABLE IF NOT EXISTS product_section_items (
        id INT AUTO_INCREMENT PRIMARY KEY,
        section_id INT NOT NULL,
        text_content TEXT NOT NULL,
        sort_order INT DEFAULT 0,
        INDEX (section_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;");

    // Check if migration has already run or if we need to migrate
    // Let's migrate products that have benefits or trust points and do not already have sections in product_sections
    $stmt_products = $pdo->query("
        SELECT id, benefits, benefits_title, trust_points, trust_title 
        FROM products 
        WHERE (benefits IS NOT NULL AND benefits != '') 
           OR (trust_points IS NOT NULL AND trust_points != '')
    ");
    $products = $stmt_products->fetchAll();

    $migrated_count = 0;
    
    $stmt_check = $pdo->prepare("SELECT COUNT(*) FROM product_sections WHERE product_id = ?");
    $stmt_insert_section = $pdo->prepare("INSERT INTO product_sections (product_id, title, icon, sort_order) VALUES (?, ?, ?, ?)");
    $stmt_insert_item = $pdo->prepare("INSERT INTO product_section_items (section_id, text_content, sort_order) VALUES (?, ?, ?)");

    foreach ($products as $prod) {
        $stmt_check->execute([$prod['id']]);
        if ($stmt_check->fetchColumn() > 0) {
            // Already has sections, skip to avoid duplicate migration
            continue;
        }

        // Migrate Benefits
        if (!empty(trim($prod['benefits']))) {
            $benefits_title = !empty(trim($prod['benefits_title'])) ? trim($prod['benefits_title']) : 'উপকারিতা:';
            // Insert benefits section
            $stmt_insert_section->execute([$prod['id'], $benefits_title, 'fas fa-shield-alt', 1]);
            $section_id = $pdo->lastInsertId();

            // Split benefits by newline
            $lines = preg_split('/\r\n|\r|\n/', $prod['benefits']);
            $order = 1;
            foreach ($lines as $line) {
                $line = trim($line);
                if (empty($line)) continue;
                
                // Strip emoji at the start if present (e.g. ✅, 🍃)
                $cleaned_line = preg_replace('/^[\x{1F000}-\x{1F9FF}\x{2600}-\x{26FF}✅🍃]+|^\s*-\s*|^\s*\*\s*/u', '', $line);
                $cleaned_line = trim($cleaned_line);
                if (empty($cleaned_line)) {
                    $cleaned_line = $line; // Fallback if regex stripped everything
                }

                $stmt_insert_item->execute([$section_id, $cleaned_line, $order++]);
            }
        }

        // Migrate Trust Points
        if (!empty(trim($prod['trust_points']))) {
            $trust_title = !empty(trim($prod['trust_title'])) ? trim($prod['trust_title']) : 'কেন আমাদের থেকে নিবেন?';
            // Insert trust section
            $stmt_insert_section->execute([$prod['id'], $trust_title, 'fas fa-heart', 2]);
            $section_id = $pdo->lastInsertId();

            // Split trust points by newline
            $lines = preg_split('/\r\n|\r|\n/', $prod['trust_points']);
            $order = 1;
            foreach ($lines as $line) {
                $line = trim($line);
                if (empty($line)) continue;
                
                // Strip emoji at the start if present
                $cleaned_line = preg_replace('/^[\x{1F000}-\x{1F9FF}\x{2600}-\x{26FF}✅🍃]+|^\s*-\s*|^\s*\*\s*/u', '', $line);
                $cleaned_line = trim($cleaned_line);
                if (empty($cleaned_line)) {
                    $cleaned_line = $line; // Fallback
                }

                $stmt_insert_item->execute([$section_id, $cleaned_line, $order++]);
            }
        }

        $migrated_count++;
    }

    header('Content-Type: application/json');
    echo json_encode([
        'success' => true, 
        'message' => "Migration completed. Created database tables and migrated $migrated_count products to dynamic sections."
    ]);
} catch (Exception $e) {
    header('Content-Type: application/json');
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
}
