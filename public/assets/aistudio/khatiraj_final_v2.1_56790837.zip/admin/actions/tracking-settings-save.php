<?php
// admin/actions/tracking-settings-save.php
// Saves tracking settings with encryption for sensitive tokens

session_start();
require_once __DIR__ . '/../includes/auth-guard.php';
require_once '../../config/database.php';
require_once '../../config/tracking_encryption.php';

// Check auth
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header('Location: ../login.php');
    exit;
}

// Only super_admin can modify tracking settings
if (($_SESSION['admin_role'] ?? '') !== 'super_admin') {
    header('Location: ../index.php?page=tracking-settings&error=Access Denied. Only Super Admin can modify tracking settings.');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? 'save';

    try {
        // Get current settings first (for comparison / keeping existing tokens)
        $stmt = $pdo->query("SELECT * FROM tracking_settings WHERE id = 1");
        $current = $stmt->fetch(PDO::FETCH_ASSOC);

        // Prepare values
        $meta_pixel_id = trim($_POST['meta_pixel_id'] ?? '');
        $tiktok_pixel_id = trim($_POST['tiktok_pixel_id'] ?? '');
        $meta_test_event_code = trim($_POST['meta_test_event_code'] ?? '');

        // Google Tracking Values
        $google_verification_code = trim($_POST['google_verification_code'] ?? '');
        // Extract code from content attribute if user pasted full meta tag
        if (preg_match('/content="([^"]+)"/', $google_verification_code, $matches)) {
            $google_verification_code = $matches[1];
        }
        $google_analytics_id = trim($_POST['google_analytics_id'] ?? '');
        $google_tag_manager_id = trim($_POST['google_tag_manager_id'] ?? '');
        $google_search_console_embed = trim($_POST['google_search_console_embed'] ?? '');

        // Handle checkboxes (checked = POST value, unchecked = hidden value)
        $enable_advanced_matching = isset($_POST['enable_advanced_matching']) ? 1 : 0;
        $is_test_mode = isset($_POST['is_test_mode']) ? 1 : 0;

        // Handle tokens — only update if new value provided, otherwise keep existing encrypted value
        $meta_token_new = trim($_POST['meta_capi_access_token'] ?? '');
        $tiktok_token_new = trim($_POST['tiktok_events_api_token'] ?? '');

        $meta_capi_encrypted = $current['meta_capi_access_token'] ?? '';
        if (!empty($meta_token_new)) {
            $meta_capi_encrypted = TrackingEncryption::encrypt($meta_token_new);
        }

        $tiktok_token_encrypted = $current['tiktok_events_api_token'] ?? '';
        if (!empty($tiktok_token_new)) {
            $tiktok_token_encrypted = TrackingEncryption::encrypt($tiktok_token_new);
        }

        // Update settings
        $stmt = $pdo->prepare("
            UPDATE tracking_settings SET
                meta_pixel_id = ?,
                meta_capi_access_token = ?,
                tiktok_pixel_id = ?,
                tiktok_events_api_token = ?,
                enable_advanced_matching = ?,
                is_test_mode = ?,
                meta_test_event_code = ?,
                google_verification_code = ?,
                google_analytics_id = ?,
                google_tag_manager_id = ?,
                google_search_console_embed = ?,
                updated_at = NOW(),
                updated_by = ?
            WHERE id = 1
        ");

        $stmt->execute([
            $meta_pixel_id,
            $meta_capi_encrypted,
            $tiktok_pixel_id,
            $tiktok_token_encrypted,
            $enable_advanced_matching,
            $is_test_mode,
            $meta_test_event_code,
            $google_verification_code,
            $google_analytics_id,
            $google_tag_manager_id,
            $google_search_console_embed,
            $_SESSION['admin_id'] ?? null
        ]);

        // Log the change
        try {
            $log_stmt = $pdo->prepare("
                INSERT INTO tracking_logs (platform, event_name, event_id, status, response_code, error_message, payload_summary)
                VALUES ('meta', 'settings_changed', ?, 'success', 0, ?, ?)
            ");
            $changes = [];
            if ($meta_pixel_id !== ($current['meta_pixel_id'] ?? '')) $changes[] = 'meta_pixel_id';
            if (!empty($meta_token_new)) $changes[] = 'meta_capi_access_token';
            if ($tiktok_pixel_id !== ($current['tiktok_pixel_id'] ?? '')) $changes[] = 'tiktok_pixel_id';
            if (!empty($tiktok_token_new)) $changes[] = 'tiktok_events_api_token';
            if ($enable_advanced_matching !== (int)($current['enable_advanced_matching'] ?? 0)) $changes[] = 'enable_advanced_matching';
            if ($is_test_mode !== (int)($current['is_test_mode'] ?? 0)) $changes[] = 'is_test_mode';
            if ($google_verification_code !== ($current['google_verification_code'] ?? '')) $changes[] = 'google_verification_code';
            if ($google_analytics_id !== ($current['google_analytics_id'] ?? '')) $changes[] = 'google_analytics_id';
            if ($google_tag_manager_id !== ($current['google_tag_manager_id'] ?? '')) $changes[] = 'google_tag_manager_id';
            if ($google_search_console_embed !== ($current['google_search_console_embed'] ?? '')) $changes[] = 'google_search_console_embed';

            $log_stmt->execute([
                'settings_' . time(),
                'Changed: ' . implode(', ', $changes),
                (string)($_SESSION['admin_id'] ?? 0)
            ]);
        } catch (\Exception $e) {}

        // Clear cached tracking settings from session
        unset($_SESSION['tracking_settings_cache']);
        require_once __DIR__ . '/../../app/Helpers/CacheHelper.php';
        CacheHelper::forget('tracking_settings');

        // If "Save & Test" was clicked, run connection tests
        if ($action === 'save_and_test') {
            $test_params = [];

            // Test Meta
            require_once '../../app/Services/MetaCapiService.php';
            $metaService = new MetaCapiService();
            $metaResult = $metaService->testConnection();
            $test_params[] = 'meta_test=' . ($metaResult['success'] ? 'ok' : 'fail');
            $test_params[] = 'meta_msg=' . urlencode($metaResult['message']);

            // Test TikTok
            require_once '../../app/Services/TikTokEventsService.php';
            $tiktokService = new TikTokEventsService();
            $tiktokResult = $tiktokService->testConnection();
            $test_params[] = 'tiktok_test=' . ($tiktokResult['success'] ? 'ok' : 'fail');
            $test_params[] = 'tiktok_msg=' . urlencode($tiktokResult['message']);

            header('Location: ../index.php?page=tracking-settings&success=Settings saved successfully!&' . implode('&', $test_params));
        } else {
            header('Location: ../index.php?page=tracking-settings&success=Tracking settings saved successfully!');
        }

    } catch (PDOException $e) {
        header('Location: ../index.php?page=tracking-settings&error=' . urlencode('Database error: ' . $e->getMessage()));
    }
} else {
    header('Location: ../index.php?page=tracking-settings');
}
