<?php
// admin/actions/inline-order-status.php
session_start();
require_once __DIR__ . '/../includes/auth-guard.php';
require_once '../../config/database.php';

header('Content-Type: application/json');

if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    echo json_encode(['success' => false, 'message' => 'Not authorized']);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $order_id = intval($_POST['order_id'] ?? 0);
    $order_status = $_POST['order_status'] ?? '';
    
    $valid_statuses = ['Pending', 'Processing', 'Shipped', 'Delivered', 'Cancelled'];
    
    if (!$order_id || !in_array($order_status, $valid_statuses)) {
        echo json_encode(['success' => false, 'message' => 'Invalid data']);
        exit;
    }
    
    try {
        $stmt = $pdo->prepare("UPDATE orders SET order_status = ? WHERE id = ?");
        $stmt->execute([$order_status, $order_id]);
        
        // --- SMS Notification ---
        try {
            require_once '../../app/Helpers/SmsHelper.php';
            $smsHelper = new \App\Helpers\SmsHelper($pdo);
            if ($smsHelper->isEnabled()) {
                $stmt = $pdo->prepare("SELECT * FROM orders WHERE id = ?");
                $stmt->execute([$order_id]);
                $order = $stmt->fetch();
                if ($order) {
                    $smsHelper->sendOrderStatusSms($order);
                }
            }
        } catch (Exception $e) { /* Silently fail */ }

        echo json_encode(['success' => true, 'message' => 'Status updated to ' . $order_status]);
    } catch (PDOException $e) {
        echo json_encode(['success' => false, 'message' => $e->getMessage()]);
    }
} else {
    echo json_encode(['success' => false, 'message' => 'Invalid method']);
}
