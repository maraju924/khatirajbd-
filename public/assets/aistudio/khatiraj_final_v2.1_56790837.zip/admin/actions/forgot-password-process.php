<?php
// admin/actions/forgot-password-process.php
session_start();
require_once '../../config/database.php';
require_once '../../app/Helpers/EmailHelper.php';
require_once '../../app/Helpers/CsrfHelper.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!CsrfHelper::validate()) {
        header('Location: ../forgot-password.php?error=' . urlencode('Invalid security token.'));
        exit;
    }

    $email = trim($_POST['email'] ?? '');
    
    try {
        $stmt = $pdo->prepare("SELECT id, name FROM admins WHERE email = ?");
        $stmt->execute([$email]);
        $admin = $stmt->fetch();

        if ($admin) {
            $token = bin2hex(random_bytes(32));
            $expiry = date('Y-m-d H:i:s', strtotime('+1 hour'));

            $stmt = $pdo->prepare("UPDATE admins SET reset_token = ?, token_expiry = ? WHERE id = ?");
            $stmt->execute([$token, $expiry, $admin['id']]);

            $emailHelper = new \App\Helpers\EmailHelper($pdo);
            
            // In admin, we need to construct the full URL
            $reset_url = SITE_URL . "/admin/reset-password.php?token=" . $token;
            
            if ($emailHelper->sendPasswordResetEmail($email, $admin['name'], $reset_url, true)) {
                header('Location: ../forgot-password.php?success=Reset link sent to your admin email.');
            } else {
                header('Location: ../forgot-password.php?error=Failed to send email. Check SMTP settings.');
            }
        } else {
            header('Location: ../forgot-password.php?error=No admin account found with this email.');
        }
    } catch (PDOException $e) {
        error_log('Admin forgot password error: ' . $e->getMessage());
        header('Location: ../forgot-password.php?error=' . urlencode('Something went wrong. Please try again.'));
    }
    exit;
}
?>
