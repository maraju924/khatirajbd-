<?php
// admin/actions/update-order-status.php
require_once '../../app/Services/SteadfastService.php';
session_start();
require_once __DIR__ . '/../includes/auth-guard.php';
require_once '../../config/database.php';

if (!isset($_SESSION['admin_logged_in'])) {
    exit('Unauthorized');
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $order_id = $_POST['order_id'];
    $order_status = $_POST['order_status'];
    $payment_status = $_POST['payment_status'];

    try {
        $stmt = $pdo->prepare("UPDATE orders SET order_status = ?, payment_status = ? WHERE id = ?");
        $stmt->execute([$order_status, $payment_status, $order_id]);

        // --- Steadfast Integration Start ---
        if ($order_status === 'Shipped') {
            // Fetch order details to check if already sent and to get data for Steadfast
            $stmt = $pdo->prepare("SELECT * FROM orders WHERE id = ?");
            $stmt->execute([$order_id]);
            $order = $stmt->fetch();

            if ($order && empty($order['courier_consignment_id'])) {
                try {
                    // Fetch Order Items for description
                    $stmt_items = $pdo->prepare("SELECT oi.*, p.name as product_name FROM order_items oi JOIN products p ON oi.product_id = p.id WHERE oi.order_id = ?");
                    $stmt_items->execute([$order_id]);
                    $order_items = $stmt_items->fetchAll();
                    $item_list = [];
                    foreach($order_items as $item) {
                        $label = $item['product_name'];
                        if (!empty($item['variant_label'])) {
                            $label .= ' [' . $item['variant_label'] . ']';
                        }
                        $item_list[] = $label . ' (x' . $item['qty'] . ')';
                    }
                    $item_description = implode(', ', $item_list);

                    // Fetch Note from settings
                    $stmt_note = $pdo->prepare("SELECT value FROM settings WHERE key_name = 'steadfast_note'");
                    $stmt_note->execute();
                    $db_note = $stmt_note->fetchColumn();
                    $note = $db_note ?: '”মাচেন্ট এর অনুমতি ব্যাতিত কোনো প্রোডাক্ট খুলবেন না। এবং সকল আপডেল মাচেন্টকে জানাবেন”';

                    // Submit to Steadfast
                    $steadfast = new SteadfastService();
                    $courierResult = $steadfast->createOrder([
                        'invoice' => $order['tracking_id'],
                        'recipient_name' => $order['customer_name'],
                        'recipient_phone' => $order['customer_phone'],
                        'recipient_address' => $order['shipping_address'],
                        'cod_amount' => $order['total_amount'],
                        'note' => $note,
                        'item_description' => $item_description
                    ]);

                    if ($courierResult && isset($courierResult['status']) && $courierResult['status'] == 200) {
                        $consignment_id = $courierResult['consignment']['consignment_id'];
                        $tracking_code = $courierResult['consignment']['tracking_code'];
                        $courier_status = $courierResult['consignment']['status'];

                        // Update local order with courier info
                        $updateStmt = $pdo->prepare("UPDATE orders SET courier_consignment_id = ?, tracking_id = ?, courier_status = ? WHERE id = ?");
                        $updateStmt->execute([$consignment_id, $tracking_code, $courier_status, $order_id]);
                    }
                } catch (Exception $e) {
                    // Silently fail or log to avoid blocking the main status update
                }
            }
        }
        // --- Steadfast Integration End ---
        
        // --- SMS Notification ---
        try {
            require_once '../../app/Helpers/SmsHelper.php';
            $smsHelper = new \App\Helpers\SmsHelper($pdo);
            if ($smsHelper->isEnabled()) {
                $stmt = $pdo->prepare("SELECT * FROM orders WHERE id = ?");
                $stmt->execute([$order_id]);
                $order = $stmt->fetch();
                if ($order) {
                    $smsHelper->sendOrderStatusSms($order);
                }
            }
        } catch (Exception $e) { /* Silently fail */ }
        
        // --- Automated Digital Delivery Email ---
        if ($payment_status === 'Paid') {
            try {
                // Fetch order details again to get fresh data including email
                $stmt = $pdo->prepare("SELECT * FROM orders WHERE id = ?");
                $stmt->execute([$order_id]);
                $order = $stmt->fetch();

                if ($order && $order['customer_email']) {
                    // Fetch items to check for digital products
                    $stmt_items = $pdo->prepare("SELECT oi.*, p.product_type, p.digital_file_url, p.name as product_name 
                                               FROM order_items oi 
                                               JOIN products p ON oi.product_id = p.id 
                                               WHERE oi.order_id = ?");
                    $stmt_items->execute([$order_id]);
                    $order_items = $stmt_items->fetchAll();

                    $has_digital = false;
                    foreach ($order_items as $item) {
                        if ($item['product_type'] === 'digital') {
                            $has_digital = true;
                            break;
                        }
                    }

                    if ($has_digital) {
                        // Automatically update order status to Delivered for digital products
                        $pdo->prepare("UPDATE orders SET order_status = 'Delivered' WHERE id = ?")
                            ->execute([$order_id]);
                        $order['order_status'] = 'Delivered'; // Update local object for SMS/Email context

                        require_once '../../app/Helpers/EmailHelper.php';
                        $emailHelper = new \App\Helpers\EmailHelper($pdo);
                        $emailHelper->sendDigitalDeliveryEmail($order, $order_items);
                    }
                }
            } catch (Exception $e) { /* Silently fail or log */ }
        }

        if (!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest') {
            echo json_encode(['success' => true, 'message' => 'Order updated successfully']);
            exit;
        }

        header("Location: ../index.php?page=order-view&id={$order_id}&success=Order updated successfully");
        exit;
    } catch (PDOException $e) {
        if (!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest') {
            echo json_encode(['success' => false, 'message' => $e->getMessage()]);
            exit;
        }
        header("Location: ../index.php?page=order-view&id={$order_id}&error=" . urlencode($e->getMessage()));
        exit;
    }
}
