<?php
// admin/actions/product-quick-update.php
session_start();
require_once __DIR__ . '/../includes/auth-guard.php';
require_once '../../config/database.php';

header('Content-Type: application/json');

if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    echo json_encode(['success' => false, 'message' => 'Not authorized']);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Invalid request method']);
    exit;
}

$id = $_POST['id'] ?? null;
$field = $_POST['field'] ?? null;
$value = $_POST['value'] ?? null;

if (!$id || !$field) {
    echo json_encode(['success' => false, 'message' => 'Required parameters missing']);
    exit;
}

// Allow only safe fields
$allowed_fields = ['price', 'quantity', 'status', 'show_on_website'];
if (!in_array($field, $allowed_fields)) {
    echo json_encode(['success' => false, 'message' => 'Field update not allowed']);
    exit;
}

try {
    // Validate values depending on fields
    if ($field === 'price') {
        $value = floatval($value);
        if ($value < 0) {
            echo json_encode(['success' => false, 'message' => 'Price cannot be negative']);
            exit;
        }
    } elseif ($field === 'quantity') {
        $value = intval($value);
        if ($value < 0) {
            echo json_encode(['success' => false, 'message' => 'Quantity cannot be negative']);
            exit;
        }
    } elseif ($field === 'status' || $field === 'show_on_website') {
        $value = intval($value) ? 1 : 0;
    }

    $stmt = $pdo->prepare("UPDATE products SET {$field} = ? WHERE id = ?");
    $stmt->execute([$value, $id]);

    echo json_encode([
        'success' => true,
        'message' => 'Product updated successfully',
        'value' => $value
    ]);
} catch (PDOException $e) {
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
}
exit;
