<?php
session_start();
require_once '../../config/database.php';
require_once '../../app/Helpers/CsrfHelper.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: ../login.php');
    exit;
}

if (!CsrfHelper::validate()) {
    header('Location: ../login.php?error=' . urlencode('Invalid security token. Please try again.'));
    exit;
}

$email = filter_input(INPUT_POST, 'email', FILTER_SANITIZE_EMAIL);
$password = $_POST['password'] ?? '';

$maxAttempts = 5;
$windowSeconds = 900;
$attemptKey = 'admin_login_attempts';
$attempts = $_SESSION[$attemptKey] ?? [];
if (!is_array($attempts)) {
    $attempts = [];
}
$now = time();
$attempts = array_values(array_filter($attempts, static function ($ts) use ($now, $windowSeconds) {
    return is_int($ts) && $ts > ($now - $windowSeconds);
}));

if (count($attempts) >= $maxAttempts) {
    $_SESSION[$attemptKey] = $attempts;
    header('Location: ../login.php?error=' . urlencode('Too many login attempts. Try again in 15 minutes.'));
    exit;
}

if (empty($email) || $password === '') {
    header('Location: ../login.php?error=All fields are required');
    exit;
}

try {
    $stmt = $pdo->prepare("SELECT * FROM admins WHERE email = :email");
    $stmt->execute(['email' => $email]);
    $admin = $stmt->fetch();

    if ($admin && password_verify($password, $admin['password'])) {
        unset($_SESSION[$attemptKey]);
        session_regenerate_id(true);
        $_SESSION['admin_logged_in'] = true;
        $_SESSION['admin_email'] = $admin['email'];
        $_SESSION['admin_role'] = $admin['role'];
        header('Location: ../index.php');
        exit;
    }

    $attempts[] = $now;
    $_SESSION[$attemptKey] = $attempts;
    header('Location: ../login.php?error=Invalid credentials');
    exit;
} catch (PDOException $e) {
    error_log('Admin login error: ' . $e->getMessage());
    header('Location: ../login.php?error=Database error');
    exit;
}
