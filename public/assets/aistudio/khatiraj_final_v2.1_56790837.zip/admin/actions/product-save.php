<?php
// admin/actions/product-save.php
session_start();
require_once __DIR__ . '/../includes/auth-guard.php';
require_once '../../config/database.php';
require_once '../../app/Helpers/ImageHelper.php';
use App\Helpers\ImageHelper;

// Check if it's an AJAX request
$is_ajax = !empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest';

if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    if ($is_ajax) {
        header('Content-Type: application/json');
        echo json_encode(['success' => false, 'message' => 'Not authorized']);
        exit;
    }
    header('Location: ../login.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $_POST['name'];
    $category_id = $_POST['category_id'];
    $price = $_POST['price'];
    $offer_price = !empty($_POST['offer_price']) ? $_POST['offer_price'] : NULL;
    if ($offer_price !== null && (float) $offer_price >= (float) $price) {
        $msg = 'Offer price must be less than regular price.';
        if ($is_ajax) {
            header('Content-Type: application/json');
            echo json_encode(['success' => false, 'message' => $msg]);
            exit;
        }
        header('Location: ../index.php?page=add-product&error=' . urlencode($msg));
        exit;
    }
    $quantity = $_POST['quantity'];
    $description = $_POST['description'];
    $benefits = $_POST['benefits'] ?? NULL;
    $benefits_title = $_POST['benefits_title'] ?? 'উপকারিতা:';
    $trust_points = $_POST['trust_points'] ?? NULL;
    $trust_title = $_POST['trust_title'] ?? 'কেন আমাদের থেকে নিবেন?';
    $video_url = $_POST['video_url'] ?? NULL;
    $stock_status = $_POST['stock_status'] ?? 'In Stock';
    $details_title = $_POST['details_title'] ?? 'বিস্তারিত বিবরণ:';
    $shipping_class_id = !empty($_POST['shipping_class_id']) ? $_POST['shipping_class_id'] : NULL;
    // Slug generation & uniqueness check
    $slug = !empty($_POST['slug']) ? trim($_POST['slug']) : $name;
    $slug = mb_strtolower($slug, 'UTF-8');
    $slug = preg_replace('/[^\w\x{0980}-\x{09FF}-]+/u', '-', $slug);
    $slug = preg_replace('/-+/', '-', $slug);
    $slug = trim($slug, '-');

    if (empty($slug)) {
        $slug = 'product-' . time();
    }

    $original_slug = $slug;
    $count = 1;
    while (true) {
        $stmt_check = $pdo->prepare("SELECT COUNT(*) FROM products WHERE slug = ?");
        $stmt_check->execute([$slug]);
        if ($stmt_check->fetchColumn() == 0) {
            break;
        }
        $slug = $original_slug . '-' . $count;
        $count++;
    }

    // Image Handling (Media Manager or Upload)
    $imagePath = $_POST['image'] ?? NULL;
    $projectRoot = realpath(__DIR__ . '/../..');

    if (!ImageHelper::isGdAvailable() && (isset($_FILES['image']) || !empty($imagePath))) {
        $msg = 'PHP GD extension is required for product images. Enable extension=gd in php.ini and restart Apache.';
        if ($is_ajax) {
            header('Content-Type: application/json');
            echo json_encode(['success' => false, 'message' => $msg]);
            exit;
        }
        die($msg);
    }

    // Direct file upload → 600x600 WebP
    if (isset($_FILES['image']) && $_FILES['image']['error'] == 0) {
        $targetDir = $projectRoot . DIRECTORY_SEPARATOR . 'uploads' . DIRECTORY_SEPARATOR . 'products' . DIRECTORY_SEPARATOR;
        $tempPath = $targetDir . 'tmp_' . uniqid('', true);

        if (move_uploaded_file($_FILES['image']['tmp_name'], $tempPath)) {
            $converted = ImageHelper::saveUploadedProductImage($tempPath, $_FILES['image']['name'], $targetDir);
            if ($converted) {
                $imagePath = $converted;
            }
        }
    } elseif (!empty($imagePath)) {
        $imagePath = ImageHelper::ensureProductWebp($imagePath, $projectRoot);
    }

    $product_type = $_POST['product_type'] ?? 'physical';
    $digital_file_url = !empty($_POST['digital_file_url']) ? $_POST['digital_file_url'] : NULL;
    $show_on_website = isset($_POST['show_on_website']) ? 1 : 0;

    try {
        $stmt = $pdo->prepare("INSERT INTO products (category_id, name, brand, sku, product_type, digital_file_url, slug, price, offer_price, quantity, weight, dimensions, image, image_alt_text, description, benefits, benefits_title, trust_points, trust_title, video_url, stock_status, details_title, shipping_class_id, meta_title, meta_description, meta_keywords, focus_keyword, show_on_website) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
        $stmt->execute([
            $category_id, 
            $name,
            $_POST['brand'] ?? NULL,
            $_POST['sku'] ?? NULL,
            $product_type,
            $digital_file_url,
            $slug, 
            $price, 
            $offer_price, 
            $quantity,
            $_POST['weight'] ?? NULL,
            $_POST['dimensions'] ?? NULL,
            $imagePath,
            $_POST['image_alt_text'] ?? NULL,
            $description, 
            $benefits, 
            $benefits_title, 
            $trust_points, 
            $trust_title, 
            $video_url, 
            $stock_status, 
            $details_title, 
            $shipping_class_id, 
            $_POST['meta_title'] ?? NULL, 
            $_POST['meta_description'] ?? NULL,
            $_POST['meta_keywords'] ?? NULL,
            $_POST['focus_keyword'] ?? NULL,
            $show_on_website
        ]);
        
        $productId = $pdo->lastInsertId();

        // Handle Dynamic Product Sections
        if (isset($_POST['sections']) && is_array($_POST['sections'])) {
            $stmt_sec = $pdo->prepare("INSERT INTO product_sections (product_id, title, icon, sort_order) VALUES (?, ?, ?, ?)");
            $stmt_item = $pdo->prepare("INSERT INTO product_section_items (section_id, text_content, sort_order) VALUES (?, ?, ?)");
            
            $sec_order = 1;
            foreach ($_POST['sections'] as $sec) {
                if (empty(trim($sec['title']))) continue;
                
                $title = trim($sec['title']);
                $icon = !empty(trim($sec['icon'])) ? trim($sec['icon']) : 'fas fa-check-circle';
                
                $stmt_sec->execute([$productId, $title, $icon, $sec_order++]);
                $section_id = $pdo->lastInsertId();
                
                if (isset($sec['items']) && is_array($sec['items'])) {
                    $item_order = 1;
                    foreach ($sec['items'] as $item_text) {
                        $item_text = trim($item_text);
                        if (empty($item_text)) continue;
                        $stmt_item->execute([$section_id, $item_text, $item_order++]);
                    }
                }
            }
        }

        // Handle Gallery Images
        if (!empty($_POST['gallery_images'])) {
            $gallery = json_decode($_POST['gallery_images'], true);
            if (is_array($gallery)) {
                $stmt_gal = $pdo->prepare("INSERT INTO product_images (product_id, image_path) VALUES (?, ?)");
                foreach ($gallery as $img_p) {
                    $img_p = ImageHelper::ensureProductWebp($img_p, $projectRoot);
                    $stmt_gal->execute([$productId, $img_p]);
                }
            }
        }

        // Handle Shipping Zones
        if (isset($_POST['shipping_zones']) && is_array($_POST['shipping_zones'])) {
            $stmt_sz = $pdo->prepare("INSERT INTO product_shipping_zones (product_id, shipping_zone_id) VALUES (?, ?)");
            foreach ($_POST['shipping_zones'] as $zone_id) {
                $stmt_sz->execute([$productId, $zone_id]);
            }
        }

        // Handle Payment Methods
        $allow_cod = isset($_POST['payment_method_cod']) ? 1 : 0;
        $pdo->prepare("UPDATE products SET allow_cod = ? WHERE id = ?")->execute([$allow_cod, $productId]);

        if (isset($_POST['payment_methods']) && is_array($_POST['payment_methods'])) {
            $stmt_pm = $pdo->prepare("INSERT INTO product_payment_methods (product_id, payment_method_id) VALUES (?, ?)");
            foreach ($_POST['payment_methods'] as $pm_id) {
                $stmt_pm->execute([$productId, $pm_id]);
            }
        }

        require_once __DIR__ . '/../../app/Helpers/ProductVariantHelper.php';
        ProductVariantHelper::saveFromPost($pdo, (int) $productId, $_POST);

        if (!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest') {
            echo json_encode(['success' => true, 'message' => 'Product created successfully']);
            exit;
        }

        header('Location: ../index.php?page=products&success=Product created');
    } catch (PDOException $e) {
        error_log('Product save error: ' . $e->getMessage());
        if (!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest') {
            echo json_encode(['success' => false, 'message' => 'Could not save product. Please try again.']);
            exit;
        }
        header('Location: ../index.php?page=products&error=' . urlencode('Could not save product. Please try again.'));
        exit;
    }
}
exit();
