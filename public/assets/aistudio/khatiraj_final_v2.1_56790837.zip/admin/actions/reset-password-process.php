<?php
// admin/actions/reset-password-process.php
session_start();
require_once '../../config/database.php';
require_once '../../app/Helpers/CsrfHelper.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!CsrfHelper::validate()) {
        header('Location: ../login.php?error=' . urlencode('Invalid security token.'));
        exit;
    }

    $token = $_POST['token'] ?? '';
    $password = $_POST['password'] ?? '';
    $confirm_password = $_POST['confirm_password'] ?? '';

    if ($password !== $confirm_password) {
        header('Location: ../reset-password.php?token=' . urlencode($token) . '&error=Passwords do not match.');
        exit;
    }

    try {
        $stmt = $pdo->prepare("SELECT id FROM admins WHERE reset_token = ? AND token_expiry > NOW()");
        $stmt->execute([$token]);
        $admin = $stmt->fetch();

        if ($admin) {
            $hashed_password = password_hash($password, PASSWORD_BCRYPT);
            $stmt = $pdo->prepare("UPDATE admins SET password = ?, reset_token = NULL, token_expiry = NULL WHERE id = ?");
            $stmt->execute([$hashed_password, $admin['id']]);

            header('Location: ../login.php?success=Password updated successfully! Please login.');
        } else {
            header('Location: ../login.php?error=Invalid or expired reset token.');
        }
    } catch (PDOException $e) {
        error_log('Admin reset password error: ' . $e->getMessage());
        header('Location: ../reset-password.php?token=' . urlencode($token) . '&error=' . urlencode('Something went wrong. Please try again.'));
    }
    exit;
}
?>
