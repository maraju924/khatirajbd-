<?php
// admin/actions/sync-steadfast-status.php
session_start();
require_once __DIR__ . '/../includes/auth-guard.php';
require_once '../../config/database.php';
require_once '../../app/Services/SteadfastService.php';

if (!isset($_SESSION['admin_logged_in'])) {
    exit(json_encode(['status' => 'error', 'message' => 'Unauthorized']));
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $order_id = $_POST['order_id'];

    try {
        $stmt = $pdo->prepare("SELECT id, tracking_id, courier_consignment_id FROM orders WHERE id = ?");
        $stmt->execute([$order_id]);
        $order = $stmt->fetch();

        if (!$order || empty($order['tracking_id'])) {
            throw new Exception("Order or Tracking ID not found.");
        }

        $steadfast = new SteadfastService();
        $result = $steadfast->getStatusByTrackingCode($order['tracking_id']);

        if ($result && isset($result['status']) && $result['status'] == 200) {
            $new_courier_status = $result['delivery_status'];
            
            // Map Steadfast Status to Local Status
            $new_order_status = match($new_courier_status) {
                'pending', 'in_review', 'hold' => 'Processing',
                'delivered' => 'Delivered',
                'partial_delivered' => 'Shipped', // Or a custom status
                'cancelled', 'unknown' => 'Cancelled',
                'delivered_approval_pending', 'partial_delivered_approval_pending' => 'Delivered',
                default => null
            };

            // Update database
            $sql = "UPDATE orders SET courier_status = ?";
            $params = [$new_courier_status];
            
            if ($new_order_status) {
                $sql .= ", order_status = ?";
                $params[] = $new_order_status;
            }
            
            $sql .= " WHERE id = ?";
            $params[] = $order_id;

            $updateStmt = $pdo->prepare($sql);
            $updateStmt->execute($params);

            if (!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest') {
                echo json_encode(['status' => 'success', 'courier_status' => $new_courier_status, 'order_status' => $new_order_status]);
                exit;
            }
            $redirect = $_POST['redirect'] ?? 'order-view';
            $location = ($redirect == 'orders') ? "index.php?page=orders&success=Status synced" : "index.php?page=order-view&id={$order_id}&success=Status synced with Steadfast";
            header("Location: ../" . $location);
            exit;
        } else {
            throw new Exception($result['error'] ?? 'Failed to fetch status from Steadfast');
        }

    } catch (Exception $e) {
        if (!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest') {
            echo json_encode(['status' => 'error', 'message' => $e->getMessage()]);
            exit;
        }
        $redirect = $_POST['redirect'] ?? 'order-view';
        $location = ($redirect == 'orders') ? "index.php?page=orders&error=" : "index.php?page=order-view&id={$order_id}&error=";
        header("Location: ../" . $location . urlencode($e->getMessage()));
        exit;
    }
}
