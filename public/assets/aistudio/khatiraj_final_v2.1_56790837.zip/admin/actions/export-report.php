<?php
// admin/actions/export-report.php
session_start();
require_once __DIR__ . '/../includes/auth-guard.php';
require_once '../../config/database.php';

// Check if admin is logged in
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header('Location: ../login.php');
    exit;
}

$start_date = $_GET['start_date'] ?? date('Y-m-01');
$end_date = $_GET['end_date'] ?? date('Y-m-d');

try {
    // Fetch Filtered Orders
    $stmt = $pdo->prepare("
        SELECT o.tracking_id, COALESCE(u.name, o.customer_name, 'Guest') as customer_name, o.total_amount, o.order_status, o.payment_status, o.created_at, o.customer_phone
        FROM orders o
        LEFT JOIN users u ON o.user_id = u.id
        WHERE o.order_status != 'Cancelled' AND DATE(o.created_at) BETWEEN ? AND ?
        ORDER BY o.created_at DESC
    ");
    $stmt->execute([$start_date, $end_date]);
    $orders = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Set headers for download
    $filename = "Sales_Report_" . $start_date . "_to_" . $end_date . ".csv";
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename=' . $filename);

    $output = fopen('php://output', 'w');
    
    // Header Row
    fputcsv($output, ['Tracking ID', 'Customer Name', 'Phone', 'Total Amount', 'Order Status', 'Payment Status', 'Date']);

    // Data Rows
    foreach ($orders as $order) {
        fputcsv($output, [
            $order['tracking_id'],
            $order['customer_name'] ?: 'Guest',
            $order['customer_phone'],
            $order['total_amount'],
            $order['order_status'],
            $order['payment_status'],
            date('Y-m-d H:i', strtotime($order['created_at']))
        ]);
    }

    fclose($output);
    exit();

} catch (PDOException $e) {
    die("Export failed: " . $e->getMessage());
}
