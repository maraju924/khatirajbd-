<?php
// admin/actions/product-toggle-visibility.php
session_start();
require_once __DIR__ . '/../includes/auth-guard.php';
require_once '../../config/database.php';

header('Content-Type: application/json');

if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    echo json_encode(['success' => false, 'message' => 'Not authorized']);
    exit;
}

$id = $_GET['id'] ?? null;

if (!$id) {
    echo json_encode(['success' => false, 'message' => 'Product ID required']);
    exit;
}

try {
    // Get current value
    $stmt = $pdo->prepare("SELECT show_on_website FROM products WHERE id = ?");
    $stmt->execute([$id]);
    $current = $stmt->fetchColumn();

    if ($current === false) {
        echo json_encode(['success' => false, 'message' => 'Product not found']);
        exit;
    }

    // Toggle
    $new_value = $current ? 0 : 1;
    $stmt_update = $pdo->prepare("UPDATE products SET show_on_website = ? WHERE id = ?");
    $stmt_update->execute([$new_value, $id]);

    echo json_encode([
        'success' => true,
        'show_on_website' => $new_value,
        'message' => $new_value ? 'Product is now visible on website' : 'Product is now hidden from website'
    ]);
} catch (PDOException $e) {
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
}
exit;
