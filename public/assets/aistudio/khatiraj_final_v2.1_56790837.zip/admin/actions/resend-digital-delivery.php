<?php
// admin/actions/resend-digital-delivery.php
session_start();
require_once __DIR__ . '/../includes/auth-guard.php';
require_once '../../config/database.php';
require_once '../../app/Helpers/EmailHelper.php';

if (!isset($_SESSION['admin_logged_in'])) {
    exit('Unauthorized');
}

$order_id = $_GET['id'] ?? null;

if (!$order_id) {
    header('Location: ../index.php?page=orders&error=Invalid Order ID');
    exit;
}

try {
    $stmt = $pdo->prepare("SELECT * FROM orders WHERE id = ?");
    $stmt->execute([$order_id]);
    $order = $stmt->fetch();

    if (!$order) {
        throw new Exception("Order not found.");
    }

    // Fetch items
    $stmt_items = $pdo->prepare("SELECT oi.*, p.product_type, p.digital_file_url, p.name as product_name 
                               FROM order_items oi 
                               JOIN products p ON oi.product_id = p.id 
                               WHERE oi.order_id = ?");
    $stmt_items->execute([$order_id]);
    $order_items = $stmt_items->fetchAll();

    $emailHelper = new \App\Helpers\EmailHelper($pdo);
    if ($emailHelper->sendDigitalDeliveryEmail($order, $order_items)) {
        header("Location: ../index.php?page=order-view&id={$order_id}&success=Digital delivery email resent successfully");
    } else {
        header("Location: ../index.php?page=order-view&id={$order_id}&error=Failed to resend email. Please check SMTP settings.");
    }
} catch (Exception $e) {
    header("Location: ../index.php?page=order-view&id={$order_id}&error=" . urlencode($e->getMessage()));
}
exit;
