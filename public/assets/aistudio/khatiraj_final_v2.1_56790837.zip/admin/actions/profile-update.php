<?php
// admin/actions/profile-update.php
session_start();
require_once __DIR__ . '/../includes/auth-guard.php';
require_once '../../config/database.php';

if (!isset($_SESSION['admin_email'])) {
    header('Location: ../login.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name']);
    $password = $_POST['password'] ?? '';
    $confirm_password = $_POST['confirm_password'] ?? '';
    $email = $_SESSION['admin_email'];

    // Check if it's an AJAX request
    $is_ajax = !empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest';

    if (empty($name)) {
        $error_msg = 'Name is required';
        if ($is_ajax) {
            header('Content-Type: application/json');
            echo json_encode(['success' => false, 'message' => $error_msg]);
            exit;
        }
        header('Location: ../index.php?page=profile&error=' . urlencode($error_msg));
        exit;
    }

    try {
        if (!empty($password)) {
            // Password change requested
            if (strlen($password) < 6) {
                $error_msg = 'Password must be at least 6 characters';
                if ($is_ajax) {
                    header('Content-Type: application/json');
                    echo json_encode(['success' => false, 'message' => $error_msg]);
                    exit;
                }
                header('Location: ../index.php?page=profile&error=' . urlencode($error_msg));
                exit;
            }
            if ($password !== $confirm_password) {
                $error_msg = 'Passwords do not match';
                if ($is_ajax) {
                    header('Content-Type: application/json');
                    echo json_encode(['success' => false, 'message' => $error_msg]);
                    exit;
                }
                header('Location: ../index.php?page=profile&error=' . urlencode($error_msg));
                exit;
            }
            $hashed_password = password_hash($password, PASSWORD_BCRYPT);
            $stmt = $pdo->prepare("UPDATE admins SET name = ?, password = ? WHERE email = ?");
            $stmt->execute([$name, $hashed_password, $email]);
        } else {
            // Only update name
            $stmt = $pdo->prepare("UPDATE admins SET name = ? WHERE email = ?");
            $stmt->execute([$name, $email]);
        }

        // Update session with new name
        $_SESSION['admin_name'] = $name;

        $success_msg = !empty($password) ? 'Password updated successfully' : 'Profile updated successfully';
        if ($is_ajax) {
            header('Content-Type: application/json');
            echo json_encode(['success' => true, 'message' => $success_msg]);
            exit;
        }
        header('Location: ../index.php?page=profile&success=' . urlencode($success_msg));
    } catch (PDOException $e) {
        $error_msg = 'Database Error: ' . $e->getMessage();
        if ($is_ajax) {
            header('Content-Type: application/json');
            echo json_encode(['success' => false, 'message' => $error_msg]);
            exit;
        }
        header('Location: ../index.php?page=profile&error=' . urlencode($error_msg));
    }
}
exit();
