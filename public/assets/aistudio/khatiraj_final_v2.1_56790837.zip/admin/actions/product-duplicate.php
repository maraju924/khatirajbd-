<?php
// admin/actions/product-duplicate.php
session_start();
require_once __DIR__ . '/../includes/auth-guard.php';
require_once '../../config/database.php';

header('Content-Type: application/json');

if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    echo json_encode(['success' => false, 'message' => 'Not authorized']);
    exit;
}

$id = $_GET['id'] ?? null;
if (!$id) {
    echo json_encode(['success' => false, 'message' => 'Product ID is required']);
    exit;
}

try {
    $pdo->beginTransaction();

    // 1. Fetch original product
    $stmt = $pdo->prepare("SELECT * FROM products WHERE id = ?");
    $stmt->execute([$id]);
    $product = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$product) {
        echo json_encode(['success' => false, 'message' => 'Product not found']);
        $pdo->rollBack();
        exit;
    }

    // 2. Generate new name and unique slug
    $new_name = $product['name'] . ' - Copy';
    $slug_base = $product['slug'] . '-copy';
    
    // Clean slug
    $slug_base = mb_strtolower($slug_base, 'UTF-8');
    $slug_base = preg_replace('/[^\w\x{0980}-\x{09FF}-]+/u', '-', $slug_base);
    $slug_base = preg_replace('/-+/', '-', $slug_base);
    $slug_base = trim($slug_base, '-');

    $slug = $slug_base;
    $count = 1;
    while (true) {
        $stmt_check = $pdo->prepare("SELECT COUNT(*) FROM products WHERE slug = ?");
        $stmt_check->execute([$slug]);
        if ($stmt_check->fetchColumn() == 0) {
            break;
        }
        $slug = $slug_base . '-' . $count;
        $count++;
    }

    // 3. Insert duplicate product
    $columns = array_keys($product);
    // remove 'id' from columns
    $columns = array_diff($columns, ['id', 'created_at', 'updated_at']);
    
    $select_placeholders = [];
    foreach ($columns as $col) {
        if ($col === 'name') {
            $select_placeholders[] = '?';
        } elseif ($col === 'slug') {
            $select_placeholders[] = '?';
        } else {
            $select_placeholders[] = '`' . $col . '`';
        }
    }

    $col_names = implode(', ', array_map(fn($c) => '`' . $c . '`', $columns));
    $sql = "INSERT INTO products ($col_names) SELECT " . implode(', ', $select_placeholders) . " FROM products WHERE id = ?";
    
    $stmt_insert = $pdo->prepare($sql);
    $stmt_insert->execute([$new_name, $slug, $id]);
    $new_id = $pdo->lastInsertId();

    // 4. Duplicate product_images (gallery)
    $stmt_images = $pdo->prepare("INSERT INTO product_images (product_id, image_path, sort_order) SELECT ?, image_path, sort_order FROM product_images WHERE product_id = ?");
    $stmt_images->execute([$new_id, $id]);

    // 5. Duplicate product_shipping_zones
    $stmt_zones = $pdo->prepare("INSERT INTO product_shipping_zones (product_id, shipping_zone_id) SELECT ?, shipping_zone_id FROM product_shipping_zones WHERE product_id = ?");
    $stmt_zones->execute([$new_id, $id]);

    // 6. Duplicate product_payment_methods
    $stmt_payment = $pdo->prepare("INSERT INTO product_payment_methods (product_id, payment_method_id) SELECT ?, payment_method_id FROM product_payment_methods WHERE product_id = ?");
    $stmt_payment->execute([$new_id, $id]);

    // 7. Duplicate product_sections
    $stmt_sections = $pdo->prepare("SELECT * FROM product_sections WHERE product_id = ? ORDER BY sort_order ASC");
    $stmt_sections->execute([$id]);
    $sections = $stmt_sections->fetchAll(PDO::FETCH_ASSOC);

    $stmt_sec_insert = $pdo->prepare("INSERT INTO product_sections (product_id, title, icon, sort_order) VALUES (?, ?, ?, ?)");
    $stmt_item_insert = $pdo->prepare("INSERT INTO product_section_items (section_id, text_content, sort_order) VALUES (?, ?, ?)");

    foreach ($sections as $section) {
        $stmt_sec_insert->execute([$new_id, $section['title'], $section['icon'], $section['sort_order']]);
        $new_sec_id = $pdo->lastInsertId();

        $stmt_items = $pdo->prepare("SELECT * FROM product_section_items WHERE section_id = ? ORDER BY sort_order ASC");
        $stmt_items->execute([$section['id']]);
        $items = $stmt_items->fetchAll(PDO::FETCH_ASSOC);

        foreach ($items as $item) {
            $stmt_item_insert->execute([$new_sec_id, $item['text_content'], $item['sort_order']]);
        }
    }

    // 8. Duplicate variants (product_variant_attributes, product_variant_attribute_values, product_variants)
    $stmt_attr = $pdo->prepare("SELECT * FROM product_variant_attributes WHERE product_id = ? ORDER BY sort_order ASC");
    $stmt_attr->execute([$id]);
    $attributes = $stmt_attr->fetchAll(PDO::FETCH_ASSOC);

    $stmt_attr_insert = $pdo->prepare("INSERT INTO product_variant_attributes (product_id, name, display_type, sort_order) VALUES (?, ?, ?, ?)");
    $stmt_val_insert = $pdo->prepare("INSERT INTO product_variant_attribute_values (attribute_id, value, color_hex, sort_order) VALUES (?, ?, ?, ?)");

    foreach ($attributes as $attr) {
        $stmt_attr_insert->execute([$new_id, $attr['name'], $attr['display_type'], $attr['sort_order']]);
        $new_attr_id = $pdo->lastInsertId();

        $stmt_vals = $pdo->prepare("SELECT * FROM product_variant_attribute_values WHERE attribute_id = ? ORDER BY sort_order ASC");
        $stmt_vals->execute([$attr['id']]);
        $vals = $stmt_vals->fetchAll(PDO::FETCH_ASSOC);

        foreach ($vals as $val) {
            $stmt_val_insert->execute([$new_attr_id, $val['value'], $val['color_hex'], $val['sort_order']]);
        }
    }

    $stmt_var_insert = $pdo->prepare("INSERT INTO product_variants (product_id, sku, combination_json, price, offer_price, quantity, stock_status, sort_order) SELECT ?, sku, combination_json, price, offer_price, quantity, stock_status, sort_order FROM product_variants WHERE product_id = ?");
    $stmt_var_insert->execute([$new_id, $id]);

    $pdo->commit();

    echo json_encode(['success' => true, 'message' => 'Product duplicated successfully']);
} catch (Exception $e) {
    $pdo->rollBack();
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
}
exit;
