<?php
// admin/actions/bulk-send-steadfast.php
// Send multiple selected orders to Steadfast in one go (max 20 per batch).
session_start();
require_once __DIR__ . '/../includes/auth-guard.php';
require_once '../../config/database.php';
require_once '../../app/Services/SteadfastService.php';

header('Content-Type: application/json');

if (!isset($_SESSION['admin_logged_in']) || !in_array($_SESSION['admin_role'] ?? '', ['super_admin', 'moderator'])) {
    http_response_code(403);
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'POST required']);
    exit;
}

$order_ids = array_slice(array_filter(array_map('intval', $_POST['order_ids'] ?? [])), 0, 20);
if (empty($order_ids)) {
    echo json_encode(['success' => false, 'message' => 'No orders selected']);
    exit;
}

$steadfast = new SteadfastService();
if (!$steadfast->isConfigured()) {
    echo json_encode(['success' => false, 'message' => 'Steadfast API not configured']);
    exit;
}

// Default note from settings
$db_note = '';
try {
    $stmt = $pdo->prepare("SELECT value FROM settings WHERE key_name = 'steadfast_note'");
    $stmt->execute();
    $db_note = $stmt->fetchColumn() ?: '';
} catch (PDOException $e) {}
$note = $db_note ?: '”মাচেন্ট এর অনুমতি ব্যাতিত কোনো প্রোডাক্ট খুলবেন না। এবং সকল আপডেল মাচেন্টকে জানাবেন”';

$sent = 0;
$skipped = 0;
$failed = [];

foreach ($order_ids as $order_id) {
    try {
        $stmt = $pdo->prepare("SELECT * FROM orders WHERE id = ?");
        $stmt->execute([$order_id]);
        $order = $stmt->fetch();

        if (!$order || !empty($order['courier_consignment_id'])) {
            $skipped++;
            continue;
        }

        $stmt_items = $pdo->prepare("SELECT oi.*, p.name as product_name FROM order_items oi JOIN products p ON oi.product_id = p.id WHERE oi.order_id = ?");
        $stmt_items->execute([$order_id]);
        $item_list = [];
        foreach ($stmt_items->fetchAll() as $item) {
            $label = $item['product_name'];
            if (!empty($item['variant_label'])) {
                $label .= ' [' . $item['variant_label'] . ']';
            }
            $item_list[] = $label . ' (x' . $item['qty'] . ')';
        }

        $result = $steadfast->createOrder([
            'invoice' => $order['tracking_id'],
            'recipient_name' => $order['customer_name'],
            'recipient_phone' => $order['customer_phone'],
            'recipient_address' => $order['shipping_address'],
            'cod_amount' => $order['total_amount'],
            'note' => $note,
            'item_description' => implode(', ', $item_list),
        ]);

        if ($result && isset($result['status']) && $result['status'] == 200) {
            $pdo->prepare("UPDATE orders SET courier_consignment_id = ?, tracking_id = ?, courier_status = ? WHERE id = ?")
                ->execute([
                    $result['consignment']['consignment_id'],
                    $result['consignment']['tracking_code'],
                    $result['consignment']['status'],
                    $order_id,
                ]);
            $sent++;
        } else {
            $failed[] = '#' . $order_id . ': ' . ($result['error'] ?? 'API error');
        }
    } catch (Throwable $e) {
        $failed[] = '#' . $order_id . ': ' . $e->getMessage();
    }
}

echo json_encode([
    'success' => true,
    'sent' => $sent,
    'skipped' => $skipped,
    'failed' => $failed,
], JSON_UNESCAPED_UNICODE);
