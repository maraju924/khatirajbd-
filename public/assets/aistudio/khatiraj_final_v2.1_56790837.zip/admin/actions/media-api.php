<?php
// admin/actions/media-api.php
session_start();
require_once __DIR__ . '/../includes/auth-guard.php';
require_once '../../config/database.php';

if (!isset($_SESSION['admin_logged_in'])) {
    header('HTTP/1.1 403 Forbidden');
    exit;
}

$base_dir = "../../uploads/";
$all_files = [];

if (is_dir($base_dir)) {
    $iterator = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($base_dir));
    foreach ($iterator as $file) {
        if ($file->isFile()) {
            $filename = $file->getFilename();
            $ext = strtolower(pathinfo($filename, PATHINFO_EXTENSION));
            $allowed = ['jpg', 'jpeg', 'png', 'gif', 'webp', 'svg'];
            
            if (in_array($ext, $allowed)) {
                // Get relative path from ecommerce-project root
                $full_path = str_replace('\\', '/', $file->getRealPath());
                $project_root = str_replace('\\', '/', realpath('../../../')); // Goes up to htdocs if we are in admin/actions, wait.
                // admin/actions/media-api.php -> realpath('../../') is htdocs/ecommerce-project/
                $project_root = str_replace('\\', '/', realpath('../../'));
                $relative_path = ltrim(str_replace($project_root, '', $full_path), '/');

                $all_files[] = [
                    'name' => $filename,
                    'path' => $relative_path,
                    'time' => $file->getMTime()
                ];
            }
        }
    }
}

// Sort by time descending
usort($all_files, function($a, $b) {
    return $b['time'] - $a['time'];
});

header('Content-Type: application/json');
echo json_encode($all_files);
