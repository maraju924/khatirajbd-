<?php
// admin/actions/page-create.php
session_start();
require_once __DIR__ . '/../includes/auth-guard.php';
require_once '../../config/database.php';
require_once '../../app/Helpers/CacheHelper.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: ../index.php?page=page-manager');
    exit;
}

$page_name = trim($_POST['page_name'] ?? '');
$slug_raw = trim($_POST['slug'] ?? '');
$content_mode = 'sections'; // Advanced Page Builder only

// Normalize slug: lowercase, spaces to hyphen, strip invalid chars
$slug = strtolower($slug_raw);
$slug = preg_replace('/[^a-z0-9\-]+/', '-', $slug);
$slug = trim($slug, '-');

if ($page_name === '' || $slug === '') {
    header('Location: ../index.php?page=page-manager&error=' . urlencode('Page name and slug are required'));
    exit;
}

$route_slug = '/' . $slug;
$route_key = 'custom_' . str_replace('-', '_', $slug);

// Reserved system slugs that must not be overridden
$reserved = ['/', '/home', '/shop', '/cart', '/checkout', '/thanks', '/login', '/register', '/auth',
    '/dashboard', '/track-order', '/blog',
    '/payment-gateway', '/order-summary-public', '/forgot-password', '/reset-password'];

try {
    if (in_array($route_slug, $reserved, true)) {
        header('Location: ../index.php?page=page-manager&error=' . urlencode('That slug is reserved by a system page'));
        exit;
    }

    // Check for existing slug or route key
    $check = $pdo->prepare("SELECT id FROM page_registry WHERE slug = ? OR route_key = ?");
    $check->execute([$route_slug, $route_key]);
    if ($check->fetchColumn()) {
        header('Location: ../index.php?page=page-manager&error=' . urlencode('A page with that slug already exists'));
        exit;
    }

    // Determine next sort order
    $sort = (int)$pdo->query("SELECT COALESCE(MAX(sort_order), 0) + 1 FROM page_registry")->fetchColumn();

    $stmt = $pdo->prepare("INSERT INTO page_registry (route_key, slug, page_group, page_name, template, content_mode, status, sort_order) VALUES (?, ?, 'content', ?, 'default', ?, 1, ?)");
    $stmt->execute([$route_key, $route_slug, $page_name, $content_mode, $sort]);
    $new_id = (int)$pdo->lastInsertId();

    CacheHelper::clearAll();

    $tab = $content_mode === 'sections' ? 'content' : 'content';
    header("Location: ../index.php?page=edit-page&id={$new_id}&tab={$tab}&success=" . urlencode('Custom page created. Add your content now.'));
    exit;
} catch (PDOException $e) {
    header('Location: ../index.php?page=page-manager&error=' . urlencode($e->getMessage()));
    exit;
}
