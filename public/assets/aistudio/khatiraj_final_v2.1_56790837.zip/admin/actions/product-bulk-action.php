<?php
// admin/actions/product-bulk-action.php
session_start();
require_once __DIR__ . '/../includes/auth-guard.php';
require_once '../../config/database.php';

header('Content-Type: application/json');

if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    echo json_encode(['success' => false, 'message' => 'Not authorized']);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Invalid request method']);
    exit;
}

$action = $_POST['action'] ?? '';
$ids = $_POST['ids'] ?? [];

if (empty($action) || empty($ids) || !is_array($ids)) {
    echo json_encode(['success' => false, 'message' => 'Invalid parameters']);
    exit;
}

// Convert all IDs to integers
$ids = array_map('intval', $ids);
$placeholders = implode(',', array_fill(0, count($ids), '?'));

try {
    if ($action === 'delete') {
        // We need to delete sections and items manually or rely on foreign key cascades
        // Let's delete sections first
        $stmt_sec = $pdo->prepare("DELETE FROM product_sections WHERE product_id IN ($placeholders)");
        $stmt_sec->execute($ids);

        // Delete variants
        $stmt_var = $pdo->prepare("DELETE FROM product_variants WHERE product_id IN ($placeholders)");
        $stmt_var->execute($ids);

        // Delete attributes
        $stmt_attr = $pdo->prepare("DELETE FROM product_variant_attributes WHERE product_id IN ($placeholders)");
        $stmt_attr->execute($ids);

        // Delete images
        $stmt_img = $pdo->prepare("DELETE FROM product_images WHERE product_id IN ($placeholders)");
        $stmt_img->execute($ids);

        // Delete shipping zones
        $stmt_sz = $pdo->prepare("DELETE FROM product_shipping_zones WHERE product_id IN ($placeholders)");
        $stmt_sz->execute($ids);

        // Delete payment methods
        $stmt_pm = $pdo->prepare("DELETE FROM product_payment_methods WHERE product_id IN ($placeholders)");
        $stmt_pm->execute($ids);

        // Delete products
        $stmt = $pdo->prepare("DELETE FROM products WHERE id IN ($placeholders)");
        $stmt->execute($ids);
        
        $msg = 'Selected products deleted successfully';
    } elseif ($action === 'visible') {
        $stmt = $pdo->prepare("UPDATE products SET show_on_website = 1 WHERE id IN ($placeholders)");
        $stmt->execute($ids);
        $msg = 'Selected products are now visible on website';
    } elseif ($action === 'hidden') {
        $stmt = $pdo->prepare("UPDATE products SET show_on_website = 0 WHERE id IN ($placeholders)");
        $stmt->execute($ids);
        $msg = 'Selected products are now hidden from website';
    } elseif ($action === 'active') {
        $stmt = $pdo->prepare("UPDATE products SET status = 1 WHERE id IN ($placeholders)");
        $stmt->execute($ids);
        $msg = 'Selected products are now active';
    } elseif ($action === 'inactive') {
        $stmt = $pdo->prepare("UPDATE products SET status = 0 WHERE id IN ($placeholders)");
        $stmt->execute($ids);
        $msg = 'Selected products are now inactive';
    } else {
        echo json_encode(['success' => false, 'message' => 'Action not supported']);
        exit;
    }

    echo json_encode(['success' => true, 'message' => $msg]);
} catch (PDOException $e) {
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
}
exit;
