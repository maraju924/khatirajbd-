<?php
/**
 * Minify admin CSS files for production
 * Usage: php admin/build-css.php
 */
$base = __DIR__ . '/css';
$files = ['admin.css', 'admin-components.css'];
$output = '';

foreach ($files as $file) {
    $path = $base . '/' . $file;
    if (!file_exists($path)) continue;
    $css = file_get_contents($path);
    $css = preg_replace('/\/\*[\s\S]*?\*\//', '', $css);
    $css = preg_replace('/\s+/', ' ', $css);
    $css = str_replace(['; ', ' {', '{ ', ' }', '} ', ': '], [';', '{', '{', '}', '}', ':'], $css);
    $output .= $css;
}

file_put_contents($base . '/admin.bundle.min.css', trim($output));
echo "Built admin.bundle.min.css (" . strlen($output) . " bytes)\n";
