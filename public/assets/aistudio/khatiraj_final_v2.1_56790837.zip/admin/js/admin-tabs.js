/**
 * Shared admin section tabs (Settings-style panels).
 * Supports .settings-layout / .admin-shell with data-settings-nav or data-admin-nav.
 */
(function (window, document) {
    'use strict';

    function getLayout(el) {
        return el ? el.closest('.settings-layout, .admin-shell') : document.querySelector('.settings-layout, .admin-shell');
    }

    function navAttr(a) {
        return a.getAttribute('data-settings-nav') || a.getAttribute('data-admin-nav');
    }

    function panelId(layout, id) {
        var prefix = layout.getAttribute('data-panel-prefix') || 'settings';
        return prefix + '-' + id;
    }

    function activateAdminSection(id, opts, layoutEl) {
        opts = opts || {};
        var layout = layoutEl || document.querySelector('.settings-layout, .admin-shell');
        if (!layout) return false;

        var prefix = layout.getAttribute('data-panel-prefix') || 'settings';
        var panel = document.getElementById(prefix + '-' + id);
        if (!panel || !(panel.classList.contains('settings-panel') || panel.classList.contains('admin-panel'))) {
            var firstNav = layout.querySelector('[data-settings-nav], [data-admin-nav]');
            id = firstNav ? navAttr(firstNav) : id;
            panel = document.getElementById(prefix + '-' + id);
        }
        if (!panel) return false;

        layout.querySelectorAll('.settings-panel, .admin-panel').forEach(function (p) {
            var on = p === panel;
            p.classList.toggle('is-active', on);
            p.hidden = !on;
            p.setAttribute('aria-hidden', on ? 'false' : 'true');
        });

        layout.querySelectorAll('[data-settings-nav], [data-admin-nav]').forEach(function (a) {
            var on = navAttr(a) === id;
            a.classList.toggle('active', on);
            a.setAttribute('aria-selected', on ? 'true' : 'false');
            a.setAttribute('tabindex', on ? '0' : '-1');
            if (on && opts.scrollTab) {
                var track = layout.querySelector('.settings-tabs-track, .admin-tabs-track');
                if (track && a.scrollIntoView) {
                    a.scrollIntoView({ behavior: 'smooth', inline: 'center', block: 'nearest' });
                }
            }
        });

        if (opts.updateHash && history.replaceState) {
            var base = location.pathname + location.search;
            history.replaceState(history.state, '', base + '#' + prefix + '-' + id);
        }

        if (opts.scrollTop !== false) {
            var tabsBar = layout.querySelector('.settings-tabs, .admin-tabs');
            var y = 0;
            if (tabsBar) {
                y = Math.max(0, tabsBar.getBoundingClientRect().top + window.pageYOffset - 80);
            }
            window.scrollTo({ top: y, behavior: opts.instant ? 'auto' : 'smooth' });
        }

        return true;
    }

    function initHiddenPairToggles(root) {
        (root || document).querySelectorAll('input[data-hidden-pair]').forEach(function (cb) {
            if (cb.dataset.adminToggleBound) return;
            cb.dataset.adminToggleBound = '1';
            var sync = function () {
                var hidden = document.getElementById(cb.getAttribute('data-hidden-pair'));
                if (hidden) hidden.disabled = cb.checked;
            };
            cb.addEventListener('change', sync);
            sync();
        });
    }

    function bootAdminTabs() {
        document.querySelectorAll('.settings-layout, .admin-shell').forEach(function (layout) {
            initHiddenPairToggles(layout);
            var prefix = layout.getAttribute('data-panel-prefix') || 'settings';
            var hashId = '';
            if (location.hash) {
                hashId = location.hash.replace(new RegExp('^#' + prefix + '-'), '').replace(/^#/, '');
            }
            var first = layout.querySelector('[data-settings-nav], [data-admin-nav]');
            var startId = hashId || (first ? navAttr(first) : '');
            if (startId) {
                activateAdminSection(startId, { scrollTab: true, scrollTop: false, updateHash: false }, layout);
            }
        });
    }

    if (!window.__adminTabsClickBound) {
        window.__adminTabsClickBound = true;
        document.addEventListener('click', function (e) {
            var a = e.target.closest('[data-settings-nav], [data-admin-nav]');
            if (!a) return;
            var layout = getLayout(a);
            if (!layout) return;
            e.preventDefault();
            e.stopPropagation();
            activateAdminSection(navAttr(a), {
                scrollTab: true,
                updateHash: true,
                scrollTop: true
            }, layout);
        }, true);
    }

    if (!window.__adminTabsBootBound) {
        window.__adminTabsBootBound = true;
        document.addEventListener('DOMContentLoaded', bootAdminTabs);
        window.addEventListener('pjax:complete', bootAdminTabs);
    }

    if (document.readyState !== 'loading') {
        bootAdminTabs();
    }

    window.AdminTabs = {
        activate: activateAdminSection,
        boot: bootAdminTabs,
        initToggles: initHiddenPairToggles
    };
})(window, document);
