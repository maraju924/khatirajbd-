/**
 * KhatiRaj Admin UI — sidebar accordion, toasts, table sort, mobile cards
 */
(function () {
    'use strict';

    // Sidebar accordion groups
    function initSidebarGroups() {
        const groups = document.querySelectorAll('.nav-group');
        const currentPage = new URLSearchParams(window.location.search).get('page') || 'dashboard';
        const saved = JSON.parse(localStorage.getItem('adminSidebarGroups') || '{}');

        groups.forEach(group => {
            const id = group.dataset.group;
            const toggle = group.querySelector('.nav-group-toggle');
            const hasActive = group.querySelector('.nav-link.active');

            if (hasActive || saved[id] === true) {
                group.classList.add('open');
            }

            toggle?.addEventListener('click', () => {
                group.classList.toggle('open');
                saved[id] = group.classList.contains('open');
                localStorage.setItem('adminSidebarGroups', JSON.stringify(saved));
            });
        });
    }

    // Sidebar quick search
    function initSidebarSearch() {
        const input = document.getElementById('sidebar-nav-search');
        if (!input) return;
        input.addEventListener('input', () => {
            const q = input.value.toLowerCase().trim();
            document.querySelectorAll('.sidebar .nav-link').forEach(link => {
                const text = link.textContent.toLowerCase();
                link.classList.toggle('hidden-by-search', q.length > 0 && !text.includes(q));
            });
            if (q.length > 0) {
                document.querySelectorAll('.nav-group').forEach(g => g.classList.add('open'));
            }
        });
    }

    // Table column sort
    function initTableSort() {
        document.querySelectorAll('.admin-table thead th.sortable').forEach(th => {
            th.addEventListener('click', () => {
                const table = th.closest('table');
                const tbody = table.querySelector('tbody');
                const idx = Array.from(th.parentNode.children).indexOf(th);
                const rows = Array.from(tbody.querySelectorAll('tr'));
                const asc = th.dataset.sort !== 'asc';
                th.dataset.sort = asc ? 'asc' : 'desc';
                th.parentNode.querySelectorAll('th').forEach(h => { if (h !== th) delete h.dataset.sort; });
                rows.sort((a, b) => {
                    const av = (a.children[idx]?.textContent || '').trim();
                    const bv = (b.children[idx]?.textContent || '').trim();
                    const an = parseFloat(av.replace(/[^0-9.-]/g, ''));
                    const bn = parseFloat(bv.replace(/[^0-9.-]/g, ''));
                    if (!isNaN(an) && !isNaN(bn)) return asc ? an - bn : bn - an;
                    return asc ? av.localeCompare(bv) : bv.localeCompare(av);
                });
                rows.forEach(r => tbody.appendChild(r));
            });
        });
    }

    // Mobile table card labels
    function initMobileTableCards() {
        document.querySelectorAll('.admin-table-mobile-cards').forEach(table => {
            const headers = Array.from(table.querySelectorAll('thead th')).map(th => th.textContent.trim());
            table.querySelectorAll('tbody tr').forEach(row => {
                Array.from(row.children).forEach((td, i) => {
                    if (headers[i]) td.setAttribute('data-label', headers[i]);
                });
            });
        });
    }

    // Toast notifications
    window.adminToast = function (message, type = 'success') {
        let container = document.getElementById('adminToastContainer');
        if (!container) {
            container = document.createElement('div');
            container.id = 'adminToastContainer';
            container.className = 'admin-toast-container';
            document.body.appendChild(container);
        }
        const icons = { success: 'fa-check-circle', error: 'fa-exclamation-circle', info: 'fa-info-circle' };
        const toast = document.createElement('div');
        toast.className = 'admin-toast ' + type;
        toast.innerHTML = '<i class="fas ' + (icons[type] || icons.info) + '"></i><span>' + message + '</span>';
        container.appendChild(toast);
        setTimeout(() => { toast.style.opacity = '0'; setTimeout(() => toast.remove(), 300); }, 3500);
    };

    // Confirm delete helper
    window.adminConfirmDelete = function (url, message) {
        if (confirm(message || 'আপনি কি নিশ্চিত?')) {
            window.location.href = url;
        }
    };

    // Unsaved form warning
    function initFormWarning() {
        document.querySelectorAll('form[data-warn-unsaved]').forEach(form => {
            let dirty = false;
            form.addEventListener('change', () => { dirty = true; });
            form.addEventListener('submit', () => { dirty = false; });
            window.addEventListener('beforeunload', e => {
                if (dirty) { e.preventDefault(); e.returnValue = ''; }
            });
        });
    }

    // Update sidebar active on PJAX
    window.addEventListener('pjax:complete', () => {
        initSidebarGroups();
        initTableSort();
        initMobileTableCards();
    });

    document.addEventListener('DOMContentLoaded', () => {
        initSidebarGroups();
        initSidebarSearch();
        initTableSort();
        initMobileTableCards();
        initFormWarning();

        // Auto-show flash as toast
        const flash = document.querySelector('.admin-flash.success');
        if (flash) adminToast(flash.textContent.trim(), 'success');
    });
})();
