/**
 * Advanced Page Builder
 * window.initPageBuilder() — safe for full page load + PJAX
 */
(function (window, document) {
  'use strict';

  var ckEditor = null;
  var sortable = null;
  var initToken = 0;

  function destroyEditor() {
    if (ckEditor) {
      try { ckEditor.destroy(); } catch (e) {}
      ckEditor = null;
    }
  }

  function destroySortable() {
    if (sortable) {
      try { sortable.destroy(); } catch (e) {}
      sortable = null;
    }
  }

  function ensureCss() {
    if (document.getElementById('pb-builder-css')) return;
    var link = document.createElement('link');
    link.id = 'pb-builder-css';
    link.rel = 'stylesheet';
    link.href = 'css/page-builder.css?v=3';
    document.head.appendChild(link);
  }

  function esc(s) {
    return String(s == null ? '' : s)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;');
  }

  function loadScript(src) {
    return new Promise(function (resolve) {
      var existing = document.querySelector('script[src="' + src + '"]');
      if (existing && (src.indexOf('Sortable') !== -1 ? typeof Sortable !== 'undefined' : typeof ClassicEditor !== 'undefined')) {
        resolve();
        return;
      }
      var s = document.createElement('script');
      s.src = src;
      s.onload = function () { resolve(); };
      s.onerror = function () { resolve(); };
      document.head.appendChild(s);
    });
  }

  window.initPageBuilder = async function initPageBuilder() {
    var root = document.getElementById('pb-root');
    if (!root) return;

    var myToken = ++initToken;
    ensureCss();
    destroyEditor();
    destroySortable();

    await loadScript('https://cdn.jsdelivr.net/npm/sortablejs@1.15.2/Sortable.min.js');
    await loadScript('https://cdn.jsdelivr.net/npm/@ckeditor/ckeditor5-build-classic@39.0.2/build/ckeditor.js');
    if (myToken !== initToken) return; // superseded by newer init

    root = document.getElementById('pb-root');
    if (!root) return;
    var pageId = parseInt(root.getAttribute('data-page-id') || '0', 10);
    var saveUrl = root.getAttribute('data-save-url') || 'actions/section-save.php';
    var baseUrl = root.getAttribute('data-base-url') || '';

    var sections = [];
    var jsonEl = document.getElementById('pb-sections-json');
    try {
      sections = JSON.parse(jsonEl ? jsonEl.textContent : '[]');
      if (!Array.isArray(sections)) sections = [];
    } catch (e) {
      console.error('Page builder JSON error', e);
      sections = [];
    }

    var activeId = null;
    var canvas = document.getElementById('pb-canvas');
    var emptyState = document.getElementById('pb-empty');
    var inspector = document.getElementById('pb-inspector');
    var palette = document.getElementById('pb-palette-list');

    if (!canvas || !inspector || !palette) {
      console.error('Page builder DOM missing');
      return;
    }

    var BLOCKS = [
      { type: 'hero', icon: 'fa-image', label: 'Hero', desc: 'Header + CTA' },
      { type: 'text', icon: 'fa-align-left', label: 'Rich Text', desc: 'Heading + body' },
      { type: 'image', icon: 'fa-image', label: 'Image Banner', desc: 'Media block' },
      { type: 'features', icon: 'fa-th-large', label: 'Features', desc: 'Icon cards' },
      { type: 'stats', icon: 'fa-chart-bar', label: 'Stats', desc: 'Counters' },
      { type: 'cta', icon: 'fa-bullhorn', label: 'CTA', desc: 'Call to action' },
      { type: 'faq', icon: 'fa-question-circle', label: 'FAQ', desc: 'Accordion' },
      { type: 'gallery', icon: 'fa-images', label: 'Gallery', desc: 'Image grid' },
      { type: 'columns', icon: 'fa-columns', label: '2 Columns', desc: 'Side by side' },
      { type: 'spacer', icon: 'fa-arrows-alt-v', label: 'Spacer', desc: 'Spacing' },
      { type: 'html', icon: 'fa-code', label: 'Custom HTML', desc: 'Raw HTML' }
    ];

    function parseExtra(sec) {
      if (!sec || !sec.extra_json) return {};
      if (typeof sec.extra_json === 'object') return sec.extra_json || {};
      try { return JSON.parse(sec.extra_json) || {}; } catch (e) { return {}; }
    }

    function toast(msg, ok) {
      var el = document.getElementById('pb-toast');
      if (!el) {
        if (window.adminToast) window.adminToast(msg, ok ? 'success' : 'error');
        return;
      }
      el.className = 'alert py-2 px-3 mb-0 ' + (ok ? 'alert-success' : 'alert-danger');
      el.textContent = msg;
      el.style.display = 'block';
      clearTimeout(toast._t);
      toast._t = setTimeout(function () { el.style.display = 'none'; }, 2500);
    }

    async function api(action, data) {
      var fd = new FormData();
      fd.append('ajax', '1');
      fd.append('action', action);
      fd.append('page_id', String(pageId));
      Object.keys(data || {}).forEach(function (k) {
        var v = data[k];
        if (v === undefined || v === null) return;
        fd.append(k, typeof v === 'object' ? JSON.stringify(v) : String(v));
      });
      try {
        var res = await fetch(saveUrl, {
          method: 'POST',
          credentials: 'same-origin',
          headers: { 'X-Requested-With': 'XMLHttpRequest' },
          body: fd
        });
        var text = await res.text();
        try {
          return JSON.parse(text);
        } catch (e) {
          console.error('API non-JSON', text.slice(0, 400));
          return { success: false, message: 'Server error (HTTP ' + res.status + ')' };
        }
      } catch (err) {
        return { success: false, message: err.message || 'Network error' };
      }
    }

    function mediaUrl(path) {
      if (!path) return '';
      if (/^https?:\/\//i.test(path)) return path;
      return (baseUrl ? baseUrl + '/' : '../') + String(path).replace(/^\//, '');
    }

    function findSection(id) {
      return sections.find(function (s) { return String(s.id) === String(id); });
    }

    function itemDefaults(type) {
      if (type === 'stats') return { value: '100+', title: 'Metric', text: '' };
      if (type === 'faq') return { q: 'Question?', a: 'Answer…' };
      if (type === 'gallery') return { image: '', title: '' };
      return { icon: 'fas fa-check', title: 'Feature', text: 'Short description' };
    }

    function needsItems(type) {
      return ['features', 'stats', 'faq', 'gallery'].indexOf(type) !== -1;
    }

    function needsEditor(type) {
      return ['text', 'hero', 'cta', 'html'].indexOf(type) !== -1;
    }

    function previewHtml(sec) {
      var extra = parseExtra(sec);
      var items = Array.isArray(extra.items) ? extra.items : [];
      switch (sec.section_type) {
        case 'hero':
          return '<div class="pb-preview-hero"><div class="fw-bold">' + esc(sec.title || 'Hero title') + '</div><div class="small opacity-75">' + esc(sec.subtitle || 'Subtitle') + '</div></div>';
        case 'cta':
          return '<div class="pb-preview-cta"><div class="fw-bold">' + esc(sec.title || 'CTA') + '</div></div>';
        case 'image':
          return sec.image
            ? '<div class="pb-preview-image"><img src="' + esc(mediaUrl(sec.image)) + '" alt=""></div>'
            : '<div class="text-muted small">No image</div>';
        case 'features':
        case 'stats':
        case 'faq':
        case 'gallery':
          return '<div class="pb-preview-grid">' +
            (items.slice(0, 3).map(function (it) {
              return '<div class="mini"><strong>' + esc(it.title || it.value || it.q || 'Item') + '</strong></div>';
            }).join('') || '<div class="mini">Add items…</div>') +
            '</div>';
        case 'spacer':
          return '<div class="text-center text-muted small py-2">Spacer · ' + esc(extra.size || 'md') + '</div>';
        case 'html':
          return '<div class="small text-muted font-monospace">' + esc(String(sec.content || '').slice(0, 100)) + '</div>';
        case 'columns':
          return '<div class="row g-2"><div class="col-6"><div class="mini p-2">Left</div></div><div class="col-6"><div class="mini p-2">Right</div></div></div>';
        default:
          return '<div><div class="fw-semibold">' + esc(sec.title || 'Text') + '</div><div class="small text-muted">' + esc(String(sec.content || '').replace(/<[^>]+>/g, '').slice(0, 80)) + '</div></div>';
      }
    }

    function renderPalette() {
      palette.innerHTML = BLOCKS.map(function (b) {
        return '<button type="button" class="pb-block-btn" data-add-type="' + b.type + '">' +
          '<i class="fas ' + b.icon + '"></i><div><span>' + b.label + '</span><small>' + b.desc + '</small></div></button>';
      }).join('');
    }

    function renderCanvas() {
      sections.sort(function (a, b) {
        return (parseInt(a.sort_order, 10) || 0) - (parseInt(b.sort_order, 10) || 0);
      });
      if (!sections.length) {
        canvas.innerHTML = '';
        if (emptyState) emptyState.style.display = 'block';
        destroySortable();
        return;
      }
      if (emptyState) emptyState.style.display = 'none';
      canvas.innerHTML = sections.map(function (sec) {
        return '<article class="pb-card ' + (String(sec.id) === String(activeId) ? 'is-active' : '') + ' ' + (parseInt(sec.status, 10) ? '' : 'is-disabled') + '" data-id="' + sec.id + '">' +
          '<div class="pb-card-head" data-select="' + sec.id + '">' +
          '<span class="pb-handle"><i class="fas fa-grip-vertical"></i></span>' +
          '<span class="pb-type-badge">' + esc(sec.section_type) + '</span>' +
          '<div><p class="pb-card-title">' + esc(sec.title || sec.section_key || 'Untitled') + '</p>' +
          '<div class="pb-card-meta"><code>' + esc(sec.section_key) + '</code></div></div>' +
          '<div class="pb-card-actions" data-stop="1">' +
          '<button type="button" class="btn btn-light btn-sm" data-toggle="' + sec.id + '"><i class="fas fa-' + (parseInt(sec.status, 10) ? 'eye' : 'eye-slash') + '"></i></button>' +
          '<button type="button" class="btn btn-light btn-sm" data-dup="' + sec.id + '"><i class="fas fa-copy"></i></button>' +
          '<button type="button" class="btn btn-light btn-sm text-danger" data-del="' + sec.id + '"><i class="fas fa-trash"></i></button>' +
          '</div></div><div class="pb-preview">' + previewHtml(sec) + '</div></article>';
      }).join('');

      destroySortable();
      if (typeof Sortable !== 'undefined') {
        sortable = Sortable.create(canvas, {
          handle: '.pb-handle',
          animation: 160,
          ghostClass: 'pb-ghost',
          chosenClass: 'pb-chosen',
          onEnd: async function () {
            var order = Array.prototype.map.call(canvas.querySelectorAll('.pb-card'), function (el) { return el.getAttribute('data-id'); });
            var res = await api('reorder', { order: order });
            if (res.success) {
              order.forEach(function (id, idx) {
                var s = findSection(id);
                if (s) s.sort_order = idx + 1;
              });
              toast('Order saved', true);
            } else {
              toast(res.message || 'Reorder failed', false);
              renderCanvas();
            }
          }
        });
      }
    }

    function renderItemsEditor(type, items) {
      var list = Array.isArray(items) ? items : [];
      if (!list.length) return '<div class="text-muted small mb-2">No items yet.</div>';
      return list.map(function (it, idx) {
        if (type === 'stats') {
          return '<div class="pb-item-row" data-idx="' + idx + '"><div class="row g-2">' +
            '<div class="col-4"><input class="form-control form-control-sm" data-f="value" value="' + esc(it.value || '') + '" placeholder="Value"></div>' +
            '<div class="col-6"><input class="form-control form-control-sm" data-f="title" value="' + esc(it.title || '') + '" placeholder="Label"></div>' +
            '<div class="col-2"><button type="button" class="btn btn-sm btn-outline-danger w-100" data-rm-item="' + idx + '"><i class="fas fa-times"></i></button></div></div></div>';
        }
        if (type === 'faq') {
          return '<div class="pb-item-row" data-idx="' + idx + '">' +
            '<input class="form-control form-control-sm mb-1" data-f="q" value="' + esc(it.q || '') + '" placeholder="Question">' +
            '<textarea class="form-control form-control-sm mb-1" data-f="a" rows="2" placeholder="Answer">' + esc(it.a || '') + '</textarea>' +
            '<button type="button" class="btn btn-sm btn-outline-danger" data-rm-item="' + idx + '"><i class="fas fa-times"></i> Remove</button></div>';
        }
        if (type === 'gallery') {
          return '<div class="pb-item-row" data-idx="' + idx + '"><div class="input-group input-group-sm mb-1">' +
            '<input class="form-control" data-f="image" id="pb_gal_' + idx + '" value="' + esc(it.image || '') + '" placeholder="Image path">' +
            '<button type="button" class="btn btn-outline-secondary" data-media="pb_gal_' + idx + '">Browse</button></div>' +
            '<div class="d-flex gap-2"><input class="form-control form-control-sm" data-f="title" value="' + esc(it.title || '') + '" placeholder="Caption">' +
            '<button type="button" class="btn btn-sm btn-outline-danger" data-rm-item="' + idx + '"><i class="fas fa-times"></i></button></div></div>';
        }
        return '<div class="pb-item-row" data-idx="' + idx + '"><div class="row g-2 mb-1">' +
          '<div class="col-5"><input class="form-control form-control-sm" data-f="icon" value="' + esc(it.icon || '') + '" placeholder="fas fa-check"></div>' +
          '<div class="col-5"><input class="form-control form-control-sm" data-f="title" value="' + esc(it.title || '') + '" placeholder="Title"></div>' +
          '<div class="col-2"><button type="button" class="btn btn-sm btn-outline-danger w-100" data-rm-item="' + idx + '"><i class="fas fa-times"></i></button></div></div>' +
          '<textarea class="form-control form-control-sm" data-f="text" rows="2" placeholder="Description">' + esc(it.text || '') + '</textarea></div>';
      }).join('');
    }

    async function mountEditor(selector) {
      destroyEditor();
      var el = document.querySelector(selector);
      if (!el || typeof ClassicEditor === 'undefined') return;
      try {
        ckEditor = await ClassicEditor.create(el, {
          toolbar: ['heading', '|', 'bold', 'italic', 'link', 'bulletedList', 'numberedList', 'blockQuote', '|', 'undo', 'redo']
        });
      } catch (e) {
        console.warn('CKEditor unavailable', e);
      }
    }

    async function renderInspector() {
      var sec = findSection(activeId);
      if (!sec) {
        destroyEditor();
        inspector.innerHTML = '<h5>Inspector</h5><p class="hint">Select a block, or add one from the left.</p>';
        return;
      }
      var extra = parseExtra(sec);
      var type = sec.section_type;
      var showImage = ['hero', 'image', 'cta'].indexOf(type) !== -1;
      var showBtn = ['hero', 'cta', 'text', 'image'].indexOf(type) !== -1;
      var showItems = needsItems(type);
      var showColumns = type === 'columns';
      var showSpacer = type === 'spacer';
      var showContent = needsEditor(type);

      var html = '<h5>Edit · ' + esc(type) + '</h5><p class="hint"><code>' + esc(sec.section_key) + '</code></p><form id="pb-edit-form">';
      html += '<input type="hidden" name="id" value="' + sec.id + '">';
      html += '<input type="hidden" name="section_type" value="' + esc(type) + '">';
      html += '<input type="hidden" name="sort_order" value="' + esc(sec.sort_order) + '">';

      if (type !== 'spacer') {
        html += '<div class="mb-2"><label class="form-label">Title</label><input type="text" name="title" class="form-control form-control-sm" value="' + esc(sec.title || '') + '"></div>';
        html += '<div class="mb-2"><label class="form-label">Subtitle</label><input type="text" name="subtitle" class="form-control form-control-sm" value="' + esc(sec.subtitle || '') + '"></div>';
      }
      if (showContent) {
        html += '<div class="mb-2"><label class="form-label">' + (type === 'html' ? 'HTML Code' : 'Content') + '</label>';
        html += '<textarea name="content" id="pb_content_editor" class="form-control form-control-sm" rows="6">' + esc(sec.content || '') + '</textarea></div>';
      }
      if (showColumns) {
        html += '<div class="mb-2"><label class="form-label">Left column</label><textarea name="col_left" class="form-control form-control-sm" rows="4">' + esc(extra.left || '') + '</textarea></div>';
        html += '<div class="mb-2"><label class="form-label">Right column</label><textarea name="col_right" class="form-control form-control-sm" rows="4">' + esc(extra.right || '') + '</textarea></div>';
      }
      if (showImage) {
        html += '<div class="mb-2"><label class="form-label">Image</label><div class="input-group input-group-sm">';
        html += '<input type="text" name="image" id="pb_edit_image" class="form-control" value="' + esc(sec.image || '') + '">';
        html += '<button type="button" class="btn btn-outline-secondary" data-media="pb_edit_image">Browse</button></div></div>';
      } else {
        html += '<input type="hidden" name="image" value="' + esc(sec.image || '') + '">';
      }
      if (showBtn) {
        html += '<div class="row g-2 mb-2"><div class="col-6"><label class="form-label">Button text</label>';
        html += '<input type="text" name="btn_text" class="form-control form-control-sm" value="' + esc(sec.btn_text || '') + '"></div>';
        html += '<div class="col-6"><label class="form-label">Button link</label>';
        html += '<input type="text" name="btn_link" class="form-control form-control-sm" value="' + esc(sec.btn_link || '') + '"></div></div>';
      } else {
        html += '<input type="hidden" name="btn_text" value="' + esc(sec.btn_text || '') + '">';
        html += '<input type="hidden" name="btn_link" value="' + esc(sec.btn_link || '') + '">';
      }
      if (showSpacer) {
        html += '<div class="mb-2"><label class="form-label">Height</label><select name="spacer_size" class="form-select form-select-sm">';
        ['sm', 'md', 'lg', 'xl'].forEach(function (sz) {
          html += '<option value="' + sz + '"' + ((extra.size || 'md') === sz ? ' selected' : '') + '>' + sz.toUpperCase() + '</option>';
        });
        html += '</select></div>';
      }
      if (showItems) {
        html += '<div class="mb-2"><div class="d-flex justify-content-between align-items-center mb-1">';
        html += '<label class="form-label mb-0">Items</label><button type="button" class="btn btn-sm btn-outline-primary" id="pb-add-item"><i class="fas fa-plus"></i> Add</button></div>';
        if (type === 'features' || type === 'stats') {
          html += '<div class="mb-2"><label class="form-label">Columns</label><select name="columns" class="form-select form-select-sm">';
          [2, 3, 4].forEach(function (n) {
            html += '<option value="' + n + '"' + ((parseInt(extra.columns, 10) || 3) === n ? ' selected' : '') + '>' + n + ' columns</option>';
          });
          html += '</select></div>';
        }
        html += '<div class="pb-items-list" id="pb-items">' + renderItemsEditor(type, extra.items || []) + '</div></div>';
      }
      html += '<div class="mb-3"><label class="form-label">Status</label><select name="status" class="form-select form-select-sm">';
      html += '<option value="1"' + (parseInt(sec.status, 10) ? ' selected' : '') + '>Active</option>';
      html += '<option value="0"' + (!parseInt(sec.status, 10) ? ' selected' : '') + '>Hidden</option></select></div>';
      html += '<button type="submit" class="btn btn-success w-100 fw-bold"><i class="fas fa-save me-1"></i> Save Block</button></form>';

      inspector.innerHTML = html;
      if (showContent && type !== 'html') await mountEditor('#pb_content_editor');
      else destroyEditor();
    }

    function collectItems() {
      return Array.prototype.map.call(inspector.querySelectorAll('.pb-item-row'), function (row) {
        var obj = {};
        Array.prototype.forEach.call(row.querySelectorAll('[data-f]'), function (inp) {
          obj[inp.getAttribute('data-f')] = inp.value;
        });
        return obj;
      });
    }

    function buildExtra(form, type) {
      var extra = parseExtra(findSection(activeId));
      if (needsItems(type)) {
        extra.items = collectItems();
        if (form.columns) extra.columns = parseInt(form.columns.value, 10) || 3;
      }
      if (type === 'columns') {
        extra.left = form.col_left ? form.col_left.value : '';
        extra.right = form.col_right ? form.col_right.value : '';
      }
      if (type === 'spacer') extra.size = form.spacer_size ? form.spacer_size.value : 'md';
      return JSON.stringify(extra);
    }

    async function selectBlock(id) {
      activeId = id;
      renderCanvas();
      await renderInspector();
    }

    async function addBlock(type) {
      var defaults = {
        hero: { title: 'Welcome', subtitle: 'Your brand story starts here', btn_text: 'Shop Now', btn_link: '/shop' },
        text: { title: 'Section title', content: '<p>Write your content…</p>' },
        image: { title: 'Image banner' },
        features: { title: 'Why choose us', extra_json: JSON.stringify({ columns: 3, items: [itemDefaults('features'), itemDefaults('features'), itemDefaults('features')] }) },
        stats: { title: 'Our numbers', extra_json: JSON.stringify({ columns: 3, items: [{ value: '10K+', title: 'Customers' }, { value: '500+', title: 'Products' }, { value: '24/7', title: 'Support' }] }) },
        cta: { title: 'Ready to order?', content: 'Get authentic products delivered fast.', btn_text: 'Browse Shop', btn_link: '/shop' },
        faq: { title: 'FAQ', extra_json: JSON.stringify({ items: [{ q: 'How long is delivery?', a: 'Usually 2–3 business days.' }] }) },
        gallery: { title: 'Gallery', extra_json: JSON.stringify({ items: [] }) },
        columns: { title: 'Two columns', extra_json: JSON.stringify({ left: '<p>Left content</p>', right: '<p>Right content</p>' }) },
        spacer: { title: 'Spacer', extra_json: JSON.stringify({ size: 'md' }) },
        html: { title: 'Custom HTML', content: '<div class="p-3">Custom markup</div>' }
      };
      var payload = Object.assign({ section_type: type, status: 1 }, defaults[type] || { title: type });
      toast('Adding…', true);
      var res = await api('add', payload);
      if (!res.success) {
        toast(res.message || 'Failed to add block', false);
        return;
      }
      window.location.href = 'index.php?page=edit-page&id=' + pageId + '&tab=content';
    }

    // Fresh listeners via cloning
    var paletteClone = palette.cloneNode(true);
    palette.parentNode.replaceChild(paletteClone, palette);
    palette = document.getElementById('pb-palette-list');

    var canvasClone = canvas.cloneNode(true);
    canvas.parentNode.replaceChild(canvasClone, canvas);
    canvas = document.getElementById('pb-canvas');

    var inspectorClone = inspector.cloneNode(true);
    inspector.parentNode.replaceChild(inspectorClone, inspector);
    inspector = document.getElementById('pb-inspector');

    renderPalette();
    renderCanvas();
    renderInspector();

    palette.addEventListener('click', function (e) {
      var btn = e.target.closest('[data-add-type]');
      if (btn) addBlock(btn.getAttribute('data-add-type'));
    });

    canvas.addEventListener('click', async function (e) {
      if (e.target.closest('[data-stop]')) {
        var tog = e.target.closest('[data-toggle]');
        var dup = e.target.closest('[data-dup]');
        var del = e.target.closest('[data-del]');
        if (tog) {
          var tid = tog.getAttribute('data-toggle');
          var tres = await api('toggle', { id: tid });
          if (tres.success) {
            var ts = findSection(tid);
            if (ts) ts.status = tres.status;
            renderCanvas();
            toast('Visibility updated', true);
          } else toast(tres.message || 'Failed', false);
          return;
        }
        if (dup) {
          var dres = await api('duplicate', { id: dup.getAttribute('data-dup') });
          if (dres.success) window.location.href = 'index.php?page=edit-page&id=' + pageId + '&tab=content';
          else toast(dres.message || 'Duplicate failed', false);
          return;
        }
        if (del) {
          if (!confirm('Delete this block?')) return;
          var did = del.getAttribute('data-del');
          var delRes = await api('delete', { id: did });
          if (delRes.success) {
            sections = sections.filter(function (s) { return String(s.id) !== String(did); });
            if (String(activeId) === String(did)) activeId = null;
            renderCanvas();
            renderInspector();
            toast('Deleted', true);
          } else toast(delRes.message || 'Delete failed', false);
          return;
        }
      }
      var sel = e.target.closest('[data-select]');
      if (sel) selectBlock(sel.getAttribute('data-select'));
    });

    inspector.addEventListener('click', function (e) {
      var mediaBtn = e.target.closest('[data-media]');
      if (mediaBtn && typeof openMediaPicker === 'function') {
        openMediaPicker(mediaBtn.getAttribute('data-media'));
        return;
      }
      if (e.target.closest('#pb-add-item')) {
        var sec = findSection(activeId);
        if (!sec) return;
        var extra = parseExtra(sec);
        if (!Array.isArray(extra.items)) extra.items = [];
        extra.items.push(itemDefaults(sec.section_type));
        sec.extra_json = JSON.stringify(extra);
        var list = document.getElementById('pb-items');
        if (list) list.innerHTML = renderItemsEditor(sec.section_type, extra.items);
        return;
      }
      var rm = e.target.closest('[data-rm-item]');
      if (rm) {
        var s2 = findSection(activeId);
        if (!s2) return;
        var ex2 = parseExtra(s2);
        ex2.items = collectItems();
        ex2.items.splice(parseInt(rm.getAttribute('data-rm-item'), 10), 1);
        s2.extra_json = JSON.stringify(ex2);
        var list2 = document.getElementById('pb-items');
        if (list2) list2.innerHTML = renderItemsEditor(s2.section_type, ex2.items);
      }
    });

    inspector.addEventListener('submit', async function (e) {
      if (!e.target || e.target.id !== 'pb-edit-form') return;
      e.preventDefault();
      var form = e.target;
      var sec = findSection(activeId);
      if (!sec) return;
      var type = sec.section_type;
      var content = form.content ? form.content.value : (sec.content || '');
      if (ckEditor) content = ckEditor.getData();
      var payload = {
        id: form.id.value,
        section_type: type,
        title: form.title ? form.title.value : (sec.title || ''),
        subtitle: form.subtitle ? form.subtitle.value : (sec.subtitle || ''),
        content: content,
        image: form.image ? form.image.value : '',
        icon: sec.icon || '',
        btn_text: form.btn_text ? form.btn_text.value : '',
        btn_link: form.btn_link ? form.btn_link.value : '',
        extra_json: buildExtra(form, type),
        sort_order: form.sort_order.value,
        status: form.status.value
      };
      var res = await api('edit', payload);
      if (!res.success) {
        toast(res.message || 'Save failed', false);
        return;
      }
      Object.assign(sec, payload);
      sec.status = parseInt(payload.status, 10);
      renderCanvas();
      toast('Block saved', true);
    });
  };

  function boot() {
    if (document.getElementById('pb-root')) {
      window.initPageBuilder();
    }
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', boot);
  } else {
    boot();
  }
  window.addEventListener('pjax:complete', boot);
})(window, document);
