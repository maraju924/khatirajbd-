<?php
// admin/includes/product-variants-form.php
$pv_data = $product_variant_data ?? ['enabled' => false, 'attributes' => [], 'variants' => []];
$pv_enabled = !empty($pv_data['enabled']);
?>
<div class="card mb-4 border-0 shadow-sm rounded-4 overflow-hidden" id="product-variants-card">
    <div class="card-header bg-light py-3 d-flex justify-content-between align-items-center">
        <h5 class="mb-0 fw-bold"><i class="fas fa-layer-group me-2 text-primary"></i>Product Variants (Color, Size, etc.)</h5>
        <div class="form-check form-switch mb-0">
            <input class="form-check-input" type="checkbox" role="switch" id="enable_variants" name="enable_variants" value="1" <?php echo $pv_enabled ? 'checked' : ''; ?>>
            <label class="form-check-label small fw-bold" for="enable_variants">Enable</label>
        </div>
    </div>
    <div class="card-body p-4" id="variants-wrapper" style="<?php echo $pv_enabled ? '' : 'display:none;'; ?>">
        <p class="text-muted small mb-3">Attribute যোগ করুন (যেমন: Size, Color) এবং value দিন। তারপর <strong>Generate Combinations</strong> ক্লিক করে প্রতিটি variant-এর price ও stock সেট করুন।</p>

        <div id="variant-attributes-container" class="mb-4"></div>
        <button type="button" class="btn btn-sm btn-outline-primary mb-4" id="add-variant-attribute">
            <i class="fas fa-plus me-1"></i> Add Attribute
        </button>

        <div class="border rounded-3 p-3 bg-light">
            <div class="d-flex justify-content-between align-items-center mb-3 flex-wrap gap-2">
                <h6 class="mb-0 fw-bold"><i class="fas fa-tags me-2 text-success"></i>Variant Combinations & Pricing</h6>
                <button type="button" class="btn btn-sm btn-success" id="generate-variant-rows">
                    <i class="fas fa-sync me-1"></i> Generate Combinations
                </button>
            </div>
            <div id="variant-rows-container"></div>
            <div id="variant-rows-empty" class="text-muted small text-center py-3">Attribute ও value যোগ করে Generate Combinations ক্লিক করুন।</div>
        </div>
    </div>
</div>

<script>
(function() {
    const initialVariantData = <?php echo json_encode($pv_data, JSON_UNESCAPED_UNICODE); ?>;
    let attributeIndex = 0;
    let variantRowIndex = 0;

    const enableToggle = document.getElementById('enable_variants');
    const variantsWrapper = document.getElementById('variants-wrapper');
    const attributesContainer = document.getElementById('variant-attributes-container');
    const variantRowsContainer = document.getElementById('variant-rows-container');
    const variantRowsEmpty = document.getElementById('variant-rows-empty');

    function escapeHtml(text) {
        if (!text) return '';
        return String(text)
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;')
            .replace(/'/g, '&#039;');
    }

    function toggleVariantsWrapper() {
        variantsWrapper.style.display = enableToggle.checked ? '' : 'none';
    }

    function createValueRowHtml(attrIndex, value = '', color = '') {
        return `
            <div class="input-group input-group-sm variant-value-row mb-2">
                <span class="input-group-text bg-white"><i class="fas fa-circle text-muted" style="font-size: 0.55rem;"></i></span>
                <input type="text" name="variant_attrs[${attrIndex}][values][]" class="form-control" value="${escapeHtml(value)}" placeholder="যেমন: XL, Red, 500g">
                <input type="text" name="variant_attrs[${attrIndex}][colors][]" class="form-control variant-color-input" value="${escapeHtml(color)}" placeholder="#FF0000" style="max-width: 95px;" title="Color hex (optional)">
                <button type="button" class="btn btn-outline-danger remove-variant-value-btn"><i class="fas fa-times"></i></button>
            </div>
        `;
    }

    function bindAttributeBlock(block) {
        block.querySelector('.remove-variant-attribute-btn').addEventListener('click', () => block.remove());
        block.querySelector('.add-variant-value-btn').addEventListener('click', () => {
            const attrIndex = block.dataset.attrIndex;
            const wrap = block.querySelector('.variant-values-wrap');
            const row = document.createElement('div');
            row.innerHTML = createValueRowHtml(attrIndex, '').trim();
            const el = row.firstChild;
            wrap.appendChild(el);
            el.querySelector('.remove-variant-value-btn').addEventListener('click', () => el.remove());
        });

        block.querySelectorAll('.remove-variant-value-btn').forEach(btn => {
            btn.addEventListener('click', () => btn.closest('.variant-value-row').remove());
        });
    }

    function addAttributeBlock(name = '', displayType = 'button', values = []) {
        const attrIndex = attributeIndex++;
        const valuesHtml = values.length
            ? values.map(v => createValueRowHtml(attrIndex, v.value || '', v.color_hex || '')).join('')
            : createValueRowHtml(attrIndex, '', '');

        const html = `
            <div class="card mb-3 border border-secondary border-opacity-25 rounded-3 variant-attribute-block" data-attr-index="${attrIndex}">
                <div class="card-header bg-white d-flex justify-content-between align-items-center py-2">
                    <h6 class="mb-0 fw-bold"><i class="fas fa-sliders-h me-2 text-primary"></i>Attribute</h6>
                    <button type="button" class="btn btn-sm btn-outline-danger remove-variant-attribute-btn py-0 px-2"><i class="fas fa-trash"></i></button>
                </div>
                <div class="card-body p-3">
                    <div class="row g-2 mb-3">
                        <div class="col-md-6">
                            <label class="form-label small fw-bold">Attribute Name *</label>
                            <input type="text" name="variant_attrs[${attrIndex}][name]" class="form-control form-control-sm" value="${escapeHtml(name)}" placeholder="যেমন: Size, Color, Weight" required>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label small fw-bold">Display Type</label>
                            <select name="variant_attrs[${attrIndex}][display_type]" class="form-select form-select-sm">
                                <option value="button" ${displayType === 'button' ? 'selected' : ''}>Button</option>
                                <option value="color" ${displayType === 'color' ? 'selected' : ''}>Color Swatch</option>
                            </select>
                        </div>
                    </div>
                    <label class="form-label small fw-bold">Values *</label>
                    <div class="variant-values-wrap">${valuesHtml}</div>
                    <button type="button" class="btn btn-sm btn-light border add-variant-value-btn mt-2"><i class="fas fa-plus me-1 text-success"></i> Add Value</button>
                </div>
            </div>
        `;

        const wrapper = document.createElement('div');
        wrapper.innerHTML = html.trim();
        const block = wrapper.firstChild;
        attributesContainer.appendChild(block);
        bindAttributeBlock(block);
    }

    function collectAttributesFromForm() {
        const attributes = [];
        document.querySelectorAll('.variant-attribute-block').forEach(block => {
            const nameInput = block.querySelector('input[name*="[name]"]');
            const typeSelect = block.querySelector('select[name*="[display_type]"]');
            const valueInputs = block.querySelectorAll('input[name*="[values]"]');
            const name = nameInput ? nameInput.value.trim() : '';
            if (!name) return;

            const values = [];
            valueInputs.forEach(input => {
                const val = input.value.trim();
                if (val) values.push(val);
            });

            if (values.length) {
                attributes.push({
                    name,
                    display_type: typeSelect ? typeSelect.value : 'button',
                    values
                });
            }
        });
        return attributes;
    }

    function cartesianProduct(attributes) {
        if (!attributes.length) return [];
        return attributes.reduce((acc, attr) => {
            if (!acc.length) {
                return attr.values.map(value => ({ [attr.name]: value }));
            }
            const next = [];
            acc.forEach(combo => {
                attr.values.forEach(value => {
                    next.push({ ...combo, [attr.name]: value });
                });
            });
            return next;
        }, []);
    }

    function comboKey(combo) {
        return Object.keys(combo).sort().map(k => k + ':' + combo[k]).join('|');
    }

    function getExistingVariantData() {
        const existing = {};
        document.querySelectorAll('.variant-row-block').forEach(row => {
            const keyInput = row.querySelector('.variant-combo-key');
            if (!keyInput) return;
            existing[keyInput.value] = {
                price: row.querySelector('input[name*="[price]"]')?.value || '',
                offer_price: row.querySelector('input[name*="[offer_price]"]')?.value || '',
                quantity: row.querySelector('input[name*="[quantity]"]')?.value || '',
                sku: row.querySelector('input[name*="[sku]"]')?.value || '',
                stock_status: row.querySelector('select[name*="[stock_status]"]')?.value || 'In Stock'
            };
        });
        return existing;
    }

    function renderVariantRows(combinations, existingData = {}) {
        variantRowsContainer.innerHTML = '';
        variantRowIndex = 0;

        if (!combinations.length) {
            variantRowsEmpty.style.display = '';
            return;
        }

        variantRowsEmpty.style.display = 'none';

        combinations.forEach(combo => {
            const rowIndex = variantRowIndex++;
            const key = comboKey(combo);
            const saved = existingData[key] || {};
            const label = Object.entries(combo).map(([k, v]) => k + ': ' + v).join(' / ');
            let hiddenCombo = '';
            Object.entries(combo).forEach(([attrName, attrValue]) => {
                hiddenCombo += `<input type="hidden" name="variants[${rowIndex}][combination][${escapeHtml(attrName)}]" value="${escapeHtml(attrValue)}">`;
            });

            const html = `
                <div class="card mb-2 border-0 shadow-sm variant-row-block">
                    <div class="card-body p-3">
                        <input type="hidden" class="variant-combo-key" value="${escapeHtml(key)}">
                        ${hiddenCombo}
                        <div class="fw-bold mb-2 text-dark"><i class="fas fa-box-open me-2 text-success"></i>${escapeHtml(label)}</div>
                        <div class="row g-2">
                            <div class="col-md-3 col-6">
                                <label class="form-label small mb-1">Price (৳)</label>
                                <input type="number" step="0.01" name="variants[${rowIndex}][price]" class="form-control form-control-sm" value="${escapeHtml(saved.price || '')}" placeholder="Base price">
                            </div>
                            <div class="col-md-3 col-6">
                                <label class="form-label small mb-1">Offer Price (৳)</label>
                                <input type="number" step="0.01" name="variants[${rowIndex}][offer_price]" class="form-control form-control-sm" value="${escapeHtml(saved.offer_price || '')}" placeholder="Optional">
                            </div>
                            <div class="col-md-2 col-6">
                                <label class="form-label small mb-1">Quantity</label>
                                <input type="number" name="variants[${rowIndex}][quantity]" class="form-control form-control-sm" value="${escapeHtml(saved.quantity || '10')}" min="0">
                            </div>
                            <div class="col-md-2 col-6">
                                <label class="form-label small mb-1">SKU</label>
                                <input type="text" name="variants[${rowIndex}][sku]" class="form-control form-control-sm" value="${escapeHtml(saved.sku || '')}" placeholder="Optional">
                            </div>
                            <div class="col-md-2 col-12">
                                <label class="form-label small mb-1">Stock</label>
                                <select name="variants[${rowIndex}][stock_status]" class="form-select form-select-sm">
                                    <option value="In Stock" ${(saved.stock_status || 'In Stock') === 'In Stock' ? 'selected' : ''}>In Stock</option>
                                    <option value="Out of Stock" ${saved.stock_status === 'Out of Stock' ? 'selected' : ''}>Out of Stock</option>
                                </select>
                            </div>
                        </div>
                    </div>
                </div>
            `;

            const wrapper = document.createElement('div');
            wrapper.innerHTML = html.trim();
            variantRowsContainer.appendChild(wrapper.firstChild);
        });
    }

    function generateVariantRows() {
        const existing = getExistingVariantData();
        const attributes = collectAttributesFromForm();
        const combinations = cartesianProduct(attributes);
        renderVariantRows(combinations, existing);
    }

    enableToggle.addEventListener('change', toggleVariantsWrapper);
    document.getElementById('add-variant-attribute').addEventListener('click', () => addAttributeBlock());
    document.getElementById('generate-variant-rows').addEventListener('click', generateVariantRows);

    if (initialVariantData.attributes && initialVariantData.attributes.length) {
        initialVariantData.attributes.forEach(attr => addAttributeBlock(attr.name, attr.display_type, attr.values));
    }

    if (initialVariantData.variants && initialVariantData.variants.length) {
        const existingData = {};
        initialVariantData.variants.forEach(variant => {
            existingData[comboKey(variant.combination)] = {
                price: variant.price ?? '',
                offer_price: variant.offer_price ?? '',
                quantity: variant.quantity ?? '',
                sku: variant.sku ?? '',
                stock_status: variant.stock_status ?? 'In Stock'
            };
        });
        renderVariantRows(initialVariantData.variants.map(v => v.combination), existingData);
    }
})();
</script>
