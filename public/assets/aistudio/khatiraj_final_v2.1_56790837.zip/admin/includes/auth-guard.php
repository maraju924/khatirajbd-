<?php
/**
 * Admin authentication + CSRF guard for actions/*.php
 * Include after session_start() (or this file will start the session).
 */
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once __DIR__ . '/../../app/Helpers/CsrfHelper.php';

$is_ajax = !empty($_SERVER['HTTP_X_REQUESTED_WITH'])
    && strtolower((string) $_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest';

if (empty($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    if ($is_ajax) {
        header('Content-Type: application/json; charset=utf-8');
        http_response_code(401);
        echo json_encode(['success' => false, 'status' => 'error', 'message' => 'Unauthorized']);
        exit;
    }
    header('Location: ../login.php');
    exit;
}

$method = strtoupper((string) ($_SERVER['REQUEST_METHOD'] ?? 'GET'));
if (in_array($method, ['POST', 'PUT', 'PATCH', 'DELETE'], true)) {
    if (!CsrfHelper::validate()) {
        if ($is_ajax) {
            header('Content-Type: application/json; charset=utf-8');
            http_response_code(403);
            echo json_encode(['success' => false, 'status' => 'error', 'message' => 'Invalid security token']);
            exit;
        }
        http_response_code(403);
        header('Content-Type: text/plain; charset=utf-8');
        echo 'Invalid security token. Please go back and try again.';
        exit;
    }
}
