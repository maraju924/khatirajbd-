<!-- admin/includes/media-picker.php -->
<div class="modal fade" id="mediaPickerModal" tabindex="-1" aria-hidden="true" style="z-index: 2000;">
    <div class="modal-dialog modal-xl modal-dialog-scrollable">
        <div class="modal-content border-0 shadow-lg">
            <div class="modal-header bg-dark text-white p-3">
                <h5 class="modal-title"><i class="fas fa-images me-2"></i>Select Media</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body bg-light p-0">
                <div class="d-flex" style="height: 500px;">
                    <!-- Sidebar for uploading -->
                    <div class="p-3 border-end bg-white" style="width: 250px;">
                        <h6 class="fw-bold mb-3 small text-muted">UPLOAD NEW</h6>
                        <form id="mediaPickerUploadForm" enctype="multipart/form-data">
                            <div class="mb-3">
                                <label class="small fw-bold">Target Folder</label>
                                <select name="folder" class="form-select form-select-sm" required>
                                    <option value="products">Products</option>
                                    <option value="categories">Categories</option>
                                    <option value="sliders">Sliders</option>
                                </select>
                            </div>
                            <div class="mb-3">
                                <input type="file" name="image" class="form-control form-control-sm" required accept="image/*">
                            </div>
                            <button type="submit" class="btn btn-primary btn-sm w-100 fw-bold">
                                <i class="fas fa-upload me-1"></i> Upload
                            </button>
                        </form>
                        <div id="uploadStatus" class="mt-2 small"></div>
                    </div>
                    
                    <!-- Main Gallery Area -->
                    <div class="flex-grow-1 p-3 overflow-auto">
                        <div id="mediaGallery" class="row g-2">
                            <!-- Images loaded via JS -->
                            <div class="col-12 text-center py-5">
                                <div class="spinner-border text-primary" role="status"></div>
                                <p class="mt-2 text-muted">Loading media...</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="modal-footer bg-white border-top p-2">
                <button type="button" class="btn btn-secondary btn-sm" data-bs-dismiss="modal">Cancel</button>
            </div>
        </div>
    </div>
</div>

<script>
let currentTargetId = '';
let isMultiple = false;
let selectedImages = [];
const mediaPickerModalEl = document.getElementById('mediaPickerModal');
const mediaPickerModal = new bootstrap.Modal(mediaPickerModalEl);

function openMediaPicker(targetInputId, multiple = false) {
    currentTargetId = targetInputId;
    isMultiple = multiple;
    selectedImages = [];
    
    // Update modal title/footer based on mode
    const title = multiple ? 'Select Multiple Images' : 'Select Media';
    mediaPickerModalEl.querySelector('.modal-title').innerHTML = `<i class="fas fa-images me-2"></i> ${title}`;
    
    // Add/Remove Confirm button
    let footer = mediaPickerModalEl.querySelector('.modal-footer');
    let confirmBtn = document.getElementById('mediaConfirmBtn');
    
    if (multiple) {
        if (!confirmBtn) {
            confirmBtn = document.createElement('button');
            confirmBtn.id = 'mediaConfirmBtn';
            confirmBtn.className = 'btn btn-primary btn-sm fw-bold';
            confirmBtn.innerText = 'Confirm Selection (0)';
            confirmBtn.onclick = confirmMultipleSelection;
            footer.appendChild(confirmBtn);
        } else {
            confirmBtn.innerText = 'Confirm Selection (0)';
            confirmBtn.classList.remove('d-none');
        }
    } else if (confirmBtn) {
        confirmBtn.classList.add('d-none');
    }

    mediaPickerModal.show();
    loadMedia();
}

document.getElementById('mediaPickerUploadForm')?.addEventListener('submit', function (e) {
    e.preventDefault();
    const statusEl = document.getElementById('uploadStatus');
    const formData = new FormData(this);
    const submitBtn = this.querySelector('button[type="submit"]');

    if (submitBtn) {
        submitBtn.disabled = true;
    }
    if (statusEl) {
        statusEl.className = 'mt-2 small text-muted';
        statusEl.textContent = 'Uploading...';
    }

    fetch('actions/media-picker-upload.php', {
        method: 'POST',
        body: formData
    })
        .then(res => res.json())
        .then(data => {
            if (data.success) {
                if (statusEl) {
                    statusEl.className = 'mt-2 small text-success';
                    statusEl.textContent = data.message || 'Uploaded successfully';
                }
                this.reset();
                loadMedia();
            } else if (statusEl) {
                statusEl.className = 'mt-2 small text-danger';
                statusEl.textContent = data.message || 'Upload failed';
            }
        })
        .catch(() => {
            if (statusEl) {
                statusEl.className = 'mt-2 small text-danger';
                statusEl.textContent = 'Upload failed. Please try again.';
            }
        })
        .finally(() => {
            if (submitBtn) {
                submitBtn.disabled = false;
            }
        });
});

function loadMedia() {
    fetch('actions/media-api.php')
        .then(res => res.json())
        .then(data => {
            const gallery = document.getElementById('mediaGallery');
            gallery.innerHTML = '';
            
            if (data.length === 0) {
                gallery.innerHTML = '<div class="col-12 text-center py-5 text-muted">No images found</div>';
                return;
            }

            data.forEach(img => {
                const col = document.createElement('div');
                col.className = 'col-4 col-md-3 col-lg-2';
                col.setAttribute('data-path', img.path);
                col.innerHTML = `
                    <div class="card h-100 shadow-sm media-item" onclick="handleMediaSelection('${img.path}', this)" style="cursor:pointer;">
                        <div class="position-relative">
                            <img src="../${img.path}" class="card-img-top" style="height: 100px; object-fit: cover;">
                            <div class="selection-overlay d-none position-absolute top-0 start-0 w-100 h-100 bg-primary opacity-50 d-flex align-items-center justify-content-center text-white">
                                <i class="fas fa-check-circle fa-2x"></i>
                            </div>
                        </div>
                        <div class="card-body p-1 text-center">
                            <small class="text-truncate d-block" style="font-size: 0.65rem;">${img.name}</small>
                        </div>
                    </div>
                `;
                gallery.appendChild(col);
            });
        });
}

function handleMediaSelection(path, element) {
    if (isMultiple) {
        const index = selectedImages.indexOf(path);
        const overlay = element.querySelector('.selection-overlay');
        
        if (index > -1) {
            selectedImages.splice(index, 1);
            overlay.classList.add('d-none');
        } else {
            selectedImages.push(path);
            overlay.classList.remove('d-none');
        }
        
        const confirmBtn = document.getElementById('mediaConfirmBtn');
        if (confirmBtn) confirmBtn.innerText = `Confirm Selection (${selectedImages.length})`;
    } else {
        selectMedia(path);
    }
}

function selectMedia(path) {
    const hiddenInput = document.getElementById(currentTargetId);
    const previewImg = document.getElementById(currentTargetId + '_preview');
    
    if (hiddenInput) hiddenInput.value = path;
    if (previewImg) {
        previewImg.src = '../' + path;
        previewImg.classList.remove('d-none');
        
        const placeholder = document.getElementById(currentTargetId + '_placeholder');
        if (placeholder) placeholder.classList.add('d-none');
    }
    
    mediaPickerModal.hide();
}

function confirmMultipleSelection() {
    const hiddenInput = document.getElementById(currentTargetId);
    if (hiddenInput) {
        hiddenInput.value = JSON.stringify(selectedImages);
    }
    
    // Update previews for gallery
    const previewContainer = document.getElementById('gallery_previews');
    if (previewContainer) {
        previewContainer.innerHTML = '';
        selectedImages.forEach(path => {
            const col = document.createElement('div');
            col.className = 'col-3';
            col.innerHTML = `
                <div class="position-relative border rounded overflow-hidden shadow-sm" style="height: 80px;">
                    <img src="../${path}" class="w-100 h-100" style="object-fit: cover;">
                    <button type="button" class="btn btn-danger btn-sm position-absolute top-0 end-0 p-0 px-1" style="font-size: 0.6rem;" onclick="removeGalleryImage('${path}', this)">
                        <i class="fas fa-times"></i>
                    </button>
                </div>
            `;
            previewContainer.appendChild(col);
        });
    }
    
    mediaPickerModal.hide();
}

function removeGalleryImage(path, btn) {
    const hiddenInput = document.getElementById('gallery_images');
    if (hiddenInput) {
        let currentImages = JSON.parse(hiddenInput.value || '[]');
        currentImages = currentImages.filter(p => p !== path);
        hiddenInput.value = JSON.stringify(currentImages);
    }
    btn.closest('.col-3').remove();
}
</script>

<style>
.media-item:hover { transform: scale(1.05); z-index: 5; border-color: var(--bs-primary); }
</style>
