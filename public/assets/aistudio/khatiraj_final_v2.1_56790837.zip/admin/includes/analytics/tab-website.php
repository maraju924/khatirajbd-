<?php
// admin/includes/analytics/tab-website.php
// Website traffic analytics powered by page_visits

try {
    // 1. Top visited pages
    $stmt_pages = $pdo->prepare("
        SELECT page_url, COUNT(*) as pageviews, COUNT(DISTINCT session_id) as unique_visits, ROUND(AVG(time_on_page)) as avg_time
        FROM page_visits
        WHERE created_at >= NOW() - INTERVAL :r DAY AND is_bot = 0
        GROUP BY page_url
        ORDER BY pageviews DESC
        LIMIT 10
    ");
    $stmt_pages->execute([':r' => $range]);
    $top_pages = $stmt_pages->fetchAll();

    // 2. Device breakdown
    $stmt_devices = $pdo->prepare("
        SELECT device_type, COUNT(*) as count
        FROM page_visits
        WHERE created_at >= NOW() - INTERVAL :r DAY AND is_bot = 0
        GROUP BY device_type
    ");
    $stmt_devices->execute([':r' => $range]);
    $devices_raw = $stmt_devices->fetchAll();
    $device_labels_arr = [];
    $device_counts_arr = [];
    foreach ($devices_raw as $dev) {
        $device_labels_arr[] = ucfirst($dev['device_type']);
        $device_counts_arr[] = (int)$dev['count'];
    }
    $device_labels_json = json_encode($device_labels_arr);
    $device_counts_json = json_encode($device_counts_arr);

    // 3. Traffic sources (Referrers & UTMs)
    $stmt_sources = $pdo->prepare("
        SELECT COALESCE(utm_source, 'Direct/None') as source, COUNT(*) as count
        FROM page_visits
        WHERE created_at >= NOW() - INTERVAL :r DAY AND is_bot = 0
        GROUP BY source
        ORDER BY count DESC
        LIMIT 5
    ");
    $stmt_sources->execute([':r' => $range]);
    $sources_raw = $stmt_sources->fetchAll();
    $source_labels_json = json_encode(array_column($sources_raw, 'source'));
    $source_counts_json = json_encode(array_map('intval', array_column($sources_raw, 'count')));

    // 4. UTM Campaigns
    $stmt_campaigns = $pdo->prepare("
        SELECT utm_campaign, utm_source, utm_medium, COUNT(*) as clicks, COUNT(DISTINCT session_id) as unique_visitors
        FROM page_visits
        WHERE created_at >= NOW() - INTERVAL :r DAY AND utm_campaign IS NOT NULL AND is_bot = 0
        GROUP BY utm_campaign, utm_source, utm_medium
        ORDER BY clicks DESC
        LIMIT 10
    ");
    $stmt_campaigns->execute([':r' => $range]);
    $utm_campaigns = $stmt_campaigns->fetchAll();

    // 5. Browser split
    $stmt_browsers = $pdo->prepare("
        SELECT browser, COUNT(*) as count
        FROM page_visits
        WHERE created_at >= NOW() - INTERVAL :r DAY AND is_bot = 0
        GROUP BY browser
        ORDER BY count DESC
        LIMIT 5
    ");
    $stmt_browsers->execute([':r' => $range]);
    $browsers_raw = $stmt_browsers->fetchAll();

    // OS split
    $stmt_os = $pdo->prepare("
        SELECT os, COUNT(*) as count
        FROM page_visits
        WHERE created_at >= NOW() - INTERVAL :r DAY AND is_bot = 0
        GROUP BY os
        ORDER BY count DESC
        LIMIT 5
    ");
    $stmt_os->execute([':r' => $range]);
    $os_raw = $stmt_os->fetchAll();

} catch (PDOException $e) {
    $website_error = $e->getMessage();
}
?>

<?php if (!empty($website_error)): ?>
    <div class="alert alert-danger"><i class="fas fa-exclamation-circle"></i> <?php echo htmlspecialchars($website_error); ?></div>
<?php endif; ?>

<!-- Traffic Overview Chart -->
<div class="glass-card p-4 mb-4">
    <h5 class="fw-bold mb-3">Traffic Sources & Device Share</h5>
    <div class="row g-4">
        <!-- Device Share Doughnut -->
        <div class="col-md-6 text-center border-end">
            <h6 class="fw-bold text-secondary mb-3">Device Distribution</h6>
            <?php if (empty($device_counts_arr)): ?>
                <div class="text-muted small py-5">কোনো ডিভাইস ডেটা নেই</div>
            <?php else: ?>
                <div style="height: 220px;"><canvas id="deviceChart"></canvas></div>
            <?php endif; ?>
        </div>
        <!-- Traffic Sources Doughnut -->
        <div class="col-md-6 text-center">
            <h6 class="fw-bold text-secondary mb-3">Traffic UTM Sources</h6>
            <?php if (empty($sources_raw)): ?>
                <div class="text-muted small py-5">কোনো সোর্স ডেটা নেই</div>
            <?php else: ?>
                <div style="height: 220px;"><canvas id="sourceChart"></canvas></div>
            <?php endif; ?>
        </div>
    </div>
</div>

<div class="row g-4 mb-4">
    <!-- Top Visited Pages Table -->
    <div class="col-lg-7">
        <div class="glass-card p-4 h-100">
            <h5 class="fw-bold mb-3"><i class="fas fa-file-alt text-primary me-2"></i>টপ ভিজিটেড পেজ (Top Visited Pages)</h5>
            <div class="table-responsive">
                <table class="table table-sm align-middle small mb-0 table-hover">
                    <thead class="text-muted text-uppercase" style="font-size: 0.7rem;">
                        <tr>
                            <th>Page Path / URL</th>
                            <th class="text-center">Pageviews</th>
                            <th class="text-center">Uniques</th>
                            <th class="text-end">Avg. Time</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($top_pages)): ?>
                            <tr><td colspan="4" class="text-center py-4 text-muted">কোনো পেজ ভিজিট ডেটা পাওয়া যায়নি</td></tr>
                        <?php else: ?>
                            <?php foreach ($top_pages as $page): ?>
                                <tr>
                                    <td><code class="text-dark"><?php echo htmlspecialchars($page['page_url']); ?></code></td>
                                    <td class="text-center fw-bold"><?php echo number_format($page['pageviews']); ?></td>
                                    <td class="text-center text-muted"><?php echo number_format($page['unique_visits']); ?></td>
                                    <td class="text-end text-success fw-bold"><?php echo $page['avg_time'] ? $page['avg_time'] . 's' : 'N/A'; ?></td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- Browser & OS Breakdowns -->
    <div class="col-lg-5">
        <div class="glass-card p-4 h-100">
            <h5 class="fw-bold mb-3"><i class="fas fa-laptop-code text-info me-2"></i>Browser & OS Details</h5>
            <div class="row g-3">
                <div class="col-6">
                    <h6 class="fw-bold small text-secondary border-bottom pb-2">Browsers</h6>
                    <?php foreach ($browsers_raw as $br): ?>
                        <div class="d-flex justify-content-between align-items-center py-1">
                            <span class="small text-slate-700"><?php echo htmlspecialchars($br['browser'] ?: 'Other'); ?></span>
                            <span class="badge bg-light text-dark fw-bold font-monospace"><?php echo number_format($br['count']); ?></span>
                        </div>
                    <?php endforeach; ?>
                </div>
                <div class="col-6">
                    <h6 class="fw-bold small text-secondary border-bottom pb-2">Operating Systems</h6>
                    <?php foreach ($os_raw as $os): ?>
                        <div class="d-flex justify-content-between align-items-center py-1">
                            <span class="small text-slate-700"><?php echo htmlspecialchars($os['os'] ?: 'Other'); ?></span>
                            <span class="badge bg-light text-dark fw-bold font-monospace"><?php echo number_format($os['count']); ?></span>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- UTM Campaign Performance -->
<div class="glass-card p-4">
    <h5 class="fw-bold mb-3"><i class="fas fa-bullhorn text-danger me-2"></i>ক্যাম্পেইন পারফরম্যান্স (UTM Campaign Tracker)</h5>
    <div class="table-responsive">
        <table class="table table-sm align-middle small mb-0 table-hover">
            <thead class="text-muted text-uppercase" style="font-size: 0.7rem;">
                <tr>
                    <th>Campaign Name</th>
                    <th>Source</th>
                    <th>Medium</th>
                    <th class="text-center">Clicks (Pageviews)</th>
                    <th class="text-end">Unique Visitors</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($utm_campaigns)): ?>
                    <tr><td colspan="5" class="text-center py-4 text-muted">সক্রিয় UTM Campaign প্যারামিটার পাওয়া যায়নি</td></tr>
                <?php else: ?>
                    <?php foreach ($utm_campaigns as $cam): ?>
                        <tr>
                            <td><strong class="text-primary"><?php echo htmlspecialchars($cam['utm_campaign']); ?></strong></td>
                            <td><span class="badge bg-light text-secondary border"><?php echo htmlspecialchars($cam['utm_source']); ?></span></td>
                            <td><code><?php echo htmlspecialchars($cam['utm_medium']); ?></code></td>
                            <td class="text-center fw-bold"><?php echo number_format($cam['clicks']); ?></td>
                            <td class="text-end font-monospace text-dark"><?php echo number_format($cam['unique_visitors']); ?></td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    if (typeof Chart === 'undefined') return;

    // Device Chart
    const devCanvas = document.getElementById('deviceChart');
    if (devCanvas) {
        new Chart(devCanvas, {
            type: 'doughnut',
            data: {
                labels: <?php echo $device_labels_json; ?>,
                datasets: [{
                    data: <?php echo $device_counts_json; ?>,
                    backgroundColor: ['#2563eb', '#10b981', '#f59e0b'],
                    borderWidth: 2
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: { legend: { position: 'bottom' } }
            }
        });
    }

    // Source Chart
    const srcCanvas = document.getElementById('sourceChart');
    if (srcCanvas) {
        new Chart(srcCanvas, {
            type: 'pie',
            data: {
                labels: <?php echo $source_labels_json; ?>,
                datasets: [{
                    data: <?php echo $source_counts_json; ?>,
                    backgroundColor: ['#3b82f6', '#8b5cf6', '#ec4899', '#f43f5e', '#64748b'],
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: { legend: { position: 'bottom' } }
            }
        });
    }
});
</script>
