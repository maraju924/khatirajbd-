<?php
// admin/includes/analytics/tab-funnel.php
// Funnel & Campaign Attribution view

try {
    // 1. Fetch Funnel steps from tracking_logs (Unique event ids)
    $funnel_steps = [
        'PageView' => "('PageView','Pageview')",
        'ViewContent' => "('ViewContent')",
        'AddToCart' => "('AddToCart')",
        'InitiateCheckout' => "('InitiateCheckout')",
        'Purchase' => "('Purchase','CompletePayment')",
    ];
    $funnel_vals = [];
    foreach ($funnel_steps as $label => $names) {
        $stmt = $pdo->prepare("
            SELECT COUNT(DISTINCT COALESCE(NULLIF(event_id, ''), CONCAT('row-', id))) AS c
            FROM tracking_logs
            WHERE created_at >= NOW() - INTERVAL :r DAY
              AND status = 'success'
              AND event_name IN {$names}
        ");
        $stmt->execute([':r' => $range]);
        $funnel_vals[$label] = (int)$stmt->fetchColumn();
    }
    
    $funnel_max_val = max(1, ...array_values($funnel_vals));

    // 2. Campaign Conversion rates from page_visits to orders mapping (simplistic attribution mapping)
    // We join page_visits having UTMs with orders having matching session_id or user_id
    $stmt_attr = $pdo->prepare("
        SELECT 
            pv.utm_campaign,
            pv.utm_source,
            COUNT(DISTINCT pv.session_id) as visitors,
            COUNT(DISTINCT o.id) as orders,
            SUM(o.total_amount) as total_rev
        FROM page_visits pv
        LEFT JOIN orders o ON pv.session_id = o.access_token OR (pv.user_id = o.user_id AND pv.user_id IS NOT NULL)
        WHERE pv.created_at >= NOW() - INTERVAL :r DAY 
          AND pv.utm_campaign IS NOT NULL
          AND pv.is_bot = 0
        GROUP BY pv.utm_campaign
        ORDER BY orders DESC
        LIMIT 5
    ");
    $stmt_attr->execute([':r' => $range]);
    $campaign_attr = $stmt_attr->fetchAll();

} catch (PDOException $e) {
    $funnel_error = $e->getMessage();
}
?>

<?php if (!empty($funnel_error)): ?>
    <div class="alert alert-danger"><i class="fas fa-exclamation-circle"></i> <?php echo htmlspecialchars($funnel_error); ?></div>
<?php endif; ?>

<div class="row g-4 mb-4">
    <!-- Visual Conversion Funnel Card -->
    <div class="col-lg-6">
        <div class="glass-card p-4 h-100">
            <h5 class="fw-bold mb-1"><i class="fas fa-filter text-primary me-2"></i>কনভার্শন ফানেল (Conversion Funnel Analysis)</h5>
            <p class="text-muted small mb-4">ওয়েবসাইটের মূল পদক্ষেপের ইউনিক ভিজিটর পারফরম্যান্স</p>
            
            <div class="d-flex flex-column gap-3 mt-2">
                <?php 
                $colors = ['#3b82f6', '#06b6d4', '#f59e0b', '#8b5cf6', '#10b981'];
                $idx = 0;
                $prev_val = $funnel_max_val;
                foreach ($funnel_vals as $step => $count): 
                    $width = round(($count / $funnel_max_val) * 100);
                    $pct = $prev_val > 0 ? round(($count / $prev_val) * 100, 1) : 0;
                    $prev_val = $count;
                ?>
                    <div>
                        <div class="d-flex justify-content-between small fw-bold mb-1">
                            <span><?php echo $step; ?></span>
                            <span class="text-muted">
                                <?php echo number_format($count); ?> 
                                <span class="badge bg-light text-dark border ms-1"><?php echo $pct; ?>% ratio</span>
                            </span>
                        </div>
                        <div class="progress" style="height: 24px; border-radius: 8px; background: #e2e8f0;">
                            <div class="progress-bar" style="width: <?php echo max(5, $width); ?>%; background: <?php echo $colors[$idx % 5]; ?>; border-radius: 8px;" role="progressbar"></div>
                        </div>
                    </div>
                <?php $idx++; endforeach; ?>
            </div>
        </div>
    </div>

    <!-- Attribution Chart / Marketing attribution stats -->
    <div class="col-lg-6">
        <div class="glass-card p-4 h-100">
            <h5 class="fw-bold mb-3"><i class="fas fa-bullseye text-success me-2"></i>ক্যাম্পেইন অ্যাট্রিবিউশন (Marketing ROI & Attribution)</h5>
            <div class="table-responsive">
                <table class="table table-sm align-middle small mb-0 table-hover">
                    <thead class="text-muted" style="font-size: 0.7rem;">
                        <tr>
                            <th>Campaign</th>
                            <th class="text-center">Unique Clicks</th>
                            <th class="text-center">Attributed Orders</th>
                            <th class="text-end">Revenue Generated</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($campaign_attr)): ?>
                            <tr><td colspan="4" class="text-center py-4 text-muted">অর্ডার বা কনভার্শন সহ কোনো সক্রিয় ক্যাম্পেইন পাওয়া যায়নি</td></tr>
                        <?php else: ?>
                            <?php foreach ($campaign_attr as $c): 
                                $c_rate = $c['visitors'] > 0 ? round(($c['orders'] / $c['visitors']) * 100, 2) : 0;
                            ?>
                                <tr>
                                    <td><strong class="text-dark"><?php echo htmlspecialchars($c['utm_campaign']); ?></strong><br><small class="text-muted">via <?php echo htmlspecialchars($c['utm_source']); ?></small></td>
                                    <td class="text-center"><?php echo number_format($c['visitors']); ?></td>
                                    <td class="text-center fw-bold text-primary"><?php echo $c['orders']; ?> <span class="badge bg-info-subtle text-info small ms-1"><?php echo $c_rate; ?>%</span></td>
                                    <td class="text-end text-success fw-bold">৳<?php echo number_format($c['total_rev']); ?></td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
