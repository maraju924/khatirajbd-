<?php
// admin/includes/analytics/tab-overview.php
// Master analytics dashboard overview for KhatiRaj Command Center

try {
    // 1. Fetch key stats for today
    $today_visits = (int) $pdo->query("SELECT COUNT(*) FROM page_visits WHERE DATE(created_at) = CURDATE() AND is_bot = 0")->fetchColumn();
    $today_visitors = (int) $pdo->query("SELECT COUNT(DISTINCT session_id) FROM page_visits WHERE DATE(created_at) = CURDATE() AND is_bot = 0")->fetchColumn();
    $today_revenue = (float) $pdo->query("SELECT SUM(total_amount) FROM orders WHERE DATE(created_at) = CURDATE() AND order_status != 'Cancelled'")->fetchColumn();
    $today_orders = (int) $pdo->query("SELECT COUNT(*) FROM orders WHERE DATE(created_at) = CURDATE()")->fetchColumn();

    // 2. Range metrics (7, 30, 90 days)
    $range_visits = (int) $pdo->query("SELECT COUNT(*) FROM page_visits WHERE created_at >= NOW() - INTERVAL $range DAY AND is_bot = 0")->fetchColumn();
    $range_visitors = (int) $pdo->query("SELECT COUNT(DISTINCT session_id) FROM page_visits WHERE created_at >= NOW() - INTERVAL $range DAY AND is_bot = 0")->fetchColumn();
    $range_revenue = (float) $pdo->query("SELECT SUM(total_amount) FROM orders WHERE created_at >= NOW() - INTERVAL $range DAY AND order_status != 'Cancelled'")->fetchColumn();
    $range_orders = (int) $pdo->query("SELECT COUNT(*) FROM orders WHERE created_at >= NOW() - INTERVAL $range DAY")->fetchColumn();

    // Prev period comparison
    $prev_range_visits = (int) $pdo->query("SELECT COUNT(*) FROM page_visits WHERE created_at >= NOW() - INTERVAL " . ($range * 2) . " DAY AND created_at < NOW() - INTERVAL $range DAY AND is_bot = 0")->fetchColumn();
    $prev_range_revenue = (float) $pdo->query("SELECT SUM(total_amount) FROM orders WHERE created_at >= NOW() - INTERVAL " . ($range * 2) . " DAY AND created_at < NOW() - INTERVAL $range DAY AND order_status != 'Cancelled'")->fetchColumn();

    // Rates
    $aov = $range_orders > 0 ? ($range_revenue / $range_orders) : 0;
    $prev_range_orders = (int) $pdo->query("SELECT COUNT(*) FROM orders WHERE created_at >= NOW() - INTERVAL " . ($range * 2) . " DAY AND created_at < NOW() - INTERVAL $range DAY")->fetchColumn();
    $prev_aov = $prev_range_orders > 0 ? ($prev_range_revenue / $prev_range_orders) : 0;

    $conversion_rate = $range_visitors > 0 ? (($range_orders / $range_visitors) * 100) : 0;
    $prev_visitors = (int) $pdo->query("SELECT COUNT(DISTINCT session_id) FROM page_visits WHERE created_at >= NOW() - INTERVAL " . ($range * 2) . " DAY AND created_at < NOW() - INTERVAL $range DAY AND is_bot = 0")->fetchColumn();
    $prev_conversion_rate = $prev_visitors > 0 ? (($prev_range_orders / $prev_visitors) * 100) : 0;

    // Changes
    [$vis_change, $vis_up] = trkChange($range_visitors, $prev_visitors);
    [$rev_change, $rev_up] = trkChange($range_revenue, $prev_range_revenue);
    [$aov_change, $aov_up] = trkChange($aov, $prev_aov);
    [$conv_change, $conv_up] = trkChange($conversion_rate, $prev_conversion_rate);

    // Active alert count
    $triggered_alerts = $pdo->query("SELECT COUNT(*) FROM analytics_alerts WHERE is_active = 1 AND last_triggered_at >= NOW() - INTERVAL 24 HOUR")->fetchColumn();
} catch (PDOException $e) {
    $overview_error = $e->getMessage();
}
?>

<div class="row g-3 mb-4">
    <!-- Today Stats -->
    <div class="col-md-3 col-6">
        <div class="card border-0 shadow-sm rounded-4 p-3 text-center h-100 bg-primary bg-opacity-10">
            <div class="text-primary small fw-bold">আজকের ভিজিটর (Today Visitors)</div>
            <div class="h3 fw-bold mb-0 text-primary mt-1"><?php echo number_format($today_visitors); ?></div>
            <div class="small text-muted mt-1"><?php echo number_format($today_visits); ?> Pageviews</div>
        </div>
    </div>
    <div class="col-md-3 col-6">
        <div class="card border-0 shadow-sm rounded-4 p-3 text-center h-100 bg-success bg-opacity-10">
            <div class="text-success small fw-bold">আজকের বিক্রি (Today Revenue)</div>
            <div class="h3 fw-bold mb-0 text-success mt-1">৳<?php echo number_format($today_revenue); ?></div>
            <div class="small text-muted mt-1"><?php echo $today_orders; ?> Orders</div>
        </div>
    </div>
    <div class="col-md-3 col-6">
        <div class="card border-0 shadow-sm rounded-4 p-3 text-center h-100 bg-warning bg-opacity-10">
            <div class="text-warning small fw-bold">AOV (গড় অর্ডার মূল্য)</div>
            <div class="h3 fw-bold mb-0 text-warning mt-1">৳<?php echo number_format($aov); ?></div>
            <div class="small text-muted mt-1">৳<?php echo number_format($prev_aov); ?> Last Period</div>
        </div>
    </div>
    <div class="col-md-3 col-6">
        <div class="card border-0 shadow-sm rounded-4 p-3 text-center h-100 bg-danger bg-opacity-10">
            <div class="text-danger small fw-bold">কনভার্শন রেট (Conversion Rate)</div>
            <div class="h3 fw-bold mb-0 text-danger mt-1"><?php echo round($conversion_rate, 2); ?>%</div>
            <div class="small text-muted mt-1"><?php echo round($prev_conversion_rate, 2); ?>% Last Period</div>
        </div>
    </div>
</div>

<div class="row g-4 mb-4">
    <!-- Main stats grid for time-range comparison -->
    <div class="col-lg-8">
        <div class="glass-card p-4 h-100">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <div>
                    <h5 class="fw-bold mb-0">Analytics Performance (<?php echo $range; ?> Days)</h5>
                    <p class="text-muted small mb-0">বিগত সময়কালের সাথে তুলনা ও পারফরম্যান্স বিশ্লেষণ</p>
                </div>
            </div>
            
            <div class="row g-4">
                <div class="col-md-6 col-lg-3">
                    <div class="border rounded-4 p-3 bg-white text-center">
                        <span class="text-secondary small d-block">ভিজিটরস (Unique)</span>
                        <span class="fs-4 fw-bold d-block my-1"><?php echo number_format($range_visitors); ?></span>
                        <span class="badge <?php echo $vis_up ? 'bg-success' : 'bg-danger'; ?> text-white small">
                            <i class="fas <?php echo $vis_up ? 'fa-arrow-up' : 'fa-arrow-down'; ?> me-1"></i><?php echo $vis_change; ?>
                        </span>
                    </div>
                </div>
                <div class="col-md-6 col-lg-3">
                    <div class="border rounded-4 p-3 bg-white text-center">
                        <span class="text-secondary small d-block">মোট রেভিনিউ</span>
                        <span class="fs-4 fw-bold d-block my-1">৳<?php echo number_format($range_revenue); ?></span>
                        <span class="badge <?php echo $rev_up ? 'bg-success' : 'bg-danger'; ?> text-white small">
                            <i class="fas <?php echo $rev_up ? 'fa-arrow-up' : 'fa-arrow-down'; ?> me-1"></i><?php echo $rev_change; ?>
                        </span>
                    </div>
                </div>
                <div class="col-md-6 col-lg-3">
                    <div class="border rounded-4 p-3 bg-white text-center">
                        <span class="text-secondary small d-block">অর্ডার ভ্যালু (গড়)</span>
                        <span class="fs-4 fw-bold d-block my-1">৳<?php echo number_format($aov); ?></span>
                        <span class="badge <?php echo $aov_up ? 'bg-success' : 'bg-danger'; ?> text-white small">
                            <i class="fas <?php echo $aov_up ? 'fa-arrow-up' : 'fa-arrow-down'; ?> me-1"></i><?php echo $aov_change; ?>
                        </span>
                    </div>
                </div>
                <div class="col-md-6 col-lg-3">
                    <div class="border rounded-4 p-3 bg-white text-center">
                        <span class="text-secondary small d-block">কনভার্শন হার</span>
                        <span class="fs-4 fw-bold d-block my-1"><?php echo round($conversion_rate, 2); ?>%</span>
                        <span class="badge <?php echo $conv_up ? 'bg-success' : 'bg-danger'; ?> text-white small">
                            <i class="fas <?php echo $conv_up ? 'fa-arrow-up' : 'fa-arrow-down'; ?> me-1"></i><?php echo $conv_change; ?>
                        </span>
                    </div>
                </div>
            </div>

            <!-- Health checklist -->
            <h5 class="fw-bold mt-4 mb-3">System Health Indexes</h5>
            <div class="row g-3">
                <div class="col-md-6">
                    <div class="p-3 border rounded-4 bg-light d-flex justify-content-between align-items-center">
                        <div>
                            <div class="fw-bold small text-dark"><i class="fas fa-satellite-dish text-primary me-2"></i>Pixel Integrations</div>
                            <small class="text-secondary">Meta, TikTok & Google</small>
                        </div>
                        <span class="badge bg-success px-3 py-2 rounded-pill"><?php echo $health_ok; ?>/6 Active</span>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="p-3 border rounded-4 bg-light d-flex justify-content-between align-items-center">
                        <div>
                            <div class="fw-bold small text-dark"><i class="fas fa-bell text-danger me-2"></i>Triggered Alerts</div>
                            <small class="text-secondary">Last 24 hours status</small>
                        </div>
                        <span class="badge <?php echo $triggered_alerts > 0 ? 'bg-danger' : 'bg-success'; ?> px-3 py-2 rounded-pill">
                            <?php echo $triggered_alerts; ?> Alerts
                        </span>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Alert feeds panel -->
    <div class="col-lg-4">
        <div class="glass-card p-4 h-100 d-flex flex-column">
            <h5 class="fw-bold mb-3"><i class="fas fa-bell text-danger me-2"></i>Real-time Alert Rules</h5>
            <div class="flex-grow-1 overflow-auto" style="max-height: 320px;" id="overview-alerts-feed">
                <!-- Fetch alert templates and rules -->
                <?php
                try {
                    $alerts = $pdo->query("SELECT * FROM analytics_alerts ORDER BY id DESC LIMIT 5")->fetchAll();
                } catch (\Exception $ex) {
                    $alerts = [];
                }
                if (empty($alerts)):
                ?>
                    <div class="text-center py-4 text-muted">
                        <i class="fas fa-shield-alt fa-2x mb-2 text-success"></i>
                        <p class="small mb-0">কোনো অ্যালার্ট রুল সক্রিয় নেই বা ট্রিগার হয়নি।</p>
                    </div>
                <?php else: ?>
                    <?php foreach ($alerts as $al): ?>
                        <div class="p-3 border rounded-3 mb-2 bg-light border-start border-4 <?php echo $al['is_active'] ? 'border-start-danger' : 'border-start-secondary'; ?>">
                            <div class="d-flex justify-content-between align-items-start">
                                <span class="fw-bold small text-dark"><?php echo htmlspecialchars($al['title']); ?></span>
                                <span class="badge bg-danger-subtle text-danger small">Active</span>
                            </div>
                            <div class="small text-muted mt-1 font-monospace">Type: <?php echo htmlspecialchars($al['alert_type']); ?></div>
                            <?php if ($al['last_triggered_at']): ?>
                                <small class="text-danger mt-1 d-block"><i class="fas fa-exclamation-triangle me-1"></i>Triggered: <?php echo date('M j, g:i A', strtotime($al['last_triggered_at'])); ?></small>
                            <?php endif; ?>
                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
            <div class="mt-3">
                <button type="button" class="btn btn-sm btn-outline-dark w-100" onclick="window.AdminTabs && AdminTabs.activate('settings', { updateHash: true, scrollTab: true });">
                    <i class="fas fa-cog me-1"></i> Manage Rules
                </button>
            </div>
        </div>
    </div>
</div>
