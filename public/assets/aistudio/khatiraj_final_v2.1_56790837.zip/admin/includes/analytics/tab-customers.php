<?php
// admin/includes/analytics/tab-customers.php
// Customer Intelligence dashboard view

try {
    // 1. Returning Customer rate
    $totalPurchasers = (int)$pdo->query("SELECT COUNT(DISTINCT customer_phone) FROM orders")->fetchColumn() ?: 1;
    $returningPurchasers = (int)$pdo->query("SELECT COUNT(*) FROM (SELECT customer_phone FROM orders GROUP BY customer_phone HAVING COUNT(*) > 1) as t")->fetchColumn() ?: 0;
    $returningPerc = round(($returningPurchasers / $totalPurchasers) * 100);

    // 2. Risky IP addresses (more than 3 orders)
    $riskyIPs = $pdo->query("
        SELECT ip_address, COUNT(*) as order_count, SUM(total_amount) as total_spent
        FROM orders 
        WHERE ip_address IS NOT NULL AND ip_address != '' 
        GROUP BY ip_address 
        HAVING order_count > 2 
        ORDER BY order_count DESC 
        LIMIT 5
    ")->fetchAll();

    // 3. Geographic performance — orders.shipping_address (not customer_address)
    $stmt_geo = $pdo->prepare("
        SELECT o.shipping_address, COUNT(*) as count, SUM(o.total_amount) as total
        FROM orders o
        WHERE o.created_at >= NOW() - INTERVAL ? DAY
        GROUP BY o.shipping_address
        ORDER BY count DESC
        LIMIT 8
    ");
    $stmt_geo->execute([(int)$range]);
    $geo_data = $stmt_geo->fetchAll();

    // 4. Repeat purchase count metrics
    $repeat_buyers = $pdo->query("
        SELECT order_count, COUNT(*) as buyers_count
        FROM (SELECT customer_phone, COUNT(*) as order_count FROM orders GROUP BY customer_phone) as cust_orders
        GROUP BY order_count
        ORDER BY order_count ASC
        LIMIT 5
    ")->fetchAll();

} catch (PDOException $e) {
    $customer_error = $e->getMessage();
}
?>

<?php if (!empty($customer_error)): ?>
    <div class="alert alert-danger"><i class="fas fa-exclamation-circle"></i> <?php echo htmlspecialchars($customer_error); ?></div>
<?php endif; ?>

<div class="row g-4 mb-4">
    <!-- Customer Return Rate Gauge -->
    <div class="col-lg-5">
        <div class="glass-card p-4 h-100 text-center d-flex flex-column justify-content-center align-items-center">
            <h5 class="fw-bold mb-3">রিটার্নিং কাস্টমার হার (Returning Customer Rate)</h5>
            <div style="width: 180px; height: 180px; position: relative;" class="my-3">
                <canvas id="returningCustomerGauge"></canvas>
                <div style="position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%);" class="text-center">
                    <span class="display-5 fw-bold text-dark"><?php echo $returningPerc; ?>%</span>
                    <span class="d-block small text-muted">Returning</span>
                </div>
            </div>
            <p class="small text-muted mb-0">মোট <?php echo number_format($totalPurchasers); ?> জন ক্রেতার মধ্যে <?php echo number_format($returningPurchasers); ?> জন একাধিকবার অর্ডার করেছেন।</p>
        </div>
    </div>

    <!-- Repeat Purchase Orders Chart -->
    <div class="col-lg-7">
        <div class="glass-card p-4 h-100">
            <h5 class="fw-bold mb-3"><i class="fas fa-history text-primary me-2"></i>অর্ডার ফ্রিকোয়েন্সি (Repeat Purchase Distribution)</h5>
            <div style="height: 250px;"><canvas id="frequencyChart"></canvas></div>
        </div>
    </div>
</div>

<div class="row g-4">
    <!-- District / Shipping Heatmap Table -->
    <div class="col-lg-6">
        <div class="glass-card p-4 h-100">
            <h5 class="fw-bold mb-3"><i class="fas fa-map-marker-alt text-danger me-2"></i>টপ ডেলিভারি লোকেশন (Top Delivery Locations)</h5>
            <div class="table-responsive">
                <table class="table table-sm align-middle small mb-0 table-hover">
                    <thead class="text-muted" style="font-size: 0.7rem;">
                        <tr>
                            <th>Address / Location keyword</th>
                            <th class="text-center">Orders Count</th>
                            <th class="text-end">Total Revenue</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($geo_data)): ?>
                            <tr><td colspan="3" class="text-center py-4 text-muted">কোনো লোকেশন ডেটা পাওয়া যায়নি</td></tr>
                        <?php else: ?>
                            <?php foreach ($geo_data as $geo): ?>
                                <tr>
                                    <td><span class="text-truncate d-inline-block" style="max-width: 250px;"><?php echo htmlspecialchars($geo['shipping_address'] ?? ''); ?></span></td>
                                    <td class="text-center fw-bold"><?php echo $geo['count']; ?></td>
                                    <td class="text-end text-success fw-bold">৳<?php echo number_format($geo['total']); ?></td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- Risky multi-order IP logs (fraud analysis) -->
    <div class="col-lg-6">
        <div class="glass-card p-4 h-100">
            <h5 class="fw-bold mb-1 text-danger"><i class="fas fa-user-shield me-2"></i>রিস্ক ও ফ্রড এনালাইসিস (Suspicious IPs)</h5>
            <p class="text-muted small mb-3">একটি আইপি থেকে একাধিক ভিন্ন ফোন নাম্বারে অর্ডার সনাক্তকরণ</p>
            <div class="table-responsive">
                <table class="table table-sm align-middle small mb-0 table-hover">
                    <thead class="text-muted" style="font-size: 0.7rem;">
                        <tr>
                            <th>IP Address</th>
                            <th class="text-center">Orders Placed</th>
                            <th class="text-end">Spent Amount</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($riskyIPs)): ?>
                            <tr><td colspan="3" class="text-center py-4 text-muted text-success"><i class="fas fa-check-circle me-1"></i>কোনো ঝুঁকিপূর্ণ আইপি সনাক্ত করা হয়নি</td></tr>
                        <?php else: ?>
                            <?php foreach ($riskyIPs as $ip): ?>
                                <tr>
                                    <td><code><?php echo htmlspecialchars($ip['ip_address']); ?></code></td>
                                    <td class="text-center text-danger fw-bold"><?php echo $ip['order_count']; ?> orders</td>
                                    <td class="text-end fw-bold">৳<?php echo number_format($ip['total_spent']); ?></td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    if (typeof Chart === 'undefined') return;

    // Returning Customer Gauge
    const gaugeCanvas = document.getElementById('returningCustomerGauge');
    if (gaugeCanvas) {
        new Chart(gaugeCanvas, {
            type: 'doughnut',
            data: {
                datasets: [{
                    data: [<?php echo $returningPerc; ?>, <?php echo 100 - $returningPerc; ?>],
                    backgroundColor: ['#6366f1', '#e2e8f0'],
                    borderWidth: 0
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                cutout: '80%',
                plugins: { legend: { display: false } }
            }
        });
    }

    // Order Frequency Bar
    const freqCanvas = document.getElementById('frequencyChart');
    if (freqCanvas) {
        const labels = <?php echo json_encode(array_map(fn($r) => $r['order_count'] . ' Orders', $repeat_buyers)); ?>;
        const counts = <?php echo json_encode(array_column($repeat_buyers, 'buyers_count')); ?>;
        new Chart(freqCanvas, {
            type: 'bar',
            data: {
                labels: labels,
                datasets: [{
                    label: 'Number of Customers',
                    data: counts,
                    backgroundColor: '#4f46e5',
                    borderRadius: 6
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: { legend: { display: false } }
            }
        });
    }
});
</script>
