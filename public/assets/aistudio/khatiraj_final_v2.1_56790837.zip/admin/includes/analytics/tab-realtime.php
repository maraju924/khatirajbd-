<?php
// admin/includes/analytics/tab-realtime.php
// Real-time site monitoring dashboard view with AJAX polling triggers

try {
    // 1. Live visitors count (unique sessions in last 5 minutes)
    $active_visitors = (int) $pdo->query("SELECT COUNT(DISTINCT session_id) FROM page_visits WHERE created_at >= NOW() - INTERVAL 5 MINUTE AND is_bot = 0")->fetchColumn();

    // 2. Active pages
    $stmt_active_pages = $pdo->query("
        SELECT page_url, COUNT(*) as active_views, COUNT(DISTINCT session_id) as active_sessions
        FROM page_visits
        WHERE created_at >= NOW() - INTERVAL 5 MINUTE AND is_bot = 0
        GROUP BY page_url
        ORDER BY active_views DESC
        LIMIT 5
    ");
    $active_pages = $stmt_active_pages->fetchAll();

    // 3. Live events stream
    $stmt_live_events = $pdo->query("
        SELECT platform, event_name, response_code, created_at
        FROM tracking_logs
        ORDER BY created_at DESC
        LIMIT 8
    ");
    $live_events = $stmt_live_events->fetchAll();

    // 4. Today's live order tick
    $stmt_live_orders = $pdo->query("
        SELECT customer_name, total_amount, created_at
        FROM orders
        ORDER BY created_at DESC
        LIMIT 5
    ");
    $live_orders = $stmt_live_orders->fetchAll();

} catch (PDOException $e) {
    $realtime_error = $e->getMessage();
}
?>

<style>
.pulse-icon {
    width: 12px;
    height: 12px;
    background: #ef4444;
    border-radius: 50%;
    display: inline-block;
    box-shadow: 0 0 0 0 rgba(239, 68, 68, 0.7);
    animation: pulse 1.4s infinite;
}
@keyframes pulse {
    0% { transform: scale(0.95); box-shadow: 0 0 0 0 rgba(239, 68, 68, 0.7); }
    70% { transform: scale(1); box-shadow: 0 0 0 6px rgba(239, 68, 68, 0); }
    100% { transform: scale(0.95); box-shadow: 0 0 0 0 rgba(239, 68, 68, 0); }
}
.live-number-card {
    background: linear-gradient(135deg, #1e293b 0%, #0f172a 100%);
    color: #38bdf8;
    border: 1px solid rgba(255,255,255,0.08);
}
</style>

<div class="row g-4 mb-4">
    <!-- Active Visitors Counters -->
    <div class="col-lg-4">
        <div class="card border-0 shadow-sm rounded-4 p-4 text-center live-number-card h-100 d-flex flex-column justify-content-center align-items-center">
            <div class="d-flex align-items-center justify-content-center gap-2 mb-2">
                <span class="pulse-icon"></span>
                <span class="text-white-50 small fw-bold text-uppercase tracking-wider">Active Visitors Right Now</span>
            </div>
            <div class="display-1 fw-black my-2 font-monospace" id="live-visitors-count"><?php echo $active_visitors; ?></div>
            <p class="small text-white-50 mb-0">ইউনিক ভিজিটর যারা গত ৫ মিনিটে পেজ ব্রাউজ করেছেন</p>
            <div class="text-info-emphasis small mt-3 border border-info border-opacity-25 bg-info bg-opacity-10 px-3 py-1 rounded-pill">
                <i class="fas fa-spinner fa-spin me-1"></i> Auto-refreshing every 15s
            </div>
        </div>
    </div>

    <!-- Active Pages Table -->
    <div class="col-lg-8">
        <div class="glass-card p-4 h-100">
            <h5 class="fw-bold mb-3"><i class="fas fa-eye text-primary me-2"></i>কোন পেজগুলো এখন দেখা হচ্ছে (Active Pages)</h5>
            <div class="table-responsive">
                <table class="table table-sm align-middle small mb-0 table-hover">
                    <thead class="text-muted text-uppercase" style="font-size: 0.7rem;">
                        <tr>
                            <th>Page Url</th>
                            <th class="text-center">Active Pageviews</th>
                            <th class="text-end">Active Sessions</th>
                        </tr>
                    </thead>
                    <tbody id="live-pages-table-body">
                        <?php if (empty($active_pages)): ?>
                            <tr><td colspan="3" class="text-center py-4 text-muted">এই মুহূর্তে কোনো সক্রিয় ভিজিটর নেই</td></tr>
                        <?php else: ?>
                            <?php foreach ($active_pages as $ap): ?>
                                <tr>
                                    <td><code class="text-dark"><?php echo htmlspecialchars($ap['page_url']); ?></code></td>
                                    <td class="text-center fw-bold text-primary"><?php echo $ap['active_views']; ?></td>
                                    <td class="text-end font-monospace"><?php echo $ap['active_sessions']; ?></td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<div class="row g-4">
    <!-- Live Events Stream (Tracking logs) -->
    <div class="col-lg-7">
        <div class="glass-card p-4 h-100">
            <h5 class="fw-bold mb-3"><i class="fas fa-wifi text-success me-2"></i>লাইভ পিক্সেল ট্র্যাকিং স্ট্রিম (Live API Event Stream)</h5>
            <div class="table-responsive" style="max-height: 380px; overflow-y: auto;">
                <table class="table table-sm align-middle small mb-0 table-hover">
                    <thead class="text-muted text-uppercase" style="font-size: 0.7rem;">
                        <tr>
                            <th>Time</th>
                            <th>Platform</th>
                            <th>Event Type</th>
                            <th class="text-end">Status</th>
                        </tr>
                    </thead>
                    <tbody id="live-events-table-body">
                        <?php if (empty($live_events)): ?>
                            <tr><td colspan="4" class="text-center py-4 text-muted">কোনো ট্র্যাকিং লগ পাওয়া যায়নি</td></tr>
                        <?php else: ?>
                            <?php foreach ($live_events as $lev): ?>
                                <tr>
                                    <td><small class="text-muted"><?php echo date('H:i:s', strtotime($lev['created_at'])); ?></small></td>
                                    <td>
                                        <?php if ($lev['platform'] === 'meta'): ?>
                                            <span class="badge bg-primary-subtle text-primary"><i class="fab fa-facebook me-1"></i>Meta</span>
                                        <?php else: ?>
                                            <span class="badge bg-dark"><i class="fab fa-tiktok me-1"></i>TikTok</span>
                                        <?php endif; ?>
                                    </td>
                                    <td><code><?php echo htmlspecialchars($lev['event_name']); ?></code></td>
                                    <td class="text-end">
                                        <span class="badge <?php echo $lev['response_code'] < 400 ? 'bg-success' : 'bg-danger'; ?>">
                                            HTTP <?php echo $lev['response_code']; ?>
                                        </span>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- Live Orders Tick -->
    <div class="col-lg-5">
        <div class="glass-card p-4 h-100">
            <h5 class="fw-bold mb-3"><i class="fas fa-shopping-cart text-warning me-2"></i>সাম্প্রতিক লাইভ অর্ডার (Recent Live Orders)</h5>
            <div class="d-flex flex-column gap-2" id="live-orders-list">
                <?php if (empty($live_orders)): ?>
                    <div class="text-center py-4 text-muted">আজকে কোনো অর্ডার নেই</div>
                <?php else: ?>
                    <?php foreach ($live_orders as $ord): ?>
                        <div class="p-3 border rounded-3 bg-light d-flex justify-content-between align-items-center animate__animated animate__fadeIn">
                            <div>
                                <strong class="text-dark small"><?php echo htmlspecialchars($ord['customer_name'] ?: 'Guest'); ?></strong>
                                <div class="text-muted small mt-1"><i class="far fa-clock me-1"></i><?php echo date('h:i A', strtotime($ord['created_at'])); ?></div>
                            </div>
                            <span class="fw-bold text-success">৳<?php echo number_format($ord['total_amount']); ?></span>
                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<script>
// Auto-refresh real-time data using AJAX
function pollRealtimeData() {
    fetch('actions/analytics-realtime-data.php', {
        headers: { 'X-Requested-With': 'XMLHttpRequest' }
    })
    .then(res => res.json())
    .then(data => {
        if (data.success) {
            // Update Active Counter
            document.getElementById('live-visitors-count').innerText = data.active_visitors;
            
            // Update Active Pages Table
            const pageBody = document.getElementById('live-pages-table-body');
            if (data.active_pages.length === 0) {
                pageBody.innerHTML = `<tr><td colspan="3" class="text-center py-4 text-muted">এই মুহূর্তে কোনো সক্রিয় ভিজিটর নেই</td></tr>`;
            } else {
                pageBody.innerHTML = data.active_pages.map(ap => `
                    <tr>
                        <td><code class="text-dark">${escapeHtml(ap.page_url)}</code></td>
                        <td class="text-center fw-bold text-primary">${ap.active_views}</td>
                        <td class="text-end font-monospace">${ap.active_sessions}</td>
                    </tr>
                `).join('');
            }
            
            // Update Live Events Table
            const eventsBody = document.getElementById('live-events-table-body');
            if (data.live_events.length === 0) {
                eventsBody.innerHTML = `<tr><td colspan="4" class="text-center py-4 text-muted">কোনো ট্র্যাকিং লগ পাওয়া যায়নি</td></tr>`;
            } else {
                eventsBody.innerHTML = data.live_events.map(lev => {
                    const badge = lev.platform === 'meta' 
                        ? `<span class="badge bg-primary-subtle text-primary"><i class="fab fa-facebook me-1"></i>Meta</span>`
                        : `<span class="badge bg-dark"><i class="fab fa-tiktok me-1"></i>TikTok</span>`;
                    const httpBadge = lev.response_code < 400 
                        ? `<span class="badge bg-success">HTTP ${lev.response_code}</span>` 
                        : `<span class="badge bg-danger">HTTP ${lev.response_code}</span>`;
                    
                    return `
                        <tr>
                            <td><small class="text-muted">${formatTime(lev.created_at)}</small></td>
                            <td>${badge}</td>
                            <td><code>${escapeHtml(lev.event_name)}</code></td>
                            <td class="text-end">${httpBadge}</td>
                        </tr>
                    `;
                }).join('');
            }

            // Update Orders List
            const ordersList = document.getElementById('live-orders-list');
            if (data.live_orders.length === 0) {
                ordersList.innerHTML = `<div class="text-center py-4 text-muted">আজকে কোনো অর্ডার নেই</div>`;
            } else {
                ordersList.innerHTML = data.live_orders.map(ord => `
                    <div class="p-3 border rounded-3 bg-light d-flex justify-content-between align-items-center">
                        <div>
                            <strong class="text-dark small">${escapeHtml(ord.customer_name || 'Guest')}</strong>
                            <div class="text-muted small mt-1"><i class="far fa-clock me-1"></i>${formatTimeHM(ord.created_at)}</div>
                        </div>
                        <span class="fw-bold text-success">৳${numberFormat(ord.total_amount)}</span>
                    </div>
                `).join('');
            }
        }
    })
    .catch(err => console.error('Real-time polling error:', err));
}

// Helpers
function escapeHtml(str) {
    if (!str) return '';
    return str.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#039;");
}

function formatTime(dateTimeStr) {
    const d = new Date(dateTimeStr);
    return d.toTimeString().split(' ')[0];
}

function formatTimeHM(dateTimeStr) {
    const d = new Date(dateTimeStr);
    return d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
}

function numberFormat(num) {
    return Number(num).toLocaleString('en-US');
}

// Start Polling Loop
let realtimeInterval = setInterval(pollRealtimeData, 15000);

// Clear interval when tab becomes inactive (if user navigates inside admin)
document.addEventListener('visibilitychange', function() {
    if (document.visibilityState === 'hidden') {
        clearInterval(realtimeInterval);
    } else {
        realtimeInterval = setInterval(pollRealtimeData, 15000);
    }
});
</script>
