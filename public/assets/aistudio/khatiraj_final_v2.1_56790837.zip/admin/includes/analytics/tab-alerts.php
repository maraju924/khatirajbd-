<?php
// admin/includes/analytics/tab-alerts.php
// Alert Rules administration dashboard sub-view

// Fetch existing alert rules
try {
    $alert_rules = $pdo->query("SELECT * FROM analytics_alerts ORDER BY id DESC")->fetchAll();
} catch (PDOException $e) {
    $alert_rules = [];
}
?>

<div class="glass-card p-4 mb-4">
    <div class="d-flex justify-content-between align-items-center mb-3">
        <div>
            <h5 class="fw-bold mb-0"><i class="fas fa-bell-slash text-danger me-2"></i>অ্যালার্ট রুলস কনফিগারেশন (Alert Rules & Monitors)</h5>
            <p class="text-muted small mb-0">নির্দিষ্ট কন্ডিশন ট্রিগার হলে সিস্টেম অ্যাডমিনকে সতর্ক করবে</p>
        </div>
        <button type="button" class="btn btn-primary btn-sm" data-bs-toggle="modal" data-bs-target="#addAlertRuleModal">
            <i class="fas fa-plus me-1"></i> নতুন রুল যোগ করুন
        </button>
    </div>

    <div class="table-responsive">
        <table class="table table-sm align-middle small mb-0 table-hover">
            <thead class="text-muted" style="font-size: 0.7rem;">
                <tr>
                    <th>Rule Title</th>
                    <th>Alert Type</th>
                    <th>Status</th>
                    <th>Condition / Threshold</th>
                    <th class="text-center">Trigger Count</th>
                    <th class="text-end">Last Triggered</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($alert_rules)): ?>
                    <tr><td colspan="6" class="text-center py-4 text-muted">কোনো অ্যালার্ট রুল সক্রিয় নেই। উপরের বাটন থেকে যোগ করুন।</td></tr>
                <?php else: ?>
                    <?php foreach ($alert_rules as $rule): 
                        $cond = json_decode($rule['condition_json'] ?? '', true) ?: [];
                        $threshold = $cond['threshold'] ?? 'N/A';
                    ?>
                        <tr>
                            <td><strong class="text-dark"><?php echo htmlspecialchars($rule['title']); ?></strong></td>
                            <td><code><?php echo htmlspecialchars($rule['alert_type']); ?></code></td>
                            <td>
                                <span class="badge <?php echo $rule['is_active'] ? 'bg-success' : 'bg-secondary'; ?>">
                                    <?php echo $rule['is_active'] ? 'Active' : 'Inactive'; ?>
                                </span>
                            </td>
                            <td>Value threshold: <span class="fw-bold text-dark"><?php echo htmlspecialchars($threshold); ?></span></td>
                            <td class="text-center font-monospace fw-bold"><?php echo $rule['trigger_count']; ?> times</td>
                            <td class="text-end text-muted">
                                <?php echo $rule['last_triggered_at'] ? date('M j, g:i A', strtotime($rule['last_triggered_at'])) : 'Never'; ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<!-- Add Alert Rule Modal -->
<div class="modal fade" id="addAlertRuleModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content border-0 shadow-lg">
            <div class="modal-header border-0 bg-primary text-white">
                <h5 class="modal-title fw-bold"><i class="fas fa-plus me-2"></i>অ্যালার্ট রুল যোগ করুন</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <form action="actions/analytics-alerts.php" method="POST">
                <input type="hidden" name="action" value="add">
                <div class="modal-body p-4">
                    <div class="mb-3">
                        <label class="form-label fw-bold">রুল শিরোনাম (Title) *</label>
                        <input type="text" name="title" class="form-control" placeholder="e.g. দৈনিক অর্ডারে ধস সতর্কবার্তা" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-bold">অ্যালার্ট ধরণ (Alert Type) *</label>
                        <select name="alert_type" class="form-select" required>
                            <option value="revenue_drop">Revenue Drop (বিক্রি কমে যাওয়া)</option>
                            <option value="high_abandoned">High Abandoned Cart Rate (কার্ট খালি রেখে চলে যাওয়া)</option>
                            <option value="pixel_failure">Pixel Failure Spike (পিক্সেল ইভেন্ট ব্যর্থতা)</option>
                            <option value="low_stock">Low Stock (স্টক ফুরিয়ে যাওয়া)</option>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-bold">থ্রেশহোল্ড মান (Value Threshold) *</label>
                        <input type="number" name="threshold" class="form-control" placeholder="e.g. 10" required>
                        <div class="form-text">শতাংশ (%) বা সংখ্যাগত মান যার নিচে/ওপরে গেলে অ্যালার্ট ট্রিগার হবে।</div>
                    </div>
                </div>
                <div class="modal-footer border-0 p-4 pt-0">
                    <button type="button" class="btn btn-light" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary fw-bold shadow-sm">রুল সংরক্ষণ করুন</button>
                </div>
            </form>
        </div>
    </div>
</div>
