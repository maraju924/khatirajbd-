<?php
// admin/includes/analytics/tab-products.php
// Product Performance dashboard view

try {
    // 1. Top Selling Products
    $stmt_top_p = $pdo->prepare("
        SELECT p.id, p.name, SUM(oi.qty) as total_qty, SUM(oi.qty * oi.price) as total_revenue
        FROM order_items oi
        JOIN products p ON oi.product_id = p.id
        JOIN orders o ON oi.order_id = o.id
        WHERE o.created_at >= NOW() - INTERVAL :r DAY AND o.order_status != 'Cancelled'
        GROUP BY p.id
        ORDER BY total_qty DESC
        LIMIT 5
    ");
    $stmt_top_p->execute([':r' => $range]);
    $top_products = $stmt_top_p->fetchAll();

    // 2. Dead stock alert: products with NO sales in the range
    $stmt_dead = $pdo->prepare("
        SELECT p.id, p.name, p.price, p.quantity as current_stock
        FROM products p
        WHERE p.status = 1 
          AND p.id NOT IN (
              SELECT DISTINCT oi.product_id 
              FROM order_items oi 
              JOIN orders o ON oi.order_id = o.id 
              WHERE o.created_at >= NOW() - INTERVAL ? DAY AND o.order_status != 'Cancelled'
          )
        ORDER BY p.quantity DESC
        LIMIT 5
    ");
    $stmt_dead->execute([(int)$range]);
    $dead_products = $stmt_dead->fetchAll();

    // 3. Category Contribution
    $stmt_cat_perf = $pdo->prepare("
        SELECT c.name as category_name, SUM(oi.qty * oi.price) as total_revenue
        FROM order_items oi
        JOIN products p ON oi.product_id = p.id
        JOIN categories c ON p.category_id = c.id
        JOIN orders o ON oi.order_id = o.id
        WHERE o.created_at >= NOW() - INTERVAL :r DAY AND o.order_status != 'Cancelled'
        GROUP BY c.id
        ORDER BY total_revenue DESC
    ");
    $stmt_cat_perf->execute([':r' => $range]);
    $cat_performance = $stmt_cat_perf->fetchAll();
    
    $cat_names = [];
    $cat_revs = [];
    foreach ($cat_performance as $cat) {
        $cat_names[] = $cat['category_name'];
        $cat_revs[] = (float)$cat['total_revenue'];
    }

} catch (PDOException $e) {
    $product_perf_error = $e->getMessage();
}
?>

<?php if (!empty($product_perf_error)): ?>
    <div class="alert alert-danger"><i class="fas fa-exclamation-circle"></i> <?php echo htmlspecialchars($product_perf_error); ?></div>
<?php endif; ?>

<div class="row g-4 mb-4">
    <!-- Top Selling products list -->
    <div class="col-lg-7">
        <div class="glass-card p-4 h-100">
            <h5 class="fw-bold mb-3"><i class="fas fa-trophy text-warning me-2"></i>সেরা বিক্রিত পণ্য (Top Selling Products)</h5>
            <div class="table-responsive">
                <table class="table table-sm align-middle small mb-0 table-hover">
                    <thead class="text-muted" style="font-size: 0.7rem;">
                        <tr>
                            <th>Product Name</th>
                            <th class="text-center">Quantity Sold</th>
                            <th class="text-end">Total Revenue Generated</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($top_products)): ?>
                            <tr><td colspan="3" class="text-center py-4 text-muted">এই সময়ে কোনো পণ্য বিক্রি হয়নি</td></tr>
                        <?php else: ?>
                            <?php foreach ($top_products as $p): ?>
                                <tr>
                                    <td><strong class="text-dark"><?php echo htmlspecialchars($p['name']); ?></strong></td>
                                    <td class="text-center fw-bold text-primary"><?php echo number_format($p['total_qty']); ?> pcs</td>
                                    <td class="text-end text-success fw-bold">৳<?php echo number_format($p['total_revenue']); ?></td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- Category Sales Breakdown -->
    <div class="col-lg-5">
        <div class="glass-card p-4 h-100 d-flex flex-column">
            <h5 class="fw-bold mb-3"><i class="fas fa-chart-pie text-success me-2"></i>ক্যাটাগরি ভিত্তিক অবদান (Category Share)</h5>
            <?php if (empty($cat_revs)): ?>
                <div class="text-muted small my-auto text-center">কোনো অবদানের ডেটা নেই</div>
            <?php else: ?>
                <div style="height: 220px;" class="mb-3"><canvas id="categoryShareChart"></canvas></div>
            <?php endif; ?>
        </div>
    </div>
</div>

<!-- Dead stock warning / slow moving items -->
<div class="glass-card p-4">
    <h5 class="fw-bold mb-1 text-danger"><i class="fas fa-exclamation-triangle me-2"></i>অচল পণ্য সতর্কবার্তা (Dead Stock Alert)</h5>
    <p class="text-muted small mb-3">সক্রিয় পণ্যসমূহ যা বিগত <?php echo $range; ?> দিনে একটিও বিক্রি হয়নি</p>
    <div class="table-responsive">
        <table class="table table-sm align-middle small mb-0 table-hover">
            <thead class="text-muted" style="font-size: 0.7rem;">
                <tr>
                    <th>Product Name</th>
                    <th>Price</th>
                    <th class="text-end">Current Stock in Hand</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($dead_products)): ?>
                    <tr><td colspan="3" class="text-center py-3 text-muted text-success"><i class="fas fa-check-circle me-1"></i>সব পণ্যই ভালো বিক্রি হচ্ছে!</td></tr>
                <?php else: ?>
                    <?php foreach ($dead_products as $p): ?>
                        <tr>
                            <td><span class="text-slate-700"><?php echo htmlspecialchars($p['name']); ?></span></td>
                            <td>৳<?php echo number_format($p['price']); ?></td>
                            <td class="text-end font-monospace fw-bold text-danger"><?php echo $p['current_stock']; ?> pcs</td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    if (typeof Chart === 'undefined') return;

    // Category Share Chart
    const catCanvas = document.getElementById('categoryShareChart');
    if (catCanvas) {
        new Chart(catCanvas, {
            type: 'pie',
            data: {
                labels: <?php echo json_encode($cat_names); ?>,
                datasets: [{
                    data: <?php echo json_encode($cat_revs); ?>,
                    backgroundColor: ['#22c55e', '#3b82f6', '#f59e0b', '#8b5cf6', '#ec4899', '#f43f5e'],
                    borderWidth: 2
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: { legend: { position: 'bottom' } }
            }
        });
    }
});
</script>
