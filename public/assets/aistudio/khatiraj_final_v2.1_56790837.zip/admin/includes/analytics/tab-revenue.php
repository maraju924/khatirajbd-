<?php
// admin/includes/analytics/tab-revenue.php
// Revenue Analytics dashboard view

try {
    // 1. Payment Methods breakdown
    $stmt_pm = $pdo->prepare("
        SELECT payment_method, COUNT(*) as count, SUM(total_amount) as total
        FROM orders
        WHERE created_at >= NOW() - INTERVAL :r DAY AND order_status != 'Cancelled'
        GROUP BY payment_method
    ");
    $stmt_pm->execute([':r' => $range]);
    $pm_raw = $stmt_pm->fetchAll();
    
    $pm_labels = [];
    $pm_totals = [];
    foreach ($pm_raw as $pm) {
        $pm_labels[] = $pm['payment_method'] === 'COD' ? 'Cash On Delivery (COD)' : $pm['payment_method'];
        $pm_totals[] = (float)$pm['total'];
    }

    // 2. Sales Velocity (Time series for selected range)
    $stmt_vel = $pdo->prepare("
        SELECT DATE(created_at) as order_date, SUM(total_amount) as daily_revenue, COUNT(*) as daily_orders
        FROM orders
        WHERE created_at >= NOW() - INTERVAL :r DAY AND order_status != 'Cancelled'
        GROUP BY DATE(created_at)
        ORDER BY DATE(created_at) ASC
    ");
    $stmt_vel->execute([':r' => $range]);
    $vel_data = $stmt_vel->fetchAll();

    $vel_labels = [];
    $vel_revenue = [];
    $vel_orders = [];
    foreach ($vel_data as $row) {
        $vel_labels[] = date('M d', strtotime($row['order_date']));
        $vel_revenue[] = (float)$row['daily_revenue'];
        $vel_orders[] = (int)$row['daily_orders'];
    }

    // 3. Day of week performance
    $stmt_dow = $pdo->prepare("
        SELECT DAYNAME(created_at) as dow, SUM(total_amount) as total
        FROM orders
        WHERE created_at >= NOW() - INTERVAL :r DAY AND order_status != 'Cancelled'
        GROUP BY DAYOFWEEK(created_at)
        ORDER BY DAYOFWEEK(created_at) ASC
    ");
    $stmt_dow->execute([':r' => $range]);
    $dow_data = $stmt_dow->fetchAll();

} catch (PDOException $e) {
    $revenue_error = $e->getMessage();
}
?>

<?php if (!empty($revenue_error)): ?>
    <div class="alert alert-danger"><i class="fas fa-exclamation-circle"></i> <?php echo htmlspecialchars($revenue_error); ?></div>
<?php endif; ?>

<div class="row g-4 mb-4">
    <!-- Revenue Velocity Chart -->
    <div class="col-lg-8">
        <div class="glass-card p-4 h-100">
            <h5 class="fw-bold mb-3"><i class="fas fa-chart-area text-primary me-2"></i>রেভিনিউ ট্রেন্ড ও গতিবেগ (Revenue Velocity)</h5>
            <div style="height: 320px;"><canvas id="revenueTrendChart"></canvas></div>
        </div>
    </div>

    <!-- Payment Methods Split -->
    <div class="col-lg-4">
        <div class="glass-card p-4 h-100 d-flex flex-column">
            <h5 class="fw-bold mb-3"><i class="fas fa-credit-card text-success me-2"></i>পেমেন্ট মেথড ডিস্ট্রিবিউশন</h5>
            <?php if (empty($pm_totals)): ?>
                <div class="text-muted small my-auto text-center">কোনো পেমেন্ট ডেটা নেই</div>
            <?php else: ?>
                <div style="height: 200px;" class="mb-3"><canvas id="paymentSplitChart"></canvas></div>
                <div class="table-responsive">
                    <table class="table table-sm table-borderless align-middle mb-0 small">
                        <tbody>
                            <?php foreach ($pm_raw as $pm): ?>
                                <tr class="border-top">
                                    <td class="fw-bold"><?php echo htmlspecialchars($pm['payment_method']); ?></td>
                                    <td class="text-center text-muted"><?php echo $pm['count']; ?> orders</td>
                                    <td class="text-end fw-bold">৳<?php echo number_format($pm['total']); ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<div class="row g-4">
    <!-- Day of week sales -->
    <div class="col-lg-6">
        <div class="glass-card p-4 h-100">
            <h5 class="fw-bold mb-3"><i class="fas fa-calendar-day text-warning me-2"></i>সপ্তাহের দিন ভিত্তিক বিক্রি</h5>
            <div class="table-responsive">
                <table class="table table-sm table-hover align-middle small mb-0">
                    <thead class="text-muted" style="font-size: 0.7rem;">
                        <tr>
                            <th>Day of Week</th>
                            <th class="text-end">Total Revenue</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($dow_data)): ?>
                            <tr><td colspan="2" class="text-center py-4 text-muted">কোনো ডেটা পাওয়া যায়নি</td></tr>
                        <?php else: ?>
                            <?php foreach ($dow_data as $row): ?>
                                <tr>
                                    <td><strong class="text-dark"><?php echo $row['dow']; ?></strong></td>
                                    <td class="text-end text-success fw-bold">৳<?php echo number_format($row['total']); ?></td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- Revenue Projection/Forecast Card -->
    <div class="col-lg-6">
        <div class="glass-card p-4 h-100 bg-dark text-white border-0">
            <h5 class="fw-bold mb-3 text-white"><i class="fas fa-magic text-info me-2"></i>রেভিনিউ পূর্বাভাস (Predictive Revenue Forecast)</h5>
            <p class="text-white-50 small">বিগত সময়ের ডেটার উপর ভিত্তি করে আগামী ৩০ দিনের আনুমানিক রেভিনিউ হিসাব</p>
            <?php
            $daily_avg = $range_orders > 0 ? ($range_revenue / $range) : 0;
            $projected_30 = $daily_avg * 30;
            ?>
            <div class="mt-4">
                <span class="text-white-50 small d-block">গড় দৈনিক বিক্রি (Daily Average)</span>
                <span class="display-6 fw-bold text-info">৳<?php echo number_format($daily_avg, 2); ?></span>
            </div>
            <div class="mt-3 border-top border-secondary pt-3">
                <span class="text-white-50 small d-block">আগামী ৩০ দিনের প্রক্ষেপিত লক্ষ্যমাত্রা (Projected 30 Days Target)</span>
                <span class="h2 fw-bold text-success">৳<?php echo number_format($projected_30); ?></span>
            </div>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    if (typeof Chart === 'undefined') return;

    // Revenue Trend Chart
    const revCanvas = document.getElementById('revenueTrendChart');
    if (revCanvas) {
        new Chart(revCanvas, {
            type: 'line',
            data: {
                labels: <?php echo json_encode($vel_labels); ?>,
                datasets: [
                    {
                        label: 'Revenue (৳)',
                        data: <?php echo json_encode($vel_revenue); ?>,
                        borderColor: '#10b981',
                        backgroundColor: 'rgba(16, 185, 129, 0.1)',
                        fill: true,
                        tension: 0.3
                    },
                    {
                        label: 'Orders Count',
                        data: <?php echo json_encode($vel_orders); ?>,
                        borderColor: '#3b82f6',
                        backgroundColor: 'transparent',
                        fill: false,
                        yAxisID: 'y1',
                        tension: 0.2
                    }
                ]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    y: { beginAtZero: true },
                    y1: { 
                        beginAtZero: true, 
                        position: 'right',
                        grid: { drawOnChartArea: false }
                    }
                }
            }
        });
    }

    // Payment Doughnut
    const pmCanvas = document.getElementById('paymentSplitChart');
    if (pmCanvas) {
        new Chart(pmCanvas, {
            type: 'doughnut',
            data: {
                labels: <?php echo json_encode($pm_labels); ?>,
                datasets: [{
                    data: <?php echo json_encode($pm_totals); ?>,
                    backgroundColor: ['#10b981', '#6366f1', '#f59e0b', '#ec4899'],
                    borderWidth: 2
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: { legend: { position: 'bottom' } }
            }
        });
    }
});
</script>
