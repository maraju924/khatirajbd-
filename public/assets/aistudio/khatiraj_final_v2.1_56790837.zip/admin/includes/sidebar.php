<?php
require_once __DIR__ . '/components/init.php';

$role = $_SESSION['admin_role'] ?? 'guest';
$currentPage = $page ?? ($_GET['page'] ?? 'dashboard');

$logo_path = '';
try {
    $logo_stmt = $pdo->query("SELECT value FROM settings WHERE key_name = 'site_logo'");
    $logo_path = $logo_stmt->fetchColumn() ?: '';
} catch (Exception $e) {}

$site_name = $site_settings['site_name'] ?? 'Khati Raj';

function navActive(array $pages, string $current): string {
    return in_array($current, $pages) ? 'active' : '';
}

function canSee(string $role, array $allowed): bool {
    return in_array($role, $allowed);
}

$navGroups = [
    'sales' => [
        'label' => 'বিক্রয়',
        'icon' => 'fa-cart-shopping',
        'roles' => ['super_admin', 'moderator'],
        'items' => [
            ['page' => 'orders', 'label' => 'অর্ডার', 'icon' => 'fa-receipt', 'roles' => ['super_admin', 'moderator']],
            ['page' => 'abandoned-carts', 'label' => 'Abandoned Carts', 'icon' => 'fa-cart-arrow-down', 'roles' => ['super_admin', 'moderator']],
            ['page' => 'courier-dashboard', 'label' => 'Courier (Steadfast)', 'icon' => 'fa-truck-fast', 'roles' => ['super_admin', 'moderator']],
            ['page' => 'customers', 'label' => 'গ্রাহক', 'icon' => 'fa-users', 'roles' => ['super_admin', 'moderator']],
            ['page' => 'reviews', 'label' => 'রিভিউ', 'icon' => 'fa-star', 'roles' => ['super_admin', 'moderator']],
            ['page' => 'payment-transactions', 'label' => 'Transactions', 'icon' => 'fa-money-check-alt', 'roles' => ['super_admin']],
        ],
    ],
    'catalog' => [
        'label' => 'ক্যাটালগ',
        'icon' => 'fa-box-open',
        'roles' => ['super_admin', 'editor'],
        'items' => [
            ['page' => 'products', 'label' => 'Products', 'icon' => 'fa-box', 'roles' => ['super_admin', 'editor'], 'also' => ['add-product', 'edit-product', 'bulk-upload']],
            ['page' => 'categories', 'label' => 'Categories', 'icon' => 'fa-tags', 'roles' => ['super_admin', 'editor'], 'also' => ['edit-category']],
            ['page' => 'coupons', 'label' => 'Coupons', 'icon' => 'fa-ticket-alt', 'roles' => ['super_admin', 'editor']],
            ['page' => 'flash-sale', 'label' => 'Flash Sale', 'icon' => 'fa-bolt', 'roles' => ['super_admin', 'marketing']],
        ],
    ],
    'content' => [
        'label' => 'কন্টেন্ট',
        'icon' => 'fa-file-lines',
        'roles' => ['super_admin', 'editor', 'marketing'],
        'items' => [
            ['page' => 'page-manager', 'label' => 'Page Manager', 'icon' => 'fa-sitemap', 'roles' => ['super_admin', 'editor'], 'also' => ['edit-page', 'homepage-builder']],
            ['page' => 'sliders', 'label' => 'Sliders', 'icon' => 'fa-images', 'roles' => ['super_admin', 'editor', 'marketing']],
            ['page' => 'landing-pages', 'label' => 'Landing Pages', 'icon' => 'fa-rocket', 'roles' => ['super_admin', 'editor'], 'also' => ['add-landing-page', 'edit-landing-page']],
            ['page' => 'blog-posts', 'label' => 'Blog', 'icon' => 'fa-blog', 'roles' => ['super_admin', 'editor'], 'also' => ['add-blog-post', 'edit-blog-post']],
            ['page' => 'menus', 'label' => 'Menus', 'icon' => 'fa-list', 'roles' => ['super_admin', 'editor']],
            ['page' => 'media', 'label' => 'Media Library', 'icon' => 'fa-photo-video', 'roles' => ['super_admin', 'editor']],
        ],
    ],
    'analytics' => [
        'label' => 'Analytics',
        'icon' => 'fa-chart-line',
        'roles' => ['super_admin', 'moderator', 'marketing'],
        'items' => [
            ['page' => 'google-dashboard', 'label' => 'Google Dashboard', 'icon' => 'fa-google', 'roles' => ['super_admin', 'moderator', 'marketing']],
            ['page' => 'insights', 'label' => 'Insights', 'icon' => 'fa-chart-pie', 'roles' => ['super_admin', 'moderator']],
            ['page' => 'reports', 'label' => 'Reports', 'icon' => 'fa-cloud-download', 'roles' => ['super_admin', 'moderator']],
            ['page' => 'tracking-settings', 'label' => 'Tracking & Pixels', 'icon' => 'fa-chart-line', 'roles' => ['super_admin']],
        ],
    ],
    'system' => [
        'label' => 'সিস্টেম',
        'icon' => 'fa-gear',
        'roles' => ['super_admin'],
        'items' => [
            ['page' => 'settings', 'label' => 'Settings', 'icon' => 'fa-sliders-h', 'roles' => ['super_admin']],
            ['page' => 'shipping', 'label' => 'Shipping', 'icon' => 'fa-truck', 'roles' => ['super_admin']],
            ['page' => 'payment-methods', 'label' => 'Payment Methods', 'icon' => 'fa-credit-card', 'roles' => ['super_admin']],
            ['page' => 'admins', 'label' => 'Manage Admins', 'icon' => 'fa-user-shield', 'roles' => ['super_admin'], 'also' => ['add-admin', 'edit-admin']],
            ['page' => 'profile', 'label' => 'প্রোফাইল', 'icon' => 'fa-user', 'roles' => ['super_admin', 'moderator', 'editor', 'marketing']],
        ],
    ],
];

function itemIsActive(array $item, string $current): bool {
    $pages = array_merge([$item['page']], $item['also'] ?? []);
    return in_array($current, $pages);
}

function groupHasActive(array $group, string $current): bool {
    foreach ($group['items'] as $item) {
        if (itemIsActive($item, $current)) return true;
    }
    return false;
}
?>
<nav class="sidebar" id="admin-sidebar">
    <div class="sidebar-header">
        <a href="index.php?page=dashboard" class="logo">
            <?php if ($logo_path): ?>
                <img src="../<?php echo htmlspecialchars($logo_path); ?>" alt="Logo" style="max-height:38px;border-radius:8px;">
            <?php else: ?>
                <div class="logo-icon"><i class="fas fa-shopping-cart text-white"></i></div>
            <?php endif; ?>
            <div class="logo-text">
                <span class="site-name d-block"><?php echo htmlspecialchars($site_name); ?></span>
                <span class="site-tag">Admin Panel</span>
            </div>
        </a>
    </div>

    <div class="sidebar-inner">
        <div class="admin-user-card">
            <div class="small text-white-50 mb-1">Signed in as</div>
            <div class="fw-bold text-white mb-2 text-truncate" style="font-size:0.85rem;"><?php echo htmlspecialchars($_SESSION['admin_email'] ?? ''); ?></div>
            <span class="role-badge"><?php echo ucfirst(str_replace('_', ' ', $role)); ?></span>
        </div>

        <div class="sidebar-search">
            <i class="fas fa-search"></i>
            <input type="text" id="sidebar-nav-search" placeholder="মেনু খুঁজুন..." autocomplete="off">
        </div>

        <ul class="nav flex-column px-2">
            <li class="nav-item mb-1">
                <a class="nav-link standalone <?php echo $currentPage === 'dashboard' ? 'active' : ''; ?>" href="index.php?page=dashboard">
                    <i class="fas fa-gauge-high"></i> ড্যাশবোর্ড
                </a>
            </li>
        </ul>

        <?php foreach ($navGroups as $groupId => $group):
            if (!canSee($role, $group['roles'])) continue;
            $visibleItems = array_filter($group['items'], fn($item) => canSee($role, $item['roles']));
            if (empty($visibleItems)) continue;
            $isOpen = groupHasActive($group, $currentPage);
        ?>
        <div class="nav-group <?php echo $isOpen ? 'open' : ''; ?>" data-group="<?php echo $groupId; ?>">
            <button type="button" class="nav-group-toggle" aria-expanded="<?php echo $isOpen ? 'true' : 'false'; ?>">
                <span><i class="fas <?php echo $group['icon']; ?> group-icon"></i><?php echo htmlspecialchars($group['label']); ?></span>
                <i class="fas fa-chevron-down chevron"></i>
            </button>
            <div class="nav-group-items">
                <ul class="nav flex-column">
                    <?php foreach ($visibleItems as $item): ?>
                    <li class="nav-item">
                        <a class="nav-link <?php echo itemIsActive($item, $currentPage) ? 'active' : ''; ?>" href="index.php?page=<?php echo htmlspecialchars($item['page']); ?>">
                            <i class="fas <?php echo $item['icon']; ?>"></i> <?php echo htmlspecialchars($item['label']); ?>
                        </a>
                    </li>
                    <?php endforeach; ?>
                </ul>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
</nav>
