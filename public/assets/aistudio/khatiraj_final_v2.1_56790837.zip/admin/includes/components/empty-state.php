<?php
function adminEmptyState(string $title, string $message, string $icon = 'fa-inbox', ?array $action = null): void {
    ?>
    <div class="empty-state">
        <div class="empty-icon"><i class="fas <?php echo htmlspecialchars($icon); ?>"></i></div>
        <h5><?php echo htmlspecialchars($title); ?></h5>
        <p><?php echo htmlspecialchars($message); ?></p>
        <?php if ($action): ?>
        <a href="<?php echo htmlspecialchars($action['url']); ?>" class="btn btn-primary btn-sm">
            <?php if (!empty($action['icon'])): ?><i class="fas <?php echo htmlspecialchars($action['icon']); ?> me-1"></i><?php endif; ?>
            <?php echo htmlspecialchars($action['label']); ?>
        </a>
        <?php endif; ?>
    </div>
    <?php
}
