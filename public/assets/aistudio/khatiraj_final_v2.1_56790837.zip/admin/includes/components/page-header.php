<?php
/**
 * Page Header Component
 */
function adminPageHeader(string $title, string $subtitle = '', array $actions = [], array $breadcrumbs = []): void {
    $page = $_GET['page'] ?? 'dashboard';
    ?>
    <?php if (!empty($breadcrumbs)): ?>
    <nav class="admin-breadcrumb mb-2" aria-label="breadcrumb">
        <a href="index.php?page=dashboard">ড্যাশবোর্ড</a>
        <?php foreach ($breadcrumbs as $i => $crumb): ?>
            <span class="mx-1">/</span>
            <?php if (!empty($crumb['url']) && $i < count($breadcrumbs) - 1): ?>
                <a href="<?php echo htmlspecialchars($crumb['url']); ?>"><?php echo htmlspecialchars($crumb['label']); ?></a>
            <?php else: ?>
                <span class="active"><?php echo htmlspecialchars($crumb['label']); ?></span>
            <?php endif; ?>
        <?php endforeach; ?>
    </nav>
    <?php endif; ?>
    <div class="admin-page-header">
        <div>
            <h1 class="page-title"><?php echo htmlspecialchars($title); ?></h1>
            <?php if ($subtitle): ?>
                <p class="page-subtitle"><?php echo htmlspecialchars($subtitle); ?></p>
            <?php endif; ?>
        </div>
        <?php if (!empty($actions)): ?>
        <div class="page-actions">
            <?php foreach ($actions as $action):
                $class = $action['class'] ?? 'btn btn-primary btn-sm';
                $icon = !empty($action['icon']) ? '<i class="fas ' . htmlspecialchars($action['icon']) . ' me-1"></i>' : '';
                $attrs = '';
                if (!empty($action['target'])) $attrs .= ' target="' . htmlspecialchars($action['target']) . '"';
                if (!empty($action['data-no-pjax'])) $attrs .= ' data-no-pjax';
                if (!empty($action['modal'])) $attrs .= ' data-bs-toggle="modal" data-bs-target="#' . htmlspecialchars($action['modal']) . '"';
            ?>
                <a href="<?php echo htmlspecialchars($action['url'] ?? '#'); ?>" class="<?php echo htmlspecialchars($class); ?>"<?php echo $attrs; ?>>
                    <?php echo $icon . htmlspecialchars($action['label']); ?>
                </a>
            <?php endforeach; ?>
        </div>
        <?php endif; ?>
    </div>
    <?php
}

function adminBreadcrumbMap(): array {
    return [
        'dashboard' => 'ড্যাশবোর্ড',
        'orders' => 'অর্ডার',
        'order-view' => 'অর্ডার বিস্তারিত',
        'edit-order' => 'অর্ডার সম্পাদনা',
        'abandoned-carts' => 'Abandoned Carts',
        'customers' => 'গ্রাহক',
        'reviews' => 'রিভিউ',
        'payment-transactions' => 'Transactions',
        'products' => 'পণ্য',
        'add-product' => 'নতুন পণ্য',
        'edit-product' => 'পণ্য সম্পাদনা',
        'categories' => 'ক্যাটাগরি',
        'coupons' => 'কুপন',
        'flash-sale' => 'Flash Sale',
        'page-manager' => 'Page Manager',
        'edit-page' => 'Page সম্পাদনা',
        'homepage-builder' => 'Homepage Builder',
        'sliders' => 'Sliders',
        'landing-pages' => 'Landing Pages',
        'blog-posts' => 'Blog',
        'menus' => 'Menus',
        'media' => 'Media Library',
        'google-dashboard' => 'Google Dashboard',
        'insights' => 'Insights',
        'reports' => 'Reports',
        'tracking-settings' => 'Tracking & Pixels',
        'settings' => 'Settings',
        'shipping' => 'Shipping',
        'payment-methods' => 'Payment Methods',
        'admins' => 'Manage Admins',
        'profile' => 'প্রোফাইল',
        'bulk-upload' => 'Bulk Upload',
    ];
}
