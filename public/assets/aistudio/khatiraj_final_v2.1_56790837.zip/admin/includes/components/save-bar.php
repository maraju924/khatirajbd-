<?php
/**
 * Sticky save bar for admin forms
 */
function adminSaveBar(string $label = 'সেভ করুন', string $icon = 'fa-save', string $extraClass = ''): void {
    ?>
    <div class="settings-save-bar admin-save-bar">
        <span class="settings-save-hint text-muted small d-none d-md-inline">পরিবর্তন সেভ করতে ক্লিক করুন</span>
        <button type="submit" class="btn btn-primary px-4 fw-semibold <?php echo htmlspecialchars($extraClass); ?>">
            <i class="fas <?php echo htmlspecialchars($icon); ?> me-2"></i><?php echo htmlspecialchars($label); ?>
        </button>
    </div>
    <?php
}
