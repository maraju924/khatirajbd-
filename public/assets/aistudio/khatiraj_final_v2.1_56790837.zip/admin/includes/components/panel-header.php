<?php
/**
 * Settings-style panel header
 * @param string $title
 * @param string $desc
 * @param string $icon Font Awesome class without "fas "
 * @param string $color green|blue|sky|amber|red
 */
function adminPanelHeader(string $title, string $desc = '', string $icon = 'fa-sliders-h', string $color = 'green'): void {
    ?>
    <div class="settings-panel-header admin-panel-header">
        <div class="settings-panel-icon admin-panel-icon <?php echo htmlspecialchars($color); ?>">
            <i class="fas <?php echo htmlspecialchars($icon); ?>"></i>
        </div>
        <div>
            <h2 class="settings-panel-title admin-panel-title"><?php echo htmlspecialchars($title); ?></h2>
            <?php if ($desc !== ''): ?>
            <p class="settings-panel-desc admin-panel-desc"><?php echo htmlspecialchars($desc); ?></p>
            <?php endif; ?>
        </div>
    </div>
    <?php
}
