<?php
function adminStatusBadge(string $status): string {
    $map = [
        'Pending' => 'pending', 'Processing' => 'processing', 'Shipped' => 'shipped',
        'Delivered' => 'delivered', 'Cancelled' => 'cancelled',
        'Active' => 'active', 'Inactive' => 'inactive', 'active' => 'active', 'inactive' => 'inactive',
        'published' => 'delivered', 'draft' => 'pending',
    ];
    $class = $map[$status] ?? 'inactive';
    return '<span class="status-badge ' . htmlspecialchars($class) . '">' . htmlspecialchars($status) . '</span>';
}
