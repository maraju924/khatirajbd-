<?php
function adminFlashMessages(): void {
    if (!empty($_GET['success'])): ?>
        <div class="admin-flash success"><i class="fas fa-check-circle"></i> <?php echo htmlspecialchars($_GET['success']); ?></div>
    <?php endif;
    if (!empty($_GET['error'])): ?>
        <div class="admin-flash error"><i class="fas fa-exclamation-circle"></i> <?php echo htmlspecialchars($_GET['error']); ?></div>
    <?php endif;
}

function adminToastContainer(): void {
    echo '<div class="admin-toast-container" id="adminToastContainer"></div>';
}
