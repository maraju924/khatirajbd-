<?php
function adminConfirmModal(string $id = 'confirmDeleteModal', string $title = 'নিশ্চিত করুন', string $message = 'আপনি কি এই আইটেমটি মুছে ফেলতে চান?'): void {
    ?>
    <div class="modal fade" id="<?php echo htmlspecialchars($id); ?>" tabindex="-1">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content border-0 shadow-lg rounded-4">
                <div class="modal-header border-0 pb-0">
                    <h5 class="modal-title fw-bold"><?php echo htmlspecialchars($title); ?></h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <p class="text-muted mb-0"><?php echo htmlspecialchars($message); ?></p>
                </div>
                <div class="modal-footer border-0 pt-0">
                    <button type="button" class="btn btn-light btn-sm" data-bs-dismiss="modal">বাতিল</button>
                    <button type="button" class="btn btn-danger btn-sm" id="<?php echo htmlspecialchars($id); ?>Confirm">হ্যাঁ, মুছুন</button>
                </div>
            </div>
        </div>
    </div>
    <?php
}
