<?php
/**
 * Admin UI Components — loader
 */
require_once __DIR__ . '/page-header.php';
require_once __DIR__ . '/stat-card.php';
require_once __DIR__ . '/empty-state.php';
require_once __DIR__ . '/status-badge.php';
require_once __DIR__ . '/confirm-modal.php';
require_once __DIR__ . '/toast-alert.php';
require_once __DIR__ . '/panel-header.php';
require_once __DIR__ . '/save-bar.php';
require_once __DIR__ . '/filter-bar.php';
