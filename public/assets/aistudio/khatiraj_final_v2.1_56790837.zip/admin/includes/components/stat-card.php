<?php
function adminStatCard(string $label, $value, string $icon = 'fa-chart-line', string $color = 'green', string $change = '', bool $changeUp = true): void {
    $changeClass = $changeUp ? 'up' : 'down';
    $changeIcon = $changeUp ? 'fa-arrow-up' : 'fa-arrow-down';
    ?>
    <div class="stat-card">
        <div class="d-flex justify-content-between align-items-start mb-3">
            <div class="stat-icon <?php echo htmlspecialchars($color); ?>">
                <i class="fas <?php echo htmlspecialchars($icon); ?>"></i>
            </div>
            <?php if ($change): ?>
            <span class="stat-change <?php echo $changeClass; ?>">
                <i class="fas <?php echo $changeIcon; ?> me-1"></i><?php echo htmlspecialchars($change); ?>
            </span>
            <?php endif; ?>
        </div>
        <div class="stat-label"><?php echo htmlspecialchars($label); ?></div>
        <div class="stat-value"><?php echo $value; ?></div>
    </div>
    <?php
}
