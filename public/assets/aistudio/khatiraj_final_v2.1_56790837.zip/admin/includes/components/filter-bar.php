<?php
/**
 * Shared list filter bar wrapper opener/closer helpers
 */
function adminFilterBarStart(string $action = '', string $method = 'GET'): void {
    $actionAttr = $action !== '' ? ' action="' . htmlspecialchars($action) . '"' : '';
    echo '<div class="admin-filter-bar"><form method="' . htmlspecialchars($method) . '"' . $actionAttr . ' class="admin-filter-form">';
}

function adminFilterBarEnd(): void {
    echo '</form></div>';
}

/**
 * Render a simple search + optional selects filter bar
 * @param array $fields [['type'=>'search'|'select'|'hidden', 'name'=>'', 'label'=>'', 'value'=>'', 'options'=>[value=>label], 'placeholder'=>'']]
 */
function adminFilterBar(array $fields, string $action = '', string $submitLabel = 'ফিল্টার'): void {
    adminFilterBarStart($action);
    echo '<div class="admin-filter-row">';
    foreach ($fields as $field) {
        $type = $field['type'] ?? 'text';
        $name = $field['name'] ?? '';
        $value = $field['value'] ?? '';
        if ($type === 'hidden') {
            echo '<input type="hidden" name="' . htmlspecialchars($name) . '" value="' . htmlspecialchars((string)$value) . '">';
            continue;
        }
        echo '<div class="admin-filter-field">';
        if (!empty($field['label'])) {
            echo '<label class="admin-filter-label">' . htmlspecialchars($field['label']) . '</label>';
        }
        if ($type === 'select') {
            echo '<select name="' . htmlspecialchars($name) . '" class="form-select form-select-sm">';
            foreach (($field['options'] ?? []) as $optVal => $optLabel) {
                $sel = ((string)$optVal === (string)$value) ? ' selected' : '';
                echo '<option value="' . htmlspecialchars((string)$optVal) . '"' . $sel . '>' . htmlspecialchars($optLabel) . '</option>';
            }
            echo '</select>';
        } else {
            $ph = $field['placeholder'] ?? '';
            echo '<input type="' . ($type === 'search' ? 'search' : 'text') . '" name="' . htmlspecialchars($name) . '" value="' . htmlspecialchars((string)$value) . '" class="form-control form-control-sm" placeholder="' . htmlspecialchars($ph) . '">';
        }
        echo '</div>';
    }
    echo '<div class="admin-filter-actions"><button type="submit" class="btn btn-primary btn-sm fw-semibold"><i class="fas fa-filter me-1"></i>' . htmlspecialchars($submitLabel) . '</button></div>';
    echo '</div>';
    adminFilterBarEnd();
}
