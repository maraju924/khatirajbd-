        </div> <!-- End of content-body-wrapper -->
    </div> <!-- End of #content -->
</div> <!-- End of #wrapper -->

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="js/admin-tabs.js?v=1"></script>
<script src="js/admin-ui.js?v=3"></script>
<?php include 'media-picker.php'; ?>
<script>
(function () {
    const csrfMeta = document.querySelector('meta[name="csrf-token"]');
    const csrfToken = csrfMeta ? csrfMeta.getAttribute('content') : '';
    if (!csrfToken) return;

    function ensureCsrfField(form) {
        if (!form || form.method.toUpperCase() === 'GET') return;
        let input = form.querySelector('input[name="csrf_token"]');
        if (!input) {
            input = document.createElement('input');
            input.type = 'hidden';
            input.name = 'csrf_token';
            form.appendChild(input);
        }
        input.value = csrfToken;
    }

    document.querySelectorAll('form').forEach(ensureCsrfField);
    document.addEventListener('submit', function (e) {
        if (e.target && e.target.tagName === 'FORM') {
            ensureCsrfField(e.target);
        }
    }, true);

    const originalFetch = window.fetch;
    window.fetch = function (input, init) {
        init = init || {};
        const method = (init.method || 'GET').toUpperCase();
        if (method !== 'GET' && method !== 'HEAD') {
            const headers = new Headers(init.headers || {});
            if (!headers.has('X-CSRF-TOKEN')) {
                headers.set('X-CSRF-TOKEN', csrfToken);
            }
            init.headers = headers;
            if (init.body instanceof FormData && !init.body.has('csrf_token')) {
                init.body.append('csrf_token', csrfToken);
            }
        }
        return originalFetch.call(this, input, init);
    };
})();
</script>
<script>
// Sidebar Toggle
document.addEventListener('click', function(e) {
    if (e.target.closest('#sidebar-toggle')) {
        document.querySelector('.sidebar').classList.toggle('active');
        document.getElementById('mobile-overlay').classList.toggle('active');
    }
    if (e.target.closest('#mobile-overlay')) {
        document.querySelector('.sidebar').classList.remove('active');
        document.getElementById('mobile-overlay').classList.remove('active');
    }
});

// Global Live Search
document.addEventListener('input', function(e) {
    if (e.target.id === 'global-search-input') {
        const searchInput = e.target;
        const resultsContainer = document.getElementById('search-results-container');
        const query = searchInput.value.trim();
        
        clearTimeout(window.searchTimeout);
        if (query.length < 2) {
            resultsContainer.classList.remove('active');
            return;
        }

        window.searchTimeout = setTimeout(() => {
            fetch(`actions/global-search.php?q=${encodeURIComponent(query)}`)
                .then(res => res.json())
                .then(data => {
                    resultsContainer.innerHTML = '';
                    if (data.length > 0) {
                        data.forEach(item => {
                            const div = document.createElement('a');
                            div.href = item.link;
                            div.className = 'search-item';
                            
                            let icon = 'fa-search';
                            if (item.type === 'Product') icon = 'fa-box';
                            if (item.type === 'Category') icon = 'fa-tags';
                            if (item.type === 'Order') icon = 'fa-receipt';

                            div.innerHTML = `
                                <div class="item-icon"><i class="fas ${icon}"></i></div>
                                <div class="item-info">
                                    <div class="item-title">${item.title}</div>
                                    <div class="item-subtitle">${item.subtitle}</div>
                                </div>
                                <div class="item-type">${item.type}</div>
                            `;
                            resultsContainer.appendChild(div);
                        });
                        resultsContainer.classList.add('active');
                    } else {
                        resultsContainer.innerHTML = '<div class="p-4 text-center text-muted small">No results found</div>';
                        resultsContainer.classList.add('active');
                    }
                });
        }, 300);
    }
});

document.addEventListener('click', function(e) {
    const resultsContainer = document.getElementById('search-results-container');
    const searchInput = document.getElementById('global-search-input');
    if (resultsContainer && searchInput && !searchInput.contains(e.target) && !resultsContainer.contains(e.target)) {
        resultsContainer.classList.remove('active');
    }
});

// --- SPA Logic Start ---
const spaLoader = document.getElementById('spa-loader');
const pjaxContainer = document.getElementById('pjax-container');

// Helper: Clean up all Bootstrap modals and their artifacts
function cleanupModals() {
    // Close all open Bootstrap modals properly
    document.querySelectorAll('.modal.show').forEach(modalEl => {
        const modalInstance = bootstrap.Modal.getInstance(modalEl);
        if (modalInstance) {
            modalInstance.hide();
            modalInstance.dispose();
        }
    });
    // Remove any leftover modal backdrops
    document.querySelectorAll('.modal-backdrop').forEach(el => el.remove());
    // Remove modal-related classes and styles from body
    document.body.classList.remove('modal-open');
    document.body.style.removeProperty('overflow');
    document.body.style.removeProperty('padding-right');
}

function loadPage(url, pushState = true) {
    // Clean up any open modals before loading new content
    cleanupModals();

    spaLoader.classList.add('active');
    spaLoader.classList.remove('finished');

    fetch(url, {
        headers: {
            'X-Requested-With': 'XMLHttpRequest'
        }
    })
    .then(response => {
        if (!response.ok) throw new Error('Network response was not ok');
        return response.text();
    })
    .then(html => {
        pjaxContainer.innerHTML = html;
        if (pushState) history.pushState({ url: url }, '', url);
        
        // Update Sidebar Active State
        const urlParams = new URLSearchParams(new URL(url, window.location.origin).search);
        const pageParam = urlParams.get('page') || 'dashboard';
        
        document.querySelectorAll('.sidebar .nav-link').forEach(link => {
            link.classList.remove('active');
            const linkUrl = new URL(link.getAttribute('href'), window.location.origin);
            if (linkUrl.searchParams.get('page') === pageParam) {
                link.classList.add('active');
                const group = link.closest('.nav-group');
                if (group) group.classList.add('open');
            }
        });

        // Try to update title if an H1 or H2 exists
        const pageTitle = pjaxContainer.querySelector('h1, h2')?.innerText;
        if (pageTitle) document.title = pageTitle + ' - Admin Dashboard';

        // Finalize Loader
        spaLoader.classList.add('finished');
        setTimeout(() => spaLoader.classList.remove('active', 'finished'), 500);

        // Re-execute scripts in the injected HTML (sequentially)
        const scripts = Array.from(pjaxContainer.querySelectorAll('script'));
        const executeScripts = async (index) => {
            if (index >= scripts.length) {
                // Manually trigger events for scripts expecting them
                // Must dispatch on 'document' because page scripts listen on 'document'
                document.dispatchEvent(new Event('DOMContentLoaded'));
                window.dispatchEvent(new CustomEvent('pjax:complete'));
                return;
            }

            const oldScript = scripts[index];
            const newScript = document.createElement('script');
            
            // Copy attributes
            Array.from(oldScript.attributes).forEach(attr => newScript.setAttribute(attr.name, attr.value));
            
            if (oldScript.src) {
                // External script: wait for it to load
                newScript.onload = () => executeScripts(index + 1);
                newScript.onerror = () => executeScripts(index + 1);
                document.head.appendChild(newScript);
            } else {
                // Inline script: execute immediately and move to next
                newScript.textContent = oldScript.textContent;
                document.head.appendChild(newScript);
                executeScripts(index + 1);
            }
            
            // Remove old script from the container to avoid double execution or clutter
            oldScript.parentNode.removeChild(oldScript);
        };
        
        executeScripts(0);

        // Close mobile sidebar if open
        document.querySelector('.sidebar').classList.remove('active');
        document.getElementById('mobile-overlay').classList.remove('active');

        // Scroll to top
        window.scrollTo(0, 0);
    })
    .catch(error => {
        console.error('SPA Error:', error);
        window.location.href = url; // Fallback to normal load
    });
}

// Intercept Link Clicks
document.addEventListener('click', function(e) {
    const link = e.target.closest('a');
    if (!link) return;

    const href = link.getAttribute('href');
    if (!href || href.startsWith('http') || href.startsWith('#') || href.includes('logout.php') || link.getAttribute('target') === '_blank' || link.hasAttribute('data-no-pjax')) {
        return;
    }

    // Only handle internal index.php links
    if (href.includes('index.php')) {
        e.preventDefault();
        loadPage(href);
    }
});

// Intercept Form Submissions
document.addEventListener('submit', function(e) {
    const form = e.target;
    if (form.hasAttribute('data-no-pjax') || form.getAttribute('method')?.toUpperCase() !== 'POST') return;
    
    const action = form.getAttribute('action');
    const isInternal = !action || action === '' || action === 'index.php' || action.startsWith('?') || action.startsWith('actions/') || action.startsWith('pages/');
    
    if (isInternal) {
        e.preventDefault();
        
        // Capture the clicked submit button (e.submitter) for its name/value
        const submitBtn = e.submitter || form.querySelector('[type="submit"]');
        const originalBtnHtml = submitBtn ? submitBtn.innerHTML : '';
        if (submitBtn) {
            submitBtn.disabled = true;
            submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin me-1"></i> Processing...';
        }

        spaLoader.classList.add('active');
        const formData = new FormData(form);

        // Append the submit button's name/value to FormData (FormData doesn't include it automatically)
        if (submitBtn && submitBtn.name && submitBtn.value) {
            formData.append(submitBtn.name, submitBtn.value);
        }

        const url = action || window.location.href;

        fetch(url, {
            method: 'POST',
            body: formData,
            headers: { 'X-Requested-With': 'XMLHttpRequest' }
        })
        .then(res => {
            if (res.redirected) {
                cleanupModals();
                loadPage(res.url);
                return null;
            }
            return res.text();
        })
        .then(html => {
            if (html === null) return;

            try {
                // Try parsing as JSON first
                const data = JSON.parse(html);
                if (data.success || data.status === 'success') {
                    const successMsg = data.message || 'Action completed successfully';
                    // Build a clean reload URL (strip old success/error params to avoid accumulation)
                    const reloadUrl = new URL(window.location.href);
                    reloadUrl.searchParams.delete('success');
                    reloadUrl.searchParams.delete('error');
                    reloadUrl.searchParams.set('success', successMsg);
                    // Clean up modals before navigating
                    cleanupModals();
                    loadPage(reloadUrl.toString());
                } else {
                    alert('Error: ' + (data.message || 'Something went wrong'));
                    if (submitBtn) {
                        submitBtn.disabled = false;
                        submitBtn.innerHTML = originalBtnHtml;
                    }
                    spaLoader.classList.remove('active');
                }
            } catch (e) {
                // Not JSON, assume HTML
                if (html.includes('<script>window.location') || html.includes('loadPage(')) {
                    // Extract URL and load it
                    const match = html.match(/href=['"]([^'"]+)['"]/);
                    const spaMatch = html.match(/loadPage\(['"]([^'"]+)['"]\)/);
                    if (spaMatch) loadPage(spaMatch[1]);
                    else if (match) loadPage(match[1]);
                } else {
                    pjaxContainer.innerHTML = html;
                    spaLoader.classList.add('finished');
                    setTimeout(() => spaLoader.classList.remove('active', 'finished'), 500);
                }
            }
        })
        .catch(err => {
            console.error('Form Submit Error:', err);
            if (submitBtn) {
                submitBtn.disabled = false;
                submitBtn.innerHTML = originalBtnHtml;
            }
            spaLoader.classList.remove('active');
        });
    }
});

// Handle Back/Forward Buttons
window.addEventListener('popstate', function(e) {
    if (e.state && e.state.url) {
        loadPage(e.state.url, false);
    } else {
        location.reload();
    }
});
// --- SPA Logic End ---
</script>
</body>
</html>
