<?php
require_once __DIR__ . '/components/init.php';

$currentPage = $_GET['page'] ?? 'dashboard';
$breadcrumbMap = adminBreadcrumbMap();
$currentLabel = $breadcrumbMap[$currentPage] ?? ucfirst(str_replace('-', ' ', $currentPage));

// Real pending orders count
$pendingOrdersCount = 0;
try {
    $pendingOrdersCount = (int) $pdo->query("SELECT COUNT(*) FROM orders WHERE order_status = 'Pending'")->fetchColumn();
} catch (Exception $e) {}

$storeUrl = '../';
if (defined('BASE_URL')) {
    $storeUrl = (defined('SITE_URL') ? SITE_URL : '..') . BASE_URL . '/';
}
?>
<!DOCTYPE html>
<html lang="bn">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($currentLabel); ?> - Admin</title>
    <meta name="csrf-token" content="<?php echo htmlspecialchars(CsrfHelper::token(), ENT_QUOTES, 'UTF-8'); ?>">
    <link rel="icon" type="image/png" href="../assets/images/icons/khatiraj logo.webp">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css">
    <link rel="stylesheet" href="css/admin.css?v=7">
    <link rel="stylesheet" href="css/admin-components.css?v=8">
    <?php if ($currentPage === 'edit-page'): ?>
    <link rel="stylesheet" href="css/page-builder.css?v=3" id="pb-builder-css">
    <?php endif; ?>
</head>
<body>
<div id="spa-loader"></div>
<?php adminToastContainer(); ?>
<div id="wrapper">
    <div class="mobile-overlay" id="mobile-overlay"></div>

    <div id="content">
        <header class="top-navbar">
            <div class="d-flex align-items-center flex-grow-1 gap-2">
                <button class="sidebar-toggle" id="sidebar-toggle" aria-label="Toggle sidebar">
                    <i class="fas fa-bars"></i>
                </button>
                <nav class="admin-breadcrumb d-none d-md-block mb-0">
                    <a href="index.php?page=dashboard">ড্যাশবোর্ড</a>
                    <?php if ($currentPage !== 'dashboard'): ?>
                        <span class="mx-1">/</span>
                        <span class="active"><?php echo htmlspecialchars($currentLabel); ?></span>
                    <?php endif; ?>
                </nav>
                <div class="search-wrapper ms-md-3">
                    <div class="search-box">
                        <i class="fas fa-search text-muted"></i>
                        <input type="text" id="global-search-input" placeholder="পণ্য, অর্ডার, ক্যাটাগরি খুঁজুন..." autocomplete="off">
                    </div>
                    <div id="search-results-container" class="search-results"></div>
                </div>
            </div>

            <div class="navbar-actions">
                <a href="<?php echo htmlspecialchars($storeUrl); ?>" class="btn-view-store" target="_blank" data-no-pjax>
                    <i class="fas fa-external-link-alt"></i>
                    <span>View Store</span>
                </a>
                <?php if ($pendingOrdersCount > 0): ?>
                <a href="index.php?page=orders&status=Pending" class="nav-icon-btn" title="Pending Orders">
                    <i class="far fa-bell"></i>
                    <span class="badge-count"><?php echo $pendingOrdersCount > 99 ? '99+' : $pendingOrdersCount; ?></span>
                </a>
                <?php else: ?>
                <span class="nav-icon-btn" title="Notifications"><i class="far fa-bell"></i></span>
                <?php endif; ?>
                <div class="dropdown">
                    <div class="user-profile" data-bs-toggle="dropdown" aria-expanded="false">
                        <div class="text-end d-none d-md-block">
                            <div class="fw-bold lh-1" style="font-size:0.85rem;"><?php echo htmlspecialchars($_SESSION['admin_name'] ?? 'Admin'); ?></div>
                            <small class="text-muted"><?php echo ucfirst(str_replace('_', ' ', $_SESSION['admin_role'] ?? 'Admin')); ?></small>
                        </div>
                        <img src="https://ui-avatars.com/api/?name=<?php echo urlencode($_SESSION['admin_name'] ?? 'Admin'); ?>&background=15803d&color=fff" alt="Admin">
                    </div>
                    <ul class="dropdown-menu dropdown-menu-end border-0 shadow-lg rounded-4 overflow-hidden p-0" style="min-width:220px;">
                        <div class="p-3 bg-light border-bottom">
                            <div class="fw-bold text-dark"><?php echo htmlspecialchars($_SESSION['admin_name'] ?? 'Admin'); ?></div>
                            <div class="small text-muted text-truncate"><?php echo htmlspecialchars($_SESSION['admin_email'] ?? ''); ?></div>
                        </div>
                        <li><a class="dropdown-item py-2 px-3" href="index.php?page=profile"><i class="fas fa-user me-2 text-primary"></i> প্রোফাইল</a></li>
                        <?php if (($_SESSION['admin_role'] ?? '') === 'super_admin'): ?>
                        <li><a class="dropdown-item py-2 px-3" href="index.php?page=settings"><i class="fas fa-sliders-h me-2 text-info"></i> Settings</a></li>
                        <?php endif; ?>
                        <li><hr class="dropdown-divider my-0"></li>
                        <li><a class="dropdown-item py-2 px-3 text-danger" href="logout.php" data-no-pjax><i class="fas fa-sign-out-alt me-2"></i> Logout</a></li>
                    </ul>
                </div>
            </div>
        </header>

        <div class="p-4 p-md-4 content-body-wrapper">
