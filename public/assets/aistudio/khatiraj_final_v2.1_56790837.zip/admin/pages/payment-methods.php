<?php
// admin/pages/payment-methods.php
// Payment Methods Management

require_once '../app/Services/PaymentGateway.php';
$paymentGateway = new PaymentGateway($pdo);
$methods = $paymentGateway->getPaymentMethods(null, false);

$mobile_count = count(array_filter($methods, fn($m) => $m['type'] === 'mobile_banking'));
$bank_count = count(array_filter($methods, fn($m) => $m['type'] === 'bank_transfer'));
$active_count = count(array_filter($methods, fn($m) => $m['is_active']));
?>

<?php adminFlashMessages(); ?>
<?php adminPageHeader('Payment Methods', 'পেমেন্ট মেথড কনফিগার ও ম্যানেজ করুন', [
    ['label' => 'নতুন Method', 'icon' => 'fa-plus', 'url' => '#', 'class' => 'btn btn-primary btn-sm', 'modal' => 'addModal'],
]); ?>

<div class="admin-kpi-row row g-3">
    <div class="col-md-4"><?php adminStatCard('Mobile Banking', $mobile_count, 'fa-mobile-alt', 'blue'); ?></div>
    <div class="col-md-4"><?php adminStatCard('Bank Transfer', $bank_count, 'fa-university', 'green'); ?></div>
    <div class="col-md-4"><?php adminStatCard('Active Methods', $active_count, 'fa-check-circle', 'sky'); ?></div>
</div>

<div class="settings-layout admin-shell">
    <div class="settings-content">
        <section class="settings-panel admin-panel is-active" id="pm-methods" role="tabpanel">
            <?php adminPanelHeader('Payment Methods', 'সব পেমেন্ট মেথডের তালিকা ও কনফিগারেশন', 'fa-credit-card', 'blue'); ?>
            <div class="settings-panel-body admin-panel-body pt-3">
                <div class="admin-list-shell">
                    <div class="admin-list-shell-header">
                        <h3 class="admin-list-shell-title"><i class="fas fa-list me-2 text-muted"></i>Methods List</h3>
                        <button type="button" class="btn btn-primary btn-sm" data-bs-toggle="modal" data-bs-target="#addModal">
                            <i class="fas fa-plus me-1"></i> Add Method
                        </button>
                    </div>
                    <div class="admin-table-wrap">
                        <table class="admin-table admin-table-mobile-cards">
                            <thead>
                                <tr>
                                    <th scope="col">#</th>
                                    <th scope="col">Method</th>
                                    <th scope="col">Type</th>
                                    <th scope="col">Account Number</th>
                                    <th scope="col">Charge</th>
                                    <th scope="col">Status</th>
                                    <th scope="col" class="text-end">Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if (empty($methods)): ?>
                                    <tr><td colspan="7"><?php adminEmptyState('কোনো Payment Method নেই', 'প্রথম পেমেন্ট মেথড যোগ করুন', 'fa-credit-card', ['label' => 'Add Method', 'url' => '#', 'icon' => 'fa-plus']); ?></td></tr>
                                <?php else: ?>
                                <?php foreach ($methods as $method): ?>
                                <tr>
                                    <td class="ps-4 text-muted"><?php echo $method['id']; ?></td>
                                    <td>
                                        <div class="d-flex align-items-center gap-2">
                                            <div class="rounded p-2 bg-light" style="width: 45px; height: 45px; display: flex; align-items: center; justify-content: center;">
                                                <?php
                                                    $logo_src = $method['logo'] ?? 'default.png';
                                                    if (!filter_var($logo_src, FILTER_VALIDATE_URL)) {
                                                        $logo_src = '../assets/images/payments/' . $logo_src;
                                                    }
                                                ?>
                                                <img src="<?php echo $logo_src; ?>"
                                                     alt="<?php echo htmlspecialchars($method['name']); ?>"
                                                     style="max-width: 35px; max-height: 35px;"
                                                     onerror="this.src='https://via.placeholder.com/35?text=<?php echo strtoupper(substr($method['name'], 0, 1)); ?>'">
                                            </div>
                                            <div>
                                                <div class="fw-bold"><?php echo htmlspecialchars($method['name']); ?></div>
                                                <small class="text-muted"><?php echo $method['slug']; ?></small>
                                            </div>
                                        </div>
                                    </td>
                                    <td>
                                        <span class="badge rounded-pill <?php
                                            if ($method['type'] === 'mobile_banking') echo 'bg-primary';
                                            elseif ($method['type'] === 'payment_gateway') echo 'bg-warning text-dark';
                                            else echo 'bg-info';
                                        ?>">
                                            <?php echo ucwords(str_replace('_', ' ', $method['type'])); ?>
                                        </span>
                                    </td>
                                    <td>
                                        <code class="text-dark"><?php echo htmlspecialchars($method['account_number'] ?? 'Not Set'); ?></code>
                                    </td>
                                    <td>
                                        <?php if ($method['charge_amount'] > 0): ?>
                                            <?php echo $method['charge_type'] === 'percentage' ? $method['charge_amount'] . '%' : '৳' . $method['charge_amount']; ?>
                                        <?php else: ?>
                                            <span class="text-muted">Free</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <form action="actions/payment-methods-save.php" method="POST" class="d-inline">
                                            <input type="hidden" name="action" value="toggle">
                                            <input type="hidden" name="id" value="<?php echo $method['id']; ?>">
                                            <button type="submit" class="btn btn-sm btn-link p-0 text-decoration-none">
                                                <?php echo $method['is_active'] ? adminStatusBadge('Active') : adminStatusBadge('Inactive'); ?>
                                            </button>
                                        </form>
                                    </td>
                                    <td class="text-end pe-4">
                                        <div class="btn-group">
                                            <button type="button" class="btn btn-sm btn-outline-primary rounded-start-pill"
                                                    data-bs-toggle="modal"
                                                    data-bs-target="#editModal<?php echo $method['id']; ?>">
                                                <i class="fas fa-edit"></i> Edit
                                            </button>
                                            <form action="actions/payment-methods-save.php" method="POST" class="d-inline"
                                                  onsubmit="return confirm('Are you sure you want to delete this payment method?')">
                                                <input type="hidden" name="action" value="delete">
                                                <input type="hidden" name="id" value="<?php echo $method['id']; ?>">
                                                <button type="submit" class="btn btn-sm btn-outline-danger rounded-end-pill">
                                                    <i class="fas fa-trash"></i>
                                                </button>
                                            </form>
                                        </div>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </section>
    </div>
</div>

<!-- Edit Modals -->
<?php foreach ($methods as $method):
    $creds = json_decode($method['credentials'] ?? '{}', true) ?: [];
?>
<div class="modal fade" id="editModal<?php echo $method['id']; ?>" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content border-0 rounded-4">
            <div class="modal-header border-0 pb-0">
                <h5 class="modal-title fw-bold">
                    <i class="fas fa-edit text-primary me-2"></i>Edit <?php echo htmlspecialchars($method['name']); ?>
                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form action="actions/payment-methods-save.php" method="POST">
                <input type="hidden" name="action" value="update">
                <input type="hidden" name="id" value="<?php echo $method['id']; ?>">
                <div class="modal-body pt-3">
                    <?php if ($method['type'] === 'payment_gateway'): ?>
                    <!-- Zinipay / Automated Gateway Settings -->
                    <div class="alert alert-info border-0 rounded-3 py-2 px-3 mb-3">
                        <i class="fas fa-bolt me-1"></i> <strong>Automated Payment Gateway</strong> — Payments are processed automatically via API.
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-bold"><i class="fas fa-key text-warning me-1"></i> API Key</label>
                        <input type="text" class="form-control rounded-3" name="api_key"
                               value="<?php echo htmlspecialchars($creds['api_key'] ?? ''); ?>"
                               placeholder="Enter your Zinipay API Key">
                        <div class="form-text">Get your API key from <a href="https://dash.zinipay.com" target="_blank">dash.zinipay.com</a></div>
                    </div>
                    <?php endif; ?>
                    <div class="mb-3">
                        <label class="form-label fw-bold">Account Number / Merchant ID</label>
                        <input type="text" class="form-control rounded-3" name="account_number"
                               value="<?php echo htmlspecialchars($method['account_number'] ?? ''); ?>"
                               placeholder="01XXXXXXXXX">
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-bold">Account Name (Optional)</label>
                        <input type="text" class="form-control rounded-3" name="account_name"
                               value="<?php echo htmlspecialchars($method['account_name'] ?? ''); ?>"
                               placeholder="Account holder name">
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-bold">Logo (Image filename or URL)</label>
                        <div class="input-group">
                            <input type="text" class="form-control rounded-start-3" name="logo" id="edit_logo_<?php echo $method['id']; ?>"
                                   value="<?php echo htmlspecialchars($method['logo'] ?? ''); ?>"
                                   placeholder="e.g. bkash.png or URL">
                            <button class="btn btn-outline-secondary rounded-end-3" type="button" onclick="openMediaPicker('edit_logo_<?php echo $method['id']; ?>')">
                                <i class="fas fa-images"></i>
                            </button>
                        </div>
                    </div>
                    <div class="row mb-3">
                        <div class="col-6">
                            <label class="form-label fw-bold">Charge Type</label>
                            <select name="charge_type" class="form-select rounded-3">
                                <option value="fixed" <?php echo $method['charge_type'] === 'fixed' ? 'selected' : ''; ?>>Fixed Amount</option>
                                <option value="percentage" <?php echo $method['charge_type'] === 'percentage' ? 'selected' : ''; ?>>Percentage</option>
                            </select>
                        </div>
                        <div class="col-6">
                            <label class="form-label fw-bold">Charge Amount</label>
                            <input type="number" step="0.01" class="form-control rounded-3" name="charge_amount"
                                   value="<?php echo $method['charge_amount']; ?>">
                        </div>
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-bold">Instructions (Bangla)</label>
                        <textarea class="form-control rounded-3" name="instructions" rows="3"><?php echo htmlspecialchars($method['instructions'] ?? ''); ?></textarea>
                    </div>
                </div>
                <div class="modal-footer border-0 pt-0">
                    <button type="button" class="btn btn-light rounded-pill px-4" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary rounded-pill px-4">
                        <i class="fas fa-save me-2"></i>Save Changes
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php endforeach; ?>

<!-- Add Modal -->
<div class="modal fade" id="addModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content border-0 rounded-4">
            <div class="modal-header border-0 pb-0">
                <h5 class="modal-title fw-bold">
                    <i class="fas fa-plus-circle text-primary me-2"></i>Add New Payment Method
                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form action="actions/payment-methods-save.php" method="POST">
                <input type="hidden" name="action" value="add">
                <div class="modal-body pt-3">
                    <div class="mb-3">
                        <label class="form-label fw-bold">Method Name</label>
                        <input type="text" class="form-control rounded-3" name="name" required placeholder="e.g. bKash Personal">
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-bold">Slug (Internal ID)</label>
                        <input type="text" class="form-control rounded-3" name="slug" required placeholder="e.g. bkash_personal">
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-bold">Type</label>
                        <select name="type" class="form-select rounded-3" id="addMethodType" onchange="toggleApiKeyField()">
                            <option value="mobile_banking">Mobile Banking</option>
                            <option value="bank_transfer">Bank Transfer</option>
                            <option value="payment_gateway">Payment Gateway (Automated)</option>
                        </select>
                    </div>
                    <div class="mb-3 d-none" id="addApiKeyField">
                        <label class="form-label fw-bold"><i class="fas fa-key text-warning me-1"></i> API Key</label>
                        <input type="text" class="form-control rounded-3" name="api_key" placeholder="Enter API Key (e.g. Zinipay API Key)">
                        <div class="form-text">Required for automated payment gateways like Zinipay</div>
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-bold">Account Number</label>
                        <input type="text" class="form-control rounded-3" name="account_number" placeholder="01XXXXXXXXX">
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-bold">Logo URL / Filename</label>
                        <div class="input-group">
                            <input type="text" class="form-control rounded-start-3" name="logo" id="add_logo_input" placeholder="e.g. bkash.png or URL">
                            <button class="btn btn-outline-secondary rounded-end-3" type="button" onclick="openMediaPicker('add_logo_input')">
                                <i class="fas fa-images"></i>
                            </button>
                        </div>
                    </div>
                    <div class="row mb-3">
                        <div class="col-6">
                            <label class="form-label fw-bold">Charge Type</label>
                            <select name="charge_type" class="form-select rounded-3">
                                <option value="fixed">Fixed</option>
                                <option value="percentage">Percentage</option>
                            </select>
                        </div>
                        <div class="col-6">
                            <label class="form-label fw-bold">Charge Amount</label>
                            <input type="number" step="0.01" class="form-control rounded-3" name="charge_amount" value="0">
                        </div>
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-bold">Instructions (Bangla)</label>
                        <textarea class="form-control rounded-3" name="instructions" rows="2" placeholder="পেমেন্ট করার নিয়মাবলী..."></textarea>
                    </div>
                </div>
                <div class="modal-footer border-0 pt-0">
                    <button type="button" class="btn btn-light rounded-pill px-4" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary rounded-pill px-4">
                        <i class="fas fa-save me-2"></i>Add Method
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Media Picker Modal -->
<div class="modal fade" id="mediaPickerModal" tabindex="-1" style="z-index: 1060;">
    <div class="modal-dialog modal-lg modal-dialog-centered">
        <div class="modal-content border-0 shadow-lg rounded-4">
            <div class="modal-header border-0 pb-0">
                <h5 class="modal-title fw-bold"><i class="fas fa-images text-primary me-2"></i>Select Media</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <div id="media-list" class="row g-2 overflow-auto" style="max-height: 400px;">
                    <div class="col-12 text-center py-4">
                        <div class="spinner-border text-primary" role="status"></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
let targetInputId = '';

function openMediaPicker(inputId) {
    targetInputId = inputId;
    const modal = new bootstrap.Modal(document.getElementById('mediaPickerModal'));
    modal.show();

    fetch('actions/media-api.php')
        .then(res => res.json())
        .then(data => {
            const container = document.getElementById('media-list');
            container.innerHTML = '';

            data.forEach(file => {
                const div = document.createElement('div');
                div.className = 'col-4 col-md-3 col-lg-2';
                div.innerHTML = `
                    <div class="card h-100 border-0 shadow-sm media-select-card" onclick="selectMedia('${file.path}')" style="cursor: pointer; transition: 0.2s;">
                        <img src="../${file.path}" class="card-img-top" style="height: 80px; object-fit: cover;">
                        <div class="card-body p-1 text-center">
                            <small class="text-truncate d-block" style="font-size: 0.7rem;">${file.name}</small>
                        </div>
                    </div>
                `;
                container.appendChild(div);
            });
        });
}

function selectMedia(path) {
    document.getElementById(targetInputId).value = path;
    const modalEl = document.getElementById('mediaPickerModal');
    const modal = bootstrap.Modal.getInstance(modalEl);
    if (modal) modal.hide();
}

function toggleApiKeyField() {
    const typeSelect = document.getElementById('addMethodType');
    const apiKeyField = document.getElementById('addApiKeyField');
    if (typeSelect.value === 'payment_gateway') {
        apiKeyField.classList.remove('d-none');
    } else {
        apiKeyField.classList.add('d-none');
    }
}
</script>

<style>
.media-select-card { border: 2px solid transparent !important; }
.media-select-card:hover { transform: scale(1.05); border-color: var(--bs-primary) !important; box-shadow: 0 5px 15px rgba(0,0,0,0.1) !important; }
</style>
