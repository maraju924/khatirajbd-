<?php
// admin/pages/google-dashboard.php

// Fetch tracking settings
$tracking = [];
try {
    $stmt = $pdo->query("SELECT * FROM tracking_settings WHERE id = 1");
    $tracking = $stmt->fetch(PDO::FETCH_ASSOC) ?: [];
} catch (PDOException $e) {
    //
}

$embed_url = $tracking['google_search_console_embed'] ?? '';
?>

<?php adminFlashMessages(); ?>
<?php
$headerActions = $embed_url ? [
    ['label' => 'Embed সেটআপ', 'icon' => 'fa-cog', 'url' => 'index.php?page=tracking-settings', 'class' => 'btn btn-outline-primary btn-sm'],
    ['label' => 'Search Console', 'icon' => 'fa-external-link-alt', 'url' => 'https://search.google.com/search-console', 'class' => 'btn btn-outline-secondary btn-sm', 'target' => '_blank', 'data-no-pjax' => true],
] : [
    ['label' => 'Tracking Settings', 'icon' => 'fa-sliders-h', 'url' => 'index.php?page=tracking-settings', 'class' => 'btn btn-primary btn-sm'],
];
adminPageHeader('Google Dashboard', 'Search Console ও Analytics রিপোর্ট দেখুন', $headerActions);
?>

<?php if (!$embed_url): ?>
    <div class="admin-list-shell">
        <div class="admin-list-shell-header">
            <h2 class="admin-list-shell-title">Setup required</h2>
        </div>
        <div class="p-4 text-center">
            <?php adminEmptyState('Google Dashboard কনফিগার করা হয়নি', 'Looker Studio embed URL সেট করলে Search Console ও Analytics ডেটা এখানে দেখা যাবে', 'fa-google', ['label' => 'Tracking Settings', 'url' => 'index.php?page=tracking-settings', 'icon' => 'fa-sliders-h']); ?>

            <div class="mt-4 border p-4 rounded-3 text-start mx-auto" style="max-width: 600px; background:#f8fafc; border-color:#e2e8f0 !important;">
                <h5 class="fw-bold mb-3"><i class="fas fa-info-circle text-success me-2"></i>How to Setup:</h5>
                <ol class="mb-0 ps-3 text-secondary" style="font-size: 0.9rem;">
                    <li class="mb-2">Go to <a href="https://lookerstudio.google.com/" target="_blank" class="fw-bold">Google Looker Studio <i class="fas fa-external-link-alt small"></i></a>.</li>
                    <li class="mb-2">Create a new report using <strong>Search Console</strong> or <strong>Google Analytics</strong> as the data source (Google provides ready-made templates for GSC & GA).</li>
                    <li class="mb-2">Once the report is ready, click on <strong>Share</strong> (top right) -> <strong>Embed report</strong>.</li>
                    <li class="mb-2">Enable embedding, check "Embed URL" (or copy the URL from the iframe src attribute), and copy that link.</li>
                    <li class="mb-2">Go to <strong>Tracking & Pixels</strong> and paste that link in the <strong>Looker Studio / Search Console Dashboard Embed URL</strong> field.</li>
                </ol>
            </div>
        </div>
    </div>
<?php else: ?>
    <div class="admin-list-shell overflow-hidden">
        <div class="admin-list-shell-header">
            <h2 class="admin-list-shell-title"><i class="fab fa-google me-2 text-success"></i>Embedded Report</h2>
            <a href="index.php?page=tracking-settings" class="btn btn-sm btn-outline-secondary">Change embed</a>
        </div>
        <div class="ratio ratio-16x9" style="min-height: 700px; height: calc(100vh - 220px);">
            <iframe src="<?php echo htmlspecialchars($embed_url); ?>"
                    frameborder="0"
                    style="border:0;"
                    allowfullscreen
                    sandbox="allow-storage-access-by-user-activation allow-scripts allow-same-origin allow-popups allow-popups-to-escape-sandbox"></iframe>
        </div>
    </div>
<?php endif; ?>
