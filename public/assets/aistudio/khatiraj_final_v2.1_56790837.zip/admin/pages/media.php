<?php
// admin/pages/media.php

$base_dir = "../uploads/";
$all_files = [];

if (is_dir($base_dir)) {
    $iterator = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($base_dir));
    foreach ($iterator as $file) {
        if ($file->isFile()) {
            $filename = $file->getFilename();
            $ext = strtolower(pathinfo($filename, PATHINFO_EXTENSION));
            $allowed = ['jpg', 'jpeg', 'png', 'gif', 'webp', 'svg'];
            
            if (in_array($ext, $allowed)) {
                $full_path = str_replace('\\', '/', $file->getRealPath());
                $project_root = str_replace('\\', '/', realpath('../'));
                $relative_path = ltrim(str_replace($project_root, '', $full_path), '/');
                
                // Fetch Meta from DB
                $stmt = $pdo->prepare("SELECT * FROM media_metadata WHERE file_path = ?");
                $stmt->execute([$relative_path]);
                $meta = $stmt->fetch();

                $folder = basename(dirname($full_path));

                $all_files[] = [
                    'name' => $filename,
                    'path' => $relative_path,
                    'folder' => $folder,
                    'size' => $file->getSize(),
                    'time' => $file->getMTime(),
                    'alt_text' => $meta['alt_text'] ?? '',
                    'title_text' => $meta['title_text'] ?? ''
                ];
            }
        }
    }
}

// Sort by time descending
usort($all_files, function($a, $b) {
    return $b['time'] - $a['time'];
});
?>

<?php adminFlashMessages(); ?>
<?php adminPageHeader('Media Library', 'ছবি আপলোড, SEO meta ও ফাইল ম্যানেজ করুন', [
    ['label' => 'আপলোড', 'icon' => 'fa-upload', 'url' => '#', 'class' => 'btn btn-primary btn-sm', 'modal' => 'uploadMediaModal'],
]); ?>

<div class="admin-list-shell">
    <div class="admin-list-shell-header">
        <h2 class="admin-list-shell-title">All Media</h2>
        <span class="text-muted small fw-semibold"><?php echo number_format(count($all_files)); ?> files</span>
    </div>
    <?php if (empty($all_files)): ?>
        <div class="p-4">
            <?php adminEmptyState('কোনো মিডিয়া ফাইল নেই', 'উপরের "আপলোড" বাটন থেকে ছবি যোগ করুন', 'fa-images'); ?>
        </div>
    <?php else: ?>
        <div class="admin-media-grid">
            <?php foreach ($all_files as $file): ?>
                <div class="admin-media-card media-card">
                    <img src="../<?php echo htmlspecialchars($file['path']); ?>" alt="<?php echo htmlspecialchars($file['alt_text']); ?>">
                    <div class="admin-media-card-body">
                        <small class="text-truncate d-block fw-bold" title="<?php echo htmlspecialchars($file['name']); ?>"><?php echo htmlspecialchars($file['name']); ?></small>
                        <div class="mt-1 mb-2">
                            <?php if ($file['alt_text']): ?>
                                <span class="badge bg-success" style="font-size: 0.6rem;">SEO OK</span>
                            <?php else: ?>
                                <span class="badge bg-warning text-dark" style="font-size: 0.6rem;">NO ALT</span>
                            <?php endif; ?>
                        </div>
                        <div class="d-flex justify-content-between align-items-center">
                            <span class="badge bg-light text-dark small" style="font-size: 0.6rem;"><?php echo strtoupper(htmlspecialchars($file['folder'])); ?></span>
                            <div class="btn-group">
                                <button type="button" class="btn btn-sm btn-outline-success media-copy-link"
                                        data-url="<?php echo htmlspecialchars(SITE_URL . '/' . $file['path']); ?>"
                                        title="Copy Link">
                                    <i class="fas fa-link"></i>
                                </button>
                                <button type="button" class="btn btn-sm btn-outline-primary"
                                        data-bs-toggle="modal"
                                        data-bs-target="#editMediaModal"
                                        data-name="<?php echo htmlspecialchars($file['name']); ?>"
                                        data-path="<?php echo htmlspecialchars($file['path']); ?>"
                                        data-alt="<?php echo htmlspecialchars($file['alt_text']); ?>"
                                        data-title="<?php echo htmlspecialchars($file['title_text']); ?>"
                                        title="Edit SEO">
                                    <i class="fas fa-pen"></i>
                                </button>
                                <a href="actions/media-delete.php?path=<?php echo urlencode($file['path']); ?>"
                                   class="btn btn-sm btn-outline-danger"
                                   onclick="return confirm('Deleted files cannot be recovered! Proceed?');">
                                    <i class="fas fa-trash"></i>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>
</div>

<!-- Upload Modal -->
<div class="modal fade" id="uploadMediaModal" tabindex="-1">
  <div class="modal-dialog">
    <form action="actions/media-upload.php" method="POST" enctype="multipart/form-data" class="modal-content">
      <div class="modal-header bg-primary text-white">
        <h5 class="modal-title">Upload New File</h5>
        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
      </div>
      <div class="modal-body">
        <div class="mb-3">
            <label class="form-label">Destination Folder</label>
            <select name="folder" class="form-select" required>
                <option value="products">Products Folder</option>
                <option value="categories">Categories Folder</option>
            </select>
        </div>
        <div class="mb-3">
            <label class="form-label">Select Image</label>
            <input type="file" name="image" class="form-control" required accept="image/*">
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        <button type="submit" class="btn btn-primary px-4">Upload</button>
      </div>
    </form>
  </div>
</div>

<!-- Edit Media SEO Modal -->
<div class="modal fade" id="editMediaModal" tabindex="-1">
  <div class="modal-dialog">
    <form action="actions/media-seo-save.php" method="POST" class="modal-content">
      <div class="modal-header bg-dark text-white">
        <h5 class="modal-title">Image SEO & Details</h5>
        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
      </div>
      <div class="modal-body">
        <input type="hidden" name="old_path" id="modal_old_path">
        
        <div class="mb-3">
            <label class="form-label fw-bold">File Name (Rename on Disk)</label>
            <input type="text" name="new_name" id="modal_new_name" class="form-control" required>
            <small class="text-muted">Warning: This will update the file name on the server.</small>
        </div>

        <hr>

        <div class="mb-3">
            <label class="form-label fw-bold font-primary">Alt Text (Search Engine Optimization)</label>
            <input type="text" name="alt_text" id="modal_alt_text" class="form-control" placeholder="Describe the image for Google">
        </div>

        <div class="mb-3">
            <label class="form-label fw-bold">Title Attribute</label>
            <input type="text" name="title_text" id="modal_title_text" class="form-control" placeholder="Hover tooltip text">
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
        <button type="submit" class="btn btn-success px-4">Save SEO Settings</button>
      </div>
    </form>
  </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    var editModal = document.getElementById('editMediaModal');
    if(editModal) {
        editModal.addEventListener('show.bs.modal', function (event) {
            var button = event.relatedTarget;
            document.getElementById('modal_old_path').value = button.getAttribute('data-path');
            document.getElementById('modal_new_name').value = button.getAttribute('data-name');
            document.getElementById('modal_alt_text').value = button.getAttribute('data-alt');
            document.getElementById('modal_title_text').value = button.getAttribute('data-title');
        });
    }

    function copyTextToClipboard(text) {
        if (navigator.clipboard && window.isSecureContext) {
            return navigator.clipboard.writeText(text);
        }
        // Fallback for non-HTTPS contexts
        return new Promise(function(resolve, reject) {
            var ta = document.createElement('textarea');
            ta.value = text;
            ta.style.position = 'fixed';
            ta.style.opacity = '0';
            document.body.appendChild(ta);
            ta.focus();
            ta.select();
            try {
                document.execCommand('copy') ? resolve() : reject();
            } catch (e) {
                reject(e);
            } finally {
                document.body.removeChild(ta);
            }
        });
    }

    document.querySelectorAll('.media-copy-link').forEach(function(btn) {
        btn.addEventListener('click', function() {
            var url = btn.getAttribute('data-url');
            copyTextToClipboard(url).then(function() {
                var icon = btn.querySelector('i');
                btn.classList.remove('btn-outline-success');
                btn.classList.add('btn-success');
                icon.className = 'fas fa-check';
                btn.title = 'Copied!';
                setTimeout(function() {
                    btn.classList.remove('btn-success');
                    btn.classList.add('btn-outline-success');
                    icon.className = 'fas fa-link';
                    btn.title = 'Copy Link';
                }, 1500);
            }).catch(function() {
                window.prompt('Copy this link:', url);
            });
        });
    });
});
</script>

<style>
.media-card { transition: all 0.2s ease-in-out; border: none; outline: 1px solid #eee; }
.media-card:hover { transform: translateY(-5px); box-shadow: 0 10px 20px rgba(0,0,0,0.1) !important; z-index: 10; cursor: pointer; }
</style>
