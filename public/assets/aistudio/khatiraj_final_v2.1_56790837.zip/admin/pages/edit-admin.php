<?php
// admin/pages/edit-admin.php
if (!isset($_GET['id'])) {
    echo '<div class="alert alert-danger m-4"><i class="fas fa-exclamation-triangle me-2"></i>Admin ID missing</div>';
    exit;
}
$id = $_GET['id'];
$stmt = $pdo->prepare("SELECT * FROM admins WHERE id = ?");
$stmt->execute([$id]);
$editAdmin = $stmt->fetch();

if (!$editAdmin) {
    echo '<div class="alert alert-danger m-4"><i class="fas fa-exclamation-triangle me-2"></i>Admin not found</div>';
    exit;
}

$joined_date = date('d M, Y', strtotime($editAdmin['created_at']));
$days_active = floor((time() - strtotime($editAdmin['created_at'])) / 86400);
?>

<?php adminFlashMessages(); ?>
<?php adminPageHeader('Edit Admin', $editAdmin['name'] . ' এর অ্যাকাউন্ট ও রোল আপডেট করুন', [
    ['label' => 'Admin তালিকা', 'icon' => 'fa-arrow-left', 'url' => 'index.php?page=admins', 'class' => 'btn btn-outline-secondary btn-sm'],
]); ?>

<form action="actions/admin-update.php" method="POST" class="settings-form">
    <input type="hidden" name="id" value="<?php echo $editAdmin['id']; ?>">
    <div class="settings-layout admin-shell" data-panel-prefix="adm">
        <div class="settings-content">
            <section class="settings-panel admin-panel is-active" id="adm-general" role="tabpanel">
                <?php adminPanelHeader('Account Details', '#' . $editAdmin['id'] . ' · ' . $joined_date . ' · ' . $days_active . ' days active', 'fa-user-edit', 'blue'); ?>
                <div class="settings-panel-body admin-panel-body">
                    <?php if($editAdmin['email'] === $_SESSION['admin_email']): ?>
                    <div class="mb-3 p-3 bg-warning-subtle rounded-3">
                        <i class="fas fa-info-circle text-warning me-1"></i>
                        <small class="text-warning fw-semibold">This is your own account</small>
                    </div>
                    <?php endif; ?>

                    <div class="row g-3">
                        <div class="col-md-6">
                            <label class="form-label">Full Name <span class="text-danger">*</span></label>
                            <input type="text" name="name" class="form-control"
                                   value="<?php echo htmlspecialchars($editAdmin['name']); ?>" required
                                   placeholder="Admin full name">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Email Address <span class="text-danger">*</span></label>
                            <input type="email" name="email" class="form-control"
                                   value="<?php echo htmlspecialchars($editAdmin['email']); ?>" required
                                   placeholder="admin@example.com">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Access Role <span class="text-danger">*</span></label>
                            <select name="role" class="form-select">
                                <option value="super_admin" <?php echo ($editAdmin['role'] == 'super_admin') ? 'selected' : ''; ?>>Super Admin — Full access</option>
                                <option value="editor" <?php echo ($editAdmin['role'] == 'editor') ? 'selected' : ''; ?>>Editor — Products, categories, blog</option>
                                <option value="moderator" <?php echo ($editAdmin['role'] == 'moderator') ? 'selected' : ''; ?>>Moderator — Orders, customers, reports</option>
                            </select>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">New Password <small class="text-muted">(leave blank to keep)</small></label>
                            <input type="password" name="password" id="admin-password" class="form-control"
                                   placeholder="Enter new password" minlength="6">
                        </div>
                    </div>
                </div>
                <?php adminSaveBar('Update Admin'); ?>
            </section>
        </div>
    </div>
</form>
