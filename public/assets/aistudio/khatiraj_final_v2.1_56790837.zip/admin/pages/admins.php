<?php
// admin/pages/admins.php
// Only Super Admin should see this ideally
$admins = $pdo->query("SELECT * FROM admins ORDER BY id ASC")->fetchAll();
?>

<?php adminFlashMessages(); ?>
<?php adminPageHeader('Manage Admins', 'অ্যাডমিন ইউজার যোগ ও ম্যানেজ করুন', [
    ['label' => 'নতুন Admin', 'icon' => 'fa-user-plus', 'url' => 'index.php?page=add-admin', 'class' => 'btn btn-primary btn-sm'],
]); ?>

<div class="admin-list-shell">
  <div class="admin-list-shell-header">
    <h2 class="admin-list-shell-title">Admin তালিকা</h2>
    <span class="text-muted small fw-semibold"><?php echo count($admins); ?> জন</span>
  </div>
  <div class="admin-table-wrap">
  <table class="admin-table admin-table-mobile-cards">
    <thead>
      <tr>
        <th scope="col">ID</th>
        <th scope="col">Name</th>
        <th scope="col">Email</th>
        <th scope="col">Role</th>
        <th scope="col">Created At</th>
        <th scope="col">Actions</th>
      </tr>
    </thead>
    <tbody>
      <?php if (empty($admins)): ?>
        <tr><td colspan="6"><?php adminEmptyState('কোনো Admin নেই', 'প্রথম admin যোগ করুন', 'fa-user-shield', ['label' => 'নতুন Admin', 'url' => 'index.php?page=add-admin', 'icon' => 'fa-user-plus']); ?></td></tr>
      <?php else: ?>
      <?php foreach ($admins as $admin): ?>
      <tr id="admin-row-<?php echo $admin['id']; ?>">
        <td><?php echo $admin['id']; ?></td>
        <td><?php echo htmlspecialchars($admin['name']); ?></td>
        <td><?php echo htmlspecialchars($admin['email']); ?></td>
        <td><span class="badge bg-secondary"><?php echo htmlspecialchars($admin['role']); ?></span></td>
        <td><?php echo date('M d, Y', strtotime($admin['created_at'])); ?></td>
        <td>
            <div class="d-flex gap-1">
                <a href="index.php?page=edit-admin&id=<?php echo $admin['id']; ?>" class="btn btn-sm btn-outline-info">
                    <i class="fas fa-edit"></i>
                </a>
                <?php if ($admin['email'] !== $_SESSION['admin_email']): ?>
                    <button type="button" class="btn btn-sm btn-outline-danger" onclick="deleteAdmin(<?php echo $admin['id']; ?>)">
                        <i class="fas fa-trash"></i>
                    </button>
                <?php endif; ?>
            </div>
        </td>
      </tr>
      <?php endforeach; ?>
      <?php endif; ?>
    </tbody>
  </table>
  </div>
</div>

<script>
function deleteAdmin(id) {
    if(confirm('Are you sure you want to delete this admin?')) {
        fetch('actions/admin-delete.php?id=' + id, {
            headers: { 'X-Requested-With': 'XMLHttpRequest' }
        })
        .then(res => res.json())
        .then(data => {
            if(data.success) {
                if (typeof loadPage === 'function') {
                    loadPage('index.php?page=admins&success=' + encodeURIComponent(data.message));
                } else {
                    window.location.href = 'index.php?page=admins&success=' + encodeURIComponent(data.message);
                }
            } else {
                alert('Error: ' + data.message);
            }
        })
        .catch(err => {
            console.error('Delete Error:', err);
            window.location.href = 'actions/admin-delete.php?id=' + id;
        });
    }
}
</script>
