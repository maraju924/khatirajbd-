<?php
// admin/pages/add-user.php
?>
<?php adminFlashMessages(); ?>
<?php adminPageHeader('Add Customer', 'নতুন গ্রাহক অ্যাকাউন্ট তৈরি করুন', [
    ['label' => 'গ্রাহক তালিকা', 'icon' => 'fa-arrow-left', 'url' => 'index.php?page=customers', 'class' => 'btn btn-outline-secondary btn-sm'],
]); ?>

<form action="actions/add-user.php" method="POST" class="settings-form">
    <div class="settings-layout admin-shell" data-panel-prefix="usr">
        <div class="settings-content">
            <section class="settings-panel admin-panel is-active" id="usr-general" role="tabpanel">
                <?php adminPanelHeader('Customer Details', 'নাম, যোগাযোগ ও ঠিকানা', 'fa-user-plus', 'green'); ?>
                <div class="settings-panel-body admin-panel-body">
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Full Name <span class="text-danger">*</span></label>
                            <input type="text" name="name" class="form-control" required placeholder="John Doe">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Email Address <span class="text-danger">*</span></label>
                            <input type="email" name="email" class="form-control" required placeholder="john@example.com">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Phone Number <span class="text-danger">*</span></label>
                            <input type="text" name="phone" class="form-control" required placeholder="017xxxxxxxx">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Password <span class="text-danger">*</span></label>
                            <input type="password" name="password" class="form-control" required placeholder="******">
                        </div>
                        <div class="col-12 mb-0">
                            <label class="form-label">Address</label>
                            <textarea name="address" class="form-control" rows="3" placeholder="Full Address"></textarea>
                        </div>
                    </div>
                </div>
                <?php adminSaveBar('Create User'); ?>
            </section>
        </div>
    </div>
</form>
