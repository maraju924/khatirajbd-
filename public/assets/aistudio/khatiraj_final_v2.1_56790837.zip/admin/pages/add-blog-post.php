<?php
// admin/pages/add-blog-post.php
?>

<!-- CKEditor 5 CDN -->
<script src="https://cdn.ckeditor.com/ckeditor5/41.4.2/classic/ckeditor.js"></script>

<?php adminFlashMessages(); ?>
<?php adminPageHeader('New Blog Post', 'নতুন ব্লগ পোস্ট লিখুন ও প্রকাশ করুন', [
    ['label' => 'ব্লগ তালিকা', 'icon' => 'fa-arrow-left', 'url' => 'index.php?page=blog-posts', 'class' => 'btn btn-outline-secondary btn-sm'],
]); ?>

<form id="addBlogForm" class="settings-form">
    <div class="settings-layout admin-shell" data-panel-prefix="blog">
        <div class="settings-content">
            <section class="settings-panel admin-panel is-active" id="blog-general" role="tabpanel">
                <?php adminPanelHeader('Blog Post', 'টাইটেল, কন্টেন্ট, SEO ও প্রকাশ', 'fa-pen', 'green'); ?>
                <div class="settings-panel-body admin-panel-body">
                    <div class="mb-3">
                        <label class="form-label fw-bold">Post Title <span class="text-danger">*</span></label>
                        <input type="text" name="title" class="form-control form-control-lg" placeholder="Enter blog post title..." required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-bold">Excerpt / Short Summary</label>
                        <textarea name="excerpt" class="form-control" rows="3" placeholder="A short summary that appears on the blog listing page..."></textarea>
                    </div>
                    <div class="mb-4">
                        <label class="form-label fw-bold">Content <span class="text-danger">*</span></label>
                        <textarea name="content" id="blogContent" class="form-control" rows="15" required></textarea>
                    </div>

                    <div class="row g-3 mb-4">
                        <div class="col-md-6">
                            <label class="form-label fw-bold">Status</label>
                            <select name="status" class="form-select">
                                <option value="0">Draft</option>
                                <option value="1">Published</option>
                            </select>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label fw-bold">Featured Image</label>
                            <div class="media-picker-container text-center p-3 border rounded bg-light">
                                <input type="hidden" name="image" id="blog_image">
                                <img id="blog_image_preview" src="" class="img-fluid rounded mb-2 d-none" style="max-height: 160px;">
                                <div id="blog_image_placeholder" class="py-2">
                                    <i class="fas fa-image fa-2x text-muted mb-2"></i>
                                    <p class="small text-muted mb-0">No image selected</p>
                                </div>
                                <button type="button" class="btn btn-sm btn-dark w-100 mt-2" onclick="openMediaPicker('blog_image')">
                                    <i class="fas fa-images me-1"></i> Select from Media
                                </button>
                            </div>
                        </div>
                    </div>

                    <h6 class="fw-bold mb-3"><i class="fas fa-search me-2 text-primary"></i>SEO Settings</h6>
                    <div class="mb-3">
                        <label class="form-label fw-bold">Meta Title</label>
                        <input type="text" name="meta_title" class="form-control" placeholder="SEO title (leave empty to use post title)">
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-bold">Meta Description</label>
                        <textarea name="meta_description" class="form-control" rows="2" placeholder="SEO description for search engines..."></textarea>
                    </div>
                    <div class="mb-0">
                        <label class="form-label fw-bold">Meta Keywords</label>
                        <input type="text" name="meta_keywords" class="form-control" placeholder="keyword1, keyword2, keyword3">
                    </div>
                </div>
                <?php adminSaveBar('Save Post'); ?>
            </section>
        </div>
    </div>
</form>

<style>
    .ck-editor__editable { min-height: 350px !important; font-size: 1rem; }
    .ck.ck-editor { border-radius: 8px; overflow: hidden; }
</style>

<script>
let blogEditor;

ClassicEditor
    .create(document.querySelector('#blogContent'), {
        toolbar: [
            'heading', '|',
            'bold', 'italic', 'underline', 'strikethrough', '|',
            'bulletedList', 'numberedList', '|',
            'blockQuote', 'insertTable', '|',
            'link', 'mediaEmbed', '|',
            'undo', 'redo'
        ],
        heading: {
            options: [
                { model: 'paragraph', title: 'Paragraph', class: 'ck-heading_paragraph' },
                { model: 'heading2', view: 'h2', title: 'Heading 2', class: 'ck-heading_heading2' },
                { model: 'heading3', view: 'h3', title: 'Heading 3', class: 'ck-heading_heading3' },
                { model: 'heading4', view: 'h4', title: 'Heading 4', class: 'ck-heading_heading4' }
            ]
        },
        placeholder: 'আপনার ব্লগ পোস্ট এখানে লিখুন...'
    })
    .then(editor => {
        blogEditor = editor;
    })
    .catch(error => {
        console.error('CKEditor Error:', error);
    });

document.getElementById('addBlogForm').addEventListener('submit', function(e) {
    e.preventDefault();

    if (blogEditor) {
        document.querySelector('#blogContent').value = blogEditor.getData();
    }

    const btn = this.querySelector('button[type="submit"]');
    btn.disabled = true;
    btn.innerHTML = '<i class="fas fa-spinner fa-spin me-2"></i>Saving...';

    fetch('actions/blog-post-save.php', { method: 'POST', body: new FormData(this) })
        .then(res => res.json())
        .then(data => {
            if(data.status === 'success') {
                alert(data.message);
                window.location.href = 'index.php?page=blog-posts';
            } else {
                alert(data.message);
                btn.disabled = false;
                btn.innerHTML = '<i class="fas fa-save me-2"></i>Save Post';
            }
        })
        .catch(() => {
            btn.disabled = false;
            btn.innerHTML = '<i class="fas fa-save me-2"></i>Save Post';
        });
});
</script>
