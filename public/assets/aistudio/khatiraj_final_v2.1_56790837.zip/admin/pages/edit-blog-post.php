<?php
// admin/pages/edit-blog-post.php
$id = intval($_GET['id'] ?? 0);
$post = $pdo->prepare("SELECT * FROM blog_posts WHERE id = ?");
$post->execute([$id]);
$post = $post->fetch();

if (!$post) {
    echo '<div class="alert alert-danger m-4">Blog post not found.</div>';
    return;
}
?>

<!-- CKEditor 5 CDN -->
<script src="https://cdn.ckeditor.com/ckeditor5/41.4.2/classic/ckeditor.js"></script>

<?php adminFlashMessages(); ?>
<?php adminPageHeader('Edit Blog Post', 'ব্লগ পোস্টের কন্টেন্ট ও SEO আপডেট করুন', [
    ['label' => 'ব্লগ তালিকা', 'icon' => 'fa-arrow-left', 'url' => 'index.php?page=blog-posts', 'class' => 'btn btn-outline-secondary btn-sm'],
]); ?>

<form id="editBlogForm" class="settings-form">
    <input type="hidden" name="id" value="<?php echo $post['id']; ?>">
    <div class="settings-layout admin-shell" data-panel-prefix="blog">
        <div class="settings-content">
            <section class="settings-panel admin-panel is-active" id="blog-general" role="tabpanel">
                <?php adminPanelHeader('Blog Post', 'Views: ' . number_format($post['views']) . ' · Created: ' . date('d M, Y', strtotime($post['created_at'])), 'fa-pen', 'blue'); ?>
                <div class="settings-panel-body admin-panel-body">
                    <div class="mb-3">
                        <label class="form-label fw-bold">Post Title <span class="text-danger">*</span></label>
                        <input type="text" name="title" class="form-control form-control-lg" value="<?php echo htmlspecialchars($post['title']); ?>" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-bold">Excerpt / Short Summary</label>
                        <textarea name="excerpt" class="form-control" rows="3"><?php echo htmlspecialchars($post['excerpt']); ?></textarea>
                    </div>
                    <div class="mb-4">
                        <label class="form-label fw-bold">Content <span class="text-danger">*</span></label>
                        <textarea name="content" id="blogContent" class="form-control" rows="15" required><?php echo htmlspecialchars($post['content']); ?></textarea>
                    </div>

                    <div class="row g-3 mb-4">
                        <div class="col-md-6">
                            <label class="form-label fw-bold">Status</label>
                            <select name="status" class="form-select">
                                <option value="0" <?php echo $post['status'] == 0 ? 'selected' : ''; ?>>Draft</option>
                                <option value="1" <?php echo $post['status'] == 1 ? 'selected' : ''; ?>>Published</option>
                            </select>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label fw-bold">Featured Image</label>
                            <div class="media-picker-container text-center p-3 border rounded bg-light">
                                <input type="hidden" name="image" id="blog_image" value="<?php echo htmlspecialchars($post['image']); ?>">
                                <img id="blog_image_preview" src="<?php echo $post['image'] ? '../' . $post['image'] : ''; ?>" class="img-fluid rounded mb-2 <?php echo $post['image'] ? '' : 'd-none'; ?>" style="max-height: 160px;">
                                <div id="blog_image_placeholder" class="py-2 <?php echo $post['image'] ? 'd-none' : ''; ?>">
                                    <i class="fas fa-image fa-2x text-muted mb-2"></i>
                                    <p class="small text-muted mb-0">No image selected</p>
                                </div>
                                <button type="button" class="btn btn-sm btn-dark w-100 mt-2" onclick="openMediaPicker('blog_image')">
                                    <i class="fas fa-images me-1"></i> Change Image
                                </button>
                            </div>
                        </div>
                    </div>

                    <h6 class="fw-bold mb-3"><i class="fas fa-search me-2 text-primary"></i>SEO Settings</h6>
                    <div class="mb-3">
                        <label class="form-label fw-bold">Meta Title</label>
                        <input type="text" name="meta_title" class="form-control" value="<?php echo htmlspecialchars($post['meta_title']); ?>">
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-bold">Meta Description</label>
                        <textarea name="meta_description" class="form-control" rows="2"><?php echo htmlspecialchars($post['meta_description']); ?></textarea>
                    </div>
                    <div class="mb-0">
                        <label class="form-label fw-bold">Meta Keywords</label>
                        <input type="text" name="meta_keywords" class="form-control" value="<?php echo htmlspecialchars($post['meta_keywords']); ?>">
                    </div>
                </div>
                <?php adminSaveBar('Update Post'); ?>
            </section>
        </div>
    </div>
</form>

<style>
    .ck-editor__editable { min-height: 350px !important; font-size: 1rem; }
    .ck.ck-editor { border-radius: 8px; overflow: hidden; }
</style>

<script>
let blogEditor;

ClassicEditor
    .create(document.querySelector('#blogContent'), {
        toolbar: [
            'heading', '|',
            'bold', 'italic', 'underline', 'strikethrough', '|',
            'bulletedList', 'numberedList', '|',
            'blockQuote', 'insertTable', '|',
            'link', 'mediaEmbed', '|',
            'undo', 'redo'
        ],
        heading: {
            options: [
                { model: 'paragraph', title: 'Paragraph', class: 'ck-heading_paragraph' },
                { model: 'heading2', view: 'h2', title: 'Heading 2', class: 'ck-heading_heading2' },
                { model: 'heading3', view: 'h3', title: 'Heading 3', class: 'ck-heading_heading3' },
                { model: 'heading4', view: 'h4', title: 'Heading 4', class: 'ck-heading_heading4' }
            ]
        },
        placeholder: 'আপনার ব্লগ পোস্ট এখানে লিখুন...'
    })
    .then(editor => {
        blogEditor = editor;
    })
    .catch(error => {
        console.error('CKEditor Error:', error);
    });

document.getElementById('editBlogForm').addEventListener('submit', function(e) {
    e.preventDefault();

    if (blogEditor) {
        document.querySelector('#blogContent').value = blogEditor.getData();
    }

    const btn = this.querySelector('button[type="submit"]');
    btn.disabled = true;
    btn.innerHTML = '<i class="fas fa-spinner fa-spin me-2"></i>Updating...';

    fetch('actions/blog-post-update.php', { method: 'POST', body: new FormData(this) })
        .then(res => res.json())
        .then(data => {
            if(data.status === 'success') {
                alert(data.message);
                window.location.href = 'index.php?page=blog-posts';
            } else {
                alert(data.message);
                btn.disabled = false;
                btn.innerHTML = '<i class="fas fa-save me-2"></i>Update Post';
            }
        })
        .catch(() => {
            btn.disabled = false;
            btn.innerHTML = '<i class="fas fa-save me-2"></i>Update Post';
        });
});
</script>
