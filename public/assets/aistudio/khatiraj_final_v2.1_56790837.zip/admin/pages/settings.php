<?php
// admin/pages/settings.php

// Fetch existing settings
$settings = [];
$social_links = [];
try {
    $stmt = $pdo->query("SELECT * FROM settings");
    while ($row = $stmt->fetch()) {
        $settings[$row['key_name']] = $row['value'];
    }

    // Fetch Dynamic Social Links
    $social_links = $pdo->query("SELECT * FROM social_links ORDER BY sort_order ASC")->fetchAll();
} catch (PDOException $e) {
    // Table might not exist yet if migration hasn't run
}

$settings_nav = [
    ['id' => 'general',     'label' => 'সাধারণ',           'icon' => 'fa-cog',              'hint' => 'সাইট ও যোগাযোগ'],
    ['id' => 'logo',        'label' => 'লোগো',             'icon' => 'fa-image',            'hint' => 'ব্র্যান্ড লোগো'],
    ['id' => 'seo',         'label' => 'SEO',              'icon' => 'fa-search',           'hint' => 'মেটা ও শেয়ার'],
    ['id' => 'marketing',   'label' => 'মার্কেটিং',        'icon' => 'fab fa-whatsapp',     'hint' => 'WhatsApp ও UI'],
    ['id' => 'footer',      'label' => 'ফুটার',            'icon' => 'fa-shoe-prints',      'hint' => 'ব্র্যান্ডিং টেক্সট'],
    ['id' => 'courier',     'label' => 'কুরিয়ার',         'icon' => 'fa-truck',            'hint' => 'Steadfast'],
    ['id' => 'sms',         'label' => 'SMS',              'icon' => 'fa-sms',              'hint' => 'নোটিফিকেশন'],
    ['id' => 'abandoned',   'label' => 'Abandoned Cart',   'icon' => 'fa-cart-arrow-down',  'hint' => 'রিকভারি'],
    ['id' => 'email',       'label' => 'ইমেইল / SMTP',     'icon' => 'fa-envelope',         'hint' => 'Gmail ডেলিভারি'],
    ['id' => 'social',      'label' => 'সোশ্যাল',          'icon' => 'fa-share-alt',        'hint' => 'লিংক ম্যানেজ'],
];
?>

<?php adminFlashMessages(); ?>
<?php adminPageHeader('Settings', 'সাইট কনফিগারেশন, SEO, সোশ্যাল লিংক ও পেমেন্ট সেটিংস', [], [['label' => 'Settings', 'url' => '']]); ?>

<div class="settings-layout">
    <!-- Top sticky horizontal section tabs -->
    <nav class="settings-tabs" aria-label="Settings sections">
        <div class="settings-tabs-track" role="tablist">
            <?php foreach ($settings_nav as $i => $item):
                $iconClass = (strpos($item['icon'], 'fab ') === 0) ? $item['icon'] : 'fas ' . $item['icon'];
            ?>
            <a href="#settings-<?php echo $item['id']; ?>"
               class="settings-tab<?php echo $i === 0 ? ' active' : ''; ?>"
               role="tab"
               data-settings-nav="<?php echo $item['id']; ?>"
               aria-selected="<?php echo $i === 0 ? 'true' : 'false'; ?>"
               tabindex="<?php echo $i === 0 ? '0' : '-1'; ?>"
               title="<?php echo htmlspecialchars($item['hint']); ?>">
                <i class="<?php echo $iconClass; ?>"></i>
                <span><?php echo htmlspecialchars($item['label']); ?></span>
            </a>
            <?php endforeach; ?>
        </div>
    </nav>

    <div class="settings-content">

        <!-- ═══ General / Site Configuration ═══ -->
        <section class="settings-panel is-active" id="settings-general" role="tabpanel">
            <div class="settings-panel-header">
                <div class="settings-panel-icon green"><i class="fas fa-cog"></i></div>
                <div>
                    <h2 class="settings-panel-title">সাইট কনফিগারেশন</h2>
                    <p class="settings-panel-desc">সাইটের নাম, সাপোর্ট কন্টাক্ট ও অফিস ঠিকানা</p>
                </div>
            </div>
            <form action="actions/settings-save.php" method="POST" class="settings-form">
                <div class="settings-panel-body">
                    <div class="mb-3">
                        <label class="form-label">Site Name</label>
                        <input type="text" name="site_name" class="form-control" value="<?php echo htmlspecialchars($settings['site_name'] ?? ''); ?>">
                        <div class="form-text">ওয়েবসাইট ও অ্যাডমিন হেডারে প্রদর্শিত নাম</div>
                    </div>

                    <div class="row g-3">
                        <div class="col-md-6">
                            <label class="form-label">Support Phone</label>
                            <input type="text" name="support_phone" class="form-control" value="<?php echo htmlspecialchars($settings['support_phone'] ?? ''); ?>">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Support Email</label>
                            <input type="email" name="support_email" class="form-control" value="<?php echo htmlspecialchars($settings['support_email'] ?? ''); ?>">
                        </div>
                    </div>

                    <div class="mt-3">
                        <label class="form-label">Office Address</label>
                        <textarea name="address" class="form-control" rows="3"><?php echo htmlspecialchars($settings['address'] ?? ''); ?></textarea>
                    </div>
                </div>
                <div class="settings-save-bar">
                    <span class="settings-save-hint text-muted small d-none d-sm-inline">পরিবর্তন সেভ করতে ক্লিক করুন</span>
                    <button type="submit" class="btn btn-primary px-4 fw-semibold">
                        <i class="fas fa-save me-2"></i>Update Site Settings
                    </button>
                </div>
            </form>
        </section>

        <!-- ═══ Logo ═══ -->
        <section class="settings-panel" id="settings-logo">
            <div class="settings-panel-header">
                <div class="settings-panel-icon sky"><i class="fas fa-image"></i></div>
                <div>
                    <h2 class="settings-panel-title">সাইট লোগো</h2>
                    <p class="settings-panel-desc">মিডিয়া লাইব্রেরি থেকে লোগো নির্বাচন করুন</p>
                </div>
            </div>
            <form action="actions/settings-save.php" method="POST" id="logoSettingsForm" class="settings-form">
                <div class="settings-panel-body">
                    <div class="settings-logo-preview">
                        <input type="hidden" id="site_logo_input" value="<?php echo htmlspecialchars($settings['site_logo'] ?? ''); ?>">
                        <img id="site_logo_input_preview" src="../<?php echo htmlspecialchars($settings['site_logo'] ?? ''); ?>" alt="Site Logo" class="img-fluid <?php echo !empty($settings['site_logo']) ? '' : 'd-none'; ?>">
                        <div id="site_logo_input_placeholder" class="settings-logo-placeholder <?php echo !empty($settings['site_logo']) ? 'd-none' : ''; ?>">
                            <i class="fas fa-cloud-upload-alt fa-2x text-muted mb-2"></i>
                            <p class="mb-0 text-muted small">কোনো লোগো নির্বাচিত নেই</p>
                        </div>
                    </div>
                    <input type="hidden" name="site_logo" id="final_logo_path" value="<?php echo htmlspecialchars($settings['site_logo'] ?? ''); ?>">
                    <div class="text-center mt-3">
                        <button type="button" class="btn btn-outline-primary px-4 fw-semibold" onclick="openMediaPicker('site_logo_input')">
                            <i class="fas fa-images me-2"></i>Select From Media
                        </button>
                    </div>
                </div>
                <div class="settings-save-bar">
                    <span class="settings-save-hint text-muted small d-none d-sm-inline">লোগো পাথ সেভ হবে</span>
                    <button type="submit" class="btn btn-primary px-4 fw-semibold">
                        <i class="fas fa-save me-2"></i>Save Logo
                    </button>
                </div>
            </form>
            <script>
                document.getElementById('logoSettingsForm').addEventListener('submit', function() {
                    document.getElementById('final_logo_path').value = document.getElementById('site_logo_input').value;
                });
            </script>
        </section>

        <!-- ═══ SEO ═══ -->
        <section class="settings-panel" id="settings-seo">
            <div class="settings-panel-header">
                <div class="settings-panel-icon blue"><i class="fas fa-search"></i></div>
                <div>
                    <h2 class="settings-panel-title">Global SEO & Identity</h2>
                    <p class="settings-panel-desc">ডিফল্ট মেটা ট্যাগ, ফ্যাভিকন ও শেয়ার ইমেজ</p>
                </div>
            </div>
            <form action="actions/settings-save.php" method="POST" class="settings-form">
                <div class="settings-panel-body">
                    <div class="row g-3">
                        <div class="col-md-6">
                            <label class="form-label">Global Title Suffix</label>
                            <input type="text" name="global_meta_title_suffix" class="form-control" value="<?php echo htmlspecialchars($settings['global_meta_title_suffix'] ?? ''); ?>" placeholder="e.g. | Khati Raj BD">
                            <div class="form-text">প্রতিটি পেজ টাইটেলের শেষে স্বয়ংক্রিয়ভাবে যোগ হবে</div>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Site Favicon</label>
                            <div class="input-group">
                                <input type="text" name="site_favicon" id="site_favicon_input" class="form-control" value="<?php echo htmlspecialchars($settings['site_favicon'] ?? ''); ?>" placeholder="Select favicon file">
                                <button type="button" class="btn btn-outline-secondary" onclick="openMediaPicker('site_favicon_input')">Browse</button>
                            </div>
                            <div class="form-text">ট্যাব আইকন (৩২×৩২ বা ১৬×১৬ px)</div>
                        </div>
                        <div class="col-12">
                            <label class="form-label">Global Meta Keywords</label>
                            <input type="text" name="global_meta_keywords" class="form-control" value="<?php echo htmlspecialchars($settings['global_meta_keywords'] ?? ''); ?>" placeholder="comma, separated, keywords">
                        </div>
                        <div class="col-12">
                            <label class="form-label">Global Meta Description</label>
                            <textarea name="global_meta_description" class="form-control" rows="3" placeholder="Default description for search engine results"><?php echo htmlspecialchars($settings['global_meta_description'] ?? ''); ?></textarea>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Global Share Image (OG Image)</label>
                            <div class="input-group">
                                <input type="text" name="global_og_image" id="global_og_image_input" class="form-control" value="<?php echo htmlspecialchars($settings['global_og_image'] ?? ''); ?>" placeholder="Select default OG image">
                                <button type="button" class="btn btn-outline-secondary" onclick="openMediaPicker('global_og_image_input')">Browse</button>
                            </div>
                            <div class="form-text">সোশ্যাল মিডিয়ায় লিংক শেয়ারের ডিফল্ট ইমেজ</div>
                        </div>
                    </div>
                </div>
                <div class="settings-save-bar">
                    <button type="submit" class="btn btn-primary px-4 fw-semibold">
                        <i class="fas fa-save me-2"></i>Save SEO Settings
                    </button>
                </div>
            </form>
        </section>

        <!-- ═══ Marketing & UI ═══ -->
        <section class="settings-panel" id="settings-marketing">
            <div class="settings-panel-header">
                <div class="settings-panel-icon green"><i class="fab fa-whatsapp"></i></div>
                <div>
                    <h2 class="settings-panel-title">মার্কেটিং ও UI</h2>
                    <p class="settings-panel-desc">WhatsApp বাটন, স্টিকি অর্ডার ও সেলস পপআপ</p>
                </div>
            </div>
            <form action="actions/settings-save.php" method="POST" class="settings-form" id="marketingSettingsForm">
                <div class="settings-panel-body">
                    <div class="row g-3">
                        <div class="col-md-4">
                            <label class="form-label">WhatsApp Number</label>
                            <input type="text" name="whatsapp_number" class="form-control" value="<?php echo htmlspecialchars($settings['whatsapp_number'] ?? ''); ?>" placeholder="e.g. 8801700000000">
                            <div class="form-text">কান্ট্রি কোডসহ, +, স্পেস ছাড়া</div>
                        </div>
                        <div class="col-md-8">
                            <label class="form-label">WhatsApp Default Message</label>
                            <input type="text" name="whatsapp_message" class="form-control" value="<?php echo htmlspecialchars($settings['whatsapp_message'] ?? 'Hello, I want to order some products.'); ?>">
                        </div>
                    </div>

                    <div class="settings-toggle-grid mt-4">
                        <label class="settings-toggle">
                            <input type="hidden" name="enable_whatsapp" value="0" id="hidden_whatsapp" <?php echo ($settings['enable_whatsapp'] ?? '0') == '1' ? 'disabled' : ''; ?>>
                            <input class="form-check-input" type="checkbox" name="enable_whatsapp" id="enable_whatsapp" value="1" data-hidden-pair="hidden_whatsapp" <?php echo ($settings['enable_whatsapp'] ?? '0') == '1' ? 'checked' : ''; ?>>
                            <span class="settings-toggle-body">
                                <span class="settings-toggle-title">Floating WhatsApp Button</span>
                                <span class="settings-toggle-desc">সাইটে ভাসমান WhatsApp চ্যাট বাটন দেখাবে</span>
                            </span>
                        </label>
                        <label class="settings-toggle">
                            <input type="hidden" name="enable_sticky_order" value="0" id="hidden_sticky" <?php echo ($settings['enable_sticky_order'] ?? '0') == '1' ? 'disabled' : ''; ?>>
                            <input class="form-check-input" type="checkbox" name="enable_sticky_order" id="enable_sticky_order" value="1" data-hidden-pair="hidden_sticky" <?php echo ($settings['enable_sticky_order'] ?? '0') == '1' ? 'checked' : ''; ?>>
                            <span class="settings-toggle-body">
                                <span class="settings-toggle-title">Mobile Sticky “Order Now”</span>
                                <span class="settings-toggle-desc">মোবাইলে নিচে স্টিকি অর্ডার বাটন</span>
                            </span>
                        </label>
                        <label class="settings-toggle">
                            <input type="hidden" name="enable_sales_popup" value="0" id="hidden_sales" <?php echo ($settings['enable_sales_popup'] ?? '0') == '1' ? 'disabled' : ''; ?>>
                            <input class="form-check-input" type="checkbox" name="enable_sales_popup" id="enable_sales_popup" value="1" data-hidden-pair="hidden_sales" <?php echo ($settings['enable_sales_popup'] ?? '0') == '1' ? 'checked' : ''; ?>>
                            <span class="settings-toggle-body">
                                <span class="settings-toggle-title">Recent Sales Popup</span>
                                <span class="settings-toggle-desc">সাম্প্রতিক অর্ডার নোটিফিকেশন পপআপ</span>
                            </span>
                        </label>
                    </div>
                </div>
                <div class="settings-save-bar">
                    <button type="submit" class="btn btn-primary px-4 fw-semibold">
                        <i class="fas fa-save me-2"></i>Save Marketing Settings
                    </button>
                </div>
            </form>
        </section>

        <!-- ═══ Footer ═══ -->
        <section class="settings-panel" id="settings-footer">
            <div class="settings-panel-header">
                <div class="settings-panel-icon amber"><i class="fas fa-shoe-prints"></i></div>
                <div>
                    <h2 class="settings-panel-title">ফুটার ব্র্যান্ডিং</h2>
                    <p class="settings-panel-desc">ফুটার কলাম টাইটেল, অ্যাবাউট ও কপিরাইট</p>
                </div>
            </div>
            <form action="actions/settings-save.php" method="POST" class="settings-form">
                <div class="settings-panel-body">
                    <div class="mb-3">
                        <label class="form-label">Footer About Text</label>
                        <textarea name="footer_about_text" class="form-control" rows="3"><?php echo htmlspecialchars($settings['footer_about_text'] ?? ''); ?></textarea>
                        <div class="form-text">ফুটারের প্রথম কলামে দেখানো সংক্ষিপ্ত বিবরণ</div>
                    </div>

                    <div class="row g-3 mb-3">
                        <div class="col-md-6">
                            <label class="form-label">Footer Column 2 Title</label>
                            <input type="text" name="footer_col2_title" class="form-control" value="<?php echo htmlspecialchars($settings['footer_col2_title'] ?? 'Quick Links'); ?>">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Footer Column 3 Title</label>
                            <input type="text" name="footer_col3_title" class="form-control" value="<?php echo htmlspecialchars($settings['footer_col3_title'] ?? 'Contact Reach'); ?>">
                        </div>
                    </div>

                    <div>
                        <label class="form-label">Copyright Text</label>
                        <input type="text" name="footer_copyright" class="form-control" value="<?php echo htmlspecialchars($settings['footer_copyright'] ?? ''); ?>">
                        <div class="form-text">যেমন: &copy; 2026 Khati Raj. All rights reserved.</div>
                    </div>
                </div>
                <div class="settings-save-bar">
                    <button type="submit" class="btn btn-primary px-4 fw-semibold">
                        <i class="fas fa-save me-2"></i>Save Footer Text
                    </button>
                </div>
            </form>
        </section>

        <!-- ═══ Courier link-out ═══ -->
        <section class="settings-panel" id="settings-courier">
            <div class="settings-panel-header">
                <div class="settings-panel-icon amber"><i class="fas fa-truck"></i></div>
                <div>
                    <h2 class="settings-panel-title">কুরিয়ার সেটিংস (Steadfast)</h2>
                    <p class="settings-panel-desc">API কী, ব্যালেন্স, পেমেন্টস — আলাদা কুরিয়ার সেকশনে</p>
                </div>
            </div>
            <div class="settings-panel-body">
                <div class="settings-callout">
                    <div class="settings-callout-icon"><i class="fas fa-truck-fast"></i></div>
                    <div class="flex-grow-1">
                        <strong>Courier settings এখন আলাদা section-এ</strong>
                        <p class="mb-0 text-muted small">Dashboard, analytics, live balance, payments সব এক জায়গায়।</p>
                    </div>
                    <a href="index.php?page=courier-dashboard" class="btn btn-dark fw-semibold px-4">
                        <i class="fas fa-arrow-right me-2"></i>Courier Section খুলুন
                    </a>
                </div>
            </div>
        </section>

        <!-- ═══ SMS ═══ -->
        <section class="settings-panel" id="settings-sms">
            <div class="settings-panel-header">
                <div class="settings-panel-icon blue"><i class="fas fa-sms"></i></div>
                <div>
                    <h2 class="settings-panel-title">SMS নোটিফিকেশন</h2>
                    <p class="settings-panel-desc">প্রোভাইডার, API কী ও অর্ডার স্ট্যাটাস টেমপ্লেট</p>
                </div>
            </div>
            <form action="actions/settings-save.php" method="POST" class="settings-form" id="smsSettingsForm">
                <div class="settings-panel-body">
                    <label class="settings-toggle mb-4">
                        <input type="hidden" name="sms_enabled" value="0" id="hidden_sms_enabled" <?php echo ($settings['sms_enabled'] ?? '0') == '1' ? 'disabled' : ''; ?>>
                        <input class="form-check-input" type="checkbox" name="sms_enabled" id="sms_enabled" value="1" data-hidden-pair="hidden_sms_enabled" <?php echo ($settings['sms_enabled'] ?? '0') == '1' ? 'checked' : ''; ?>>
                        <span class="settings-toggle-body">
                            <span class="settings-toggle-title">Enable SMS Notifications</span>
                            <span class="settings-toggle-desc">অর্ডার স্ট্যাটাস পরিবর্তনে SMS পাঠাবে</span>
                        </span>
                    </label>

                    <div class="row g-3">
                        <div class="col-md-4">
                            <label class="form-label">SMS Provider</label>
                            <select name="sms_provider" class="form-select">
                                <option value="bulksmsbd" <?php echo ($settings['sms_provider'] ?? '') == 'bulksmsbd' ? 'selected' : ''; ?>>BulkSMSBD</option>
                            </select>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">API Key / Password</label>
                            <input type="text" name="sms_api_key" class="form-control" value="<?php echo htmlspecialchars($settings['sms_api_key'] ?? ''); ?>" placeholder="Enter API Key">
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">Sender ID / Username</label>
                            <input type="text" name="sms_sender_id" class="form-control" value="<?php echo htmlspecialchars($settings['sms_sender_id'] ?? ''); ?>" placeholder="Enter Sender ID">
                        </div>
                    </div>

                    <div class="settings-subsection mt-4">
                        <h3 class="settings-subsection-title">SMS Templates</h3>
                        <p class="settings-var-hint"><i class="fas fa-code me-1"></i> Variables: {name}, {order_id}, {total}, {tracking_id}</p>
                        <div class="row g-3">
                            <div class="col-md-4">
                                <label class="form-label">Order Placed Template</label>
                                <textarea name="sms_order_placed_text" class="form-control" rows="4"><?php echo htmlspecialchars($settings['sms_order_placed_text'] ?? ''); ?></textarea>
                            </div>
                            <div class="col-md-4">
                                <label class="form-label">Order Shipped Template</label>
                                <textarea name="sms_order_shipped_text" class="form-control" rows="4"><?php echo htmlspecialchars($settings['sms_order_shipped_text'] ?? ''); ?></textarea>
                            </div>
                            <div class="col-md-4">
                                <label class="form-label">Order Delivered Template</label>
                                <textarea name="sms_order_delivered_text" class="form-control" rows="4"><?php echo htmlspecialchars($settings['sms_order_delivered_text'] ?? ''); ?></textarea>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="settings-save-bar">
                    <button type="submit" class="btn btn-primary px-4 fw-semibold">
                        <i class="fas fa-save me-2"></i>Save SMS Settings
                    </button>
                </div>
            </form>
        </section>

        <!-- ═══ Abandoned Cart ═══ -->
        <section class="settings-panel" id="settings-abandoned">
            <div class="settings-panel-header">
                <div class="settings-panel-icon red"><i class="fas fa-cart-arrow-down"></i></div>
                <div>
                    <h2 class="settings-panel-title">Abandoned Cart Recovery</h2>
                    <p class="settings-panel-desc">SMS + WhatsApp রিকভারি রিমাইন্ডার</p>
                </div>
            </div>
            <form action="actions/settings-save.php" method="POST" class="settings-form" id="abandonedSettingsForm">
                <div class="settings-panel-body">
                    <label class="settings-toggle mb-3">
                        <input type="hidden" name="abandoned_cart_enabled" value="0" id="hidden_abandoned_cart_enabled" <?php echo ($settings['abandoned_cart_enabled'] ?? '0') == '1' ? 'disabled' : ''; ?>>
                        <input class="form-check-input" type="checkbox" name="abandoned_cart_enabled" id="abandoned_cart_enabled" value="1" data-hidden-pair="hidden_abandoned_cart_enabled" <?php echo ($settings['abandoned_cart_enabled'] ?? '0') == '1' ? 'checked' : ''; ?>>
                        <span class="settings-toggle-body">
                            <span class="settings-toggle-title">Enable Abandoned Cart Recovery</span>
                            <span class="settings-toggle-desc">কাস্টমার চেকআউটে ফোন দিলে কিন্তু অর্ডার না করলে SMS/WhatsApp reminder পাঠাবে।</span>
                        </span>
                    </label>

                    <div class="row g-3">
                        <div class="col-md-4">
                            <label class="form-label">Reminder Delay (minutes)</label>
                            <input type="number" name="abandoned_cart_delay_minutes" class="form-control" min="5" value="<?php echo htmlspecialchars($settings['abandoned_cart_delay_minutes'] ?? '30'); ?>">
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">Max Reminders</label>
                            <input type="number" name="abandoned_cart_max_reminders" class="form-control" min="1" max="5" value="<?php echo htmlspecialchars($settings['abandoned_cart_max_reminders'] ?? '2'); ?>">
                        </div>
                        <div class="col-md-4 d-flex align-items-end">
                            <label class="settings-toggle w-100 mb-0">
                                <input type="hidden" name="abandoned_cart_whatsapp_enabled" value="0" id="hidden_abandoned_cart_whatsapp_enabled" <?php echo ($settings['abandoned_cart_whatsapp_enabled'] ?? '0') == '1' ? 'disabled' : ''; ?>>
                                <input class="form-check-input" type="checkbox" name="abandoned_cart_whatsapp_enabled" id="abandoned_cart_whatsapp_enabled" value="1" data-hidden-pair="hidden_abandoned_cart_whatsapp_enabled" <?php echo ($settings['abandoned_cart_whatsapp_enabled'] ?? '0') == '1' ? 'checked' : ''; ?>>
                                <span class="settings-toggle-body">
                                    <span class="settings-toggle-title">Auto WhatsApp Reminder</span>
                                </span>
                            </label>
                        </div>
                    </div>

                    <div class="settings-subsection mt-4">
                        <p class="settings-var-hint mb-3"><i class="fas fa-code me-1"></i> Variables: {name}, {total}, {products}, {recovery_link}, {site_name}, {phone}</p>
                        <div class="row g-3">
                            <div class="col-md-6">
                                <label class="form-label">Abandoned Cart SMS Template</label>
                                <textarea name="abandoned_cart_sms_text" class="form-control" rows="4"><?php echo htmlspecialchars($settings['abandoned_cart_sms_text'] ?? 'হ্যালো {name}! {site_name}-এ আপনার কার্টে ৳{total} এর পণ্য ({products}) রয়েছে। অর্ডার সম্পূর্ণ করুন: {recovery_link}'); ?></textarea>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label">Abandoned Cart WhatsApp Template</label>
                                <textarea name="abandoned_cart_whatsapp_text" class="form-control" rows="4"><?php echo htmlspecialchars($settings['abandoned_cart_whatsapp_text'] ?? "হ্যালো {name}! 👋\n\n{site_name}-এ আপনার কার্টে ৳{total} এর পণ্য ({products}) রয়েছে।\n\nঅর্ডার সম্পূর্ণ করতে ক্লিক করুন:\n{recovery_link}"); ?></textarea>
                            </div>
                        </div>
                    </div>

                    <div class="settings-subsection mt-4">
                        <h3 class="settings-subsection-title">WhatsApp Cloud API (Auto Send)</h3>
                        <p class="form-text mb-3">Meta Business Suite থেকে Access Token ও Phone Number ID নিন। না থাকলে Admin → Abandoned Carts থেকে ম্যানুয়াল WhatsApp বাটন ব্যবহার করুন।</p>

                        <label class="settings-toggle mb-3">
                            <input type="hidden" name="wa_api_enabled" value="0" id="hidden_wa_api_enabled" <?php echo ($settings['wa_api_enabled'] ?? '0') == '1' ? 'disabled' : ''; ?>>
                            <input class="form-check-input" type="checkbox" name="wa_api_enabled" id="wa_api_enabled" value="1" data-hidden-pair="hidden_wa_api_enabled" <?php echo ($settings['wa_api_enabled'] ?? '0') == '1' ? 'checked' : ''; ?>>
                            <span class="settings-toggle-body">
                                <span class="settings-toggle-title">Enable WhatsApp Cloud API</span>
                            </span>
                        </label>

                        <div class="row g-3">
                            <div class="col-md-6">
                                <label class="form-label">WhatsApp Access Token</label>
                                <input type="text" name="wa_api_token" class="form-control" value="<?php echo htmlspecialchars($settings['wa_api_token'] ?? ''); ?>" placeholder="EAAxxxx...">
                            </div>
                            <div class="col-md-6">
                                <label class="form-label">Phone Number ID</label>
                                <input type="text" name="wa_phone_number_id" class="form-control" value="<?php echo htmlspecialchars($settings['wa_phone_number_id'] ?? ''); ?>" placeholder="e.g. 123456789012345">
                            </div>
                        </div>
                    </div>
                </div>
                <div class="settings-save-bar">
                    <button type="submit" class="btn btn-primary px-4 fw-semibold">
                        <i class="fas fa-save me-2"></i>Save Abandoned Cart Settings
                    </button>
                </div>
            </form>
        </section>

        <!-- ═══ Email / SMTP ═══ -->
        <section class="settings-panel" id="settings-email">
            <div class="settings-panel-header">
                <div class="settings-panel-icon red"><i class="fas fa-envelope"></i></div>
                <div>
                    <h2 class="settings-panel-title">ইমেইল / SMTP (Gmail)</h2>
                    <p class="settings-panel-desc">ডিজিটাল প্রোডাক্ট ডেলিভারি ইমেইল</p>
                </div>
            </div>
            <form action="actions/settings-save.php" method="POST" class="settings-form" id="emailSettingsForm">
                <div class="settings-panel-body">
                    <label class="settings-toggle mb-3">
                        <input type="hidden" name="email_enabled" value="0" id="hidden_email_enabled" <?php echo ($settings['email_enabled'] ?? '0') == '1' ? 'disabled' : ''; ?>>
                        <input class="form-check-input" type="checkbox" name="email_enabled" id="email_enabled" value="1" data-hidden-pair="hidden_email_enabled" <?php echo ($settings['email_enabled'] ?? '0') == '1' ? 'checked' : ''; ?>>
                        <span class="settings-toggle-body">
                            <span class="settings-toggle-title">Enable Automated Email Delivery</span>
                            <span class="settings-toggle-desc">চালু করলে ডিজিটাল প্রোডাক্ট পেমেন্ট “Paid” হওয়ার সাথে সাথে কাস্টমারের মেইলে ডাউনলোড লিংক চলে যাবে।</span>
                        </span>
                    </label>

                    <div class="row g-3">
                        <div class="col-md-4">
                            <label class="form-label">SMTP Host</label>
                            <input type="text" name="smtp_host" class="form-control" value="<?php echo htmlspecialchars($settings['smtp_host'] ?? 'smtp.gmail.com'); ?>">
                        </div>
                        <div class="col-md-2">
                            <label class="form-label">SMTP Port</label>
                            <input type="text" name="smtp_port" class="form-control" value="<?php echo htmlspecialchars($settings['smtp_port'] ?? '587'); ?>">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">SMTP Username (Gmail)</label>
                            <input type="email" name="smtp_user" class="form-control" value="<?php echo htmlspecialchars($settings['smtp_user'] ?? ''); ?>" placeholder="your-email@gmail.com">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">SMTP Password (App Password)</label>
                            <input type="password" name="smtp_pass" class="form-control" value="<?php echo htmlspecialchars($settings['smtp_pass'] ?? ''); ?>" placeholder="Enter App Password">
                            <div class="form-text">জিমেইলের জন্য অবশ্যই “App Password” ব্যবহার করতে হবে।</div>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">SMTP Encryption</label>
                            <select name="smtp_encryption" class="form-select">
                                <option value="tls" <?php echo ($settings['smtp_encryption'] ?? 'tls') == 'tls' ? 'selected' : ''; ?>>TLS (Recommended for 587)</option>
                                <option value="ssl" <?php echo ($settings['smtp_encryption'] ?? '') == 'ssl' ? 'selected' : ''; ?>>SSL (Port 465)</option>
                            </select>
                        </div>
                    </div>

                    <div class="settings-subsection mt-4">
                        <h3 class="settings-subsection-title">Email Templates</h3>
                        <p class="settings-var-hint"><i class="fas fa-code me-1"></i> Variables: {customer_name}, {order_id}, {download_links}</p>
                        <label class="form-label">Digital Delivery Email Body</label>
                        <textarea name="email_digital_delivery_text" class="form-control" rows="6"><?php
                            echo htmlspecialchars($settings['email_digital_delivery_text'] ?? "আস্সালামু আলাইকুম {customer_name},\n\nআপনার ডিজিটাল প্রোডাক্টের অর্ডার #{order_id} সফলভাবে সম্পন্ন হয়েছে। নিচে আপনার কাঙ্ক্ষিত প্রোডাক্টটির ডাউনলোড লিংক দেওয়া হলো:\n\n{download_links}\n\nধন্যবাদ,\nKhati Raj BD");
                        ?></textarea>
                    </div>
                </div>
                <div class="settings-save-bar">
                    <button type="submit" class="btn btn-primary px-4 fw-semibold">
                        <i class="fas fa-save me-2"></i>Save Email Settings
                    </button>
                </div>
            </form>
        </section>

        <!-- ═══ Social Links ═══ -->
        <section class="settings-panel" id="settings-social">
            <div class="settings-panel-header">
                <div class="settings-panel-icon blue"><i class="fas fa-share-alt"></i></div>
                <div class="flex-grow-1">
                    <h2 class="settings-panel-title">সোশ্যাল মিডিয়া লিংক</h2>
                    <p class="settings-panel-desc">ফুটার ও হেডারে দেখানো প্ল্যাটফর্ম লিংক</p>
                </div>
                <button class="btn btn-primary btn-sm fw-semibold" data-bs-toggle="modal" data-bs-target="#addSocialModal">
                    <i class="fas fa-plus me-1"></i> Add New Link
                </button>
            </div>
            <div class="settings-panel-body p-0">
                <div class="admin-table-wrap">
                    <table class="admin-table admin-table-mobile-cards mb-0">
                        <thead>
                            <tr>
                                <th>Platform</th>
                                <th>Icon</th>
                                <th>URL</th>
                                <th>Order</th>
                                <th>Status</th>
                                <th class="text-end">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (empty($social_links)): ?>
                                <tr>
                                    <td colspan="6" class="text-center py-5">
                                        <div class="empty-state py-4">
                                            <div class="empty-icon"><i class="fas fa-share-alt"></i></div>
                                            <h5>কোনো সোশ্যাল লিংক নেই</h5>
                                            <p>প্রথম সোশ্যাল মিডিয়া লিংক যোগ করুন</p>
                                            <button type="button" class="btn btn-primary btn-sm" data-bs-toggle="modal" data-bs-target="#addSocialModal">
                                                <i class="fas fa-plus me-1"></i> Add New Link
                                            </button>
                                        </div>
                                    </td>
                                </tr>
                            <?php else: ?>
                                <?php foreach ($social_links as $link): ?>
                                    <tr>
                                        <td data-label="Platform" class="fw-semibold"><?php echo htmlspecialchars($link['platform_name']); ?></td>
                                        <td data-label="Icon"><i class="<?php echo htmlspecialchars($link['icon_class']); ?> fs-5"></i></td>
                                        <td data-label="URL">
                                            <a href="<?php echo htmlspecialchars($link['url']); ?>" target="_blank" rel="noopener" class="text-decoration-none small text-truncate d-inline-block" style="max-width: 220px;"><?php echo htmlspecialchars($link['url']); ?></a>
                                        </td>
                                        <td data-label="Order"><?php echo (int) $link['sort_order']; ?></td>
                                        <td data-label="Status">
                                            <?php if ($link['status']): ?>
                                                <span class="status-badge active">Active</span>
                                            <?php else: ?>
                                                <span class="status-badge inactive">Hidden</span>
                                            <?php endif; ?>
                                        </td>
                                        <td data-label="Actions" class="text-end">
                                            <div class="btn-group">
                                                <button type="button" class="btn btn-sm btn-outline-primary edit-social-btn" data-social='<?php echo htmlspecialchars(json_encode($link), ENT_QUOTES, 'UTF-8'); ?>' data-bs-toggle="modal" data-bs-target="#editSocialModal">
                                                    <i class="fas fa-edit"></i>
                                                </button>
                                                <form action="actions/social-actions.php" method="POST" class="d-inline" onsubmit="return confirm('Delete this social link?')">
                                                    <input type="hidden" name="id" value="<?php echo (int) $link['id']; ?>">
                                                    <button type="submit" name="action" value="delete" class="btn btn-sm btn-outline-danger">
                                                        <i class="fas fa-trash"></i>
                                                    </button>
                                                </form>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </section>

    </div>
</div>

<!-- Add Social Modal -->
<div class="modal fade" id="addSocialModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content border-0 shadow-lg rounded-4">
            <div class="modal-header border-0 bg-primary text-white">
                <h5 class="modal-title fw-bold">Add Social Link</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <form action="actions/social-actions.php" method="POST">
                <div class="modal-body p-4">
                    <div class="mb-3">
                        <label class="form-label fw-semibold">Platform Name</label>
                        <input type="text" name="platform_name" class="form-control" placeholder="e.g. Facebook" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-semibold">Icon Class (FontAwesome)</label>
                        <input type="text" name="icon_class" class="form-control" placeholder="e.g. fab fa-facebook" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-semibold">URL</label>
                        <input type="url" name="url" class="form-control" placeholder="https://..." required>
                    </div>
                    <div class="row">
                        <div class="col-6 mb-3">
                            <label class="form-label fw-semibold">Sort Order</label>
                            <input type="number" name="sort_order" class="form-control" value="0">
                        </div>
                        <div class="col-6 mb-3">
                            <label class="form-label fw-semibold">Status</label>
                            <select name="status" class="form-select">
                                <option value="1">Active</option>
                                <option value="0">Hidden</option>
                            </select>
                        </div>
                    </div>
                </div>
                <div class="modal-footer border-0 p-4 pt-0">
                    <button type="button" class="btn btn-light px-4" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" name="action" value="add" class="btn btn-primary px-4 fw-semibold">Add Link</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Edit Social Modal -->
<div class="modal fade" id="editSocialModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content border-0 shadow-lg rounded-4">
            <div class="modal-header border-0 bg-dark text-white">
                <h5 class="modal-title fw-bold">Edit Social Link</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <form action="actions/social-actions.php" method="POST">
                <input type="hidden" name="id" id="edit-social-id">
                <div class="modal-body p-4">
                    <div class="mb-3">
                        <label class="form-label fw-semibold">Platform Name</label>
                        <input type="text" name="platform_name" id="edit-social-name" class="form-control" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-semibold">Icon Class (FontAwesome)</label>
                        <input type="text" name="icon_class" id="edit-social-icon" class="form-control" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-semibold">URL</label>
                        <input type="url" name="url" id="edit-social-url" class="form-control" required>
                    </div>
                    <div class="row">
                        <div class="col-6 mb-3">
                            <label class="form-label fw-semibold">Sort Order</label>
                            <input type="number" name="sort_order" id="edit-social-order" class="form-control">
                        </div>
                        <div class="col-6 mb-3">
                            <label class="form-label fw-semibold">Status</label>
                            <select name="status" id="edit-social-status" class="form-select">
                                <option value="1">Active</option>
                                <option value="0">Hidden</option>
                            </select>
                        </div>
                    </div>
                </div>
                <div class="modal-footer border-0 p-4 pt-0">
                    <button type="button" class="btn btn-light px-4" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" name="action" value="edit" class="btn btn-primary px-4 fw-semibold">Update Link</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
(function () {
    // Tabs + toggles handled by admin/js/admin-tabs.js
    function initSocialEdit() {
        document.querySelectorAll('.edit-social-btn').forEach(function (btn) {
            if (btn.dataset.settingsSocialBound) return;
            btn.dataset.settingsSocialBound = '1';
            btn.addEventListener('click', function () {
                var data = JSON.parse(this.getAttribute('data-social'));
                document.getElementById('edit-social-id').value = data.id;
                document.getElementById('edit-social-name').value = data.platform_name;
                document.getElementById('edit-social-icon').value = data.icon_class;
                document.getElementById('edit-social-url').value = data.url;
                document.getElementById('edit-social-order').value = data.sort_order;
                document.getElementById('edit-social-status').value = data.status;
            });
        });
    }
    document.addEventListener('DOMContentLoaded', initSocialEdit);
    window.addEventListener('pjax:complete', initSocialEdit);
    if (document.readyState !== 'loading') initSocialEdit();
})();
</script>
