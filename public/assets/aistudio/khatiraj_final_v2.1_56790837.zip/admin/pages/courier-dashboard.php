<?php
// admin/pages/courier-dashboard.php
// Courier (Steadfast) — dedicated section: analytics dashboard, consignments,
// live balance/payments/returns from the Steadfast API, and settings.

$settings = [];
try {
    $settings = $pdo->query("SELECT key_name, value FROM settings WHERE key_name IN ('steadfast_api_key', 'steadfast_secret_key', 'steadfast_note')")->fetchAll(PDO::FETCH_KEY_PAIR);
} catch (PDOException $e) {}

$api_configured = !empty($settings['steadfast_api_key']) && !empty($settings['steadfast_secret_key']);

$active_tab = $_GET['tab'] ?? 'overview';
if (!in_array($active_tab, ['overview', 'consignments', 'payments', 'returns', 'settings'], true)) {
    $active_tab = 'overview';
}
if (isset($_GET['success']) || isset($_GET['error'])) {
    // After saving settings, stay on the settings tab
    $active_tab = $_GET['tab'] ?? 'settings';
}

// ─── Local analytics (orders sent to Steadfast) ───
$stats = ['sent' => 0, 'delivered' => 0, 'cancelled' => 0, 'in_transit' => 0, 'cod_total' => 0.0, 'cod_delivered' => 0.0];
$status_breakdown = [];
$daily_series = [];

try {
    $row = $pdo->query("
        SELECT
            COUNT(*) AS sent,
            SUM(courier_status = 'delivered') AS delivered,
            SUM(courier_status = 'cancelled') AS cancelled,
            SUM(courier_status IS NULL OR courier_status NOT IN ('delivered', 'cancelled')) AS in_transit,
            COALESCE(SUM(total_amount), 0) AS cod_total,
            COALESCE(SUM(CASE WHEN courier_status = 'delivered' THEN total_amount END), 0) AS cod_delivered
        FROM orders
        WHERE courier_consignment_id IS NOT NULL
    ")->fetch(PDO::FETCH_ASSOC) ?: [];
    foreach ($stats as $k => $v) {
        $stats[$k] = $row[$k] ?? 0;
    }

    $status_breakdown = $pdo->query("
        SELECT COALESCE(courier_status, 'not_synced') AS cs, COUNT(*) AS total, COALESCE(SUM(total_amount), 0) AS amount
        FROM orders
        WHERE courier_consignment_id IS NOT NULL
        GROUP BY cs
        ORDER BY total DESC
    ")->fetchAll();

    // Last 30 days: consignments created per day
    for ($i = 29; $i >= 0; $i--) {
        $d = date('Y-m-d', strtotime("-{$i} days"));
        $daily_series[$d] = ['label' => date('M j', strtotime($d)), 'sent' => 0, 'delivered' => 0];
    }
    $rows = $pdo->query("
        SELECT DATE(created_at) AS d,
               COUNT(*) AS sent,
               SUM(courier_status = 'delivered') AS delivered
        FROM orders
        WHERE courier_consignment_id IS NOT NULL
          AND created_at >= NOW() - INTERVAL 30 DAY
        GROUP BY DATE(created_at)
    ")->fetchAll();
    foreach ($rows as $r) {
        if (isset($daily_series[$r['d']])) {
            $daily_series[$r['d']]['sent'] = (int) $r['sent'];
            $daily_series[$r['d']]['delivered'] = (int) $r['delivered'];
        }
    }
} catch (PDOException $e) {}

$delivery_rate = ($stats['delivered'] + $stats['cancelled']) > 0
    ? round(($stats['delivered'] / ($stats['delivered'] + $stats['cancelled'])) * 100, 1)
    : 0;

// ─── Consignment list (Consignments tab) ───
$cs_filter = $_GET['cs'] ?? 'all';
$cs_search = trim($_GET['q'] ?? '');
$per_page = 25;
$pg = max(1, (int) ($_GET['pg'] ?? 1));

$conditions = ['courier_consignment_id IS NOT NULL'];
$params = [];
if ($cs_filter === 'in_transit') {
    $conditions[] = "(courier_status IS NULL OR courier_status NOT IN ('delivered', 'cancelled'))";
} elseif ($cs_filter !== 'all') {
    $conditions[] = 'courier_status = ?';
    $params[] = $cs_filter;
}
if ($cs_search !== '') {
    $conditions[] = '(customer_name LIKE ? OR customer_phone LIKE ? OR tracking_id LIKE ? OR courier_consignment_id LIKE ?)';
    $like = '%' . $cs_search . '%';
    array_push($params, $like, $like, $like, $like);
}
$whereSql = implode(' AND ', $conditions);

$consignments = [];
$total_rows = 0;
try {
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM orders WHERE $whereSql");
    $stmt->execute($params);
    $total_rows = (int) $stmt->fetchColumn();

    $offset = ($pg - 1) * $per_page;
    $stmt = $pdo->prepare("SELECT * FROM orders WHERE $whereSql ORDER BY id DESC LIMIT $per_page OFFSET $offset");
    $stmt->execute($params);
    $consignments = $stmt->fetchAll();
} catch (PDOException $e) {}

$total_pages = max(1, (int) ceil($total_rows / $per_page));

// Courier status badge with proper colors
function courierStatusBadge(?string $status): string {
    $status = $status ?: 'not_synced';
    $map = [
        'delivered' => ['delivered', 'Delivered'],
        'partial_delivered' => ['shipped', 'Partial Delivered'],
        'cancelled' => ['cancelled', 'Cancelled'],
        'in_review' => ['processing', 'In Review'],
        'pending' => ['pending', 'Pending'],
        'hold' => ['inactive', 'Hold'],
        'delivered_approval_pending' => ['processing', 'Delivery Approval'],
        'partial_delivered_approval_pending' => ['processing', 'Partial Approval'],
        'cancelled_approval_pending' => ['pending', 'Cancel Approval'],
        'unknown_approval_pending' => ['inactive', 'Unknown Pending'],
        'unknown' => ['inactive', 'Unknown'],
        'not_synced' => ['inactive', 'Not Synced'],
    ];
    [$class, $label] = $map[$status] ?? ['inactive', ucwords(str_replace('_', ' ', $status))];
    return '<span class="status-badge ' . $class . '">' . $label . '</span>';
}

// Chart payloads
$chart_labels = json_encode(array_column(array_values($daily_series), 'label'));
$chart_sent = json_encode(array_column(array_values($daily_series), 'sent'));
$chart_delivered = json_encode(array_column(array_values($daily_series), 'delivered'));
$pie_labels = json_encode(array_map(fn($r) => ucwords(str_replace('_', ' ', $r['cs'])), $status_breakdown));
$pie_counts = json_encode(array_map(fn($r) => (int) $r['total'], $status_breakdown));
?>

<?php adminFlashMessages(); ?>
<?php adminPageHeader('Courier (Steadfast)', 'কুরিয়ার অ্যানালিটিক্স, কনসাইনমেন্ট, ব্যালেন্স ও পেমেন্ট — সব এক জায়গায়'); ?>

<?php if (!$api_configured): ?>
    <div class="admin-flash error">
        <i class="fas fa-triangle-exclamation me-2"></i>
        <strong>Steadfast API configured নেই।</strong> Settings ট্যাবে API Key ও Secret Key দিন।
    </div>
<?php endif; ?>

<div class="d-flex flex-wrap justify-content-between align-items-center gap-2 mb-4">
    <nav class="admin-tabs flex-grow-1 mb-0" style="position:static; background:transparent; backdrop-filter:none; margin:0; padding:0;" aria-label="Courier sections">
        <div class="admin-tabs-track" role="tablist">
            <button type="button" class="admin-tab <?php echo $active_tab === 'overview' ? 'active' : ''; ?>" data-bs-toggle="pill" data-bs-target="#cr-overview" role="tab" aria-selected="<?php echo $active_tab === 'overview' ? 'true' : 'false'; ?>"><i class="fas fa-chart-line"></i><span>Overview</span></button>
            <button type="button" class="admin-tab <?php echo $active_tab === 'consignments' ? 'active' : ''; ?>" data-bs-toggle="pill" data-bs-target="#cr-consignments" role="tab" aria-selected="<?php echo $active_tab === 'consignments' ? 'true' : 'false'; ?>"><i class="fas fa-boxes-stacked"></i><span>Consignments</span><span class="badge bg-light text-dark ms-1"><?php echo number_format($stats['sent']); ?></span></button>
            <button type="button" class="admin-tab <?php echo $active_tab === 'payments' ? 'active' : ''; ?>" data-bs-toggle="pill" data-bs-target="#cr-payments" role="tab" id="cr-payments-tab" aria-selected="<?php echo $active_tab === 'payments' ? 'true' : 'false'; ?>"><i class="fas fa-money-bill-wave"></i><span>Payments</span></button>
            <button type="button" class="admin-tab <?php echo $active_tab === 'returns' ? 'active' : ''; ?>" data-bs-toggle="pill" data-bs-target="#cr-returns" role="tab" id="cr-returns-tab" aria-selected="<?php echo $active_tab === 'returns' ? 'true' : 'false'; ?>"><i class="fas fa-rotate-left"></i><span>Returns</span></button>
            <button type="button" class="admin-tab <?php echo $active_tab === 'settings' ? 'active' : ''; ?>" data-bs-toggle="pill" data-bs-target="#cr-settings" role="tab" aria-selected="<?php echo $active_tab === 'settings' ? 'true' : 'false'; ?>"><i class="fas fa-sliders-h"></i><span>Settings</span></button>
        </div>
    </nav>
    <button type="button" class="btn btn-sm btn-primary px-3" id="cr-sync-all" <?php echo $api_configured ? '' : 'disabled'; ?>>
        <i class="fas fa-arrows-rotate me-1"></i> Sync All Statuses
    </button>
</div>

<div class="tab-content">

<!-- ════════════ TAB: OVERVIEW ════════════ -->
<div class="tab-pane fade <?php echo $active_tab === 'overview' ? 'show active' : ''; ?>" id="cr-overview">

    <div class="admin-kpi-row row g-3">
        <div class="col-md-3 col-6">
            <div class="stat-card">
                <div class="d-flex justify-content-between align-items-start mb-3">
                    <div class="stat-icon green"><i class="fas fa-wallet"></i></div>
                    <button type="button" class="btn btn-sm btn-link p-0 text-muted" onclick="crLoadBalance()" title="Refresh"><i class="fas fa-arrows-rotate"></i></button>
                </div>
                <div class="stat-value" id="cr-balance"><span class="spinner-border spinner-border-sm text-muted"></span></div>
                <div class="stat-label">Steadfast Balance (Live)</div>
            </div>
        </div>
        <div class="col-md-3 col-6"><?php adminStatCard('Total Consignments', number_format($stats['sent']), 'fa-boxes-stacked', 'blue'); ?></div>
        <div class="col-md-3 col-6"><?php adminStatCard('In Transit', number_format($stats['in_transit']), 'fa-truck-fast', 'amber'); ?></div>
        <div class="col-md-3 col-6"><?php adminStatCard('Delivery Success', $delivery_rate . '%', 'fa-circle-check', 'green', number_format($stats['delivered']) . ' delivered'); ?></div>
    </div>

    <div class="row g-3 mb-4">
        <div class="col-md-6">
            <div class="admin-metric-strip">
                <div>
                    <div class="label">মোট COD পাঠানো হয়েছে</div>
                    <div class="value">৳<?php echo number_format((float) $stats['cod_total']); ?></div>
                </div>
                <i class="fas fa-hand-holding-dollar fa-2x text-secondary opacity-50"></i>
            </div>
        </div>
        <div class="col-md-6">
            <div class="admin-metric-strip">
                <div>
                    <div class="label">Delivered COD (collected)</div>
                    <div class="value text-success">৳<?php echo number_format((float) $stats['cod_delivered']); ?></div>
                </div>
                <i class="fas fa-sack-dollar fa-2x text-success opacity-50"></i>
            </div>
        </div>
    </div>

    <?php if ($stats['sent'] == 0): ?>
        <div class="admin-list-shell mb-4">
            <div class="p-4">
                <?php adminEmptyState('এখনো কোনো অর্ডার Steadfast-এ পাঠানো হয়নি', 'Order view পেজ থেকে "Send to Steadfast" করলে এখানে analytics দেখা যাবে', 'fa-truck-fast'); ?>
            </div>
        </div>
    <?php else: ?>
    <div class="row g-4 mb-4">
        <div class="col-lg-8">
            <div class="admin-list-shell h-100">
                <div class="admin-list-shell-header">
                    <h2 class="admin-list-shell-title">Consignments — Last 30 Days</h2>
                </div>
                <div class="p-4">
                    <div style="height: 300px;"><canvas id="crTimelineChart"></canvas></div>
                </div>
            </div>
        </div>
        <div class="col-lg-4">
            <div class="admin-list-shell h-100">
                <div class="admin-list-shell-header">
                    <h2 class="admin-list-shell-title">Status Distribution</h2>
                </div>
                <div class="p-4">
                    <div style="height: 220px;" class="mb-3"><canvas id="crStatusChart"></canvas></div>
                    <div class="admin-table-wrap">
                        <table class="admin-table mb-0" style="font-size:0.8rem;">
                            <tbody>
                                <?php foreach ($status_breakdown as $sb): ?>
                                <tr>
                                    <td><?php echo courierStatusBadge($sb['cs']); ?></td>
                                    <td class="text-center fw-bold"><?php echo number_format($sb['total']); ?></td>
                                    <td class="text-end text-muted">৳<?php echo number_format((float) $sb['amount']); ?></td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php endif; ?>
</div>

<!-- ════════════ TAB: CONSIGNMENTS ════════════ -->
<div class="tab-pane fade <?php echo $active_tab === 'consignments' ? 'show active' : ''; ?>" id="cr-consignments">

    <div class="admin-filter-bar mb-3">
        <div class="admin-filter-row align-items-center">
            <div class="btn-group btn-group-sm">
                <?php foreach (['all' => 'All', 'in_transit' => 'In Transit', 'delivered' => 'Delivered', 'cancelled' => 'Cancelled'] as $key => $label): ?>
                    <a href="index.php?page=courier-dashboard&tab=consignments&cs=<?php echo $key; ?><?php echo $cs_search !== '' ? '&q=' . urlencode($cs_search) : ''; ?>"
                       class="btn <?php echo $cs_filter === $key ? 'btn-primary' : 'btn-outline-secondary'; ?>"><?php echo $label; ?></a>
                <?php endforeach; ?>
            </div>
            <form method="GET" action="index.php" class="d-flex ms-auto" style="max-width: 340px; width: 100%;">
                <input type="hidden" name="page" value="courier-dashboard">
                <input type="hidden" name="tab" value="consignments">
                <input type="hidden" name="cs" value="<?php echo htmlspecialchars($cs_filter); ?>">
                <div class="input-group input-group-sm">
                    <span class="input-group-text bg-white border-end-0"><i class="fas fa-search text-muted"></i></span>
                    <input type="text" name="q" class="form-control border-start-0" placeholder="নাম / ফোন / tracking খুঁজুন..." value="<?php echo htmlspecialchars($cs_search); ?>">
                    <button type="submit" class="btn btn-primary">Search</button>
                </div>
            </form>
        </div>
    </div>

    <div class="admin-list-shell mb-3">
        <div class="admin-list-shell-header">
            <h2 class="admin-list-shell-title">Consignments</h2>
            <span class="text-muted small fw-semibold"><?php echo number_format($total_rows); ?> records</span>
        </div>
        <div class="admin-table-wrap">
            <table class="admin-table admin-table-mobile-cards">
                <thead>
                    <tr>
                        <th scope="col">Order</th>
                        <th scope="col">Customer</th>
                        <th scope="col">Tracking</th>
                        <th scope="col">COD</th>
                        <th scope="col">Courier Status</th>
                        <th scope="col">Order Status</th>
                        <th scope="col">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($consignments)): ?>
                        <tr><td colspan="7"><?php adminEmptyState('কোনো consignment নেই', 'অর্ডার Steadfast-এ পাঠালে এখানে দেখা যাবে', 'fa-boxes-stacked'); ?></td></tr>
                    <?php else: ?>
                        <?php foreach ($consignments as $order): ?>
                        <tr id="cr-row-<?php echo $order['id']; ?>">
                            <td>
                                <a href="index.php?page=order-view&id=<?php echo $order['id']; ?>" class="fw-bold text-decoration-none">#<?php echo $order['id']; ?></a>
                                <small class="text-muted d-block"><?php echo date('d M, h:i A', strtotime($order['created_at'])); ?></small>
                            </td>
                            <td>
                                <div class="fw-semibold"><?php echo htmlspecialchars($order['customer_name']); ?></div>
                                <small class="text-muted"><?php echo htmlspecialchars($order['customer_phone']); ?></small>
                            </td>
                            <td>
                                <code class="user-select-all"><?php echo htmlspecialchars($order['tracking_id']); ?></code>
                                <small class="text-muted d-block">CID: <?php echo htmlspecialchars($order['courier_consignment_id']); ?></small>
                            </td>
                            <td class="fw-bold">৳<?php echo number_format((float) $order['total_amount']); ?></td>
                            <td class="cr-status-cell"><?php echo courierStatusBadge($order['courier_status']); ?></td>
                            <td><?php echo adminStatusBadge($order['order_status']); ?></td>
                            <td>
                                <div class="btn-group btn-group-sm">
                                    <button type="button" class="btn btn-outline-primary cr-sync-one" data-order-id="<?php echo $order['id']; ?>" title="Sync Status">
                                        <i class="fas fa-arrows-rotate"></i>
                                    </button>
                                    <a href="https://steadfast.com.bd/t/<?php echo urlencode($order['tracking_id']); ?>" target="_blank" class="btn btn-outline-secondary" title="Public Tracking Page">
                                        <i class="fas fa-map-location-dot"></i>
                                    </a>
                                    <a href="index.php?page=order-view&id=<?php echo $order['id']; ?>" class="btn btn-outline-dark" title="View Order">
                                        <i class="fas fa-eye"></i>
                                    </a>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <?php if ($total_pages > 1): ?>
    <nav class="d-flex justify-content-between align-items-center mb-4">
        <small class="text-muted"><?php echo number_format($total_rows); ?> consignments — page <?php echo $pg; ?> of <?php echo $total_pages; ?></small>
        <ul class="pagination pagination-sm mb-0">
            <?php
            $qs = 'index.php?page=courier-dashboard&tab=consignments&cs=' . $cs_filter . ($cs_search !== '' ? '&q=' . urlencode($cs_search) : '');
            for ($p = max(1, $pg - 2); $p <= min($total_pages, $pg + 2); $p++): ?>
                <li class="page-item <?php echo $p === $pg ? 'active' : ''; ?>">
                    <a class="page-link" href="<?php echo $qs . '&pg=' . $p; ?>"><?php echo $p; ?></a>
                </li>
            <?php endfor; ?>
        </ul>
    </nav>
    <?php endif; ?>
</div>

<!-- ════════════ TAB: PAYMENTS ════════════ -->
<div class="tab-pane fade <?php echo $active_tab === 'payments' ? 'show active' : ''; ?>" id="cr-payments">
    <div class="admin-list-shell mb-4">
        <div class="admin-list-shell-header">
            <h2 class="admin-list-shell-title"><i class="fas fa-money-bill-wave me-2 text-success"></i>Steadfast Payments (Live)</h2>
            <button type="button" class="btn btn-sm btn-outline-primary" onclick="crLoadPayments(true)"><i class="fas fa-arrows-rotate me-1"></i> Refresh</button>
        </div>
        <div class="p-4" id="cr-payments-body">
            <div class="text-center text-muted py-4"><span class="spinner-border spinner-border-sm me-2"></span>Loading payments from Steadfast...</div>
        </div>
    </div>
</div>

<!-- ════════════ TAB: RETURNS ════════════ -->
<div class="tab-pane fade <?php echo $active_tab === 'returns' ? 'show active' : ''; ?>" id="cr-returns">
    <div class="admin-list-shell mb-4">
        <div class="admin-list-shell-header">
            <h2 class="admin-list-shell-title"><i class="fas fa-rotate-left me-2 text-warning"></i>Return Requests (Live)</h2>
            <button type="button" class="btn btn-sm btn-outline-primary" onclick="crLoadReturns(true)"><i class="fas fa-arrows-rotate me-1"></i> Refresh</button>
        </div>
        <div class="p-4" id="cr-returns-body">
            <div class="text-center text-muted py-4"><span class="spinner-border spinner-border-sm me-2"></span>Loading return requests...</div>
        </div>
    </div>
</div>

<!-- ════════════ TAB: SETTINGS ════════════ -->
<div class="tab-pane fade <?php echo $active_tab === 'settings' ? 'show active' : ''; ?>" id="cr-settings">
    <section class="admin-panel is-active mb-4">
        <?php adminPanelHeader('Courier Settings (Steadfast)', 'API credentials ও ডিফল্ট ডেলিভারি নোট', 'fa-truck', 'amber'); ?>
        <div class="admin-panel-body">
            <form action="actions/settings-save.php" method="POST">
                <input type="hidden" name="redirect_to" value="courier-dashboard&tab=settings">
                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label class="form-label fw-bold">Steadfast API Key</label>
                        <input type="text" name="steadfast_api_key" class="form-control" value="<?php echo htmlspecialchars($settings['steadfast_api_key'] ?? ''); ?>" placeholder="Enter API Key">
                    </div>
                    <div class="col-md-6 mb-3">
                        <label class="form-label fw-bold">Steadfast Secret Key</label>
                        <input type="text" name="steadfast_secret_key" class="form-control" value="<?php echo htmlspecialchars($settings['steadfast_secret_key'] ?? ''); ?>" placeholder="Enter Secret Key">
                    </div>
                    <div class="col-12 mb-3">
                        <label class="form-label fw-bold">Default Delivery Note</label>
                        <textarea name="steadfast_note" class="form-control" rows="2" placeholder="e.g. Do not open product without permission..."><?php echo htmlspecialchars($settings['steadfast_note'] ?? ''); ?></textarea>
                        <div class="form-text">প্রতিটা অর্ডারের সাথে এই note Steadfast-এ যাবে।</div>
                    </div>
                </div>
                <div class="admin-save-bar px-0" style="position:static; border:0; background:transparent; padding-bottom:0;">
                    <button type="button" class="btn btn-outline-success px-4 fw-semibold" onclick="crTestConnection(this)">
                        <i class="fas fa-vial me-2"></i> Test Connection
                    </button>
                    <button type="submit" class="btn btn-primary px-4 fw-semibold">
                        <i class="fas fa-save me-2"></i> Save Courier Settings
                    </button>
                </div>
            </form>
        </div>
    </section>
</div>

</div><!-- /tab-content -->

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
(function() {
    var API = 'actions/courier-api.php';

    // ── Live balance ──
    window.crLoadBalance = function() {
        var el = document.getElementById('cr-balance');
        if (!el) return;
        el.innerHTML = '<span class="spinner-border spinner-border-sm text-muted"></span>';
        fetch(API + '?action=balance')
            .then(function(r) { return r.json(); })
            .then(function(data) {
                el.innerText = data.status === 'success' ? '৳' + Number(data.balance).toLocaleString() : '—';
                if (data.status !== 'success') el.title = data.message || '';
            })
            .catch(function() { el.innerText = '—'; });
    };
    crLoadBalance();

    // ── Payments (lazy-loaded) ──
    var paymentsLoaded = false;
    window.crLoadPayments = function(force) {
        if (paymentsLoaded && !force) return;
        paymentsLoaded = true;
        var body = document.getElementById('cr-payments-body');
        body.innerHTML = '<div class="text-center text-muted py-4"><span class="spinner-border spinner-border-sm me-2"></span>Loading payments from Steadfast...</div>';
        fetch(API + '?action=payments')
            .then(function(r) { return r.json(); })
            .then(function(data) {
                if (data.status !== 'success') {
                    body.innerHTML = '<div class="alert alert-warning mb-0">' + (data.message || 'Failed to load payments') + '</div>';
                    return;
                }
                var payments = data.payments || [];
                if (!payments.length) {
                    body.innerHTML = '<div class="text-center text-muted py-4"><i class="fas fa-inbox fa-2x mb-2 d-block"></i>কোনো payment পাওয়া যায়নি</div>';
                    return;
                }
                var html = '<div class="table-responsive"><table class="table table-hover align-middle small">' +
                    '<thead class="text-muted text-uppercase" style="font-size:0.7rem;"><tr>' +
                    '<th>ID</th><th>Amount</th><th>Status</th><th>Details</th><th>Date</th></tr></thead><tbody>';
                payments.forEach(function(p) {
                    var amount = p.total_amount ?? p.amount ?? p.paid_amount ?? '—';
                    var status = p.status ?? '—';
                    var date = (p.created_at || '').substring(0, 10);
                    html += '<tr>' +
                        '<td class="fw-bold">#' + (p.id ?? '—') + '</td>' +
                        '<td class="fw-bold text-success">৳' + Number(amount).toLocaleString() + '</td>' +
                        '<td><span class="badge bg-success-subtle text-success">' + status + '</span></td>' +
                        '<td><pre class="small text-muted mb-0" style="white-space:pre-wrap;max-width:340px;">' + crSummarize(p) + '</pre></td>' +
                        '<td class="text-muted">' + date + '</td></tr>';
                });
                html += '</tbody></table></div>';
                body.innerHTML = html;
            })
            .catch(function() {
                body.innerHTML = '<div class="alert alert-danger mb-0">Steadfast API-তে connect করা যায়নি</div>';
            });
    };

    // ── Returns (lazy-loaded) ──
    var returnsLoaded = false;
    window.crLoadReturns = function(force) {
        if (returnsLoaded && !force) return;
        returnsLoaded = true;
        var body = document.getElementById('cr-returns-body');
        body.innerHTML = '<div class="text-center text-muted py-4"><span class="spinner-border spinner-border-sm me-2"></span>Loading return requests...</div>';
        fetch(API + '?action=returns')
            .then(function(r) { return r.json(); })
            .then(function(data) {
                if (data.status !== 'success') {
                    body.innerHTML = '<div class="alert alert-warning mb-0">' + (data.message || 'Failed to load returns') + '</div>';
                    return;
                }
                var returns = data.returns || [];
                if (!returns.length) {
                    body.innerHTML = '<div class="text-center text-muted py-4"><i class="fas fa-circle-check fa-2x mb-2 d-block text-success"></i>কোনো return request নেই</div>';
                    return;
                }
                var html = '<div class="table-responsive"><table class="table table-hover align-middle small">' +
                    '<thead class="text-muted text-uppercase" style="font-size:0.7rem;"><tr>' +
                    '<th>ID</th><th>Consignment</th><th>Reason</th><th>Status</th><th>Date</th></tr></thead><tbody>';
                returns.forEach(function(r) {
                    html += '<tr>' +
                        '<td class="fw-bold">#' + (r.id ?? '—') + '</td>' +
                        '<td><code>' + (r.consignment_id ?? '—') + '</code></td>' +
                        '<td>' + (r.reason || '<span class="text-muted">—</span>') + '</td>' +
                        '<td><span class="badge bg-warning-subtle text-warning">' + (r.status ?? '—') + '</span></td>' +
                        '<td class="text-muted">' + ((r.created_at || '').substring(0, 10)) + '</td></tr>';
                });
                html += '</tbody></table></div>';
                body.innerHTML = html;
            })
            .catch(function() {
                body.innerHTML = '<div class="alert alert-danger mb-0">Steadfast API-তে connect করা যায়নি</div>';
            });
    };

    function crSummarize(obj) {
        var skip = ['id', 'created_at', 'updated_at', 'status'];
        var parts = [];
        Object.keys(obj).forEach(function(k) {
            if (skip.indexOf(k) === -1 && obj[k] !== null && typeof obj[k] !== 'object') {
                parts.push(k + ': ' + obj[k]);
            }
        });
        return parts.slice(0, 6).join('\n');
    }

    // Lazy-load payments/returns when their tab first opens
    var payTab = document.getElementById('cr-payments-tab');
    if (payTab) payTab.addEventListener('shown.bs.tab', function() { crLoadPayments(false); });
    var retTab = document.getElementById('cr-returns-tab');
    if (retTab) retTab.addEventListener('shown.bs.tab', function() { crLoadReturns(false); });
    <?php if ($active_tab === 'payments'): ?>crLoadPayments(false);<?php endif; ?>
    <?php if ($active_tab === 'returns'): ?>crLoadReturns(false);<?php endif; ?>

    // ── Sync all statuses ──
    var syncAllBtn = document.getElementById('cr-sync-all');
    if (syncAllBtn) {
        syncAllBtn.addEventListener('click', function() {
            syncAllBtn.disabled = true;
            syncAllBtn.innerHTML = '<span class="spinner-border spinner-border-sm me-1"></span> Syncing...';
            fetch(API + '?action=sync_all', { method: 'POST' })
                .then(function(r) { return r.json(); })
                .then(function(data) {
                    if (data.status === 'success') {
                        alert('Sync complete!\nChecked: ' + data.checked + '\nUpdated: ' + data.changed + (data.errors ? '\nErrors: ' + data.errors : ''));
                        window.location.reload();
                    } else {
                        alert('Sync failed: ' + (data.message || 'Unknown error'));
                        syncAllBtn.disabled = false;
                        syncAllBtn.innerHTML = '<i class="fas fa-arrows-rotate me-1"></i> Sync All Statuses';
                    }
                })
                .catch(function() {
                    alert('Steadfast API-তে connect করা যায়নি');
                    syncAllBtn.disabled = false;
                    syncAllBtn.innerHTML = '<i class="fas fa-arrows-rotate me-1"></i> Sync All Statuses';
                });
        });
    }

    // ── Sync single consignment ──
    document.querySelectorAll('.cr-sync-one').forEach(function(btn) {
        btn.addEventListener('click', function() {
            var orderId = btn.getAttribute('data-order-id');
            var icon = btn.querySelector('i');
            icon.classList.add('fa-spin');
            var formData = new FormData();
            formData.append('order_id', orderId);
            fetch('actions/sync-steadfast-status.php', {
                method: 'POST',
                headers: { 'X-Requested-With': 'XMLHttpRequest' },
                body: formData
            })
                .then(function(r) { return r.json(); })
                .then(function(data) {
                    icon.classList.remove('fa-spin');
                    if (data.status === 'success') {
                        window.location.reload();
                    } else {
                        alert('Sync failed: ' + (data.message || 'Unknown error'));
                    }
                })
                .catch(function() { icon.classList.remove('fa-spin'); });
        });
    });

    // ── Test connection (Settings tab) ──
    window.crTestConnection = function(btn) {
        var original = btn.innerHTML;
        btn.disabled = true;
        btn.innerHTML = '<span class="spinner-border spinner-border-sm me-1"></span> Testing...';
        fetch(API + '?action=balance')
            .then(function(r) { return r.json(); })
            .then(function(data) {
                btn.disabled = false;
                btn.innerHTML = original;
                if (data.status === 'success') {
                    alert('Connection successful!\nCurrent balance: ৳' + Number(data.balance).toLocaleString());
                } else {
                    alert('Connection failed: ' + (data.message || 'Invalid credentials'));
                }
            })
            .catch(function() {
                btn.disabled = false;
                btn.innerHTML = original;
                alert('Connection failed — network error');
            });
    };

    // ── Charts ──
    if (typeof Chart !== 'undefined') {
        var tl = document.getElementById('crTimelineChart');
        if (tl) {
            new Chart(tl, {
                data: {
                    labels: <?php echo $chart_labels; ?>,
                    datasets: [
                        {
                            type: 'bar',
                            label: 'Sent',
                            data: <?php echo $chart_sent; ?>,
                            backgroundColor: 'rgba(59, 130, 246, 0.65)',
                            borderRadius: 4
                        },
                        {
                            type: 'line',
                            label: 'Delivered',
                            data: <?php echo $chart_delivered; ?>,
                            borderColor: '#22c55e',
                            backgroundColor: 'rgba(34, 197, 94, 0.1)',
                            fill: true,
                            tension: 0.35,
                            pointRadius: 0
                        }
                    ]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    interaction: { mode: 'index', intersect: false },
                    plugins: { legend: { position: 'bottom', labels: { usePointStyle: true, boxHeight: 7 } } },
                    scales: {
                        x: { grid: { display: false } },
                        y: { beginAtZero: true, ticks: { precision: 0 } }
                    }
                }
            });
        }

        var pie = document.getElementById('crStatusChart');
        if (pie) {
            new Chart(pie, {
                type: 'doughnut',
                data: {
                    labels: <?php echo $pie_labels; ?>,
                    datasets: [{
                        data: <?php echo $pie_counts; ?>,
                        backgroundColor: ['#22c55e', '#f59e0b', '#ef4444', '#3b82f6', '#8b5cf6', '#06b6d4', '#64748b', '#ec4899'],
                        borderWidth: 3,
                        borderColor: '#ffffff'
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    cutout: '65%',
                    plugins: { legend: { position: 'bottom', labels: { usePointStyle: true, boxHeight: 7 } } }
                }
            });
        }
    }
})();
</script>
