<?php
// admin/pages/categories.php
$categories = $pdo->query("SELECT * FROM categories ORDER BY id DESC")->fetchAll();
?>

<?php adminFlashMessages(); ?>
<?php adminPageHeader('Categories', 'ক্যাটাগরি যোগ, সম্পাদনা ও স্ট্যাটাস ম্যানেজ করুন', [
    ['label' => 'নতুন ক্যাটাগরি', 'icon' => 'fa-plus', 'url' => '#', 'class' => 'btn btn-primary btn-sm', 'modal' => 'addCategoryModal'],
]); ?>

<!-- Toast for Notifications -->
<div class="toast-container position-fixed bottom-0 end-0 p-3" style="z-index: 1085;">
  <div id="categoryToast" class="toast" role="alert" aria-live="assertive" aria-atomic="true">
    <div class="toast-header">
      <strong class="me-auto">Notification</strong>
      <button type="button" class="btn-close" data-bs-dismiss="toast" aria-label="Close"></button>
    </div>
    <div class="toast-body" id="categoryToastMessage"></div>
  </div>
</div>

<style>
.status-badge {
    cursor: pointer;
    user-select: none;
    transition: transform 0.15s ease;
}
.status-badge:hover {
    transform: scale(1.05);
}
.bulk-bar {
    background: #f0fdf4;
    border: 1px solid #bbf7d0;
    border-radius: 12px;
    animation: fadeInSlide 0.25s ease-out;
}
@keyframes fadeInSlide {
    from { opacity: 0; transform: translateY(-10px); }
    to { opacity: 1; transform: translateY(0); }
}
</style>

<!-- Live Search and Filter Bar -->
<div class="admin-filter-bar">
    <div class="admin-filter-row">
        <div class="admin-filter-field" style="flex: 2 1 240px; max-width: none;">
            <label class="admin-filter-label">Search</label>
            <input type="search" id="category-search" class="form-control form-control-sm" placeholder="ক্যাটাগরি বা স্ল্যাগ সার্চ করুন..." oninput="filterCategories()">
        </div>
        <div class="admin-filter-actions">
            <span class="text-secondary small fw-bold">মোট: <span id="total-categories-count" class="text-primary"><?php echo count($categories); ?></span>টি</span>
        </div>
    </div>
</div>

<!-- Bulk Actions Panel (Hidden by default, shown when checkboxes are selected) -->
<div class="bulk-bar p-3 mb-4 align-items-center justify-content-between gap-3" id="bulk-actions-bar" style="display: none !important;">
    <div class="d-flex align-items-center gap-2">
        <i class="fas fa-check-square text-success fs-5"></i>
        <span class="fw-bold text-success small"><span id="selected-count">0</span>টি ক্যাটাগরি সিলেক্ট করা হয়েছে</span>
    </div>
    <div class="d-flex align-items-center gap-2">
        <select class="form-select form-select-sm" id="bulk-action-select" style="width: 200px;">
            <option value="">অ্যাকশন সিলেক্ট করুন...</option>
            <option value="active">সক্রিয় করুন (Status: Active)</option>
            <option value="inactive">নিষ্ক্রিয় করুন (Status: Inactive)</option>
            <option value="delete">মুছে ফেলুন (Bulk Delete)</option>
        </select>
        <button type="button" class="btn btn-success btn-sm px-4 fw-bold" onclick="applyBulkAction()">প্রয়োগ করুন</button>
    </div>
</div>

<div class="admin-list-shell">
  <div class="admin-list-shell-header">
    <h2 class="admin-list-shell-title">ক্যাটাগরি তালিকা</h2>
    <span class="text-muted small fw-semibold"><?php echo count($categories); ?>টি</span>
  </div>
  <div class="admin-table-wrap">
  <table class="admin-table admin-table-mobile-cards">
    <thead>
      <tr>
        <th scope="col" style="width: 40px;">
            <input type="checkbox" id="check-all" class="form-check-input" onclick="toggleCheckAll(this)">
        </th>
        <th scope="col" style="width: 50px;">#</th>
        <th scope="col" style="width: 80px;">আইকন</th>
        <th scope="col">নাম</th>
        <th scope="col">Slug</th>
        <th scope="col" style="width: 120px;">স্ট্যাটাস</th>
        <th scope="col" style="width: 120px;">অ্যাকশন</th>
      </tr>
    </thead>
    <tbody id="categoryTableBody">
      <?php if(count($categories) > 0): ?>
          <?php foreach ($categories as $cat): ?>
          <tr id="category-row-<?php echo $cat['id']; ?>" class="category-row" data-name="<?php echo htmlspecialchars($cat['name']); ?>" data-slug="<?php echo htmlspecialchars($cat['slug']); ?>">
            <td>
                <input type="checkbox" class="category-checkbox form-check-input" value="<?php echo $cat['id']; ?>" onclick="toggleRowCheck()">
            </td>
            <td><?php echo $cat['id']; ?></td>
            <td class="col-image">
                <?php if($cat['image']): ?>
                    <img src="../<?php echo $cat['image']; ?>" width="40" height="40" class="rounded border p-1" style="object-fit: contain;">
                <?php else: ?>
                    <span class="text-muted"><i class="fas fa-image fa-lg"></i></span>
                <?php endif; ?>
            </td>
            <td class="col-name fw-bold text-dark"><?php echo htmlspecialchars($cat['name']); ?></td>
            <td class="col-slug"><?php echo htmlspecialchars($cat['slug']); ?></td>
            <td class="col-status">
                <span class="badge bg-<?php echo $cat['status'] ? 'success' : 'secondary'; ?> status-badge" 
                      onclick="toggleCategoryStatus(<?php echo $cat['id']; ?>, this)"
                      title="ক্লিক করে স্ট্যাটাস সক্রিয়/নিষ্ক্রিয় করুন">
                    <?php echo $cat['status'] ? 'Active' : 'Inactive'; ?>
                </span>
            </td>
            <td>
                <div class="d-flex gap-1">
                    <button type="button" class="btn btn-sm btn-outline-secondary edit-category-btn" 
                            data-bs-toggle="modal" data-bs-target="#editCategoryModal"
                            data-id="<?php echo $cat['id']; ?>"
                            data-name="<?php echo htmlspecialchars($cat['name']); ?>"
                            data-slug="<?php echo htmlspecialchars($cat['slug']); ?>"
                            data-status="<?php echo $cat['status']; ?>"
                            data-h1_title="<?php echo htmlspecialchars($cat['h1_title'] ?? ''); ?>"
                            data-description="<?php echo htmlspecialchars($cat['description'] ?? ''); ?>"
                            data-meta_title="<?php echo htmlspecialchars($cat['meta_title'] ?? ''); ?>"
                            data-meta_description="<?php echo htmlspecialchars($cat['meta_description'] ?? ''); ?>"
                            data-meta_keywords="<?php echo htmlspecialchars($cat['meta_keywords'] ?? ''); ?>">
                        <i class="fas fa-edit"></i>
                    </button>
                    <button type="button" class="btn btn-sm btn-outline-danger delete-category-btn" data-id="<?php echo $cat['id']; ?>">
                        <i class="fas fa-trash"></i>
                    </button>
                </div>
            </td>
          </tr>
          <?php endforeach; ?>
      <?php else: ?>
          <tr id="no-categories-row"><td colspan="7"><?php adminEmptyState('কোনো ক্যাটাগরি নেই', 'উপরের "নতুন ক্যাটাগরি" বাটন থেকে যোগ করুন', 'fa-tags'); ?></td></tr>
      <?php endif; ?>
    </tbody>
  </table>
  </div>
</div>

<!-- Add Category Modal -->
<div class="modal fade" id="addCategoryModal" tabindex="-1">
  <div class="modal-dialog">
    <form id="addCategoryForm" class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">Add New Category</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>
      <div class="modal-body">
        <div class="mb-3">
            <label class="form-label">Category Name</label>
            <input type="text" name="name" id="add_cat_name" class="form-control" required>
        </div>
        <div class="mb-3">
            <label class="form-label">Slug / URL Key *</label>
            <input type="text" name="slug" id="add_cat_slug" class="form-control" required placeholder="যেমন: Modhu-o-Kalojeera">
            <div class="form-text">এসইও ফ্রেন্ডলি ক্যাটাগরি লিংকের জন্য (যেমন: <code>modhu-o-kalojeera</code>)</div>
        </div>
        <div class="mb-3">
            <label class="form-label">Icon / Image</label>
            <div class="media-picker-container text-center p-3 border rounded bg-light">
                <input type="hidden" name="image" id="add_cat_image">
                <img id="add_cat_image_preview" src="" class="img-fluid rounded mb-2 d-none" style="max-height: 100px;">
                <div id="add_cat_image_placeholder" class="py-2">
                    <i class="fas fa-image fa-2x text-muted mb-2"></i>
                    <p class="small text-muted mb-0">No image selected</p>
                </div>
                <button type="button" class="btn btn-sm btn-dark w-100 mt-2" onclick="openMediaPicker('add_cat_image')">
                    <i class="fas fa-images me-1"></i> Select from Media
                </button>
            </div>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        <button type="submit" class="btn btn-primary">Save Category</button>
      </div>
    </form>
  </div>
</div>

<!-- Edit Category Modal -->
<div class="modal fade" id="editCategoryModal" tabindex="-1">
  <div class="modal-dialog">
    <form id="editCategoryForm" class="modal-content">
      <input type="hidden" name="id" id="edit_cat_id">
      <div class="modal-header">
        <h5 class="modal-title">Edit Category</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>
      <div class="modal-body">
        <div class="mb-3">
            <label class="form-label">Category Name</label>
            <input type="text" name="name" id="edit_cat_name" class="form-control" required>
        </div>
        <div class="mb-3">
            <div class="d-flex justify-content-between align-items-center mb-1">
                <label class="form-label mb-0">Slug / URL Key *</label>
                <button type="button" class="btn btn-link btn-sm p-0 text-decoration-none" onclick="generateEditSlug()"><i class="fas fa-magic me-1"></i>Generate from Name</button>
            </div>
            <input type="text" name="slug" id="edit_cat_slug" class="form-control" required placeholder="যেমন: Modhu-o-Kalojeera">
            <div class="form-text">এসইও ফ্রেন্ডলি ক্যাটাগরি লিংকের জন্য (যেমন: <code>modhu-o-kalojeera</code>)</div>
        </div>
        <div class="mb-3">
            <label class="form-label">Icon / Image</label>
            <div class="media-picker-container text-center p-3 border rounded bg-light">
                <input type="hidden" name="image" id="edit_cat_image">
                <img id="edit_cat_image_preview" src="" class="img-fluid rounded mb-2 d-none" style="max-height: 100px;">
                <div id="edit_cat_image_placeholder" class="py-2">
                    <i class="fas fa-image fa-2x text-muted mb-2"></i>
                    <p class="small text-muted mb-0">No image selected</p>
                </div>
                <button type="button" class="btn btn-sm btn-dark w-100 mt-2" onclick="openMediaPicker('edit_cat_image')">
                    <i class="fas fa-images me-1"></i> Change Image
                </button>
            </div>
        </div>
        <div class="mb-3">
            <label class="form-label">Status</label>
            <select name="status" id="edit_cat_status" class="form-control">
                <option value="1">Active</option>
                <option value="0">Inactive</option>
            </select>
        </div>

        <hr>
        <h6 class="fw-bold text-primary mb-3"><i class="fas fa-search me-1"></i> SEO & Content</h6>
        <div class="mb-3">
            <label class="form-label">Page Heading (H1)</label>
            <input type="text" name="h1_title" id="edit_cat_h1_title" class="form-control" placeholder="Optional heading shown on category page">
        </div>
        <div class="mb-3">
            <label class="form-label">Category Intro Description</label>
            <textarea name="description" id="edit_cat_description" class="form-control" rows="2" placeholder="Short intro text for this category page"></textarea>
        </div>
        <div class="mb-3">
            <label class="form-label">Meta Title</label>
            <input type="text" name="meta_title" id="edit_cat_meta_title" class="form-control" placeholder="SEO title (leave empty to use name)">
        </div>
        <div class="mb-3">
            <label class="form-label">Meta Description</label>
            <textarea name="meta_description" id="edit_cat_meta_description" class="form-control" rows="2" placeholder="SEO description for search engines"></textarea>
        </div>
        <div class="mb-3">
            <label class="form-label">Meta Keywords</label>
            <input type="text" name="meta_keywords" id="edit_cat_meta_keywords" class="form-control" placeholder="keyword1, keyword2">
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        <button type="submit" class="btn btn-primary">Update Category</button>
      </div>
    </form>
  </div>
</div>

<script>
// Auto slugification helper
function slugify(text) {
    return text.toString().toLowerCase()
        .replace(/\s+/g, '-')
        .replace(/[^\w\u0980-\u09ff-]+/g, '') // Bengali, english, numbers and hyphens
        .replace(/\-\-+/g, '-')
        .replace(/^-+/, '')
        .replace(/-+$/, '');
}

// Add category auto-slugify
document.getElementById('add_cat_name').addEventListener('input', function() {
    document.getElementById('add_cat_slug').value = slugify(this.value);
});

// Edit category slug generator
function generateEditSlug() {
    const nameVal = document.getElementById('edit_cat_name').value;
    document.getElementById('edit_cat_slug').value = slugify(nameVal);
}

// Live Search Function
function filterCategories() {
    const searchVal = document.getElementById('category-search').value.toLowerCase();
    const rows = document.querySelectorAll('.category-row');
    let visibleCount = 0;
    
    rows.forEach(row => {
        const name = row.getAttribute('data-name').toLowerCase();
        const slug = row.getAttribute('data-slug').toLowerCase();
        
        if (name.includes(searchVal) || slug.includes(searchVal)) {
            row.style.display = '';
            visibleCount++;
        } else {
            row.style.display = 'none';
        }
    });
    
    document.getElementById('total-categories-count').innerText = visibleCount;
    
    const emptyRow = document.getElementById('no-categories-search-row');
    if (visibleCount === 0) {
        if (!emptyRow) {
            const tbody = document.getElementById('categoryTableBody');
            const tr = document.createElement('tr');
            tr.id = 'no-categories-search-row';
            tr.innerHTML = `<td colspan="7" class="text-center py-4 text-muted"><i class="fas fa-search fa-2x mb-2 d-block"></i>কোনো ক্যাটাগরি পাওয়া যায়নি</td>`;
            tbody.appendChild(tr);
        }
    } else {
        emptyRow?.remove();
    }
}

// Status Toggle (AJAX)
function toggleCategoryStatus(id, badge) {
    fetch(`actions/category-toggle-status.php?id=${id}`, {
        headers: { 'X-Requested-With': 'XMLHttpRequest' }
    })
    .then(res => res.json())
    .then(data => {
        if (data.status === 'success') {
            if (data.new_status) {
                badge.className = 'badge bg-success status-badge';
                badge.innerText = 'Active';
            } else {
                badge.className = 'badge bg-secondary status-badge';
                badge.innerText = 'Inactive';
            }
            
            // Update edit button datasets to reflect status
            const editBtn = badge.closest('tr').querySelector('.edit-category-btn');
            if(editBtn) editBtn.dataset.status = data.new_status;
            
            // Show toast message
            const toast = new bootstrap.Toast(document.getElementById('categoryToast'));
            const toastMessage = document.getElementById('categoryToastMessage');
            toastMessage.textContent = data.message;
            const toastEl = document.getElementById('categoryToast');
            toastEl.className = 'toast bg-success text-white';
            toast.show();
        } else {
            alert('Error toggling status: ' + data.message);
        }
    })
    .catch(err => console.error(err));
}

(function() {
    const toast = new bootstrap.Toast(document.getElementById('categoryToast'));
    const toastMessage = document.getElementById('categoryToastMessage');

    function showToast(message, isError = false) {
        toastMessage.textContent = message;
        const toastEl = document.getElementById('categoryToast');
        toastEl.classList.remove('bg-danger', 'text-white', 'bg-success');
        if (isError) {
            toastEl.classList.add('bg-danger', 'text-white');
        } else {
            toastEl.classList.add('bg-success', 'text-white');
        }
        toast.show();
    }

    function rowHtml(cat) {
        const image = cat.image ? `<img src="../${cat.image}" width="40" height="40" class="rounded border p-1" style="object-fit: contain;">` : '<span class="text-muted"><i class="fas fa-image fa-lg"></i></span>';
        const status = cat.status == 1 ? 'Active' : 'Inactive';
        const statusClass = cat.status == 1 ? 'success' : 'secondary';
        
        return `
            <td>
                <input type="checkbox" class="category-checkbox form-check-input" value="${cat.id}" onclick="toggleRowCheck()">
            </td>
            <td>${cat.id}</td>
            <td class="col-image">${image}</td>
            <td class="col-name fw-bold text-dark">${cat.name}</td>
            <td class="col-slug">${cat.slug}</td>
            <td class="col-status">
                <span class="badge bg-${statusClass} status-badge" onclick="toggleCategoryStatus(${cat.id}, this)" title="ক্লিক করে স্ট্যাটাস সক্রিয়/নিষ্ক্রিয় করুন">
                    ${status}
                </span>
            </td>
            <td>
                <div class="d-flex gap-1">
                    <button type="button" class="btn btn-sm btn-outline-secondary edit-category-btn" 
                            data-bs-toggle="modal" data-bs-target="#editCategoryModal"
                            data-id="${cat.id}"
                            data-name="${cat.name}"
                            data-slug="${cat.slug}"
                            data-status="${cat.status}"
                            data-h1_title="${cat.h1_title || ''}"
                            data-description="${cat.description || ''}"
                            data-meta_title="${cat.meta_title || ''}"
                            data-meta_description="${cat.meta_description || ''}"
                            data-meta_keywords="${cat.meta_keywords || ''}">
                        <i class="fas fa-edit"></i>
                    </button>
                    <button type="button" class="btn btn-sm btn-outline-danger delete-category-btn" data-id="${cat.id}">
                        <i class="fas fa-trash"></i>
                    </button>
                </div>
            </td>
        `;
    }

    document.getElementById('categoryTableBody').addEventListener('click', function(e) {
        // Edit button populate
        if(e.target.closest('.edit-category-btn')) {
            const btn = e.target.closest('.edit-category-btn');
            document.getElementById('edit_cat_id').value = btn.dataset.id;
            document.getElementById('edit_cat_name').value = btn.dataset.name;
            document.getElementById('edit_cat_slug').value = btn.dataset.slug;
            document.getElementById('edit_cat_status').value = btn.dataset.status;
            document.getElementById('edit_cat_h1_title').value = btn.dataset.h1_title || '';
            document.getElementById('edit_cat_description').value = btn.dataset.description || '';
            document.getElementById('edit_cat_meta_title').value = btn.dataset.meta_title || '';
            document.getElementById('edit_cat_meta_description').value = btn.dataset.meta_description || '';
            document.getElementById('edit_cat_meta_keywords').value = btn.dataset.meta_keywords || '';
            
            // Handle Image Preview
            const imgPath = btn.closest('tr').querySelector('.col-image img')?.getAttribute('src')?.replace('../', '') || '';
            document.getElementById('edit_cat_image').value = imgPath;
            const preview = document.getElementById('edit_cat_image_preview');
            const placeholder = document.getElementById('edit_cat_image_placeholder');
            if (imgPath) {
                preview.src = '../' + imgPath;
                preview.classList.remove('d-none');
                placeholder.classList.add('d-none');
            } else {
                preview.classList.add('d-none');
                preview.src = '';
                placeholder.classList.remove('d-none');
            }
        }

        // Delete button
        if(e.target.closest('.delete-category-btn')) {
            if(!confirm('Delete this category?')) return;
            const btn = e.target.closest('.delete-category-btn');
            const id = btn.dataset.id;
            fetch(`actions/category-delete.php?id=${id}`)
                .then(res => res.json())
                .then(data => {
                    if(data.status === 'success') {
                        document.getElementById(`category-row-${id}`).remove();
                        showToast(data.message);
                    } else {
                        showToast(data.message, true);
                    }
                });
        }
    });

    // Add Category Form submit
    document.getElementById('addCategoryForm').addEventListener('submit', function(e) {
        e.preventDefault();
        fetch('actions/category-save.php', { method: 'POST', body: new FormData(this) })
            .then(res => res.json())
            .then(data => {
                if(data.status === 'success') {
                    const noRow = document.getElementById('no-categories-row');
                    if(noRow) noRow.remove();
                    
                    const tr = document.createElement('tr');
                    tr.id = `category-row-${data.data.id}`;
                    tr.className = 'category-row';
                    tr.setAttribute('data-name', data.data.name);
                    tr.setAttribute('data-slug', data.data.slug);
                    tr.innerHTML = rowHtml(data.data);
                    
                    document.getElementById('categoryTableBody').prepend(tr);
                    
                    bootstrap.Modal.getInstance(document.getElementById('addCategoryModal')).hide();
                    this.reset();
                    
                    // Reset image picker previews
                    document.getElementById('add_cat_image_preview').classList.add('d-none');
                    document.getElementById('add_cat_image_placeholder').classList.remove('d-none');
                    
                    showToast(data.message);
                } else showToast(data.message, true);
            });
    });

    // Edit Category Form submit
    document.getElementById('editCategoryForm').addEventListener('submit', function(e) {
        e.preventDefault();
        fetch('actions/category-update.php', { method: 'POST', body: new FormData(this) })
            .then(res => res.json())
            .then(data => {
                if(data.status === 'success') {
                    const row = document.getElementById(`category-row-${data.data.id}`);
                    row.setAttribute('data-name', data.data.name);
                    row.setAttribute('data-slug', data.data.slug);
                    row.innerHTML = rowHtml(data.data);
                    
                    bootstrap.Modal.getInstance(document.getElementById('editCategoryModal')).hide();
                    showToast(data.message);
                } else showToast(data.message, true);
            });
    });
})();

// Checkbox selection utility functions
function toggleCheckAll(master) {
    const checkboxes = document.querySelectorAll('.category-checkbox');
    checkboxes.forEach(cb => {
        const row = cb.closest('tr');
        if (row && row.style.display !== 'none') {
            cb.checked = master.checked;
        }
    });
    toggleBulkBar();
}

function toggleRowCheck() {
    const master = document.getElementById('check-all');
    const checkboxes = document.querySelectorAll('.category-checkbox');
    let allChecked = true;
    let anyChecked = false;
    
    checkboxes.forEach(cb => {
        const row = cb.closest('tr');
        if (row && row.style.display !== 'none') {
            if (!cb.checked) allChecked = false;
            if (cb.checked) anyChecked = true;
        }
    });
    
    master.checked = allChecked && checkboxes.length > 0;
    toggleBulkBar();
}

function toggleBulkBar() {
    const bulkBar = document.getElementById('bulk-actions-bar');
    const checkedBoxes = document.querySelectorAll('.category-checkbox:checked');
    const selectedCount = document.getElementById('selected-count');
    
    if (checkedBoxes.length > 0) {
        selectedCount.innerText = checkedBoxes.length;
        bulkBar.style.setProperty('display', 'flex', 'important');
    } else {
        bulkBar.style.setProperty('display', 'none', 'important');
    }
}

function applyBulkAction() {
    const action = document.getElementById('bulk-action-select').value;
    if (!action) {
        alert('অনুগ্রহ করে একটি বাল্ক অ্যাকশন নির্বাচন করুন।');
        return;
    }
    
    const checkedBoxes = document.querySelectorAll('.category-checkbox:checked');
    const ids = Array.from(checkedBoxes).map(cb => cb.value);
    
    if (action === 'delete') {
        if (!confirm('সিলেক্ট করা ' + ids.length + 'টি ক্যাটাগরি আপনি কি চিরতরে মুছে ফেলতে চান?')) {
            return;
        }
    }
    
    const data = new FormData();
    data.append('action', action);
    ids.forEach(id => data.append('ids[]', id));
    
    fetch('actions/category-bulk-action.php', {
        method: 'POST',
        body: data,
        headers: { 'X-Requested-With': 'XMLHttpRequest' }
    })
    .then(res => res.json())
    .then(resData => {
        if (resData.status === 'success') {
            document.getElementById('check-all').checked = false;
            window.location.reload();
        } else {
            alert('Bulk action failed: ' + resData.message);
        }
    })
    .catch(err => console.error(err));
}
</script>
