<?php
// admin/pages/customers.php
$users = $pdo->query("SELECT * FROM users ORDER BY created_at DESC")->fetchAll();
?>

<?php adminFlashMessages(); ?>
<?php adminPageHeader('গ্রাহক', 'সব কাস্টমার দেখুন ও ম্যানেজ করুন', [
    ['label' => 'নতুন গ্রাহক', 'icon' => 'fa-plus', 'url' => 'index.php?page=add-user', 'class' => 'btn btn-primary btn-sm'],
]); ?>

<div class="admin-list-shell">
  <div class="admin-list-shell-header">
    <h2 class="admin-list-shell-title">গ্রাহক তালিকা</h2>
    <span class="text-muted small fw-semibold"><?php echo count($users); ?> জন</span>
  </div>
  <div class="admin-table-wrap">
          <table class="admin-table admin-table-mobile-cards">
            <thead>
              <tr>
                <th scope="col">ID</th>
                <th scope="col">Name</th>
                <th scope="col">Email</th>
                <th scope="col">Phone</th>
                <th scope="col">Address</th>
                <th scope="col">Joined</th>
                <th scope="col" class="text-end">Actions</th>
              </tr>
            </thead>
            <tbody>
              <?php if(empty($users)): ?>
                <tr><td colspan="7"><?php adminEmptyState('কোনো গ্রাহক নেই', 'এখনো কোনো রেজিস্টার্ড গ্রাহক নেই', 'fa-users'); ?></td></tr>
              <?php else: ?>
              <?php foreach ($users as $user): ?>
              <tr id="user-row-<?php echo $user['id']; ?>">
                <td>#<?php echo $user['id']; ?></td>
                <td class="fw-bold"><?php echo htmlspecialchars($user['name']); ?></td>
                <td><?php echo htmlspecialchars($user['email']); ?></td>
                <td><?php echo htmlspecialchars($user['phone']); ?></td>
                <td class="small text-muted"><?php echo htmlspecialchars(substr($user['address'] ?? '', 0, 30)) . (strlen($user['address'] ?? '') > 30 ? '...' : ''); ?></td>
                <td><?php echo date('M d, Y', strtotime($user['created_at'])); ?></td>
                <td class="text-end">
                    <div class="btn-group btn-group-sm">
                        <a href="index.php?page=user-details&id=<?php echo $user['id']; ?>" class="btn btn-info text-white" title="View Profile">
                            <i class="fas fa-eye"></i>
                        </a>
                        <a href="index.php?page=edit-user&id=<?php echo $user['id']; ?>" class="btn btn-primary" title="Edit">
                            <i class="fas fa-edit"></i>
                        </a>
                        <button type="button" class="btn btn-danger" onclick="deleteUser(<?php echo $user['id']; ?>)" title="Delete">
                            <i class="fas fa-trash"></i>
                        </button>
                    </div>
                </td>
              </tr>
              <?php endforeach; ?>
              <?php endif; ?>
            </tbody>
          </table>
  </div>
</div>

<script>
function deleteUser(id) {
    if(confirm('Are you sure you want to delete this user? This cannot be undone.')) {
        fetch('actions/delete-user.php?id=' + id, {
            headers: { 'X-Requested-With': 'XMLHttpRequest' }
        })
        .then(res => res.json())
        .then(data => {
            if(data.success) {
                if (typeof loadPage === 'function') {
                    loadPage('index.php?page=customers&success=' + encodeURIComponent(data.message));
                } else {
                    window.location.href = 'index.php?page=customers&success=' + encodeURIComponent(data.message);
                }
            } else {
                alert('Error: ' + data.message);
            }
        })
        .catch(err => {
            console.error('Delete Error:', err);
            window.location.href = 'actions/delete-user.php?id=' + id;
        });
    }
}
</script>
