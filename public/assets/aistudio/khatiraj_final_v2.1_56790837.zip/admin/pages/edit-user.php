<?php
// admin/pages/edit-user.php
$id = $_GET['id'] ?? null;
if (!$id) {
    header("Location: index.php?page=customers");
    exit;
}

$stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
$stmt->execute([$id]);
$user = $stmt->fetch();

if (!$user) {
    echo '<div class="alert alert-danger m-4"><i class="fas fa-exclamation-triangle me-2"></i>User not found!</div>';
    exit;
}

$stmt_orders = $pdo->prepare("SELECT COUNT(*) as total_orders, COALESCE(SUM(CASE WHEN payment_status='Paid' THEN total_amount ELSE 0 END), 0) as total_spent FROM orders WHERE user_id = ?");
$stmt_orders->execute([$id]);
$stats = $stmt_orders->fetch();

$joined_date = date('d M, Y', strtotime($user['created_at']));
?>

<?php adminFlashMessages(); ?>
<?php adminPageHeader('Edit Customer', $user['name'] . ' এর তথ্য আপডেট করুন', [
    ['label' => 'প্রোফাইল দেখুন', 'icon' => 'fa-eye', 'url' => 'index.php?page=user-details&id=' . $user['id'], 'class' => 'btn btn-outline-primary btn-sm'],
    ['label' => 'গ্রাহক তালিকা', 'icon' => 'fa-arrow-left', 'url' => 'index.php?page=customers', 'class' => 'btn btn-outline-secondary btn-sm'],
]); ?>

<form action="actions/edit-user.php" method="POST" id="edit-user-form" class="settings-form">
    <input type="hidden" name="id" value="<?php echo $user['id']; ?>">
    <div class="settings-layout admin-shell" data-panel-prefix="usr">
        <div class="settings-content">
            <section class="settings-panel admin-panel is-active" id="usr-general" role="tabpanel">
                <?php adminPanelHeader('Customer Details', '#' . $user['id'] . ' · ' . $joined_date . ' · ' . (int)$stats['total_orders'] . ' orders · ৳' . number_format($stats['total_spent']), 'fa-user', 'blue'); ?>
                <div class="settings-panel-body admin-panel-body">
                    <div class="row g-3">
                        <div class="col-md-6">
                            <label class="form-label">Full Name <span class="text-danger">*</span></label>
                            <input type="text" name="name" class="form-control"
                                   required value="<?php echo htmlspecialchars($user['name']); ?>"
                                   placeholder="Customer's full name">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Email Address <span class="text-danger">*</span></label>
                            <input type="email" name="email" class="form-control"
                                   required value="<?php echo htmlspecialchars($user['email']); ?>"
                                   placeholder="customer@example.com">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Phone Number <span class="text-danger">*</span></label>
                            <input type="text" name="phone" class="form-control"
                                   required value="<?php echo htmlspecialchars($user['phone']); ?>"
                                   placeholder="01XXXXXXXXX">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Password <small class="text-muted">(leave blank to keep)</small></label>
                            <input type="password" name="password" id="user-password" class="form-control"
                                   placeholder="New password" minlength="6">
                        </div>
                        <div class="col-12">
                            <label class="form-label">Address</label>
                            <textarea name="address" class="form-control" rows="3"
                                      placeholder="Enter complete address (House, Road, Area, District)"><?php echo htmlspecialchars($user['address'] ?? ''); ?></textarea>
                        </div>
                    </div>
                </div>
                <?php adminSaveBar('Update Customer'); ?>
            </section>
        </div>
    </div>
</form>
