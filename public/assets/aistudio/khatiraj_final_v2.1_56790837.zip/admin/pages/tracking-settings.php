<?php
// admin/pages/tracking-settings.php
// Tracking & Pixels — Analytics Dashboard + configuration — Super Admin only

require_once __DIR__ . '/../../config/tracking_encryption.php';

// ─── Date range for the analytics dashboard ───
$allowed_ranges = [7, 30, 90];
$range = (int)($_GET['range'] ?? 7);
if (!in_array($range, $allowed_ranges, true)) {
    $range = 7;
}
$active_tab = $_GET['tab'] ?? 'overview';
if (isset($_GET['success']) || isset($_GET['error']) || isset($_GET['meta_test']) || isset($_GET['tiktok_test'])) {
    $active_tab = 'settings';
}

// ─── Fetch current tracking settings ───
$tracking = [];
try {
    $stmt = $pdo->query("SELECT * FROM tracking_settings WHERE id = 1");
    $tracking = $stmt->fetch(PDO::FETCH_ASSOC) ?: [];
} catch (PDOException $e) {
    // Table might not exist
}

$meta_token_raw = !empty($tracking['meta_capi_access_token']) ? TrackingEncryption::decrypt($tracking['meta_capi_access_token']) : '';
$tiktok_token_raw = !empty($tracking['tiktok_events_api_token']) ? TrackingEncryption::decrypt($tracking['tiktok_events_api_token']) : '';
$meta_token_masked = TrackingEncryption::maskToken($meta_token_raw);
$tiktok_token_masked = TrackingEncryption::maskToken($tiktok_token_raw);

require_once __DIR__ . '/../../app/Services/VisitorTracker.php';
VisitorTracker::cleanup(90);

// ─── Analytics data (all from tracking_logs) ───
$stats = [
    'total' => 0, 'success' => 0, 'failed' => 0, 'purchases' => 0,
    'prev_total' => 0, 'prev_success' => 0, 'prev_failed' => 0, 'prev_purchases' => 0,
];
$daily_series = [];
$platform_stats = [];
$event_breakdown = [];
$funnel = [];
$purchase_value = 0.0;
$recent_errors = [];
$last_event_at = null;

// Purchase event names across platforms (Meta / TikTok naming)
$purchase_names = "('Purchase','CompletePayment')";

try {
    // Current vs previous period core stats
    $stmt = $pdo->prepare("
        SELECT
            SUM(created_at >= NOW() - INTERVAL :r1 DAY) AS total,
            SUM(created_at >= NOW() - INTERVAL :r2 DAY AND status = 'success') AS success,
            SUM(created_at >= NOW() - INTERVAL :r3 DAY AND status = 'failed') AS failed,
            SUM(created_at >= NOW() - INTERVAL :r4 DAY AND status = 'success' AND event_name IN {$purchase_names}) AS purchases,
            SUM(created_at < NOW() - INTERVAL :r5 DAY AND created_at >= NOW() - INTERVAL :r6 DAY) AS prev_total,
            SUM(created_at < NOW() - INTERVAL :r7 DAY AND created_at >= NOW() - INTERVAL :r8 DAY AND status = 'success') AS prev_success,
            SUM(created_at < NOW() - INTERVAL :r9 DAY AND created_at >= NOW() - INTERVAL :r10 DAY AND status = 'failed') AS prev_failed,
            SUM(created_at < NOW() - INTERVAL :r11 DAY AND created_at >= NOW() - INTERVAL :r12 DAY AND status = 'success' AND event_name IN {$purchase_names}) AS prev_purchases
        FROM tracking_logs
        WHERE created_at >= NOW() - INTERVAL :r13 DAY
    ");
    $double = $range * 2;
    $stmt->execute([
        ':r1' => $range, ':r2' => $range, ':r3' => $range, ':r4' => $range,
        ':r5' => $range, ':r6' => $double, ':r7' => $range, ':r8' => $double,
        ':r9' => $range, ':r10' => $double, ':r11' => $range, ':r12' => $double,
        ':r13' => $double,
    ]);
    $row = $stmt->fetch(PDO::FETCH_ASSOC) ?: [];
    foreach ($stats as $k => $v) {
        $stats[$k] = (int) round((float) ($row[$k] ?? 0));
    }

    // Daily series (fill missing days in PHP)
    for ($i = $range - 1; $i >= 0; $i--) {
        $d = date('Y-m-d', strtotime("-{$i} days"));
        $daily_series[$d] = ['label' => date('M j', strtotime($d)), 'success' => 0, 'failed' => 0];
    }
    $stmt = $pdo->prepare("
        SELECT DATE(created_at) AS d,
               SUM(status = 'success') AS ok,
               SUM(status = 'failed') AS bad
        FROM tracking_logs
        WHERE created_at >= NOW() - INTERVAL :r DAY
        GROUP BY DATE(created_at)
    ");
    $stmt->execute([':r' => $range]);
    foreach ($stmt->fetchAll() as $r) {
        if (isset($daily_series[$r['d']])) {
            $daily_series[$r['d']]['success'] = (int)$r['ok'];
            $daily_series[$r['d']]['failed'] = (int)$r['bad'];
        }
    }

    // Platform breakdown + health
    $stmt = $pdo->prepare("
        SELECT platform,
               COUNT(*) AS total,
               SUM(status = 'success') AS ok,
               SUM(status = 'failed') AS bad,
               MAX(created_at) AS last_event
        FROM tracking_logs
        WHERE created_at >= NOW() - INTERVAL :r DAY AND event_name != 'settings_changed'
        GROUP BY platform
    ");
    $stmt->execute([':r' => $range]);
    foreach ($stmt->fetchAll() as $r) {
        $platform_stats[$r['platform']] = $r;
    }

    // Event type breakdown (normalize TikTok names to Meta naming)
    $stmt = $pdo->prepare("
        SELECT
            CASE event_name
                WHEN 'Pageview' THEN 'PageView'
                WHEN 'CompletePayment' THEN 'Purchase'
                ELSE event_name
            END AS ev,
            COUNT(*) AS total,
            SUM(status = 'success') AS ok
        FROM tracking_logs
        WHERE created_at >= NOW() - INTERVAL :r DAY AND event_name != 'settings_changed'
        GROUP BY ev
        ORDER BY total DESC
    ");
    $stmt->execute([':r' => $range]);
    $event_breakdown = $stmt->fetchAll();

    // Conversion funnel — distinct event ids so Meta+TikTok double-sends count once
    $funnel_steps = [
        'PageView' => "('PageView','Pageview')",
        'ViewContent' => "('ViewContent')",
        'AddToCart' => "('AddToCart')",
        'InitiateCheckout' => "('InitiateCheckout')",
        'Purchase' => $purchase_names,
    ];
    foreach ($funnel_steps as $label => $names) {
        $stmt = $pdo->prepare("
            SELECT COUNT(DISTINCT COALESCE(NULLIF(event_id, ''), CONCAT('row-', id))) AS c
            FROM tracking_logs
            WHERE created_at >= NOW() - INTERVAL :r DAY
              AND status = 'success'
              AND event_name IN {$names}
        ");
        $stmt->execute([':r' => $range]);
        $funnel[$label] = (int)$stmt->fetchColumn();
    }

    // Tracked purchase revenue (parse sanitized payload summaries)
    $stmt = $pdo->prepare("
        SELECT payload_summary
        FROM tracking_logs
        WHERE created_at >= NOW() - INTERVAL :r DAY
          AND status = 'success'
          AND platform = 'meta'
          AND event_name IN {$purchase_names}
    ");
    $stmt->execute([':r' => $range]);
    foreach ($stmt->fetchAll(PDO::FETCH_COLUMN) as $payload) {
        $decoded = json_decode($payload ?? '', true);
        if (isset($decoded['custom_data']['value'])) {
            $purchase_value += (float)$decoded['custom_data']['value'];
        }
    }

    // Recent failures
    $stmt = $pdo->prepare("
        SELECT * FROM tracking_logs
        WHERE status = 'failed' AND created_at >= NOW() - INTERVAL :r DAY
        ORDER BY created_at DESC
        LIMIT 8
    ");
    $stmt->execute([':r' => $range]);
    $recent_errors = $stmt->fetchAll();

    $last_event_at = $pdo->query("SELECT MAX(created_at) FROM tracking_logs WHERE event_name != 'settings_changed'")->fetchColumn();
} catch (PDOException $e) {
    // tracking_logs table might not exist yet
}

$success_rate = $stats['total'] > 0 ? round(($stats['success'] / $stats['total']) * 100, 1) : 0;
$prev_rate = $stats['prev_total'] > 0 ? round(($stats['prev_success'] / $stats['prev_total']) * 100, 1) : 0;

function trkChange($current, $previous): array {
    $current = (int) round((float) $current);
    $previous = (int) round((float) $previous);
    if ($previous <= 0) {
        return [$current > 0 ? '+100%' : '', true];
    }
    $pct = round((($current - $previous) / $previous) * 100, 1);
    return [($pct >= 0 ? '+' : '') . $pct . '%', $pct >= 0];
}
[$total_change, $total_up] = trkChange($stats['total'], $stats['prev_total']);
[$purchase_change, $purchase_up] = trkChange($stats['purchases'], $stats['prev_purchases']);
[$failed_change, $failed_up_raw] = trkChange($stats['failed'], $stats['prev_failed']);
$failed_up = !$failed_up_raw; // fewer failures = good

// Chart payloads
$chart_labels = json_encode(array_column(array_values($daily_series), 'label'));
$chart_success = json_encode(array_column(array_values($daily_series), 'success'));
$chart_failed = json_encode(array_column(array_values($daily_series), 'failed'));
$event_labels = json_encode(array_column($event_breakdown, 'ev'));
$event_counts = json_encode(array_map('intval', array_column($event_breakdown, 'total')));
$platform_labels = json_encode(array_map('ucfirst', array_keys($platform_stats)));
$platform_counts = json_encode(array_map(fn($p) => (int)$p['total'], array_values($platform_stats)));

// Integration health checklist
$health_items = [
    ['label' => 'Meta Pixel ID', 'ok' => !empty($tracking['meta_pixel_id']), 'icon' => 'fa-facebook-f'],
    ['label' => 'Meta CAPI Token', 'ok' => $meta_token_raw !== '', 'icon' => 'fa-facebook-f'],
    ['label' => 'TikTok Pixel ID', 'ok' => !empty($tracking['tiktok_pixel_id']), 'icon' => 'fa-tiktok'],
    ['label' => 'TikTok API Token', 'ok' => $tiktok_token_raw !== '', 'icon' => 'fa-tiktok'],
    ['label' => 'GA4 Measurement ID', 'ok' => !empty($tracking['google_analytics_id']), 'icon' => 'fa-google'],
    ['label' => 'Google Tag Manager', 'ok' => !empty($tracking['google_tag_manager_id']), 'icon' => 'fa-google'],
];
$health_ok = count(array_filter($health_items, fn($h) => $h['ok']));

// ─── Logs (Logs tab) ───
$api_logs = [];
try {
    $stmt = $pdo->query("
        SELECT * FROM tracking_logs 
        WHERE event_name != 'settings_changed'
        ORDER BY created_at DESC 
        LIMIT 50
    ");
    $api_logs = $stmt->fetchAll();
} catch (PDOException $e) {}

$funnel_max = max(1, $funnel['PageView'] ?? 1, ...array_values($funnel ?: [0]));
?>

<?php adminFlashMessages(); ?>
<?php adminPageHeader('Tracking & Pixels', 'অ্যানালিটিক্স ড্যাশবোর্ড, Meta, TikTok ও Google ট্র্যাকিং'); ?>

<?php if(isset($_GET['meta_test'])): ?>
    <div class="admin-flash <?php echo $_GET['meta_test'] === 'ok' ? 'success' : 'error'; ?>">
        <i class="fab fa-facebook me-2"></i><strong>Meta CAPI Test:</strong> <?php echo htmlspecialchars($_GET['meta_msg'] ?? ''); ?>
    </div>
<?php endif; ?>

<?php if(isset($_GET['tiktok_test'])): ?>
    <div class="admin-flash <?php echo $_GET['tiktok_test'] === 'ok' ? 'success' : 'error'; ?>">
        <i class="fab fa-tiktok me-2"></i><strong>TikTok API Test:</strong> <?php echo htmlspecialchars($_GET['tiktok_msg'] ?? ''); ?>
    </div>
<?php endif; ?>

<script>
(function () {
    var tab = <?php echo json_encode($active_tab); ?>;
    if (!location.hash || location.hash.indexOf('#trk-') !== 0) {
        if (history.replaceState) {
            history.replaceState(null, '', location.pathname + location.search + '#trk-' + tab);
        }
    }
})();
</script>

<div class="d-flex flex-wrap justify-content-end align-items-center gap-2 mb-3">
    <span class="status-badge <?php echo ($tracking['is_test_mode'] ?? 0) ? 'pending' : 'active'; ?>">
        <i class="fas <?php echo ($tracking['is_test_mode'] ?? 0) ? 'fa-flask' : 'fa-broadcast-tower'; ?> me-1"></i>
        <?php echo ($tracking['is_test_mode'] ?? 0) ? 'TEST MODE' : 'LIVE MODE'; ?>
    </span>
    <div class="dropdown">
        <button class="btn btn-sm btn-outline-secondary dropdown-toggle bg-white rounded-3 shadow-sm px-3" type="button" data-bs-toggle="dropdown">
            <i class="fas fa-download me-1"></i> Export Data
        </button>
        <ul class="dropdown-menu dropdown-menu-end">
            <li><a class="dropdown-item" href="actions/analytics-export.php?type=traffic&range=<?php echo $range; ?>" data-no-pjax="true"><i class="fas fa-globe me-2 text-primary"></i>Traffic Logs (CSV)</a></li>
            <li><a class="dropdown-item" href="actions/analytics-export.php?type=revenue&range=<?php echo $range; ?>" data-no-pjax="true"><i class="fas fa-wallet me-2 text-success"></i>Revenue Orders (CSV)</a></li>
            <li><a class="dropdown-item" href="actions/analytics-export.php?type=products&range=<?php echo $range; ?>" data-no-pjax="true"><i class="fas fa-box me-2 text-warning"></i>Product Sales (CSV)</a></li>
        </ul>
    </div>
    <div class="btn-group btn-group-sm bg-white rounded-3 shadow-sm" role="group">
        <?php foreach ($allowed_ranges as $r): ?>
            <a href="index.php?page=tracking-settings&range=<?php echo $r; ?>"
               class="btn <?php echo $range === $r ? 'btn-primary' : 'btn-white text-muted'; ?>"><?php echo $r; ?>d</a>
        <?php endforeach; ?>
    </div>
</div>

<div class="settings-layout admin-shell" data-panel-prefix="trk">
    <nav class="settings-tabs admin-tabs" id="trkTabs" aria-label="Tracking sections">
        <div class="settings-tabs-track admin-tabs-track" role="tablist">
            <a href="#trk-overview" class="settings-tab admin-tab <?php echo $active_tab === 'overview' ? 'active' : ''; ?>" data-admin-nav="overview" role="tab" aria-selected="<?php echo $active_tab === 'overview' ? 'true' : 'false'; ?>">
                <i class="fas fa-tachometer-alt"></i><span>Overview</span>
            </a>
            <a href="#trk-website" class="settings-tab admin-tab <?php echo $active_tab === 'website' ? 'active' : ''; ?>" data-admin-nav="website" role="tab" aria-selected="<?php echo $active_tab === 'website' ? 'true' : 'false'; ?>">
                <i class="fas fa-globe"></i><span>Traffic</span>
            </a>
            <a href="#trk-realtime" class="settings-tab admin-tab <?php echo $active_tab === 'realtime' ? 'active' : ''; ?>" data-admin-nav="realtime" role="tab" aria-selected="<?php echo $active_tab === 'realtime' ? 'true' : 'false'; ?>">
                <i class="fas fa-bolt"></i><span>Live</span>
            </a>
            <a href="#trk-revenue" class="settings-tab admin-tab <?php echo $active_tab === 'revenue' ? 'active' : ''; ?>" data-admin-nav="revenue" role="tab" aria-selected="<?php echo $active_tab === 'revenue' ? 'true' : 'false'; ?>">
                <i class="fas fa-wallet"></i><span>Revenue</span>
            </a>
            <a href="#trk-customers" class="settings-tab admin-tab <?php echo $active_tab === 'customers' ? 'active' : ''; ?>" data-admin-nav="customers" role="tab" aria-selected="<?php echo $active_tab === 'customers' ? 'true' : 'false'; ?>">
                <i class="fas fa-users"></i><span>Customers</span>
            </a>
            <a href="#trk-products" class="settings-tab admin-tab <?php echo $active_tab === 'products' ? 'active' : ''; ?>" data-admin-nav="products" role="tab" aria-selected="<?php echo $active_tab === 'products' ? 'true' : 'false'; ?>">
                <i class="fas fa-box"></i><span>Products</span>
            </a>
            <a href="#trk-funnel" class="settings-tab admin-tab <?php echo $active_tab === 'funnel' ? 'active' : ''; ?>" data-admin-nav="funnel" role="tab" aria-selected="<?php echo $active_tab === 'funnel' ? 'true' : 'false'; ?>">
                <i class="fas fa-filter"></i><span>Funnel</span>
            </a>
            <a href="#trk-pixel" class="settings-tab admin-tab <?php echo $active_tab === 'pixel' ? 'active' : ''; ?>" data-admin-nav="pixel" role="tab" aria-selected="<?php echo $active_tab === 'pixel' ? 'true' : 'false'; ?>">
                <i class="fas fa-satellite-dish"></i><span>Pixel Stats</span>
            </a>
            <a href="#trk-settings" class="settings-tab admin-tab <?php echo $active_tab === 'settings' ? 'active' : ''; ?>" data-admin-nav="settings" role="tab" aria-selected="<?php echo $active_tab === 'settings' ? 'true' : 'false'; ?>">
                <i class="fas fa-sliders-h"></i><span>Configuration</span>
            </a>
            <a href="#trk-logs" class="settings-tab admin-tab <?php echo $active_tab === 'logs' ? 'active' : ''; ?>" data-admin-nav="logs" role="tab" aria-selected="<?php echo $active_tab === 'logs' ? 'true' : 'false'; ?>">
                <i class="fas fa-list-alt"></i><span>API Logs</span>
            </a>
        </div>
    </nav>

    <div class="settings-content">

<!-- ════════════ TAB: OVERVIEW ════════════ -->
<section class="settings-panel admin-panel <?php echo $active_tab === 'overview' ? 'is-active' : ''; ?>" id="trk-overview" role="tabpanel" <?php echo $active_tab !== 'overview' ? 'hidden' : ''; ?>>
    <?php include __DIR__ . '/../includes/analytics/tab-overview.php'; ?>
</section>

<!-- ════════════ TAB: WEBSITE TRAFFIC ════════════ -->
<section class="settings-panel admin-panel <?php echo $active_tab === 'website' ? 'is-active' : ''; ?>" id="trk-website" role="tabpanel" <?php echo $active_tab !== 'website' ? 'hidden' : ''; ?>>
    <?php include __DIR__ . '/../includes/analytics/tab-website.php'; ?>
</section>

<!-- ════════════ TAB: REAL-TIME MONITOR ════════════ -->
<section class="settings-panel admin-panel <?php echo $active_tab === 'realtime' ? 'is-active' : ''; ?>" id="trk-realtime" role="tabpanel" <?php echo $active_tab !== 'realtime' ? 'hidden' : ''; ?>>
    <?php include __DIR__ . '/../includes/analytics/tab-realtime.php'; ?>
</section>

<!-- ════════════ TAB: REVENUE ════════════ -->
<section class="settings-panel admin-panel <?php echo $active_tab === 'revenue' ? 'is-active' : ''; ?>" id="trk-revenue" role="tabpanel" <?php echo $active_tab !== 'revenue' ? 'hidden' : ''; ?>>
    <?php include __DIR__ . '/../includes/analytics/tab-revenue.php'; ?>
</section>

<!-- ════════════ TAB: CUSTOMERS ════════════ -->
<section class="settings-panel admin-panel <?php echo $active_tab === 'customers' ? 'is-active' : ''; ?>" id="trk-customers" role="tabpanel" <?php echo $active_tab !== 'customers' ? 'hidden' : ''; ?>>
    <?php include __DIR__ . '/../includes/analytics/tab-customers.php'; ?>
</section>

<!-- ════════════ TAB: PRODUCTS ════════════ -->
<section class="settings-panel admin-panel <?php echo $active_tab === 'products' ? 'is-active' : ''; ?>" id="trk-products" role="tabpanel" <?php echo $active_tab !== 'products' ? 'hidden' : ''; ?>>
    <?php include __DIR__ . '/../includes/analytics/tab-products.php'; ?>
</section>

<!-- ════════════ TAB: FUNNEL ════════════ -->
<section class="settings-panel admin-panel <?php echo $active_tab === 'funnel' ? 'is-active' : ''; ?>" id="trk-funnel" role="tabpanel" <?php echo $active_tab !== 'funnel' ? 'hidden' : ''; ?>>
    <?php include __DIR__ . '/../includes/analytics/tab-funnel.php'; ?>
</section>

<!-- ════════════ TAB: PIXEL ANALYTICS ════════════ -->
<section class="settings-panel admin-panel <?php echo $active_tab === 'pixel' ? 'is-active' : ''; ?>" id="trk-pixel" role="tabpanel" <?php echo $active_tab !== 'pixel' ? 'hidden' : ''; ?>>
    <?php adminPanelHeader('Pixel Analytics', 'ইভেন্ট টাইমলাইন, ফানেল ও ইন্টিগ্রেশন হেলথ', 'fa-satellite-dish', 'blue'); ?>
    <div class="settings-panel-body admin-panel-body pt-3">

    <!-- KPI Cards -->
    <div class="row g-3 mb-4">
        <div class="col-md-3 col-6"><?php adminStatCard('মোট Events (' . $range . 'd)', number_format($stats['total']), 'fa-satellite-dish', 'blue', $total_change, $total_up); ?></div>
        <div class="col-md-3 col-6"><?php adminStatCard('Success Rate', $success_rate . '%', 'fa-check-double', 'green', ($prev_rate ? ($success_rate >= $prev_rate ? '+' : '') . round($success_rate - $prev_rate, 1) . '%' : ''), $success_rate >= $prev_rate); ?></div>
        <div class="col-md-3 col-6"><?php adminStatCard('Failed Events', number_format($stats['failed']), 'fa-triangle-exclamation', 'amber', $failed_change, $failed_up); ?></div>
        <div class="col-md-3 col-6"><?php adminStatCard('Purchases Tracked', number_format($stats['purchases']) . ($purchase_value > 0 ? ' (৳' . number_format($purchase_value) . ')' : ''), 'fa-cart-shopping', 'purple', $purchase_change, $purchase_up); ?></div>
    </div>

    <?php if ($stats['total'] === 0): ?>
        <div class="admin-card mb-4 p-4">
            <?php adminEmptyState('এই সময়ে কোনো tracking event নেই', 'Pixel/CAPI কনফিগার করা থাকলে ইভেন্ট আসা শুরু হলে এখানে অ্যানালিটিক্স দেখা যাবে', 'fa-satellite-dish'); ?>
        </div>
    <?php endif; ?>

    <!-- Events Timeline + Platform Split -->
    <div class="row g-4 mb-4">
        <div class="col-lg-8">
            <div class="glass-card p-4 h-100">
                <div class="d-flex justify-content-between align-items-center mb-3">
                    <h5 class="fw-bold mb-0">Events Timeline</h5>
                    <?php if ($last_event_at): ?>
                        <small class="text-muted"><i class="far fa-clock me-1"></i>Last event: <?php echo date('M j, g:i A', strtotime($last_event_at)); ?></small>
                    <?php endif; ?>
                </div>
                <div style="height: 320px;"><canvas id="trkTimelineChart"></canvas></div>
            </div>
        </div>
        <div class="col-lg-4">
            <div class="glass-card p-4 h-100 d-flex flex-column">
                <h5 class="fw-bold mb-3">Platform Split</h5>
                <?php if (empty($platform_stats)): ?>
                    <div class="text-muted small my-auto text-center">No events yet</div>
                <?php else: ?>
                    <div style="height: 190px;" class="mb-3"><canvas id="trkPlatformChart"></canvas></div>
                    <?php foreach ($platform_stats as $pf => $p): 
                        $rate = $p['total'] > 0 ? round(($p['ok'] / $p['total']) * 100, 1) : 0; ?>
                        <div class="d-flex justify-content-between align-items-center py-2 border-top">
                            <span class="fw-bold small">
                                <?php if ($pf === 'meta'): ?>
                                    <i class="fab fa-facebook text-primary me-1"></i>Meta
                                <?php else: ?>
                                    <i class="fab fa-tiktok me-1"></i>TikTok
                                <?php endif; ?>
                            </span>
                            <span class="small text-muted"><?php echo number_format($p['total']); ?> events</span>
                            <span class="badge <?php echo $rate >= 95 ? 'bg-success' : ($rate >= 80 ? 'bg-warning text-dark' : 'bg-danger'); ?>"><?php echo $rate; ?>% OK</span>
                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- Funnel + Event Breakdown -->
    <div class="row g-4 mb-4">
        <div class="col-lg-6">
            <div class="glass-card p-4 h-100">
                <h5 class="fw-bold mb-1">Conversion Funnel</h5>
                <p class="text-muted small mb-4">Successful unique events — PageView থেকে Purchase পর্যন্ত journey</p>
                <?php 
                $funnel_colors = ['#3b82f6', '#06b6d4', '#f59e0b', '#8b5cf6', '#22c55e'];
                $ci = 0;
                $first_step = max(1, reset($funnel) ?: 1);
                foreach ($funnel as $step => $count): 
                    $width = max(4, round(($count / $funnel_max) * 100));
                    $pct_of_first = round(($count / $first_step) * 100, 1);
                ?>
                    <div class="mb-3">
                        <div class="d-flex justify-content-between small mb-1">
                            <span class="fw-bold"><?php echo $step; ?></span>
                            <span class="text-muted"><?php echo number_format($count); ?> <span class="ms-1 badge bg-light text-dark"><?php echo $pct_of_first; ?>%</span></span>
                        </div>
                        <div class="progress" style="height: 22px; border-radius: 8px; background: #f1f5f9;">
                            <div class="progress-bar" style="width: <?php echo $width; ?>%; background: <?php echo $funnel_colors[$ci % 5]; ?>; border-radius: 8px;"></div>
                        </div>
                    </div>
                <?php $ci++; endforeach; ?>
                <?php if (($funnel['PageView'] ?? 0) > 0 && ($funnel['Purchase'] ?? 0) >= 0): ?>
                    <div class="border-top pt-3 mt-3 d-flex justify-content-between align-items-center">
                        <span class="small text-muted">Overall conversion (PageView → Purchase)</span>
                        <span class="fw-bold fs-5 text-success"><?php echo round((($funnel['Purchase'] ?? 0) / max(1, $funnel['PageView'])) * 100, 2); ?>%</span>
                    </div>
                <?php endif; ?>
            </div>
        </div>
        <div class="col-lg-6">
            <div class="glass-card p-4 h-100 d-flex flex-column">
                <h5 class="fw-bold mb-3">Event Type Breakdown</h5>
                <?php if (empty($event_breakdown)): ?>
                    <div class="text-muted small my-auto text-center">No events yet</div>
                <?php else: ?>
                    <div style="height: 220px;" class="mb-3"><canvas id="trkEventChart"></canvas></div>
                    <div class="table-responsive">
                        <table class="table table-sm table-borderless align-middle mb-0 small">
                            <thead class="text-muted text-uppercase" style="font-size: 0.68rem;">
                                <tr><th>Event</th><th class="text-center">Count</th><th class="text-end">Success</th></tr>
                            </thead>
                            <tbody>
                                <?php foreach ($event_breakdown as $ev): 
                                    $er = $ev['total'] > 0 ? round(($ev['ok'] / $ev['total']) * 100) : 0; ?>
                                    <tr>
                                        <td><code><?php echo htmlspecialchars($ev['ev']); ?></code></td>
                                        <td class="text-center fw-bold"><?php echo number_format($ev['total']); ?></td>
                                        <td class="text-end"><span class="badge <?php echo $er >= 95 ? 'bg-success-subtle text-success' : 'bg-warning-subtle text-warning'; ?>"><?php echo $er; ?>%</span></td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- Integration Health + Recent Failures -->
    <div class="row g-4 mb-4">
        <div class="col-lg-5">
            <div class="glass-card p-4 h-100">
                <div class="d-flex justify-content-between align-items-center mb-3">
                    <h5 class="fw-bold mb-0">Integration Health</h5>
                    <span class="badge <?php echo $health_ok === count($health_items) ? 'bg-success' : 'bg-warning text-dark'; ?>"><?php echo $health_ok; ?>/<?php echo count($health_items); ?> configured</span>
                </div>
                <?php foreach ($health_items as $h): ?>
                    <div class="d-flex justify-content-between align-items-center py-2 border-bottom">
                        <span class="small"><i class="fab <?php echo $h['icon']; ?> me-2 text-muted"></i><?php echo $h['label']; ?></span>
                        <?php if ($h['ok']): ?>
                            <span class="text-success small fw-bold"><i class="fas fa-check-circle me-1"></i>Active</span>
                        <?php else: ?>
                            <span class="text-muted small"><i class="far fa-circle me-1"></i>Not set</span>
                        <?php endif; ?>
                    </div>
                <?php endforeach; ?>
                <div class="mt-3">
                    <button class="btn btn-sm btn-outline-primary rounded-pill px-3" type="button" onclick="window.AdminTabs && AdminTabs.activate('settings', { updateHash: true, scrollTab: true });">
                        <i class="fas fa-sliders-h me-1"></i> Configure Now
                    </button>
                </div>
            </div>
        </div>
        <div class="col-lg-7">
            <div class="glass-card p-4 h-100">
                <h5 class="fw-bold mb-3">Recent Failures <span class="badge bg-danger-subtle text-danger ms-1"><?php echo count($recent_errors); ?></span></h5>
                <?php if (empty($recent_errors)): ?>
                    <div class="text-center py-4">
                        <i class="fas fa-shield-heart fa-2x text-success mb-2"></i>
                        <p class="text-muted small mb-0">গত <?php echo $range; ?> দিনে কোনো failed event নেই — সব ঠিকঠাক চলছে!</p>
                    </div>
                <?php else: ?>
                    <div class="table-responsive">
                        <table class="table table-sm align-middle small mb-0">
                            <thead class="text-muted text-uppercase" style="font-size: 0.68rem;">
                                <tr><th>Platform</th><th>Event</th><th>HTTP</th><th>Error</th><th class="text-end">Time</th></tr>
                            </thead>
                            <tbody>
                                <?php foreach ($recent_errors as $err): ?>
                                    <tr>
                                        <td>
                                            <?php if ($err['platform'] === 'meta'): ?>
                                                <span class="badge bg-primary-subtle text-primary">Meta</span>
                                            <?php else: ?>
                                                <span class="badge bg-dark">TikTok</span>
                                            <?php endif; ?>
                                        </td>
                                        <td><code><?php echo htmlspecialchars($err['event_name']); ?></code></td>
                                        <td><span class="badge bg-light text-dark"><?php echo $err['response_code']; ?></span></td>
                                        <td class="text-danger" style="max-width: 220px;"><small><?php echo htmlspecialchars(mb_substr($err['error_message'] ?? '', 0, 70)); ?></small></td>
                                        <td class="text-end text-muted"><small><?php echo date('M j, g:i A', strtotime($err['created_at'])); ?></small></td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
    </div>
</section>

<!-- ════════════ TAB 2: CONFIGURATION ════════════ -->
<section class="settings-panel admin-panel <?php echo $active_tab === 'settings' ? 'is-active' : ''; ?>" id="trk-settings" role="tabpanel" <?php echo $active_tab !== 'settings' ? 'hidden' : ''; ?>>
<?php adminPanelHeader('Tracking Configuration', 'Meta, TikTok, Google পিক্সেল ও অপশন সেট করুন', 'fa-sliders-h', 'green'); ?>
<form action="actions/tracking-settings-save.php" method="POST" class="settings-form">
<div class="settings-panel-body admin-panel-body pt-3">
<div class="row g-4">
    <!-- Meta (Facebook) Pixel Settings -->
    <div class="col-lg-6">
        <div class="admin-list-shell h-100">
            <div class="settings-panel-header admin-panel-header px-3 pt-3 pb-0 border-0">
                <div class="settings-panel-icon admin-panel-icon blue">
                    <i class="fab fa-facebook-f"></i>
                </div>
                <div>
                    <h2 class="settings-panel-title admin-panel-title">Meta (Facebook) Pixel</h2>
                    <p class="settings-panel-desc admin-panel-desc">Pixel ID ও Conversions API টোকেন</p>
                </div>
            </div>
            <div class="p-4">
                <div class="mb-3">
                    <label class="form-label fw-bold">
                        Pixel ID
                        <small class="text-muted fw-normal ms-1">(Public)</small>
                    </label>
                    <input type="text" name="meta_pixel_id" class="form-control"
                           value="<?php echo htmlspecialchars($tracking['meta_pixel_id'] ?? ''); ?>"
                           placeholder="e.g. 123456789012345">
                    <div class="form-text">Found in Meta Events Manager → Data Sources</div>
                </div>

                <div class="mb-3">
                    <label class="form-label fw-bold">
                        Conversions API Access Token
                        <span class="badge bg-warning text-dark ms-1"><i class="fas fa-lock me-1"></i>Encrypted</span>
                    </label>
                    <div class="input-group">
                        <input type="password" name="meta_capi_access_token" id="meta_token_input" class="form-control"
                               placeholder="<?php echo $meta_token_masked ?: 'Paste your access token here'; ?>"
                               value="">
                        <button class="btn btn-outline-secondary" type="button" onclick="togglePassword('meta_token_input', this)">
                            <i class="fas fa-eye"></i>
                        </button>
                    </div>
                    <div class="form-text">
                        <?php if ($meta_token_raw): ?>
                            <span class="text-success"><i class="fas fa-check-circle me-1"></i>Token saved: <?php echo $meta_token_masked; ?></span>
                            <span class="text-muted ms-2">Leave blank to keep current token</span>
                        <?php else: ?>
                            <span class="text-muted">Generate in Meta Events Manager → Settings → Generate Access Token</span>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- TikTok Pixel Settings -->
    <div class="col-lg-6">
        <div class="admin-list-shell h-100">
            <div class="settings-panel-header admin-panel-header px-3 pt-3 pb-0 border-0">
                <div class="settings-panel-icon admin-panel-icon amber">
                    <i class="fab fa-tiktok"></i>
                </div>
                <div>
                    <h2 class="settings-panel-title admin-panel-title">TikTok Pixel</h2>
                    <p class="settings-panel-desc admin-panel-desc">Pixel ID ও Events API টোকেন</p>
                </div>
            </div>
            <div class="p-4">
                <div class="mb-3">
                    <label class="form-label fw-bold">
                        Pixel ID
                        <small class="text-muted fw-normal ms-1">(Public)</small>
                    </label>
                    <input type="text" name="tiktok_pixel_id" class="form-control"
                           value="<?php echo htmlspecialchars($tracking['tiktok_pixel_id'] ?? ''); ?>"
                           placeholder="e.g. CXXXXXXXXXXXXXXXXX">
                    <div class="form-text">Found in TikTok Ads Manager → Events → Web Events</div>
                </div>

                <div class="mb-3">
                    <label class="form-label fw-bold">
                        Events API Access Token
                        <span class="badge bg-warning text-dark ms-1"><i class="fas fa-lock me-1"></i>Encrypted</span>
                    </label>
                    <div class="input-group">
                        <input type="password" name="tiktok_events_api_token" id="tiktok_token_input" class="form-control"
                               placeholder="<?php echo $tiktok_token_masked ?: 'Paste your access token here'; ?>"
                               value="">
                        <button class="btn btn-outline-secondary" type="button" onclick="togglePassword('tiktok_token_input', this)">
                            <i class="fas fa-eye"></i>
                        </button>
                    </div>
                    <div class="form-text">
                        <?php if ($tiktok_token_raw): ?>
                            <span class="text-success"><i class="fas fa-check-circle me-1"></i>Token saved: <?php echo $tiktok_token_masked; ?></span>
                            <span class="text-muted ms-2">Leave blank to keep current token</span>
                        <?php else: ?>
                            <span class="text-muted">Generate in TikTok Business Center → Settings → Access Token</span>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Google Search Console & Analytics Settings -->
    <div class="col-lg-12">
        <div class="admin-list-shell">
            <div class="settings-panel-header admin-panel-header px-3 pt-3 pb-0 border-0">
                <div class="settings-panel-icon admin-panel-icon red">
                    <i class="fab fa-google"></i>
                </div>
                <div>
                    <h2 class="settings-panel-title admin-panel-title">Google Search Console & Analytics</h2>
                    <p class="settings-panel-desc admin-panel-desc">Verification, GA4, GTM ও Looker embed</p>
                </div>
            </div>
            <div class="p-4">
                <div class="row g-4">
                    <div class="col-md-6">
                        <label class="form-label fw-bold">Google Site Verification Code (Search Console)</label>
                        <input type="text" name="google_verification_code" class="form-control"
                               value="<?php echo htmlspecialchars($tracking['google_verification_code'] ?? ''); ?>"
                               placeholder="e.g. google-site-verification=XXXXXXXXXXXXXXXXXXXX or paste full tag">
                        <div class="form-text text-muted">Paste the <code>google-site-verification</code> tag/code. This verification tag is placed in the head of your site.</div>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label fw-bold">Google Analytics 4 Measurement ID (GA4)</label>
                        <input type="text" name="google_analytics_id" class="form-control"
                               value="<?php echo htmlspecialchars($tracking['google_analytics_id'] ?? ''); ?>"
                               placeholder="e.g. G-XXXXXXXXXX">
                        <div class="form-text text-muted">Enter your GA4 Measurement ID starting with <code>G-</code> to track site traffic.</div>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label fw-bold">Google Tag Manager Container ID (GTM)</label>
                        <input type="text" name="google_tag_manager_id" class="form-control"
                               value="<?php echo htmlspecialchars($tracking['google_tag_manager_id'] ?? ''); ?>"
                               placeholder="e.g. GTM-XXXXXXX">
                        <div class="form-text text-muted">Used for launching advanced analytics and tags through Google Tag Manager.</div>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label fw-bold">Looker Studio / Search Console Dashboard Embed URL</label>
                        <input type="text" name="google_search_console_embed" class="form-control"
                               value="<?php echo htmlspecialchars($tracking['google_search_console_embed'] ?? ''); ?>"
                               placeholder="https://lookerstudio.google.com/embed/reporting/...">
                        <div class="form-text text-muted">Allows you to view your Google Search Console reports directly in the admin dashboard. Connect Search Console to Looker Studio, choose Share -> Embed report, copy the URL and paste it here.</div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Options Card -->
    <div class="col-lg-12">
        <div class="admin-list-shell">
            <div class="settings-panel-header admin-panel-header px-3 pt-3 pb-0 border-0">
                <div class="settings-panel-icon admin-panel-icon sky">
                    <i class="fas fa-sliders-h"></i>
                </div>
                <div>
                    <h2 class="settings-panel-title admin-panel-title">Tracking Options</h2>
                    <p class="settings-panel-desc admin-panel-desc">Advanced matching ও test mode</p>
                </div>
            </div>
            <div class="p-4">
                <div class="row">
                    <div class="col-md-4 mb-3">
                        <div class="form-check form-switch">
                            <input class="form-check-input" type="checkbox" name="enable_advanced_matching" id="enable_advanced_matching" value="1"
                                   <?php echo ($tracking['enable_advanced_matching'] ?? 0) ? 'checked' : ''; ?>>
                            <label class="form-check-label fw-bold" for="enable_advanced_matching">
                                Enable Advanced Matching
                            </label>
                        </div>
                        <div class="form-text">Send hashed email/phone for better ad targeting (SHA-256)</div>
                    </div>
                    <div class="col-md-4 mb-3">
                        <div class="form-check form-switch">
                            <input class="form-check-input" type="checkbox" name="is_test_mode" id="is_test_mode" value="1"
                                   <?php echo ($tracking['is_test_mode'] ?? 0) ? 'checked' : ''; ?>
                                   onchange="document.getElementById('test_code_field').style.display = this.checked ? 'block' : 'none'">
                            <label class="form-check-label fw-bold" for="is_test_mode">
                                <i class="fas fa-flask text-warning me-1"></i> Test Mode
                            </label>
                        </div>
                        <div class="form-text">Events will be sent with test_event_code for debugging</div>
                    </div>
                    <div class="col-md-4 mb-3" id="test_code_field" style="display: <?php echo ($tracking['is_test_mode'] ?? 0) ? 'block' : 'none'; ?>">
                        <label class="form-label fw-bold">Meta Test Event Code</label>
                        <input type="text" name="meta_test_event_code" class="form-control"
                               value="<?php echo htmlspecialchars($tracking['meta_test_event_code'] ?? ''); ?>"
                               placeholder="e.g. TEST12345">
                        <div class="form-text">Found in Meta Events Manager → Test Events tab</div>
                    </div>
                </div>

                <!-- Hidden inputs for unchecked checkboxes -->
                <input type="hidden" name="enable_advanced_matching_hidden" value="0">
                <input type="hidden" name="is_test_mode_hidden" value="0">
            </div>
        </div>
    </div>
</div>
</div>
<div class="settings-save-bar admin-save-bar">
    <span class="settings-save-hint text-muted small d-none d-md-inline">পরিবর্তন সেভ করতে ক্লিক করুন</span>
    <div class="d-flex flex-wrap gap-2">
        <button type="submit" name="action" value="save_and_test" class="btn btn-outline-success px-4 fw-semibold">
            <i class="fas fa-vial me-2"></i> Save &amp; Test Connection
        </button>
        <button type="submit" name="action" value="save" class="btn btn-primary px-4 fw-semibold">
            <i class="fas fa-save me-2"></i> Save Tracking Settings
        </button>
    </div>
</div>
</form>
<div class="settings-panel-body admin-panel-body pt-0">
    <?php include __DIR__ . '/../includes/analytics/tab-alerts.php'; ?>
</div>
</section>

<!-- ════════════ TAB 3: API LOGS ════════════ -->
<section class="settings-panel admin-panel <?php echo $active_tab === 'logs' ? 'is-active' : ''; ?>" id="trk-logs" role="tabpanel" <?php echo $active_tab !== 'logs' ? 'hidden' : ''; ?>>
    <?php adminPanelHeader('API Logs', 'সাম্প্রতিক tracking API ইভেন্ট লগ', 'fa-list-alt', 'amber'); ?>
    <div class="settings-panel-body admin-panel-body pt-3">
    <div class="admin-list-shell overflow-hidden mb-0">
        <div class="admin-list-shell-header">
            <h3 class="admin-list-shell-title"><i class="fas fa-list-alt me-2 text-muted"></i>Recent API Logs</h3>
            <span class="badge bg-secondary"><?php echo count($api_logs); ?> recent</span>
        </div>
        <div class="admin-table-wrap">
                <table class="admin-table admin-table-mobile-cards">
                    <thead>
                        <tr>
                            <th scope="col">Platform</th>
                            <th scope="col">Event</th>
                            <th scope="col">Event ID</th>
                            <th scope="col">Status</th>
                            <th scope="col">HTTP</th>
                            <th scope="col">Error</th>
                            <th scope="col">Time</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($api_logs)): ?>
                            <tr><td colspan="7"><?php adminEmptyState('কোনো API Log নেই', 'ট্র্যাকিং কনফিগার করলে ইভেন্ট লগ এখানে দেখা যাবে', 'fa-list-alt'); ?></td></tr>
                        <?php else: ?>
                            <?php foreach ($api_logs as $log): ?>
                            <tr>
                                <td class="px-4">
                                    <?php if ($log['platform'] === 'meta'): ?>
                                        <span class="badge bg-primary-subtle text-primary"><i class="fab fa-facebook me-1"></i>Meta</span>
                                    <?php else: ?>
                                        <span class="badge bg-dark"><i class="fab fa-tiktok me-1"></i>TikTok</span>
                                    <?php endif; ?>
                                </td>
                                <td><code><?php echo htmlspecialchars($log['event_name']); ?></code></td>
                                <td><small class="text-muted"><?php echo htmlspecialchars(substr($log['event_id'] ?? '', 0, 20)); ?></small></td>
                                <td>
                                    <span class="status-badge <?php echo $log['status'] === 'success' ? 'delivered' : 'cancelled'; ?>">
                                        <?php echo $log['status'] === 'success' ? 'OK' : 'Failed'; ?>
                                    </span>
                                </td>
                                <td><span class="badge bg-light text-dark"><?php echo $log['response_code']; ?></span></td>
                                <td><small class="text-danger"><?php echo htmlspecialchars(substr($log['error_message'] ?? '', 0, 60)); ?></small></td>
                                <td><small class="text-muted"><?php echo date('M j, g:i A', strtotime($log['created_at'])); ?></small></td>
                            </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
        </div>
    </div>
    </div>
</section>

    </div><!-- /settings-content -->
</div><!-- /settings-layout -->

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
function togglePassword(inputId, btn) {
    const input = document.getElementById(inputId);
    const icon = btn.querySelector('i');
    if (input.type === 'password') {
        input.type = 'text';
        icon.classList.replace('fa-eye', 'fa-eye-slash');
    } else {
        input.type = 'password';
        icon.classList.replace('fa-eye-slash', 'fa-eye');
    }
}

(function initTrackingCharts() {
    if (typeof Chart === 'undefined') return;

    // Events Timeline — stacked bars (success/failed) + total line
    const tlCanvas = document.getElementById('trkTimelineChart');
    if (tlCanvas) {
        const labels = <?php echo $chart_labels; ?>;
        const okData = <?php echo $chart_success; ?>;
        const badData = <?php echo $chart_failed; ?>;
        new Chart(tlCanvas, {
            data: {
                labels: labels,
                datasets: [
                    {
                        type: 'line',
                        label: 'Total',
                        data: okData.map((v, i) => v + badData[i]),
                        borderColor: '#6366f1',
                        backgroundColor: 'rgba(99, 102, 241, 0.08)',
                        fill: true,
                        tension: 0.35,
                        pointRadius: labels.length > 35 ? 0 : 3,
                        order: 0
                    },
                    {
                        type: 'bar',
                        label: 'Success',
                        data: okData,
                        backgroundColor: 'rgba(34, 197, 94, 0.75)',
                        borderRadius: 4,
                        stack: 'ev',
                        order: 1
                    },
                    {
                        type: 'bar',
                        label: 'Failed',
                        data: badData,
                        backgroundColor: 'rgba(239, 68, 68, 0.8)',
                        borderRadius: 4,
                        stack: 'ev',
                        order: 1
                    }
                ]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                interaction: { mode: 'index', intersect: false },
                plugins: { legend: { position: 'bottom', labels: { usePointStyle: true, boxHeight: 7 } } },
                scales: {
                    x: { stacked: true, grid: { display: false } },
                    y: { stacked: true, beginAtZero: true, ticks: { precision: 0 } }
                }
            }
        });
    }

    // Platform doughnut
    const pfCanvas = document.getElementById('trkPlatformChart');
    if (pfCanvas) {
        new Chart(pfCanvas, {
            type: 'doughnut',
            data: {
                labels: <?php echo $platform_labels; ?>,
                datasets: [{
                    data: <?php echo $platform_counts; ?>,
                    backgroundColor: ['#1877f2', '#0f172a', '#f59e0b'],
                    borderWidth: 3,
                    borderColor: '#ffffff'
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                cutout: '68%',
                plugins: { legend: { position: 'bottom', labels: { usePointStyle: true, boxHeight: 7 } } }
            }
        });
    }

    // Event type horizontal bars
    const evCanvas = document.getElementById('trkEventChart');
    if (evCanvas) {
        new Chart(evCanvas, {
            type: 'bar',
            data: {
                labels: <?php echo $event_labels; ?>,
                datasets: [{
                    data: <?php echo $event_counts; ?>,
                    backgroundColor: ['#3b82f6', '#22c55e', '#f59e0b', '#8b5cf6', '#06b6d4', '#ef4444', '#ec4899', '#64748b'],
                    borderRadius: 6
                }]
            },
            options: {
                indexAxis: 'y',
                responsive: true,
                maintainAspectRatio: false,
                plugins: { legend: { display: false } },
                scales: {
                    x: { beginAtZero: true, ticks: { precision: 0 } },
                    y: { grid: { display: false } }
                }
            }
        });
    }
})();
</script>
