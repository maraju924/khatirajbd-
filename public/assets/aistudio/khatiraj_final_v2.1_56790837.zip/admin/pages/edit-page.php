<?php
// admin/pages/edit-page.php
declare(strict_types=1);

require_once __DIR__ . '/../../app/Helpers/PageHelper.php';

$page_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

if ($page_id <= 0) {
    echo '<div class="alert alert-danger m-4">Invalid Page ID.</div>';
    return;
}

$stmt = $pdo->prepare('SELECT * FROM page_registry WHERE id = ?');
$stmt->execute([$page_id]);
$page_data = $stmt->fetch();

if (!$page_data) {
    echo '<div class="alert alert-danger m-4">Page not found.</div>';
    return;
}

if (!PageHelper::isManageable((string)$page_data['route_key'])) {
    echo '<div class="alert alert-warning m-4">এই পেজ Page & SEO Manager এ সম্পাদনাযোগ্য নয়। SEO প্রতি পেজের নিজস্ব হেডার/এন্টিটি ফিল্ড থেকে আসে। <a href="index.php?page=page-manager" class="alert-link">পেজ তালিকায় ফিরে যান</a>.</div>';
    return;
}

// Auto-upgrade legacy wysiwyg custom pages to advanced section builder
if (($page_data['content_mode'] ?? '') === 'wysiwyg' && ($page_data['page_group'] ?? '') === 'content') {
    $pdo->prepare("UPDATE page_registry SET content_mode = 'sections' WHERE id = ?")->execute([$page_id]);
    $page_data['content_mode'] = 'sections';
    $cnt = $pdo->prepare('SELECT COUNT(*) FROM page_sections WHERE page_id = ?');
    $cnt->execute([$page_id]);
    if ((int)$cnt->fetchColumn() === 0 && trim((string)($page_data['content_html'] ?? '')) !== '') {
        $ins = $pdo->prepare(
            'INSERT INTO page_sections (page_id, section_key, section_type, title, subtitle, content, sort_order, status)
             VALUES (?, ?, ?, ?, ?, ?, 1, 1)'
        );
        $ins->execute([
            $page_id,
            'body_content',
            'text',
            (string)($page_data['h1_title'] ?? $page_data['page_name']),
            (string)($page_data['subtitle'] ?? ''),
            (string)$page_data['content_html'],
        ]);
    }
}

$stmt_sections = $pdo->prepare('SELECT * FROM page_sections WHERE page_id = ? ORDER BY sort_order ASC');
$stmt_sections->execute([$page_id]);
$page_sections = $stmt_sections->fetchAll(PDO::FETCH_ASSOC);

$active_tab = isset($_GET['tab']) ? (string)$_GET['tab'] : 'seo';
if (!in_array($active_tab, ['seo', 'content'], true)) {
    $active_tab = 'seo';
}
$sections_json = json_encode($page_sections, JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_AMP);
?>

<link rel="stylesheet" href="css/page-builder.css?v=3">

<?php adminFlashMessages(); ?>
<?php
$edit_page_actions = [
    ['label' => 'Page Manager', 'icon' => 'fa-arrow-left', 'url' => 'index.php?page=page-manager', 'class' => 'btn btn-outline-secondary btn-sm'],
];
if ($page_data['slug'] !== null && $page_data['slug'] !== '404') {
    $edit_page_actions[] = [
        'label' => 'View Live',
        'icon' => 'fa-external-link-alt',
        'url' => '../' . ltrim((string)$page_data['slug'], '/'),
        'class' => 'btn btn-outline-primary btn-sm',
        'target' => '_blank',
        'data-no-pjax' => true,
    ];
}
adminPageHeader(
    'Page সম্পাদনা: ' . $page_data['page_name'],
    'Route Key: ' . $page_data['route_key'] . ' — SEO ও Advanced Page Builder',
    $edit_page_actions
);
?>

<div class="settings-layout admin-shell" data-panel-prefix="page">
    <nav class="settings-tabs admin-tabs" aria-label="Page edit sections">
        <div class="settings-tabs-track admin-tabs-track" role="tablist">
            <a href="#page-seo" class="settings-tab admin-tab <?php echo $active_tab === 'seo' ? 'active' : ''; ?>" data-admin-nav="seo" role="tab" aria-selected="<?php echo $active_tab === 'seo' ? 'true' : 'false'; ?>">
                <i class="fas fa-search"></i><span>SEO &amp; Meta</span>
            </a>
            <a href="#page-content" class="settings-tab admin-tab <?php echo $active_tab === 'content' ? 'active' : ''; ?>" data-admin-nav="content" role="tab" aria-selected="<?php echo $active_tab === 'content' ? 'true' : 'false'; ?>">
                <i class="fas fa-layer-group"></i><span>Page Builder</span>
            </a>
        </div>
    </nav>

    <div class="settings-content">
        <section class="settings-panel admin-panel <?php echo $active_tab === 'seo' ? 'is-active' : ''; ?>" id="page-seo" role="tabpanel" <?php echo $active_tab !== 'seo' ? 'hidden' : ''; ?>>
            <?php adminPanelHeader('SEO & Meta', 'ফোকাস কিওয়ার্ড, মেটা ও স্ট্যাটাস', 'fa-search', 'blue'); ?>
            <form action="actions/page-save.php" method="POST" class="settings-form">
                <input type="hidden" name="id" value="<?php echo (int)$page_data['id']; ?>">
                <div class="settings-panel-body admin-panel-body">
                    <div class="row g-3">
                        <div class="col-md-6">
                            <label class="form-label fw-bold">Focus Keyword</label>
                            <input type="text" name="focus_keyword" class="form-control" value="<?php echo htmlspecialchars((string)($page_data['focus_keyword'] ?? '')); ?>">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label fw-bold">URL Slug</label>
                            <input type="text" name="slug" class="form-control" value="<?php echo htmlspecialchars((string)($page_data['slug'] ?? '')); ?>"
                                   <?php echo $page_data['page_group'] !== 'content' ? 'readonly' : ''; ?>>
                        </div>
                        <div class="col-12">
                            <label class="form-label fw-bold">Meta Title</label>
                            <input type="text" name="meta_title" class="form-control" value="<?php echo htmlspecialchars((string)($page_data['meta_title'] ?? '')); ?>">
                        </div>
                        <div class="col-12">
                            <label class="form-label fw-bold">Meta Keywords</label>
                            <input type="text" name="meta_keywords" class="form-control" value="<?php echo htmlspecialchars((string)($page_data['meta_keywords'] ?? '')); ?>">
                        </div>
                        <div class="col-12">
                            <label class="form-label fw-bold">Meta Description</label>
                            <textarea name="meta_description" class="form-control" rows="3"><?php echo htmlspecialchars((string)($page_data['meta_description'] ?? '')); ?></textarea>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label fw-bold">Social Share Image (OG Image)</label>
                            <div class="input-group">
                                <input type="text" name="og_image" id="og_image_input" class="form-control" value="<?php echo htmlspecialchars((string)($page_data['og_image'] ?? '')); ?>">
                                <button type="button" class="btn btn-outline-secondary" onclick="openMediaPicker('og_image_input')">Browse</button>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label fw-bold">Canonical URL Override</label>
                            <input type="text" name="canonical_override" class="form-control" value="<?php echo htmlspecialchars((string)($page_data['canonical_override'] ?? '')); ?>">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label fw-bold">Status</label>
                            <select name="status" class="form-select">
                                <option value="1" <?php echo $page_data['status'] ? 'selected' : ''; ?>>Active</option>
                                <option value="0" <?php echo !$page_data['status'] ? 'selected' : ''; ?>>Disabled</option>
                            </select>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label fw-bold">Sort Order</label>
                            <input type="number" name="sort_order" class="form-control" value="<?php echo (int)$page_data['sort_order']; ?>">
                        </div>
                    </div>
                </div>
                <?php adminSaveBar('Save SEO Settings'); ?>
            </form>
        </section>

        <section class="settings-panel admin-panel <?php echo $active_tab === 'content' ? 'is-active' : ''; ?>" id="page-content" role="tabpanel" <?php echo $active_tab !== 'content' ? 'hidden' : ''; ?>>
            <?php adminPanelHeader('Advanced Page Builder', 'ব্লক যোগ করুন, সাজান ও এডিট করুন', 'fa-layer-group', 'green'); ?>
            <?php if ($page_data['content_mode'] === 'none'): ?>
                <div class="settings-panel-body admin-panel-body text-center py-5">
                    <i class="fas fa-shield-halved fa-4x text-muted mb-3"></i>
                    <h5 class="fw-bold text-dark mb-2">System Controlled Layout</h5>
                    <p class="text-muted mb-0">This page uses a fixed template. Only heading overrides (if any) apply.</p>
                </div>
            <?php else: ?>
                <div class="pb-workspace">
                    <div class="pb-topbar">
                        <div>
                            <p class="title mb-0"><i class="fas fa-layer-group me-2 text-success"></i>Advanced Page Builder</p>
                            <p class="sub">Left থেকে ব্লক যোগ করুন · মাঝে সাজান · ডানে এডিট করুন</p>
                        </div>
                        <div class="d-flex align-items-center gap-2">
                            <?php if (($page_data['route_key'] ?? '') === 'home'): ?>
                                <span class="badge text-bg-warning">Home headings only</span>
                            <?php endif; ?>
                            <span class="badge text-bg-dark rounded-pill px-3"><?php echo count($page_sections); ?> blocks</span>
                            <?php if ($page_data['slug'] !== null): ?>
                                <a href="../<?php echo ltrim((string)$page_data['slug'], '/'); ?>" target="_blank" class="btn btn-sm btn-outline-success rounded-pill" data-no-pjax>
                                    <i class="fas fa-external-link-alt me-1"></i> Preview
                                </a>
                            <?php endif; ?>
                        </div>
                    </div>

                    <div id="pb-toast" style="display:none" class="mx-3 mt-2"></div>
                    <script type="application/json" id="pb-sections-json"><?php echo $sections_json ?: '[]'; ?></script>

                    <div id="pb-root"
                         data-page-id="<?php echo (int)$page_id; ?>"
                         data-save-url="actions/section-save.php"
                         data-base-url="<?php echo htmlspecialchars(BASE_URL); ?>">
                        <div class="pb-shell">
                            <aside class="pb-palette">
                                <div class="pb-palette-head">
                                    <h6>Block Library</h6>
                                    <p>ক্লিক করে ক্যানভাসে যোগ করুন</p>
                                </div>
                                <div id="pb-palette-list"></div>
                            </aside>
                            <div class="pb-canvas-wrap">
                                <div class="pb-canvas-toolbar">
                                    <div>
                                        <h5>Canvas</h5>
                                        <small>Drag করে reorder · ক্লিক করে edit</small>
                                    </div>
                                </div>
                                <div id="pb-empty" class="pb-empty" style="<?php echo $page_sections ? 'display:none' : ''; ?>">
                                    <i class="fas fa-layer-group fa-3x mb-3"></i>
                                    <h5 class="fw-bold text-dark">Start building</h5>
                                    <p class="mb-0">বাম পাশ থেকে Hero / Text / Features যেকোনো ব্লক বেছে নিন</p>
                                </div>
                                <div id="pb-canvas" class="pb-canvas"></div>
                            </div>
                            <aside class="pb-inspector" id="pb-inspector">
                                <h5>Inspector</h5>
                                <p class="hint">একটি ব্লক সিলেক্ট করুন বা বাম থেকে নতুন যোগ করুন</p>
                            </aside>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
        </section>
    </div>
</div>

<?php if ($page_data['content_mode'] !== 'none'): ?>
<script src="js/page-builder.js?v=3"></script>
<script>
(function () {
  function run() {
    if (typeof window.initPageBuilder === 'function') {
      window.initPageBuilder();
    }
  }
  document.addEventListener('click', function (e) {
    var a = e.target.closest('[data-admin-nav="content"]');
    if (a) setTimeout(run, 50);
  }, true);
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', run);
  } else {
    run();
  }
})();
</script>
<?php endif; ?>
