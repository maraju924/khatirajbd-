<?php
// admin/pages/add-product.php
$categories = $pdo->query("SELECT * FROM categories WHERE status = 1")->fetchAll();
$shipping_classes = $pdo->query("SELECT * FROM shipping_classes WHERE status = 1")->fetchAll();
$shipping_zones = $pdo->query("SELECT * FROM shipping_zones WHERE status = 1")->fetchAll();
require_once '../app/Services/PaymentGateway.php';
$pg = new PaymentGateway($pdo);
$payment_methods = $pg->getPaymentMethods(null, true);

require_once __DIR__ . '/../../app/Helpers/ProductVariantHelper.php';
$product_variant_data = ['enabled' => false, 'attributes' => [], 'variants' => []];
?>

<?php adminFlashMessages(); ?>
<?php adminPageHeader('Add Product', 'নতুন পণ্য যোগ করুন ও কনফিগার করুন', [
    ['label' => 'পণ্য তালিকা', 'icon' => 'fa-arrow-left', 'url' => 'index.php?page=products', 'class' => 'btn btn-outline-secondary btn-sm'],
]); ?>

<form action="actions/product-save.php" method="POST" enctype="multipart/form-data" class="settings-form">
    <div class="settings-layout admin-shell" data-panel-prefix="prod">
        <nav class="settings-tabs admin-tabs" aria-label="Product sections">
            <div class="settings-tabs-track admin-tabs-track" role="tablist">
                <a href="#prod-general" class="settings-tab admin-tab active" data-admin-nav="general" role="tab" aria-selected="true">
                    <i class="fas fa-info-circle"></i><span>General</span>
                </a>
                <a href="#prod-pricing" class="settings-tab admin-tab" data-admin-nav="pricing" role="tab" aria-selected="false">
                    <i class="fas fa-tags"></i><span>Pricing / Inventory</span>
                </a>
                <a href="#prod-media" class="settings-tab admin-tab" data-admin-nav="media" role="tab" aria-selected="false">
                    <i class="fas fa-images"></i><span>Media</span>
                </a>
                <a href="#prod-variants" class="settings-tab admin-tab" data-admin-nav="variants" role="tab" aria-selected="false">
                    <i class="fas fa-layer-group"></i><span>Variants</span>
                </a>
                <a href="#prod-seo" class="settings-tab admin-tab" data-admin-nav="seo" role="tab" aria-selected="false">
                    <i class="fas fa-search"></i><span>SEO</span>
                </a>
            </div>
        </nav>

        <div class="settings-content">
            <section class="settings-panel admin-panel is-active" id="prod-general" role="tabpanel">
                <?php adminPanelHeader('General', 'নাম, স্লাগ, ক্যাটাগরি, টাইপ ও বিবরণ', 'fa-info-circle', 'green'); ?>
                <div class="settings-panel-body admin-panel-body">
                    <div class="mb-3">
                        <label class="form-label">Product Name *</label>
                        <input type="text" name="name" id="product_name" class="form-control" required>
                    </div>

                    <div class="mb-3">
                        <label class="form-label">Slug / URL Key *</label>
                        <input type="text" name="slug" id="slug" class="form-control" required placeholder="যেমন: super-honey-500g">
                        <div class="form-text">এসইও ফ্রেন্ডলি প্রোডাক্ট লিংক/ইউআরএল এর জন্য (যেমন: <code>super-honey-500g</code>)</div>
                    </div>

                    <script>
                    document.getElementById('product_name').addEventListener('input', function() {
                        document.getElementById('slug').value = slugify(this.value);
                    });
                    function slugify(text) {
                        return text.toString().toLowerCase()
                            .replace(/\s+/g, '-')
                            .replace(/[^\w\u0980-\u09ff-]+/g, '')
                            .replace(/\-\-+/g, '-')
                            .replace(/^-+/, '')
                            .replace(/-+$/, '');
                    }
                    </script>

                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Brand / Manufacturer</label>
                            <input type="text" name="brand" class="form-control" placeholder="যেমন: KhatiRaj BD, Bihado, Manee">
                            <div class="form-text">প্রোডাক্টের ব্র্যান্ড নাম (Google Product Listing-এ গুরুত্বপূর্ণ)</div>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">SKU / Product Code</label>
                            <input type="text" name="sku" class="form-control" placeholder="যেমন: KR-HONEY-001">
                            <div class="form-text">প্রতিটি প্রোডাক্টের ইউনিক কোড (Google-এ আলাদাভাবে চিনতে সাহায্য করে)</div>
                        </div>
                    </div>

                    <div class="mb-3">
                        <label class="form-label">Category *</label>
                        <select name="category_id" class="form-select" required>
                            <option value="">Select Category</option>
                            <?php foreach($categories as $cat): ?>
                                <option value="<?php echo $cat['id']; ?>"><?php echo htmlspecialchars($cat['name']); ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="mb-4 p-3 border rounded-3 bg-light">
                        <div class="row align-items-center">
                            <div class="col-md-6 mb-3 mb-md-0">
                                <label class="form-label fw-bold d-block">Product Type</label>
                                <div class="form-check form-check-inline">
                                    <input class="form-check-input" type="radio" name="product_type" id="type_physical" value="physical" checked onclick="toggleDigitalSection(false)">
                                    <label class="form-check-label" for="type_physical">Physical Product</label>
                                </div>
                                <div class="form-check form-check-inline">
                                    <input class="form-check-input" type="radio" name="product_type" id="type_digital" value="digital" onclick="toggleDigitalSection(true)">
                                    <label class="form-check-label" for="type_digital">Digital Product</label>
                                </div>
                            </div>
                            <div class="col-md-6" id="digital_section" style="display: none;">
                                <label class="form-label fw-bold">Digital File URL / Download Link</label>
                                <div class="input-group">
                                    <span class="input-group-text"><i class="fas fa-link"></i></span>
                                    <input type="text" name="digital_file_url" id="digital_file_url" class="form-control" placeholder="https://example.com/file.zip">
                                    <button class="btn btn-dark" type="button" onclick="openMediaPicker('digital_file_url')">
                                        <i class="fas fa-file-upload"></i> Select File
                                    </button>
                                </div>
                                <div class="form-text small">Provide the link or select a file from media manager.</div>
                            </div>
                        </div>
                    </div>

                    <script>
                    function toggleDigitalSection(show) {
                        const section = document.getElementById('digital_section');
                        const fileInput = document.getElementById('digital_file_url');
                        section.style.display = show ? 'block' : 'none';
                        if(show) {
                            fileInput.setAttribute('required', 'required');
                            document.getElementById('shipping_card_wrapper')?.classList.add('d-none');
                        } else {
                            fileInput.removeAttribute('required');
                            document.getElementById('shipping_card_wrapper')?.classList.remove('d-none');
                        }
                    }
                    </script>

                    <div class="mb-4">
                        <div class="d-flex justify-content-between align-items-center mb-3">
                            <h6 class="mb-0 fw-bold"><i class="fas fa-list-ul me-2 text-primary"></i>Product Sections</h6>
                            <button type="button" class="btn btn-sm btn-dark" onclick="addSection()">
                                <i class="fas fa-plus me-1"></i> Add New Section
                            </button>
                        </div>
                        <div id="dynamic-sections-container"></div>
                        <div class="form-text mt-2"><i class="fas fa-info-circle me-1"></i>You can add unlimited sections, and inside each section you can add unlimited bullet points/text lines.</div>
                    </div>

                    <script>
                    let sectionIndex = 0;
                    function addSection(title = '', icon = 'fas fa-check-circle', items = []) {
                        const container = document.getElementById('dynamic-sections-container');
                        const index = sectionIndex++;
                        let itemsHtml = '';
                        items.forEach((item) => { itemsHtml += createItemRowHtml(index, item); });
                        const iconOptions = [
                            {value: 'fas fa-check-circle', label: 'Check Circle (Default)'},
                            {value: 'fas fa-shield-alt', label: 'Shield / Security'},
                            {value: 'fas fa-heart', label: 'Heart / Trust'},
                            {value: 'fas fa-truck', label: 'Truck / Delivery'},
                            {value: 'fas fa-undo', label: 'Undo / Return'},
                            {value: 'fas fa-leaf', label: 'Leaf / Organic'},
                            {value: 'fas fa-star', label: 'Star / Review'},
                            {value: 'fas fa-award', label: 'Award / Quality'},
                            {value: 'fas fa-gift', label: 'Gift / Offer'},
                            {value: 'fas fa-info-circle', label: 'Info Circle'}
                        ];
                        let selectOptions = '';
                        iconOptions.forEach(opt => {
                            const selected = opt.value === icon ? 'selected' : '';
                            selectOptions += `<option value="${opt.value}" ${selected}>${opt.label}</option>`;
                        });
                        const html = `
                        <div class="card mb-3 border border-secondary border-opacity-25 rounded-3 section-block" data-section-index="${index}">
                            <div class="card-header bg-light d-flex justify-content-between align-items-center py-2">
                                <h6 class="mb-0 fw-bold"><i class="fas fa-th me-2 text-primary"></i>Section #<span class="section-num"></span></h6>
                                <button type="button" class="btn btn-sm btn-outline-danger remove-section-btn py-1"><i class="fas fa-trash"></i> Remove Section</button>
                            </div>
                            <div class="card-body p-3">
                                <div class="row g-2 mb-3">
                                    <div class="col-md-7">
                                        <label class="form-label small fw-bold">Section Heading *</label>
                                        <input type="text" name="sections[${index}][title]" class="form-control form-control-sm" value="${escapeHtml(title)}" placeholder="যেমন: উপকারিতা, কেন আমাদের থেকে নিবেন..." required>
                                    </div>
                                    <div class="col-md-5">
                                        <label class="form-label small fw-bold">Section Icon (FontAwesome)</label>
                                        <select name="sections[${index}][icon]" class="form-select form-select-sm">${selectOptions}</select>
                                    </div>
                                </div>
                                <div class="mb-0">
                                    <label class="form-label small fw-bold">Section Items (List Lines) *</label>
                                    <div class="items-list-container mb-2 d-flex flex-column gap-2">${itemsHtml}</div>
                                    <button type="button" class="btn btn-sm btn-light border add-item-btn py-1 px-3"><i class="fas fa-plus me-1 text-success"></i> Add Line</button>
                                </div>
                            </div>
                        </div>`;
                        const div = document.createElement('div');
                        div.innerHTML = html.trim();
                        const element = div.firstChild;
                        container.appendChild(element);
                        element.querySelector('.remove-section-btn').addEventListener('click', function() {
                            element.remove();
                            updateSectionNumbers();
                        });
                        element.querySelector('.add-item-btn').addEventListener('click', function() {
                            const itemsContainer = element.querySelector('.items-list-container');
                            const itemRow = document.createElement('div');
                            itemRow.innerHTML = createItemRowHtml(index, '').trim();
                            const rowElement = itemRow.firstChild;
                            itemsContainer.appendChild(rowElement);
                            rowElement.querySelector('.remove-item-btn').addEventListener('click', function() { rowElement.remove(); });
                        });
                        if (items.length === 0) element.querySelector('.add-item-btn').click();
                        updateSectionNumbers();
                    }
                    function createItemRowHtml(sectionIdx, value) {
                        return `<div class="input-group input-group-sm item-row">
                            <span class="input-group-text bg-white"><i class="fas fa-circle-notch text-muted" style="font-size: 0.7rem;"></i></span>
                            <input type="text" name="sections[${sectionIdx}][items][]" class="form-control" value="${escapeHtml(value)}" placeholder="লাইন লিখুন (যেমন: ১০০% খাঁটি উপাদান)" required>
                            <button type="button" class="btn btn-danger remove-item-btn"><i class="fas fa-times"></i></button>
                        </div>`;
                    }
                    function updateSectionNumbers() {
                        document.querySelectorAll('#dynamic-sections-container .section-block').forEach((block, idx) => {
                            block.querySelector('.section-num').innerText = idx + 1;
                        });
                    }
                    function escapeHtml(text) {
                        if (!text) return '';
                        return text.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#039;");
                    }
                    document.addEventListener('DOMContentLoaded', function() {
                        addSection('উপকারিতা:', 'fas fa-shield-alt', ['১০০% খাঁটি ও প্রাকৃতিক উপাদান', 'কোনো প্রকার ভেজাল নেই', 'গুনগত মান নিশ্চিত']);
                        addSection('কেন আমাদের থেকে নিবেন?', 'fas fa-heart', ['সারাদেশে হোম ডেলিভারি', 'সঠিক মাপ ও ওজনের নিশ্চয়তা', 'প্রিমিয়াম কোয়ালিটি নিশ্চিত']);
                    });
                    </script>

                    <div class="mb-3">
                        <label class="form-label">Details Section Heading</label>
                        <input type="text" name="details_title" class="form-control" value="বিস্তারিত বিবরণ:">
                    </div>

                    <div class="mb-3">
                        <label class="form-label fw-bold"><i class="fas fa-file-alt me-1 text-primary"></i> Detailed Description / Product Content</label>
                        <textarea name="description" id="productDescription" class="form-control" rows="8" placeholder="এখানে বিস্তারিত বিবরণ লিখুন..."></textarea>
                    </div>

                    <script src="https://cdn.ckeditor.com/ckeditor5/41.4.2/classic/ckeditor.js"></script>
                    <style>
                        .ck-editor__editable { min-height: 300px !important; font-size: 1rem; line-height: 1.8; }
                        .ck.ck-editor { border-radius: 8px; overflow: hidden; }
                        .ck.ck-editor__main>.ck-editor__editable { border-color: #dee2e6 !important; }
                        .ck.ck-editor__main>.ck-editor__editable:focus { border-color: #86b7fe !important; box-shadow: 0 0 0 0.25rem rgba(13,110,253,.25) !important; }
                    </style>
                    <script>
                    let productEditor;
                    ClassicEditor
                        .create(document.querySelector('#productDescription'), {
                            toolbar: ['heading', '|', 'bold', 'italic', 'underline', 'strikethrough', '|', 'bulletedList', 'numberedList', '|', 'blockQuote', 'insertTable', '|', 'link', 'mediaEmbed', '|', 'undo', 'redo'],
                            heading: {
                                options: [
                                    { model: 'paragraph', title: 'Paragraph', class: 'ck-heading_paragraph' },
                                    { model: 'heading2', view: 'h2', title: 'Heading 2', class: 'ck-heading_heading2' },
                                    { model: 'heading3', view: 'h3', title: 'Heading 3', class: 'ck-heading_heading3' },
                                    { model: 'heading4', view: 'h4', title: 'Heading 4', class: 'ck-heading_heading4' }
                                ]
                            },
                            placeholder: 'এখানে বিস্তারিত বিবরণ লিখুন... (Bold, Heading, List, Link ইত্যাদি ব্যবহার করতে পারবেন)'
                        })
                        .then(editor => {
                            productEditor = editor;
                            const form = document.querySelector('#productDescription')?.closest('form')
                                         || document.querySelector('form[action*="product-save"]');
                            if (form) {
                                form.addEventListener('submit', function() {
                                    if (typeof editor.updateSourceElement === 'function') editor.updateSourceElement();
                                    const textarea = document.querySelector('#productDescription');
                                    if (textarea) textarea.value = editor.getData();
                                    if (!textarea || !textarea.closest('form')) {
                                        let hidden = form.querySelector('input[name="description"]');
                                        if (!hidden) {
                                            hidden = document.createElement('input');
                                            hidden.type = 'hidden';
                                            hidden.name = 'description';
                                            form.appendChild(hidden);
                                        }
                                        hidden.value = editor.getData();
                                    }
                                });
                            }
                        })
                        .catch(error => console.error('CKEditor Error:', error));
                    </script>

                    <div class="mb-3">
                        <label class="form-label">YouTube Video URL</label>
                        <input type="url" name="video_url" class="form-control" placeholder="https://youtube.com/watch?v=...">
                    </div>

                    <div class="mb-0">
                        <label class="form-label fw-bold"><i class="fas fa-globe me-1 text-primary"></i>Website Visibility</label>
                        <div class="form-check form-switch">
                            <input class="form-check-input" type="checkbox" role="switch" name="show_on_website" id="show_on_website" value="1" checked style="width: 3em; height: 1.5em;">
                            <label class="form-check-label ms-2 fw-bold" for="show_on_website" id="visibility_label">
                                <span class="text-success"><i class="fas fa-eye me-1"></i>Visible on Website</span>
                            </label>
                        </div>
                        <div class="form-text small mt-2">
                            <i class="fas fa-info-circle me-1"></i>OFF করলে প্রোডাক্ট ওয়েবসাইটে দেখাবে না, তবে ল্যান্ডিং পেজে ব্যবহার করা যাবে।
                        </div>
                    </div>
                    <script>
                    document.getElementById('show_on_website')?.addEventListener('change', function() {
                        const label = document.getElementById('visibility_label');
                        label.innerHTML = this.checked
                            ? '<span class="text-success"><i class="fas fa-eye me-1"></i>Visible on Website</span>'
                            : '<span class="text-warning"><i class="fas fa-eye-slash me-1"></i>Hidden from Website</span>';
                    });
                    </script>
                </div>
            </section>

            <section class="settings-panel admin-panel" id="prod-pricing" role="tabpanel" hidden>
                <?php adminPanelHeader('Pricing / Inventory', 'মূল্য, স্টক, শিপিং ও পেমেন্ট', 'fa-tags', 'amber'); ?>
                <div class="settings-panel-body admin-panel-body">
                    <div class="row">
                        <div class="col-md-4 mb-3">
                            <label class="form-label">Regular Price (৳) *</label>
                            <input type="number" step="0.01" name="price" class="form-control" required>
                        </div>
                        <div class="col-md-4 mb-3">
                            <label class="form-label">Offer Price (৳)</label>
                            <input type="number" step="0.01" name="offer_price" class="form-control">
                        </div>
                        <div class="col-md-4 mb-3">
                            <label class="form-label">Stock Status</label>
                            <select name="stock_status" class="form-select">
                                <option value="In Stock">In Stock</option>
                                <option value="Out of Stock">Out of Stock</option>
                            </select>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-4 mb-3">
                            <label class="form-label">Stock Quantity</label>
                            <input type="number" name="quantity" class="form-control" value="10">
                        </div>
                        <div class="col-md-4 mb-3">
                            <label class="form-label">Weight (ওজন)</label>
                            <input type="text" name="weight" class="form-control" placeholder="যেমন: 500g, 1kg, 250ml">
                            <div class="form-text">Google Shopping ও Rich Result-এ দেখায়</div>
                        </div>
                        <div class="col-md-4 mb-3">
                            <label class="form-label">Dimensions (মাপ)</label>
                            <input type="text" name="dimensions" class="form-control" placeholder="যেমন: 10cm x 5cm x 3cm">
                            <div class="form-text">প্রোডাক্টের দৈর্ঘ্য x প্রস্থ x উচ্চতা</div>
                        </div>
                    </div>
                    <div class="mb-3" id="shipping_card_wrapper">
                        <label class="form-label">Shipping Class</label>
                        <select name="shipping_class_id" class="form-select">
                            <option value="">No Special Class</option>
                            <?php foreach($shipping_classes as $sc): ?>
                                <option value="<?php echo $sc['id']; ?>"><?php echo htmlspecialchars($sc['name']); ?> (+৳<?php echo number_format($sc['extra_charge']); ?>)</option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-bold">Available Shipping Zones</label>
                        <div class="shipping-zones-list px-2" style="max-height: 150px; overflow-y: auto; border: 1px solid #dee2e6; padding: 10px; border-radius: 5px; background: #fff;">
                            <?php foreach($shipping_zones as $zone): ?>
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" name="shipping_zones[]" value="<?php echo $zone['id']; ?>" id="zone_<?php echo $zone['id']; ?>" checked>
                                    <label class="form-check-label" for="zone_<?php echo $zone['id']; ?>">
                                        <?php echo htmlspecialchars($zone['name']); ?> (৳<?php echo number_format($zone['charge']); ?>)
                                    </label>
                                </div>
                            <?php endforeach; ?>
                            <?php if (empty($shipping_zones)): ?>
                                <p class="text-muted small mb-0">No shipping zones found.</p>
                            <?php endif; ?>
                        </div>
                        <div class="form-text small mt-2">Select the zones where this product can be shipped.</div>
                    </div>
                    <div class="mb-0">
                        <label class="form-label fw-bold">Allowed Payment Methods</label>
                        <div class="payment-methods-list px-2" style="max-height: 150px; overflow-y: auto; border: 1px solid #dee2e6; padding: 10px; border-radius: 5px; background: #fff;">
                            <div class="form-check mb-2">
                                <input class="form-check-input" type="checkbox" name="payment_method_cod" value="1" id="pm_cod" checked>
                                <label class="form-check-label fw-bold" for="pm_cod">Cash on Delivery (COD)</label>
                            </div>
                            <hr class="my-2">
                            <?php foreach($payment_methods as $pm): ?>
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" name="payment_methods[]" value="<?php echo $pm['id']; ?>" id="pm_<?php echo $pm['id']; ?>" checked>
                                    <label class="form-check-label" for="pm_<?php echo $pm['id']; ?>"><?php echo htmlspecialchars($pm['name']); ?></label>
                                </div>
                            <?php endforeach; ?>
                        </div>
                        <div class="form-text small mt-2">Select which payment methods are allowed for this product. By default, all are selected.</div>
                    </div>
                </div>
            </section>

            <section class="settings-panel admin-panel" id="prod-media" role="tabpanel" hidden>
                <?php adminPanelHeader('Media', 'প্রধান ছবি ও গ্যালারি', 'fa-images', 'blue'); ?>
                <div class="settings-panel-body admin-panel-body">
                    <div class="mb-4">
                        <label class="form-label">Product Image *</label>
                        <div class="media-picker-container text-center p-3 border rounded bg-light" style="max-width: 360px;">
                            <input type="hidden" name="image" id="product_image" required>
                            <img id="product_image_preview" src="" class="img-fluid rounded mb-2 d-none" style="max-height: 150px;">
                            <div id="product_image_placeholder" class="py-3">
                                <i class="fas fa-image fa-3x text-muted mb-2"></i>
                                <p class="small text-muted mb-0">No image selected</p>
                            </div>
                            <button type="button" class="btn btn-sm btn-dark w-100 mt-2" onclick="openMediaPicker('product_image')">
                                <i class="fas fa-images me-1"></i> Select Main Image
                            </button>
                        </div>
                    </div>
                    <div class="mb-0">
                        <label class="form-label fw-bold">Product Gallery</label>
                        <div id="gallery_previews" class="row g-2 mb-2"></div>
                        <input type="hidden" name="gallery_images" id="gallery_images">
                        <button type="button" class="btn btn-sm btn-outline-dark" onclick="openMediaPicker('gallery_images', true)">
                            <i class="fas fa-plus-circle me-1"></i> Add Gallery Images
                        </button>
                        <div class="form-text small mt-2">You can select multiple images from the media manager.</div>
                    </div>
                </div>
            </section>

            <section class="settings-panel admin-panel" id="prod-variants" role="tabpanel" hidden>
                <?php adminPanelHeader('Variants', 'অ্যাট্রিবিউট ও ভ্যারিয়েন্ট কনফিগারেশন', 'fa-layer-group', 'sky'); ?>
                <div class="settings-panel-body admin-panel-body">
                    <?php include __DIR__ . '/../includes/product-variants-form.php'; ?>
                </div>
            </section>

            <section class="settings-panel admin-panel" id="prod-seo" role="tabpanel" hidden>
                <?php adminPanelHeader('SEO Metadata', 'সার্চ ইঞ্জিন ও ইমেজ অল্ট টেক্সট', 'fa-search', 'blue'); ?>
                <div class="settings-panel-body admin-panel-body">
                    <div class="mb-3">
                        <label class="form-label fw-bold"><i class="fas fa-bullseye me-1 text-danger"></i>Focus Keyword</label>
                        <input type="text" name="focus_keyword" class="form-control" placeholder="যেমন: খাঁটি মধু অনলাইন, best honey in bangladesh">
                        <div class="form-text">এই প্রোডাক্ট কোন keyword-এ rank করবে সেটি লিখুন। Meta Title, URL এবং Description-এ এই keyword ব্যবহার করুন।</div>
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-bold">Meta Title (SEO Title)</label>
                        <input type="text" name="meta_title" class="form-control" placeholder="সার্চ ইঞ্জিনের জন্য শিরোনাম (ঐচ্ছিক)" maxlength="70">
                        <div class="form-text">সর্বোচ্চ ৬০ অক্ষরের মধ্যে রাখা ভালো। এটি গুগল সার্চ রেজাল্টে দেখাবে।</div>
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-bold">Meta Description</label>
                        <textarea name="meta_description" class="form-control" rows="3" placeholder="সার্চ ইঞ্জিনের জন্য সংক্ষিপ্ত বর্ণনা (ঐচ্ছিক)" maxlength="170"></textarea>
                        <div class="form-text">সর্বোচ্চ ১৫০-১৬০ অক্ষরের মধ্যে রাখা ভালো। এটি সার্চের সময় শিরোনামের নিচে দেখাবে।</div>
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-bold">Meta Keywords</label>
                        <input type="text" name="meta_keywords" class="form-control" placeholder="যেমন: খাঁটি মধু, প্রাকৃতিক মধু, black seed honey">
                        <div class="form-text">কমা দিয়ে আলাদা করে keywords লিখুন। Bing ও অন্যান্য সার্চ ইঞ্জিনে কাজ করে।</div>
                    </div>
                    <div class="mb-0">
                        <label class="form-label fw-bold">Image Alt Text (SEO)</label>
                        <input type="text" name="image_alt_text" class="form-control" placeholder="যেমন: কালোজিরা ফুলের মধু - ১০০% খাঁটি - KhatiRaj BD">
                        <div class="form-text">প্রোডাক্ট ইমেজের জন্য SEO-friendly alt text। Google Image Search-এ rank করতে সাহায্য করবে।</div>
                    </div>
                </div>
            </section>
        </div>

        <?php adminSaveBar('Save Product'); ?>
    </div>
</form>
