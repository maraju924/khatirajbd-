<?php
// admin/pages/page-manager.php
declare(strict_types=1);

require_once __DIR__ . '/../../app/Helpers/PageHelper.php';

// Fetch manageable pages only (shop/auth/cart templates etc. are excluded)
try {
    $stmt = $pdo->query("SELECT * FROM page_registry ORDER BY sort_order ASC");
    $all_pages = array_values(array_filter(
        $stmt->fetchAll(),
        static fn(array $p): bool => PageHelper::isManageable((string)$p['route_key'])
    ));
} catch (PDOException $e) {
    $all_pages = [];
}

// Group pages manually for cleaner tabs
$grouped_pages = [
    'system' => [],
    'commerce' => [],
    'content' => [],
];

foreach ($all_pages as $page_item) {
    $group = $page_item['page_group'];
    if (isset($grouped_pages[$group])) {
        $grouped_pages[$group][] = $page_item;
    } else {
        $grouped_pages['content'][] = $page_item; // Fallback (custom pages, etc.)
    }
}

// Hide empty groups from tabs
$grouped_pages = array_filter($grouped_pages, static fn(array $list): bool => $list !== []);

// Function to calculate SEO completeness score
function getSeoScore(array $page): array {
    $fields = ['meta_title', 'meta_description', 'meta_keywords', 'og_image'];
    $filled = 0;
    foreach ($fields as $field) {
        if (!empty($page[$field])) {
            $filled++;
        }
    }
    $percentage = (int)(($filled / count($fields)) * 100);
    
    if ($percentage === 100) {
        $badge = '<span class="badge bg-success-subtle text-success border border-success border-opacity-10"><i class="fas fa-check-circle me-1"></i>Optimized</span>';
    } elseif ($percentage >= 50) {
        $badge = '<span class="badge bg-warning-subtle text-warning border border-warning border-opacity-10"><i class="fas fa-exclamation-triangle me-1"></i>Partial</span>';
    } else {
        $badge = '<span class="badge bg-danger-subtle text-danger border border-danger border-opacity-10"><i class="fas fa-times-circle me-1"></i>Missing</span>';
    }
    
    return ['percent' => $percentage, 'badge' => $badge];
}

$tab_meta = [
    'system' => ['label' => 'System & Core', 'icon' => 'fa-window-restore'],
    'commerce' => ['label' => 'E-Commerce', 'icon' => 'fa-shopping-bag'],
    'content' => ['label' => 'Content & Legal', 'icon' => 'fa-file-invoice'],
];
$first_group = array_key_first($grouped_pages) ?: 'content';
?>

<div class="animate__animated animate__fadeIn">
<?php adminFlashMessages(); ?>
<?php adminPageHeader('Page & SEO Manager', 'Editable content pages এবং SEO rules ম্যানেজ করুন', [
    ['label' => 'Homepage Hub', 'icon' => 'fa-home', 'url' => 'index.php?page=homepage-builder', 'class' => 'btn btn-outline-primary btn-sm'],
    ['label' => 'Global SEO', 'icon' => 'fa-sliders-h', 'url' => 'index.php?page=settings', 'class' => 'btn btn-outline-secondary btn-sm'],
    ['label' => 'New Custom Page', 'icon' => 'fa-plus', 'url' => '#', 'class' => 'btn btn-primary btn-sm', 'modal' => 'newPageModal'],
]); ?>

    <!-- Quick Insights Dashboard Row -->
    <div class="admin-kpi-row row g-3">
        <div class="col-md-4"><?php adminStatCard('Manageable Pages', (string)count($all_pages), 'fa-sitemap', 'blue'); ?></div>
        <div class="col-md-4"><?php adminStatCard('System Static', (string)count($grouped_pages['system'] ?? []), 'fa-check-double', 'green'); ?></div>
        <div class="col-md-4"><?php adminStatCard('Content & Legal', (string)count($grouped_pages['content'] ?? []), 'fa-file-invoice', 'sky'); ?></div>
    </div>

    <!-- Tabbed Page Registry Lists -->
    <div class="admin-list-shell mb-4">
        <div class="admin-list-shell-header">
            <h2 class="admin-list-shell-title">Page Registry</h2>
            <ul class="nav nav-pills gap-1 mb-0" id="cmsTabs" role="tablist">
                <?php foreach ($grouped_pages as $group_key => $pages_list):
                    $meta = $tab_meta[$group_key] ?? ['label' => ucfirst($group_key), 'icon' => 'fa-folder'];
                ?>
                <li class="nav-item" role="presentation">
                    <button class="nav-link btn-sm py-1 px-3 <?php echo $group_key === $first_group ? 'active' : ''; ?>" id="<?php echo $group_key; ?>-tab" data-bs-toggle="tab" data-bs-target="#<?php echo $group_key; ?>-pane" type="button" role="tab"><i class="fas <?php echo $meta['icon']; ?> me-1"></i><?php echo htmlspecialchars($meta['label']); ?> (<?php echo count($pages_list); ?>)</button>
                </li>
                <?php endforeach; ?>
            </ul>
        </div>
        <div class="tab-content" id="cmsTabsContent">
                
                <?php foreach ($grouped_pages as $group_key => $pages_list): ?>
                    <div class="tab-pane fade <?php echo $group_key === $first_group ? 'show active' : ''; ?>" id="<?php echo $group_key; ?>-pane" role="tabpanel">
                        <div class="admin-table-wrap">
                            <table class="admin-table admin-table-mobile-cards">
                                <thead>
                                    <tr>
                                        <th>Page / Key</th>
                                        <th>URL / Slug</th>
                                        <th>Template</th>
                                        <th>Mode</th>
                                        <th class="text-center">SEO Score</th>
                                        <th class="text-center">Status</th>
                                        <th class="text-end">Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php if (empty($pages_list)): ?>
                                        <tr>
                                            <td colspan="7"><?php adminEmptyState('এই গ্রুপে কোনো পেজ নেই', 'নতুন কাস্টম পেজ তৈরি করুন অথবা অন্য ট্যাব দেখুন', 'fa-folder-open'); ?></td>
                                        </tr>
                                    <?php else: ?>
                                        <?php foreach ($pages_list as $page): 
                                            $seo = getSeoScore($page);
                                        ?>
                                            <tr class="hover-row">
                                                <td>
                                                    <div class="d-flex align-items-center">
                                                        <div class="me-3" style="width: 8px; height: 8px; border-radius: 50%; background: var(--admin-primary, #15803d); box-shadow: 0 0 0 3px rgba(21,128,61,0.15);"></div>
                                                        <div>
                                                            <div class="fw-bold text-dark"><?php echo htmlspecialchars($page['page_name']); ?></div>
                                                            <code class="small text-muted"><?php echo htmlspecialchars($page['route_key']); ?></code>
                                                        </div>
                                                    </div>
                                                </td>
                                                <td>
                                                    <?php if ($page['slug'] === null): ?>
                                                        <span class="text-muted small">Dynamic template</span>
                                                    <?php else: ?>
                                                        <span class="badge bg-light text-dark font-monospace"><?php echo htmlspecialchars($page['slug']); ?></span>
                                                    <?php endif; ?>
                                                </td>
                                                <td>
                                                    <span class="text-capitalize small"><?php echo htmlspecialchars($page['template']); ?></span>
                                                </td>
                                                <td>
                                                    <span class="badge bg-secondary-subtle text-secondary text-capitalize px-2 py-1"><?php echo htmlspecialchars($page['content_mode']); ?></span>
                                                </td>
                                                <td class="text-center">
                                                    <div class="d-flex flex-column align-items-center">
                                                        <div class="d-flex align-items-center gap-2 mb-1">
                                                            <div class="progress" style="width: 60px; height: 6px; border-radius: 3px;">
                                                                <div class="progress-bar bg-success" role="progressbar" style="width: <?php echo $seo['percent']; ?>%"></div>
                                                            </div>
                                                            <span class="small fw-bold text-muted"><?php echo $seo['percent']; ?>%</span>
                                                        </div>
                                                        <?php echo $seo['badge']; ?>
                                                    </div>
                                                </td>
                                                <td class="text-center">
                                                    <?php echo $page['status'] ? adminStatusBadge('Active') : adminStatusBadge('Inactive'); ?>
                                                </td>
                                                <td class="text-end">
                                                     <div class="btn-group">
                                                         <a href="index.php?page=edit-page&id=<?php echo $page['id']; ?>" class="btn btn-sm btn-outline-primary px-3" title="Edit SEO & Metadata" data-no-pjax>
                                                             <i class="fas fa-search me-1"></i> Edit SEO
                                                         </a>
                                                         <?php if ($page['content_mode'] !== 'none'): ?>
                                                             <a href="index.php?page=edit-page&id=<?php echo $page['id']; ?>&tab=content" class="btn btn-sm btn-outline-success px-3" title="Advanced Page Builder" data-no-pjax>
                                                                 <i class="fas fa-layer-group me-1"></i> Builder
                                                             </a>
                                                         <?php endif; ?>
                                                        <?php if ($page['slug'] !== null && $page['slug'] !== '404'): ?>
                                                            <a href="../<?php echo ltrim($page['slug'], '/'); ?>" target="_blank" class="btn btn-sm btn-outline-secondary px-3" title="Preview Live page">
                                                                <i class="fas fa-external-link-alt"></i>
                                                            </a>
                                                        <?php else: ?>
                                                            <button class="btn btn-sm btn-outline-secondary px-3" disabled>
                                                                <i class="fas fa-ban"></i>
                                                            </button>
                                                        <?php endif; ?>
                                                    </div>
                                                </td>
                                            </tr>
                                        <?php endforeach; ?>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                <?php endforeach; ?>

            </div>
    </div>
</div>

<!-- New Custom Page Modal -->
<div class="modal fade" id="newPageModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content border-0 shadow-lg rounded-4">
            <div class="modal-header border-0 bg-primary text-white">
                <h5 class="modal-title fw-bold">Create New Custom Page</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <form action="actions/page-create.php" method="POST">
                <div class="modal-body p-4">
                    <div class="mb-3">
                        <label class="form-label fw-bold">Page Name</label>
                        <input type="text" name="page_name" class="form-control" placeholder="e.g. Frequently Asked Questions" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-bold">URL Slug</label>
                        <div class="input-group">
                            <span class="input-group-text">/</span>
                            <input type="text" name="slug" class="form-control" placeholder="faq" required>
                        </div>
                        <div class="form-text">Only lowercase letters, numbers and hyphens. Opens in <strong>Advanced Page Builder</strong>.</div>
                    </div>
                    <input type="hidden" name="content_mode" value="sections">
                </div>
                <div class="modal-footer border-0 p-4 pt-0">
                    <button type="button" class="btn btn-light px-4" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary px-4 fw-bold">Create Page</button>
                </div>
            </form>
        </div>
    </div>
</div>
