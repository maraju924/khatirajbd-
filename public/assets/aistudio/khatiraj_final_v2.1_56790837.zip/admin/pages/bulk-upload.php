<?php
// admin/pages/bulk-upload.php
?>

<?php adminFlashMessages(); ?>
<?php adminPageHeader('Bulk Upload', 'CSV ফাইল দিয়ে একসাথে অনেক পণ্য আপলোড করুন'); ?>

<div class="row justify-content-center">
    <div class="col-md-8">
        <div class="admin-card">
            <div class="p-5">
                <div class="text-center mb-5">
                    <div class="bg-primary text-white rounded-circle d-inline-flex align-items-center justify-content-center mb-3" style="width: 80px; height: 80px;">
                        <i class="fas fa-file-upload fa-3x"></i>
                    </div>
                    <h4 class="fw-bold">Upload CSV File</h4>
                    <p class="text-muted">Upload a CSV file to add or update multiple products at once.</p>
                </div>

                <div class="alert alert-info border-0 shadow-sm mb-5" style="border-radius: 12px;">
                    <h6 class="fw-bold"><i class="fas fa-info-circle me-2"></i> CSV Format Instructions:</h6>
                    <ul class="small mb-0">
                        <li>The first row must contain headers: <code>name, slug, price, offer_price, category_id, stock, status, image, description</code></li>
                        <li><code>slug</code> must be unique. If it matches an existing product, that product will be updated.</li>
                        <li><code>status</code> should be 1 for Active and 0 for Inactive.</li>
                        <li><a href="actions/download-sample-csv.php" class="fw-bold text-primary">Download Sample CSV</a></li>
                    </ul>
                </div>

                <form action="actions/bulk-upload-action.php" method="POST" enctype="multipart/form-data">
                    <div class="mb-4">
                        <label class="form-label fw-bold">Select CSV File</label>
                        <input type="file" name="csv_file" class="form-control form-control-lg" accept=".csv" required>
                    </div>
                    <button type="submit" class="btn btn-primary w-100 py-3 fw-bold rounded-pill">
                        <i class="fas fa-cloud-upload-alt me-2"></i> Start Bulk Upload
                    </button>
                </form>
            </div>
        </div>
    </div>
</div>
