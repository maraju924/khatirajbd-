<?php
// admin/pages/menus.php
$menus = $pdo->query("SELECT m1.*, m2.title as parent_title 
                     FROM menus m1 
                     LEFT JOIN menus m2 ON m1.parent_id = m2.id 
                     ORDER BY m1.sort_order ASC")->fetchAll();
$parent_menus = $pdo->query("SELECT id, title FROM menus WHERE parent_id IS NULL ORDER BY sort_order ASC")->fetchAll();
?>

<?php adminFlashMessages(); ?>
<?php adminPageHeader('Menu Management', 'হেডার ও ফুটার মেনু আইটেম ম্যানেজ করুন', [
    ['label' => 'নতুন Menu', 'icon' => 'fa-plus', 'url' => '#', 'class' => 'btn btn-primary btn-sm', 'modal' => 'addMenuModal'],
]); ?>

<!-- Toast for Notifications -->
<div class="toast-container position-fixed bottom-0 end-0 p-3">
  <div id="liveToast" class="toast" role="alert" aria-live="assertive" aria-atomic="true">
    <div class="toast-header">
      <strong class="me-auto">Notification</strong>
      <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
    </div>
    <div class="toast-body" id="toastMessage"></div>
  </div>
</div>

<div class="settings-layout admin-shell">
  <div class="settings-content">
    <section class="settings-panel admin-panel is-active" id="menu-list" role="tabpanel">
      <?php adminPanelHeader('Menu Items', 'হেডার ও ফুটার নেভিগেশন আইটেম', 'fa-bars', 'blue'); ?>
      <div class="settings-panel-body admin-panel-body pt-3">
        <div class="admin-list-shell">
          <div class="admin-list-shell-header">
            <h3 class="admin-list-shell-title"><i class="fas fa-sitemap me-2 text-muted"></i>All Menus</h3>
            <button type="button" class="btn btn-primary btn-sm" data-bs-toggle="modal" data-bs-target="#addMenuModal">
              <i class="fas fa-plus me-1"></i> নতুন Menu
            </button>
          </div>
          <div class="admin-table-wrap">
            <table class="admin-table admin-table-mobile-cards">
              <thead>
                <tr>
                  <th scope="col">Order</th>
                  <th scope="col">Title</th>
                  <th scope="col">Parent</th>
                  <th scope="col">URL</th>
                  <th scope="col">Location</th>
                  <th scope="col">Status</th>
                  <th scope="col">Action</th>
                </tr>
              </thead>
              <tbody id="menuTableBody">
                <?php if(count($menus) > 0): ?>
                    <?php foreach ($menus as $menu): ?>
                    <tr id="menu-row-<?php echo $menu['id']; ?>">
                      <td class="col-order"><?php echo $menu['sort_order']; ?></td>
                      <td class="col-title"><?php echo htmlspecialchars($menu['title']); ?></td>
                      <td class="col-parent"><?php echo $menu['parent_title'] ? htmlspecialchars($menu['parent_title']) : '<span class="text-muted">Main</span>'; ?></td>
                      <td class="col-url"><code><?php echo htmlspecialchars($menu['url']); ?></code></td>
                      <td class="col-location"><span class="badge bg-info text-dark"><?php echo strtoupper($menu['location']); ?></span></td>
                      <td class="col-status">
                          <?php echo $menu['status'] ? adminStatusBadge('Active') : adminStatusBadge('Inactive'); ?>
                      </td>
                      <td>
                          <button type="button" class="btn btn-sm btn-outline-secondary edit-menu-btn" 
                                  data-bs-toggle="modal" data-bs-target="#editMenuModal"
                                  data-id="<?php echo $menu['id']; ?>"
                                  data-title="<?php echo htmlspecialchars($menu['title']); ?>"
                                  data-url="<?php echo htmlspecialchars($menu['url']); ?>"
                                  data-parent="<?php echo $menu['parent_id']; ?>"
                                  data-order="<?php echo $menu['sort_order']; ?>"
                                  data-location="<?php echo $menu['location']; ?>"
                                  data-status="<?php echo $menu['status']; ?>">
                              <i class="fas fa-edit"></i>
                          </button>
                          <button type="button" class="btn btn-sm btn-outline-danger delete-menu-btn" data-id="<?php echo $menu['id']; ?>">
                              <i class="fas fa-trash"></i>
                          </button>
                      </td>
                    </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr id="no-menus-row"><td colspan="7"><?php adminEmptyState('কোনো Menu নেই', 'প্রথম menu item যোগ করুন', 'fa-bars', ['label' => 'নতুন Menu', 'url' => '#', 'icon' => 'fa-plus']); ?></td></tr>
                <?php endif; ?>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </section>
  </div>
</div>

<!-- Add Menu Modal -->
<div class="modal fade" id="addMenuModal" tabindex="-1">
  <div class="modal-dialog">
    <form id="addMenuForm" class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">Add New Menu Item</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>
      <div class="modal-body">
        <div class="mb-3">
            <label class="form-label">Title</label>
            <input type="text" name="title" class="form-control" placeholder="e.g. Home, Shop" required>
        </div>
        <div class="mb-3">
            <label class="form-label">URL</label>
            <input type="text" name="url" class="form-control" placeholder="e.g. index.php, shop.php" required>
        </div>
        <div class="mb-3">
            <label class="form-label">Parent Menu</label>
            <select name="parent_id" class="form-select">
                <option value="">None (Main Menu)</option>
                <?php foreach($parent_menus as $pm): ?>
                    <option value="<?php echo $pm['id']; ?>"><?php echo htmlspecialchars($pm['title']); ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="mb-3">
            <label class="form-label">Location</label>
            <select name="location" class="form-select">
                <option value="header">Header Menu</option>
                <option value="footer">Footer Menu</option>
            </select>
        </div>
        <div class="mb-3">
            <label class="form-label">Sort Order</label>
            <input type="number" name="sort_order" class="form-control" value="0">
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        <button type="submit" class="btn btn-primary">Save Menu</button>
      </div>
    </form>
  </div>
</div>

<!-- Edit Menu Modal -->
<div class="modal fade" id="editMenuModal" tabindex="-1">
  <div class="modal-dialog">
    <form id="editMenuForm" class="modal-content">
      <input type="hidden" name="id" id="edit_id">
      <div class="modal-header">
        <h5 class="modal-title">Edit Menu Item</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>
      <div class="modal-body">
        <div class="mb-3">
            <label class="form-label">Title</label>
            <input type="text" name="title" id="edit_title" class="form-control" required>
        </div>
        <div class="mb-3">
            <label class="form-label">URL</label>
            <input type="text" name="url" id="edit_url" class="form-control" required>
        </div>
        <div class="mb-3">
            <label class="form-label">Parent Menu</label>
            <select name="parent_id" id="edit_parent_id" class="form-select">
                <option value="">None (Main Menu)</option>
                <?php foreach($parent_menus as $pm): ?>
                    <option value="<?php echo $pm['id']; ?>"><?php echo htmlspecialchars($pm['title']); ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="mb-3">
            <label class="form-label">Location</label>
            <select name="location" id="edit_location" class="form-select">
                <option value="header">Header Menu</option>
                <option value="footer">Footer Menu</option>
            </select>
        </div>
        <div class="mb-3">
            <label class="form-label">Sort Order</label>
            <input type="number" name="sort_order" id="edit_sort_order" class="form-control">
        </div>
        <div class="mb-3">
            <label class="form-label">Status</label>
            <select name="status" id="edit_status" class="form-select">
                <option value="1">Active</option>
                <option value="0">Inactive</option>
            </select>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        <button type="submit" class="btn btn-primary">Update Menu</button>
      </div>
    </form>
  </div>
</div>

<script>
(function() {
    const toast = new bootstrap.Toast(document.getElementById('liveToast'));
    const toastMessage = document.getElementById('toastMessage');

    function showToast(message, isError = false) {
        toastMessage.textContent = message;
        document.getElementById('liveToast').classList.remove('bg-danger', 'text-white', 'bg-success');
        if (isError) {
            document.getElementById('liveToast').classList.add('bg-danger', 'text-white');
        } else {
            document.getElementById('liveToast').classList.add('bg-success', 'text-white');
        }
        toast.show();
    }

    function createRowHtml(menu) {
        const parentTitle = menu.parent_title ? menu.parent_title : '<span class="text-muted">Main</span>';
        const statusBadge = menu.status == 1
            ? '<span class="status-badge active">Active</span>'
            : '<span class="status-badge inactive">Inactive</span>';
        
        return `
            <td class="col-order">${menu.sort_order}</td>
            <td class="col-title">${menu.title}</td>
            <td class="col-parent">${parentTitle}</td>
            <td class="col-url"><code>${menu.url}</code></td>
            <td class="col-location"><span class="badge bg-info text-dark">${menu.location.toUpperCase()}</span></td>
            <td class="col-status">${statusBadge}</td>
            <td>
                <button type="button" class="btn btn-sm btn-outline-secondary edit-menu-btn" 
                        data-bs-toggle="modal" data-bs-target="#editMenuModal"
                        data-id="${menu.id}"
                        data-title="${menu.title}"
                        data-url="${menu.url}"
                        data-parent="${menu.parent_id || ''}"
                        data-order="${menu.sort_order}"
                        data-location="${menu.location}"
                        data-status="${menu.status}">
                    <i class="fas fa-edit"></i>
                </button>
                <button type="button" class="btn btn-sm btn-outline-danger delete-menu-btn" data-id="${menu.id}">
                    <i class="fas fa-trash"></i>
                </button>
            </td>
        `;
    }

    // Delegation for dynamic elements
    const menuTableBody = document.getElementById('menuTableBody');
    if (menuTableBody) {
        menuTableBody.addEventListener('click', function(e) {
            // Edit button
            if (e.target.closest('.edit-menu-btn')) {
                const btn = e.target.closest('.edit-menu-btn');
                document.getElementById('edit_id').value = btn.dataset.id;
                document.getElementById('edit_title').value = btn.dataset.title;
                document.getElementById('edit_url').value = btn.dataset.url;
                document.getElementById('edit_parent_id').value = btn.dataset.parent || '';
                document.getElementById('edit_sort_order').value = btn.dataset.order;
                document.getElementById('edit_location').value = btn.dataset.location;
                document.getElementById('edit_status').value = btn.dataset.status;
            }

            // Delete button
            if (e.target.closest('.delete-menu-btn')) {
                if (!confirm('Delete this menu item?')) return;
                const btn = e.target.closest('.delete-menu-btn');
                const id = btn.dataset.id;

                fetch(`actions/menu-action.php?action=delete&id=${id}`)
                    .then(res => res.json())
                    .then(data => {
                        if (data.status === 'success') {
                            const row = document.getElementById(`menu-row-${id}`);
                            if (row) row.remove();
                            showToast(data.message);
                        } else {
                            showToast(data.message, true);
                        }
                    });
            }
        });
    }

    // Add Menu AJAX
    const addMenuForm = document.getElementById('addMenuForm');
    if (addMenuForm) {
        addMenuForm.addEventListener('submit', function(e) {
            e.preventDefault();
            const formData = new FormData(this);
            
            fetch('actions/menu-action.php?action=add', {
                method: 'POST',
                body: formData
            })
            .then(res => res.json())
            .then(data => {
                if (data.status === 'success') {
                    const noRow = document.getElementById('no-menus-row');
                    if (noRow) noRow.remove();

                    const newRow = document.createElement('tr');
                    newRow.id = `menu-row-${data.data.id}`;
                    newRow.innerHTML = createRowHtml(data.data);
                    document.getElementById('menuTableBody').appendChild(newRow);
                    
                    const modal = bootstrap.Modal.getInstance(document.getElementById('addMenuModal'));
                    if (modal) modal.hide();
                    this.reset();
                    showToast(data.message);
                } else {
                    showToast(data.message, true);
                }
            });
        });
    }

    // Edit Menu AJAX
    const editMenuForm = document.getElementById('editMenuForm');
    if (editMenuForm) {
        editMenuForm.addEventListener('submit', function(e) {
            e.preventDefault();
            const formData = new FormData(this);
            
            fetch('actions/menu-action.php?action=edit', {
                method: 'POST',
                body: formData
            })
            .then(res => res.json())
            .then(data => {
                if (data.status === 'success') {
                    const row = document.getElementById(`menu-row-${data.data.id}`);
                    if (row) row.innerHTML = createRowHtml(data.data);
                    
                    const modal = bootstrap.Modal.getInstance(document.getElementById('editMenuModal'));
                    if (modal) modal.hide();
                    showToast(data.message);
                } else {
                    showToast(data.message, true);
                }
            });
        });
    }
})();
</script>
