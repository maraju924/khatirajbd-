<?php
// admin/pages/sliders.php

// Fetch Sliders
$sliders = [];
try {
    $stmt = $pdo->query("SELECT * FROM sliders ORDER BY sort_order ASC, id DESC");
    $sliders = $stmt->fetchAll();
} catch (PDOException $e) {
    $error = 'Error fetching sliders: ' . $e->getMessage();
}

// Positions mapping
$positions = [
    'main_hero' => 'Home Main Hero Carousel',
    'promo_slider' => 'Home Promo Carousel/Slider',
    'middle_banner' => 'Home Middle Banner',
    'footer_slider' => 'Home Footer Carousel/Slider'
];
?>

<?php adminFlashMessages(); ?>
<?php adminPageHeader('Sliders', 'ওয়েবসাইটের বিভিন্ন ক্যারোসেল এবং ব্যানার স্লাইড ম্যানেজ করুন', [
    ['label' => 'নতুন স্লাইড', 'icon' => 'fa-plus', 'url' => '#', 'class' => 'btn btn-primary btn-sm', 'modal' => 'addSliderModal'],
]); ?>

<?php if (!empty($error)): ?>
    <div class="alert alert-danger"><i class="fas fa-exclamation-circle"></i> <?php echo htmlspecialchars($error); ?></div>
<?php endif; ?>

<style>
.status-badge {
    cursor: pointer;
    user-select: none;
    transition: transform 0.15s ease;
}
.status-badge:hover {
    transform: scale(1.05);
}
.action-btn-circle {
    width: 32px;
    height: 32px;
    border-radius: 50%;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    padding: 0;
    transition: all 0.2s ease;
}
.action-btn-circle:hover {
    transform: scale(1.1);
}
.bulk-bar {
    background: #f0fdf4;
    border: 1px solid #bbf7d0;
    border-radius: 12px;
    animation: fadeInSlide 0.25s ease-out;
}
@keyframes fadeInSlide {
    from { opacity: 0; transform: translateY(-10px); }
    to { opacity: 1; transform: translateY(0); }
}
.arrow-btn {
    cursor: pointer;
    color: #64748b;
    padding: 2px 6px;
    border-radius: 4px;
    transition: background 0.15s ease, color 0.15s ease;
}
.arrow-btn:hover {
    background: #f1f5f9;
    color: var(--kr-primary);
}
</style>

<!-- Live Search and Filter Bar -->
<div class="admin-filter-bar">
    <div class="admin-filter-row">
        <div class="admin-filter-field" style="flex: 2 1 220px; max-width: none;">
            <label class="admin-filter-label">Search</label>
            <input type="search" id="slider-search" class="form-control form-control-sm" placeholder="স্লাইড শিরোনাম বা সাবটাইটেল সার্চ করুন..." oninput="filterSliders()">
        </div>
        <div class="admin-filter-field" style="flex: 1.5 1 180px; max-width: none;">
            <label class="admin-filter-label">Position</label>
            <select id="position-filter" class="form-select form-select-sm" onchange="filterSliders()">
                <option value="">সকল পজিশন</option>
                <?php foreach ($positions as $key => $name): ?>
                    <option value="<?php echo htmlspecialchars($key); ?>"><?php echo htmlspecialchars($name); ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="admin-filter-actions">
            <span class="text-secondary small fw-bold">মোট: <span id="total-sliders-count" class="text-primary"><?php echo count($sliders); ?></span>টি</span>
        </div>
    </div>
</div>

<!-- Bulk Actions Panel (Hidden by default, shown when checkboxes are selected) -->
<div class="bulk-bar p-3 mb-4 align-items-center justify-content-between gap-3" id="bulk-actions-bar" style="display: none !important;">
    <div class="d-flex align-items-center gap-2">
        <i class="fas fa-check-square text-success fs-5"></i>
        <span class="fw-bold text-success small"><span id="selected-count">0</span>টি স্লাইড সিলেক্ট করা হয়েছে</span>
    </div>
    <div class="d-flex align-items-center gap-2">
        <select class="form-select form-select-sm" id="bulk-action-select" style="width: 200px;">
            <option value="">অ্যাকশন সিলেক্ট করুন...</option>
            <option value="active">সক্রিয় করুন (Status: Active)</option>
            <option value="inactive">নিষ্ক্রিয় করুন (Status: Inactive)</option>
            <option value="delete">মুছে ফেলুন (Bulk Delete)</option>
        </select>
        <button type="button" class="btn btn-success btn-sm px-4 fw-bold" onclick="applyBulkAction()">প্রয়োগ করুন</button>
    </div>
</div>

<div class="admin-list-shell">
    <div class="admin-list-shell-header">
        <h2 class="admin-list-shell-title">স্লাইড তালিকা</h2>
        <span class="text-muted small fw-semibold"><?php echo count($sliders); ?>টি</span>
    </div>
    <div class="admin-table-wrap">
        <table class="admin-table admin-table-mobile-cards">
            <thead>
                <tr>
                    <th scope="col" style="width: 40px;">
                        <input type="checkbox" id="check-all" class="form-check-input" onclick="toggleCheckAll(this)">
                    </th>
                    <th>ছবি</th>
                    <th>কন্টেন্ট</th>
                    <th>পজিশন</th>
                    <th style="width: 120px;">অর্ডার</th>
                    <th style="width: 100px;">স্ট্যাটাস</th>
                    <th class="text-end" style="width: 180px;">অ্যাকশন</th>
                </tr>
            </thead>
            <tbody id="sliderTableBody">
                <?php if (empty($sliders)): ?>
                    <tr id="no-sliders-row">
                        <td colspan="7"><?php adminEmptyState('কোনো স্লাইড নেই', 'উপরের "নতুন স্লাইড" বাটন থেকে প্রথম স্লাইড যোগ করুন', 'fa-images'); ?></td>
                    </tr>
                <?php else: ?>
                    <?php foreach ($sliders as $slider): 
                        $pos_key = $slider['position'] ?? 'main_hero';
                        $pos_name = $positions[$pos_key] ?? $pos_key;
                    ?>
                        <tr id="slider-row-<?php echo $slider['id']; ?>" 
                            class="slider-row" 
                            data-title="<?php echo htmlspecialchars($slider['title'] ?? ''); ?>"
                            data-subtitle="<?php echo htmlspecialchars($slider['subtitle'] ?? ''); ?>"
                            data-position="<?php echo htmlspecialchars($pos_key); ?>">
                            <td>
                                <input type="checkbox" class="slider-checkbox form-check-input" value="<?php echo $slider['id']; ?>" onclick="toggleRowCheck()">
                            </td>
                            <td>
                                <img src="../<?php echo htmlspecialchars($slider['image']); ?>" alt="" class="rounded border shadow-sm bg-light" style="width: 110px; height: 55px; object-fit: cover;">
                            </td>
                            <td>
                                <div class="fw-bold text-dark"><?php echo htmlspecialchars($slider['title'] ?: 'No Title'); ?></div>
                                <div class="small text-muted text-truncate" style="max-width: 250px;"><?php echo htmlspecialchars($slider['subtitle'] ?: 'No Subtitle'); ?></div>
                            </td>
                            <td>
                                <span class="badge bg-light text-secondary border"><?php echo htmlspecialchars($pos_name); ?></span>
                            </td>
                            <td>
                                <div class="d-flex align-items-center gap-2">
                                    <span class="badge bg-white text-dark border px-2 py-1 font-monospace" id="sort-order-display-<?php echo $slider['id']; ?>"><?php echo $slider['sort_order']; ?></span>
                                    <div class="d-flex flex-column">
                                        <i class="fas fa-chevron-up arrow-btn" onclick="adjustSort(<?php echo $slider['id']; ?>, 'up')" title="ওপরে নিন (অর্ডার কমান)"></i>
                                        <i class="fas fa-chevron-down arrow-btn" onclick="adjustSort(<?php echo $slider['id']; ?>, 'down')" title="নিচে নিন (অর্ডার বাড়ান)"></i>
                                    </div>
                                </div>
                            </td>
                            <td>
                                <span class="badge bg-<?php echo $slider['status'] ? 'success' : 'secondary'; ?> status-badge" 
                                      onclick="toggleSliderStatus(<?php echo $slider['id']; ?>, this)"
                                      title="ক্লিক করে স্ট্যাটাস সক্রিয়/নিষ্ক্রিয় করুন">
                                    <?php echo $slider['status'] ? 'Active' : 'Inactive'; ?>
                                </span>
                            </td>
                            <td class="text-end">
                                <div class="d-flex gap-1 justify-content-end align-items-center">
                                    <!-- Duplicate / Clone Shortcut -->
                                    <button type="button" 
                                            class="btn btn-sm btn-outline-success action-btn-circle" 
                                            onclick="duplicateSlider(<?php echo $slider['id']; ?>)"
                                            title="স্লাইডটি ডুপ্লিকেট/কপি করুন">
                                        <i class="fas fa-copy"></i>
                                    </button>
                                    
                                    <!-- Edit Button -->
                                    <button class="btn btn-sm btn-outline-info action-btn-circle edit-slider-btn" 
                                            data-slider='<?php echo htmlspecialchars(json_encode($slider), ENT_QUOTES, 'UTF-8'); ?>'
                                            data-bs-toggle="modal" data-bs-target="#editSliderModal"
                                            title="সম্পাদনা করুন">
                                        <i class="fas fa-edit"></i>
                                    </button>
                                    
                                    <!-- Delete Button -->
                                    <form action="actions/slider-actions.php" method="POST" class="d-inline" onsubmit="return confirm('Are you sure you want to delete this slider?')">
                                        <input type="hidden" name="id" value="<?php echo $slider['id']; ?>">
                                        <input type="hidden" name="action" value="delete">
                                        <button type="submit" class="btn btn-sm btn-outline-danger action-btn-circle" title="মুছে ফেলুন">
                                            <i class="fas fa-trash"></i>
                                        </button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<!-- Add Slider Modal -->
<div class="modal fade" id="addSliderModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content border-0 shadow-lg">
            <div class="modal-header border-0 bg-primary text-white">
                <h5 class="modal-title fw-bold"><i class="fas fa-plus me-2"></i>Add New Slider</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <form action="actions/slider-actions.php" method="POST" enctype="multipart/form-data">
                <input type="hidden" name="action" value="add">
                <div class="modal-body p-4">
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label fw-bold">Title (Optional)</label>
                            <input type="text" name="title" class="form-control" placeholder="Summer Collection 2026">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label fw-bold">Subtitle (Optional)</label>
                            <input type="text" name="subtitle" class="form-control" placeholder="Up to 50% Off">
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-12 mb-3">
                            <label class="form-label fw-bold">Slider Position / Group *</label>
                            <select name="position" class="form-select" required>
                                <?php foreach ($positions as $key => $name): ?>
                                    <option value="<?php echo htmlspecialchars($key); ?>"><?php echo htmlspecialchars($name); ?></option>
                                <?php endforeach; ?>
                            </select>
                            <div class="form-text">স্লাইডারটি ওয়েবসাইটের কোথায় প্রদর্শন করা হবে তা নির্বাচন করুন।</div>
                        </div>
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-bold">Slider Image</label>
                        <div class="media-picker-container text-center p-3 border rounded bg-light">
                            <input type="hidden" name="image" id="add_slider_image" required>
                            <img id="add_slider_image_preview" src="" class="img-fluid rounded mb-2 d-none" style="max-height: 120px; width: 100%; object-fit: cover;">
                            <div id="add_slider_image_placeholder" class="py-3">
                                <i class="fas fa-image fa-3x text-muted mb-2"></i>
                                <p class="small text-muted mb-0">No image selected</p>
                            </div>
                            <button type="button" class="btn btn-sm btn-dark w-100 mt-2" onclick="openMediaPicker('add_slider_image')">
                                <i class="fas fa-images me-1"></i> Select from Media
                            </button>
                        </div>
                        <div class="form-text mt-2"><i class="fas fa-info-circle me-1"></i>Recommended size: 1200x400px (JPG/PNG)</div>
                    </div>
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label fw-bold">Button Text</label>
                            <input type="text" name="btn_text" class="form-control" placeholder="Shop Now">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label fw-bold">Button Link</label>
                            <input type="text" name="btn_link" class="form-control" placeholder="<?php echo BASE_URL; ?>/shop">
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label fw-bold">Overlay Color</label>
                            <input type="color" name="overlay_color" class="form-control form-control-color w-100" value="#000000">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label fw-bold">Overlay Opacity</label>
                            <input type="range" name="overlay_opacity" class="form-range" min="0" max="1" step="0.05" value="0.40">
                            <div class="d-flex justify-content-between small text-muted">
                                <span>Transparent</span>
                                <span>Opaque</span>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label fw-bold">Sort Order</label>
                            <input type="number" name="sort_order" class="form-control" value="0">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label fw-bold">Status</label>
                            <select name="status" class="form-select">
                                <option value="1">Active</option>
                                <option value="0">Inactive</option>
                            </select>
                        </div>
                    </div>
                </div>
                <div class="modal-footer border-0 p-4 pt-0">
                    <button type="button" class="btn btn-light px-4" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary px-4 fw-bold shadow-sm">Save Slider</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Edit Slider Modal -->
<div class="modal fade" id="editSliderModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content border-0 shadow-lg">
            <div class="modal-header border-0 bg-dark text-white">
                <h5 class="modal-title fw-bold"><i class="fas fa-edit me-2"></i>Edit Slider</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <form action="actions/slider-actions.php" method="POST" enctype="multipart/form-data">
                <input type="hidden" name="action" value="edit">
                <input type="hidden" name="id" id="edit-id">
                <input type="hidden" name="old_image" id="edit-old-image">
                <div class="modal-body p-4">
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label fw-bold">Title (Optional)</label>
                            <input type="text" name="title" id="edit-title" class="form-control">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label fw-bold">Subtitle (Optional)</label>
                            <input type="text" name="subtitle" id="edit-subtitle" class="form-control">
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-12 mb-3">
                            <label class="form-label fw-bold">Slider Position / Group *</label>
                            <select name="position" id="edit-position" class="form-select" required>
                                <?php foreach ($positions as $key => $name): ?>
                                    <option value="<?php echo htmlspecialchars($key); ?>"><?php echo htmlspecialchars($name); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-bold">Change Slider Image</label>
                        <div class="media-picker-container text-center p-3 border rounded bg-light">
                            <input type="hidden" name="image" id="edit_slider_image">
                            <img id="edit_slider_image_preview" src="" class="img-fluid rounded mb-2 d-none" style="max-height: 120px; width: 100%; object-fit: cover;">
                            <div id="edit_slider_image_placeholder" class="py-3 d-none">
                                <i class="fas fa-image fa-3x text-muted mb-2"></i>
                                <p class="small text-muted mb-0">No image selected</p>
                            </div>
                            <button type="button" class="btn btn-sm btn-dark w-100 mt-2" onclick="openMediaPicker('edit_slider_image')">
                                <i class="fas fa-images me-1"></i> Change Image
                            </button>
                        </div>
                        <div class="form-text text-primary"><i class="fas fa-info-circle me-1"></i>Selection from Media Manager will override upload</div>
                    </div>
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label fw-bold">Button Text</label>
                            <input type="text" name="btn_text" id="edit-btn-text" class="form-control">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label fw-bold">Button Link</label>
                            <input type="text" name="btn_link" id="edit-btn-link" class="form-control">
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label fw-bold">Overlay Color</label>
                            <input type="color" name="overlay_color" id="edit-overlay-color" class="form-control form-control-color w-100">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label fw-bold">Overlay Opacity</label>
                            <input type="range" name="overlay_opacity" id="edit-overlay-opacity" class="form-range" min="0" max="1" step="0.05">
                            <div class="d-flex justify-content-between small text-muted">
                                <span>Transparent</span>
                                <span>Opaque</span>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label fw-bold">Sort Order</label>
                            <input type="number" name="sort_order" id="edit-sort-order" class="form-control">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label fw-bold">Status</label>
                            <select name="status" id="edit-status" class="form-select">
                                <option value="1">Active</option>
                                <option value="0">Inactive</option>
                            </select>
                        </div>
                    </div>
                </div>
                <div class="modal-footer border-0 p-4 pt-0">
                    <button type="button" class="btn btn-light px-4" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary px-4 fw-bold shadow-sm">Update Slider</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
// Filter Sliders
function filterSliders() {
    const searchVal = document.getElementById('slider-search').value.toLowerCase();
    const positionVal = document.getElementById('position-filter').value;
    
    const rows = document.querySelectorAll('.slider-row');
    let visibleCount = 0;
    
    rows.forEach(row => {
        const title = row.getAttribute('data-title').toLowerCase();
        const subtitle = row.getAttribute('data-subtitle').toLowerCase();
        const position = row.getAttribute('data-position');
        
        const matchSearch = title.includes(searchVal) || subtitle.includes(searchVal);
        const matchPosition = positionVal === "" || position === positionVal;
        
        if (matchSearch && matchPosition) {
            row.style.display = '';
            visibleCount++;
        } else {
            row.style.display = 'none';
        }
    });
    
    document.getElementById('total-sliders-count').innerText = visibleCount;
    
    const emptyRow = document.getElementById('no-sliders-search-row');
    if (visibleCount === 0) {
        if (!emptyRow) {
            const tbody = document.getElementById('sliderTableBody');
            const tr = document.createElement('tr');
            tr.id = 'no-sliders-search-row';
            tr.innerHTML = `<td colspan="7" class="text-center py-4 text-muted"><i class="fas fa-search fa-2x mb-2 d-block"></i>কোনো স্লাইডার পাওয়া যায়নি</td>`;
            tbody.appendChild(tr);
        }
    } else {
        emptyRow?.remove();
    }
}

// Adjust Sort Order via AJAX
function adjustSort(id, direction) {
    fetch(`actions/slider-quick-sort.php?id=${id}&dir=${direction}`, {
        headers: { 'X-Requested-With': 'XMLHttpRequest' }
    })
    .then(res => res.json())
    .then(data => {
        if (data.success) {
            document.getElementById('sort-order-display-' + id).innerText = data.sort_order;
            
            // Highlight effect
            const displayBadge = document.getElementById('sort-order-display-' + id);
            displayBadge.classList.remove('bg-white');
            displayBadge.classList.add('bg-warning');
            setTimeout(() => {
                displayBadge.classList.remove('bg-warning');
                displayBadge.classList.add('bg-white');
            }, 300);
            
            // Reload page or sort elements client-side to keep order correct
            // For robust UX, reload page after a brief moment or reload table
            setTimeout(() => window.location.reload(), 500);
        } else {
            alert('Sorting failed: ' + data.message);
        }
    })
    .catch(err => console.error(err));
}

// Toggle Slider Status (AJAX)
function toggleSliderStatus(id, badge) {
    fetch(`actions/slider-toggle-status.php?id=${id}`, {
        headers: { 'X-Requested-With': 'XMLHttpRequest' }
    })
    .then(res => res.json())
    .then(data => {
        if (data.success) {
            if (data.status) {
                badge.className = 'badge bg-success status-badge';
                badge.innerText = 'Active';
            } else {
                badge.className = 'badge bg-secondary status-badge';
                badge.innerText = 'Inactive';
            }
        } else {
            alert('Status update failed: ' + data.message);
        }
    })
    .catch(err => console.error(err));
}

// Duplicate Slider Shortcut (AJAX)
function duplicateSlider(id) {
    if (confirm('এই স্লাইডারটি কি ডুপ্লিকেট/কপি করতে চান?')) {
        fetch(`actions/slider-duplicate.php?id=${id}`, {
            headers: { 'X-Requested-With': 'XMLHttpRequest' }
        })
        .then(res => res.json())
        .then(data => {
            if (data.success) {
                window.location.reload();
            } else {
                alert('Duplication failed: ' + data.message);
            }
        })
        .catch(err => console.error(err));
    }
}

// Edit Slider Populate
document.addEventListener('DOMContentLoaded', function() {
    const editBtns = document.querySelectorAll('.edit-slider-btn');
    editBtns.forEach(btn => {
        btn.addEventListener('click', function() {
            const data = JSON.parse(this.getAttribute('data-slider'));
            
            document.getElementById('edit-id').value = data.id;
            document.getElementById('edit-old-image').value = data.image;
            document.getElementById('edit-title').value = data.title;
            document.getElementById('edit-subtitle').value = data.subtitle;
            document.getElementById('edit-position').value = data.position || 'main_hero';
            document.getElementById('edit-btn-text').value = data.btn_text;
            document.getElementById('edit-btn-link').value = data.btn_link;
            document.getElementById('edit-overlay-color').value = data.overlay_color || '#000000';
            document.getElementById('edit-overlay-opacity').value = data.overlay_opacity || 0.40;
            document.getElementById('edit-sort-order').value = data.sort_order;
            document.getElementById('edit-status').value = data.status;
            
            // Handle Image Preview
            document.getElementById('edit_slider_image').value = data.image;
            const preview = document.getElementById('edit_slider_image_preview');
            preview.src = '../' + data.image;
            preview.classList.remove('d-none');
            document.getElementById('edit_slider_image_placeholder').classList.add('d-none');
        });
    });
});

// Checkbox Selection for Bulk Actions
function toggleCheckAll(master) {
    const checkboxes = document.querySelectorAll('.slider-checkbox');
    checkboxes.forEach(cb => {
        const row = cb.closest('tr');
        if (row && row.style.display !== 'none') {
            cb.checked = master.checked;
        }
    });
    toggleBulkBar();
}

function toggleRowCheck() {
    const master = document.getElementById('check-all');
    const checkboxes = document.querySelectorAll('.slider-checkbox');
    let allChecked = true;
    let anyChecked = false;
    
    checkboxes.forEach(cb => {
        const row = cb.closest('tr');
        if (row && row.style.display !== 'none') {
            if (!cb.checked) allChecked = false;
            if (cb.checked) anyChecked = true;
        }
    });
    
    master.checked = allChecked && checkboxes.length > 0;
    toggleBulkBar();
}

function toggleBulkBar() {
    const bulkBar = document.getElementById('bulk-actions-bar');
    const checkedBoxes = document.querySelectorAll('.slider-checkbox:checked');
    const selectedCount = document.getElementById('selected-count');
    
    if (checkedBoxes.length > 0) {
        selectedCount.innerText = checkedBoxes.length;
        bulkBar.style.setProperty('display', 'flex', 'important');
    } else {
        bulkBar.style.setProperty('display', 'none', 'important');
    }
}

function applyBulkAction() {
    const action = document.getElementById('bulk-action-select').value;
    if (!action) {
        alert('অনুগ্রহ করে একটি বাল্ক অ্যাকশন নির্বাচন করুন।');
        return;
    }
    
    const checkedBoxes = document.querySelectorAll('.slider-checkbox:checked');
    const ids = Array.from(checkedBoxes).map(cb => cb.value);
    
    if (action === 'delete') {
        if (!confirm('সিলেক্ট করা ' + ids.length + 'টি স্লাইডার আপনি কি চিরতরে মুছে ফেলতে চান?')) {
            return;
        }
    }
    
    const data = new FormData();
    data.append('action', action);
    ids.forEach(id => data.append('ids[]', id));
    
    fetch('actions/slider-bulk-action.php', {
        method: 'POST',
        body: data,
        headers: { 'X-Requested-With': 'XMLHttpRequest' }
    })
    .then(res => res.json())
    .then(resData => {
        if (resData.success) {
            document.getElementById('check-all').checked = false;
            window.location.reload();
        } else {
            alert('Bulk action failed: ' + resData.message);
        }
    })
    .catch(err => console.error(err));
}
</script>
