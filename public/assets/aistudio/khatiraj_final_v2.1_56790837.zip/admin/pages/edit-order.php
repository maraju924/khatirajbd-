<?php
// admin/pages/edit-order.php
$id = $_GET['id'] ?? null;

if (!$id) {
    echo "<h2>Invalid Order ID</h2>";
    return;
}

$stmt = $pdo->prepare("SELECT o.*, u.name as user_name FROM orders o LEFT JOIN users u ON o.user_id = u.id WHERE o.id = ?");
$stmt->execute([$id]);
$order = $stmt->fetch();

if (!$order) {
    echo "<h2>Order Not Found</h2>";
    return;
}

$stmt_items = $pdo->prepare("SELECT oi.*, p.name as product_name FROM order_items oi JOIN products p ON oi.product_id = p.id WHERE oi.order_id = ?");
$stmt_items->execute([$id]);
$order_items = $stmt_items->fetchAll();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $customer_name = $_POST['customer_name'];
    $customer_phone = $_POST['customer_phone'];
    $shipping_address = $_POST['shipping_address'];
    $order_status = $_POST['order_status'];
    $payment_status = $_POST['payment_status'];
    $total_amount = $_POST['total_amount'];

    try {
        $stmt_update = $pdo->prepare("UPDATE orders SET customer_name = ?, customer_phone = ?, shipping_address = ?, order_status = ?, payment_status = ?, total_amount = ? WHERE id = ?");
        $stmt_update->execute([$customer_name, $customer_phone, $shipping_address, $order_status, $payment_status, $total_amount, $id]);

        $message = "Order updated successfully";
        if (!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest') {
            header('Content-Type: application/json');
            echo json_encode(['success' => true, 'message' => $message]);
            exit;
        }

        echo "<script>
            if (typeof loadPage === 'function') {
                loadPage('index.php?page=orders&success=" . urlencode($message) . "');
            } else {
                window.location.href='index.php?page=orders&success=" . urlencode($message) . "';
            }
        </script>";
        exit;
    } catch (PDOException $e) {
        if (!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest') {
            header('Content-Type: application/json');
            echo json_encode(['success' => false, 'message' => $e->getMessage()]);
            exit;
        }
        $error = $e->getMessage();
    }
}
?>

<?php adminFlashMessages(); ?>
<?php if(isset($error)): ?>
    <div class="admin-flash error"><i class="fas fa-exclamation-circle"></i> <?php echo htmlspecialchars($error); ?></div>
<?php endif; ?>
<?php adminPageHeader('অর্ডার সম্পাদনা #' . $order['tracking_id'], 'কাস্টমার তথ্য, স্ট্যাটাস ও পেমেন্ট আপডেট করুন', [
    ['label' => 'অর্ডার তালিকা', 'icon' => 'fa-arrow-left', 'url' => 'index.php?page=orders', 'class' => 'btn btn-outline-secondary btn-sm'],
]); ?>

<form action="" method="POST" class="settings-form">
    <div class="settings-layout admin-shell" data-panel-prefix="ord">
        <nav class="settings-tabs admin-tabs" aria-label="Order sections">
            <div class="settings-tabs-track admin-tabs-track" role="tablist">
                <a href="#ord-customer" class="settings-tab admin-tab active" data-admin-nav="customer" role="tab" aria-selected="true">
                    <i class="fas fa-user"></i><span>Customer</span>
                </a>
                <a href="#ord-items" class="settings-tab admin-tab" data-admin-nav="items" role="tab" aria-selected="false">
                    <i class="fas fa-shopping-bag"></i><span>Items</span>
                </a>
                <a href="#ord-settings" class="settings-tab admin-tab" data-admin-nav="settings" role="tab" aria-selected="false">
                    <i class="fas fa-cog"></i><span>Settings</span>
                </a>
            </div>
        </nav>

        <div class="settings-content">
            <section class="settings-panel admin-panel is-active" id="ord-customer" role="tabpanel">
                <?php adminPanelHeader('Customer Information', 'নাম, ফোন ও শিপিং ঠিকানা', 'fa-user', 'blue'); ?>
                <div class="settings-panel-body admin-panel-body">
                    <div class="mb-3">
                        <label class="form-label">Customer Name</label>
                        <input type="text" name="customer_name" class="form-control" value="<?php echo htmlspecialchars($order['customer_name'] ?: $order['user_name'] ?: ''); ?>" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Customer Phone</label>
                        <input type="text" name="customer_phone" class="form-control" value="<?php echo htmlspecialchars($order['customer_phone']); ?>" required>
                    </div>
                    <div class="mb-0">
                        <label class="form-label">Shipping Address</label>
                        <textarea name="shipping_address" class="form-control" rows="3" required><?php echo htmlspecialchars($order['shipping_address']); ?></textarea>
                    </div>
                </div>
            </section>

            <section class="settings-panel admin-panel" id="ord-items" role="tabpanel" hidden>
                <?php adminPanelHeader('Order Items', 'অর্ডার আইটেম (শুধু দেখুন)', 'fa-shopping-bag', 'green'); ?>
                <div class="settings-panel-body admin-panel-body p-0">
                    <div class="admin-table-wrap">
                        <table class="admin-table mb-0">
                            <thead>
                                <tr>
                                    <th>Product</th>
                                    <th>Price</th>
                                    <th>Qty</th>
                                    <th>Total</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach($order_items as $item): ?>
                                <tr>
                                    <td>
                                        <span class="d-block fw-semibold"><?php echo htmlspecialchars($item['product_name']); ?></span>
                                        <?php if (!empty($item['variant_label'])): ?>
                                        <small class="text-muted"><i class="fas fa-layer-group me-1"></i><?php echo htmlspecialchars($item['variant_label']); ?></small>
                                        <?php endif; ?>
                                    </td>
                                    <td>৳<?php echo number_format($item['price']); ?></td>
                                    <td><?php echo $item['qty']; ?></td>
                                    <td>৳<?php echo number_format($item['price'] * $item['qty']); ?></td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </section>

            <section class="settings-panel admin-panel" id="ord-settings" role="tabpanel" hidden>
                <?php adminPanelHeader('Order Settings', 'স্ট্যাটাস, পেমেন্ট ও টোটাল', 'fa-cog', 'amber'); ?>
                <div class="settings-panel-body admin-panel-body">
                    <div class="mb-3">
                        <label class="form-label">Order Status</label>
                        <select name="order_status" class="form-select">
                            <option value="Pending" <?php echo $order['order_status'] == 'Pending' ? 'selected' : ''; ?>>Pending</option>
                            <option value="Processing" <?php echo $order['order_status'] == 'Processing' ? 'selected' : ''; ?>>Processing</option>
                            <option value="Shipped" <?php echo $order['order_status'] == 'Shipped' ? 'selected' : ''; ?>>Shipped</option>
                            <option value="Delivered" <?php echo $order['order_status'] == 'Delivered' ? 'selected' : ''; ?>>Delivered</option>
                            <option value="Cancelled" <?php echo $order['order_status'] == 'Cancelled' ? 'selected' : ''; ?>>Cancelled</option>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Payment Status</label>
                        <select name="payment_status" class="form-select">
                            <option value="Pending" <?php echo $order['payment_status'] == 'Pending' ? 'selected' : ''; ?>>Pending</option>
                            <option value="Paid" <?php echo $order['payment_status'] == 'Paid' ? 'selected' : ''; ?>>Paid</option>
                            <option value="Failed" <?php echo $order['payment_status'] == 'Failed' ? 'selected' : ''; ?>>Failed</option>
                        </select>
                    </div>
                    <div class="mb-0">
                        <label class="form-label">Total Amount (Manual Override)</label>
                        <div class="input-group">
                            <span class="input-group-text">৳</span>
                            <input type="number" name="total_amount" class="form-control" value="<?php echo $order['total_amount']; ?>" step="0.01">
                        </div>
                    </div>
                </div>
            </section>
        </div>

        <?php adminSaveBar('Update Order Details', 'fa-save'); ?>
    </div>
</form>
