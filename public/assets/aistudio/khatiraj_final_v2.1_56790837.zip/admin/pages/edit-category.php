<?php
// admin/pages/edit-category.php
if (!isset($_GET['id'])) {
    echo "ID missing";
    exit;
}
$id = $_GET['id'];
$stmt = $pdo->prepare("SELECT * FROM categories WHERE id = ?");
$stmt->execute([$id]);
$category = $stmt->fetch();

if (!$category) {
    echo "Category not found";
    exit;
}
?>
<?php adminFlashMessages(); ?>
<?php adminPageHeader('Edit Category', 'ক্যাটাগরির নাম, আইকন ও স্ট্যাটাস আপডেট করুন', [
    ['label' => 'ক্যাটাগরি তালিকা', 'icon' => 'fa-arrow-left', 'url' => 'index.php?page=categories', 'class' => 'btn btn-outline-secondary btn-sm'],
]); ?>

<form action="actions/category-update.php" method="POST" enctype="multipart/form-data" class="settings-form">
    <input type="hidden" name="id" value="<?php echo $category['id']; ?>">
    <div class="settings-layout admin-shell" data-panel-prefix="cat">
        <div class="settings-content">
            <section class="settings-panel admin-panel is-active" id="cat-general" role="tabpanel">
                <?php adminPanelHeader('Category Details', 'নাম, আইকন ও অ্যাকটিভ স্ট্যাটাস', 'fa-folder', 'green'); ?>
                <div class="settings-panel-body admin-panel-body">
                    <div class="mb-3">
                        <label class="form-label">Category Name</label>
                        <input type="text" name="name" class="form-control" value="<?php echo htmlspecialchars($category['name']); ?>" required>
                    </div>

                    <div class="mb-3">
                        <label class="form-label">Current Icon</label><br>
                        <?php if($category['image']): ?>
                            <img src="../<?php echo $category['image']; ?>" width="80" class="img-thumbnail mb-2">
                        <?php else: ?>
                            <p class="text-muted">No icon uploaded.</p>
                        <?php endif; ?>
                        <input type="file" name="image" class="form-control">
                        <small class="text-muted">Upload new image to replace.</small>
                    </div>

                    <div class="mb-0">
                        <div class="form-check form-switch">
                            <input class="form-check-input" type="checkbox" name="status" value="1" <?php echo $category['status'] ? 'checked' : ''; ?>>
                            <label class="form-check-label">Active Status</label>
                        </div>
                    </div>
                </div>
                <?php adminSaveBar('Update Category'); ?>
            </section>
        </div>
    </div>
</form>
