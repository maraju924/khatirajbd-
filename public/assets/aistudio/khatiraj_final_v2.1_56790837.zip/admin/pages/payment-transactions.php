<?php
// admin/pages/payment-transactions.php
// Payment Transactions Management

require_once '../app/Services/PaymentGateway.php';
$paymentGateway = new PaymentGateway($pdo);

$statusFilter = $_GET['status'] ?? null;
$transactions = $paymentGateway->getTransactions($statusFilter, 100);
$stats = $paymentGateway->getStats();
?>

<?php adminFlashMessages(); ?>
<?php if (isset($_GET['success'])): ?>
    <div class="admin-flash success"><i class="fas fa-check-circle"></i> <?php echo htmlspecialchars($_GET['success']); ?></div>
<?php endif; ?>
<?php if (isset($_GET['error'])): ?>
    <div class="admin-flash error"><i class="fas fa-exclamation-circle"></i> <?php echo htmlspecialchars($_GET['error']); ?></div>
<?php endif; ?>

<?php adminPageHeader('Payment Transactions', 'পেমেন্ট ট্রানজেকশন দেখুন, অনুমোদন ও ম্যানেজ করুন'); ?>

<!-- Statistics Cards -->
<div class="row g-3 mb-4 admin-kpi-row">
    <div class="col-6 col-md-3"><?php adminStatCard('Total Transactions', number_format($stats['total']), 'fa-exchange-alt', 'blue'); ?></div>
    <div class="col-6 col-md-3"><?php adminStatCard('Pending', number_format($stats['pending']), 'fa-clock', 'amber'); ?></div>
    <div class="col-6 col-md-3"><?php adminStatCard('Completed', number_format($stats['completed']), 'fa-check-circle', 'green'); ?></div>
    <div class="col-6 col-md-3"><?php adminStatCard('Total Amount', '৳' . number_format($stats['total_amount']), 'fa-coins', 'sky'); ?></div>
</div>

<!-- Filter Tabs -->
<div class="admin-filter-bar">
    <div class="admin-filter-row align-items-center">
        <div class="btn-group btn-group-sm" role="group">
            <a href="?page=payment-transactions" class="btn <?php echo !$statusFilter ? 'btn-primary' : 'btn-outline-secondary'; ?>">All</a>
            <a href="?page=payment-transactions&status=pending" class="btn <?php echo $statusFilter === 'pending' ? 'btn-warning' : 'btn-outline-secondary'; ?>">Pending</a>
            <a href="?page=payment-transactions&status=completed" class="btn <?php echo $statusFilter === 'completed' ? 'btn-success' : 'btn-outline-secondary'; ?>">Completed</a>
            <a href="?page=payment-transactions&status=failed" class="btn <?php echo $statusFilter === 'failed' ? 'btn-danger' : 'btn-outline-secondary'; ?>">Failed</a>
        </div>
        <div class="admin-filter-actions">
            <span class="text-muted small fw-semibold"><?php echo count($transactions); ?> shown</span>
        </div>
    </div>
</div>

<!-- Transactions Table -->
<div class="admin-list-shell">
    <div class="admin-list-shell-header">
        <h2 class="admin-list-shell-title">Payment Transactions</h2>
        <span class="text-muted small fw-semibold"><?php echo count($transactions); ?>টি</span>
    </div>
    <div class="admin-table-wrap">
        <table class="admin-table admin-table-mobile-cards">
            <thead>
                <tr>
                    <th>Invoice</th>
                    <th>Order</th>
                    <th>Customer</th>
                    <th>Method</th>
                    <th>Transaction ID</th>
                    <th>Amount</th>
                    <th>Status</th>
                    <th>Date</th>
                    <th class="text-end">Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($transactions)): ?>
                    <tr><td colspan="9"><?php adminEmptyState('কোনো ট্রানজেকশন নেই', 'পেমেন্ট সাবমিট হলে এখানে দেখা যাবে', 'fa-receipt'); ?></td></tr>
                <?php else: ?>
                    <?php foreach ($transactions as $tx): ?>
                    <tr>
                        <td>
                            <code class="text-primary fw-bold"><?php echo $tx['invoice_id']; ?></code>
                        </td>
                        <td>
                            <?php if ($tx['order_id']): ?>
                            <a href="?page=order-view&id=<?php echo $tx['order_id']; ?>" class="text-decoration-none">
                                <?php echo $tx['tracking_id'] ?? '#' . $tx['order_id']; ?>
                            </a>
                            <?php else: ?>
                            <span class="text-muted">-</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <div class="fw-bold"><?php echo htmlspecialchars($tx['customer_name']); ?></div>
                            <small class="text-muted"><?php echo $tx['customer_phone']; ?></small>
                        </td>
                        <td>
                            <span class="badge bg-primary bg-opacity-10 text-primary rounded-pill">
                                <?php echo htmlspecialchars($tx['method_name']); ?>
                            </span>
                        </td>
                        <td>
                            <?php if ($tx['transaction_id']): ?>
                            <code><?php echo htmlspecialchars($tx['transaction_id']); ?></code>
                            <br><small class="text-muted">From: <?php echo $tx['sender_number']; ?></small>
                            <?php else: ?>
                            <span class="text-muted">Not provided</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <div class="fw-bold">৳<?php echo number_format($tx['total_amount'], 2); ?></div>
                            <?php if ($tx['charge'] > 0): ?>
                            <small class="text-muted">(+৳<?php echo $tx['charge']; ?> charge)</small>
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php
                            $statusClasses = [
                                'pending' => 'warning',
                                'processing' => 'info',
                                'completed' => 'success',
                                'failed' => 'danger',
                                'cancelled' => 'secondary',
                                'refunded' => 'dark'
                            ];
                            $statusClass = $statusClasses[$tx['status']] ?? 'secondary';
                            ?>
                            <span class="badge bg-<?php echo $statusClass; ?> rounded-pill">
                                <?php echo ucfirst($tx['status']); ?>
                            </span>
                        </td>
                        <td>
                            <small class="text-muted"><?php echo date('d M Y', strtotime($tx['created_at'])); ?></small>
                            <br><small class="text-muted"><?php echo date('h:i A', strtotime($tx['created_at'])); ?></small>
                        </td>
                        <td class="text-end">
                            <?php if ($tx['status'] === 'pending'): ?>
                            <div class="btn-group">
                                <form action="actions/payment-transaction-update.php" method="POST" class="d-inline"
                                      onsubmit="return confirm('Approve this payment?')">
                                    <input type="hidden" name="id" value="<?php echo $tx['id']; ?>">
                                    <input type="hidden" name="status" value="completed">
                                    <button type="submit" class="btn btn-sm btn-success">
                                        <i class="fas fa-check"></i> Approve
                                    </button>
                                </form>
                                <form action="actions/payment-transaction-update.php" method="POST" class="d-inline"
                                      onsubmit="return confirm('Reject this payment?')">
                                    <input type="hidden" name="id" value="<?php echo $tx['id']; ?>">
                                    <input type="hidden" name="status" value="failed">
                                    <button type="submit" class="btn btn-sm btn-danger">
                                        <i class="fas fa-times"></i> Reject
                                    </button>
                                </form>
                            </div>
                            <?php else: ?>
                            <button type="button" class="btn btn-sm btn-outline-secondary"
                                    data-bs-toggle="modal" data-bs-target="#detailModal<?php echo $tx['id']; ?>">
                                <i class="fas fa-eye"></i> View
                            </button>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<!-- Detail Modals -->
<?php foreach ($transactions as $tx):
    $statusClasses = [
        'pending' => 'warning',
        'processing' => 'info',
        'completed' => 'success',
        'failed' => 'danger',
        'cancelled' => 'secondary',
        'refunded' => 'dark'
    ];
?>
<div class="modal fade" id="detailModal<?php echo $tx['id']; ?>" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content border-0 rounded-4">
            <div class="modal-header border-0 pb-0">
                <h5 class="modal-title fw-bold">
                    <i class="fas fa-receipt text-primary me-2"></i><?php echo $tx['invoice_id']; ?>
                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <table class="table table-borderless mb-0">
                    <tr><td class="text-muted">Customer</td><td class="fw-bold"><?php echo htmlspecialchars($tx['customer_name']); ?></td></tr>
                    <tr><td class="text-muted">Phone</td><td><?php echo $tx['customer_phone']; ?></td></tr>
                    <tr><td class="text-muted">Method</td><td><span class="badge bg-primary"><?php echo $tx['method_name']; ?></span></td></tr>
                    <tr><td class="text-muted">Transaction ID</td><td><code><?php echo $tx['transaction_id'] ?? 'N/A'; ?></code></td></tr>
                    <tr><td class="text-muted">Sender Number</td><td><?php echo $tx['sender_number'] ?? 'N/A'; ?></td></tr>
                    <tr><td class="text-muted">Amount</td><td class="fw-bold">৳<?php echo number_format($tx['amount'], 2); ?></td></tr>
                    <tr><td class="text-muted">Charge</td><td>৳<?php echo number_format($tx['charge'], 2); ?></td></tr>
                    <tr><td class="text-muted">Total</td><td class="fw-bold text-success">৳<?php echo number_format($tx['total_amount'], 2); ?></td></tr>
                    <tr><td class="text-muted">Status</td><td><span class="badge bg-<?php echo $statusClasses[$tx['status']] ?? 'secondary'; ?>"><?php echo ucfirst($tx['status']); ?></span></td></tr>
                    <?php if ($tx['admin_note']): ?>
                    <tr><td class="text-muted">Admin Note</td><td><?php echo htmlspecialchars($tx['admin_note']); ?></td></tr>
                    <?php endif; ?>
                    <tr><td class="text-muted">Date</td><td><?php echo date('d M Y, h:i A', strtotime($tx['created_at'])); ?></td></tr>
                </table>
            </div>
            <div class="modal-footer border-0 pt-0">
                <button type="button" class="btn btn-light rounded-pill px-4" data-bs-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>
<?php endforeach; ?>
