<?php
// Fetch sophisticated stats
$total_products = $pdo->query("SELECT COUNT(*) FROM products")->fetchColumn();
$total_orders = $pdo->query("SELECT COUNT(*) FROM orders")->fetchColumn();
$total_revenue = $pdo->query("SELECT SUM(total_amount) FROM orders WHERE order_status != 'Cancelled'")->fetchColumn() ?: 0;
$total_customers = $pdo->query("SELECT COUNT(*) FROM users")->fetchColumn();

// Fetch Category Distribution for Doughnut Chart
$cat_data = $pdo->query("SELECT c.name, COUNT(p.id) as count 
                        FROM categories c 
                        LEFT JOIN products p ON c.id = p.category_id 
                        GROUP BY c.id LIMIT 5")->fetchAll();
$cat_labels = json_encode(array_column($cat_data, 'name'));
$cat_counts = json_encode(array_column($cat_data, 'count'));

// Recent Orders with Details
$recent_orders = $pdo->query("SELECT o.*, u.name as customer_name 
                             FROM orders o 
                             LEFT JOIN users u ON o.user_id = u.id 
                             ORDER BY o.created_at DESC LIMIT 6")->fetchAll();

// Fetch Sales Velocity (Last 7 Days)
$stmt_velocity = $pdo->query("
    SELECT 
        DATE_FORMAT(d.date, '%b %d') as date_label,
        COALESCE(SUM(o.total_amount), 0) as daily_revenue,
        COALESCE(COUNT(o.id), 0) as daily_orders
    FROM (
        SELECT CURDATE() - INTERVAL (a.a + (10 * b.a) + (100 * c.a)) DAY AS date
        FROM (SELECT 0 AS a UNION ALL SELECT 1 UNION ALL SELECT 2 UNION ALL SELECT 3 UNION ALL SELECT 4 UNION ALL SELECT 5 UNION ALL SELECT 6 UNION ALL SELECT 7 UNION ALL SELECT 8 UNION ALL SELECT 9) AS a
        CROSS JOIN (SELECT 0 AS a UNION ALL SELECT 1 UNION ALL SELECT 2 UNION ALL SELECT 3 UNION ALL SELECT 4 UNION ALL SELECT 5 UNION ALL SELECT 6 UNION ALL SELECT 7 UNION ALL SELECT 8 UNION ALL SELECT 9) AS b
        CROSS JOIN (SELECT 0 AS a UNION ALL SELECT 1 UNION ALL SELECT 2 UNION ALL SELECT 3 UNION ALL SELECT 4 UNION ALL SELECT 5 UNION ALL SELECT 6 UNION ALL SELECT 7 UNION ALL SELECT 8 UNION ALL SELECT 9) AS c
    ) d
    LEFT JOIN orders o ON DATE(o.created_at) = d.date AND o.order_status != 'Cancelled'
    WHERE d.date BETWEEN CURDATE() - INTERVAL 6 DAY AND CURDATE()
    GROUP BY d.date
    ORDER BY d.date ASC
");
$velocity_result = $stmt_velocity->fetchAll();
$velocity_labels = json_encode(array_column($velocity_result, 'date_label'));
$velocity_revenue = json_encode(array_column($velocity_result, 'daily_revenue'));
$velocity_orders = json_encode(array_column($velocity_result, 'daily_orders'));

// Fetch Order Status Distribution
$status_dist = $pdo->query("SELECT order_status, COUNT(*) as count FROM orders GROUP BY order_status")->fetchAll();
$status_labels = json_encode(array_column($status_dist, 'order_status'));
$status_counts = json_encode(array_column($status_dist, 'count'));

// Fetch Top Selling Products
$top_products = $pdo->query("
    SELECT p.name, SUM(oi.qty) as total_qty, SUM(oi.qty * oi.price) as total_revenue
    FROM order_items oi
    JOIN products p ON oi.product_id = p.id
    GROUP BY p.id
    ORDER BY total_qty DESC
    LIMIT 5
")->fetchAll();
?>
<?php adminFlashMessages(); ?>

<div class="dashboard-v2 animate__animated animate__fadeIn">
    <?php adminPageHeader('ড্যাশবোর্ড', 'স্বাগতম, ' . htmlspecialchars($_SESSION['admin_name'] ?? 'Admin') . ' — ' . date('l, d M Y'), [
        ['label' => 'Reports', 'icon' => 'fa-download', 'url' => 'index.php?page=reports', 'class' => 'btn btn-outline-primary btn-sm'],
        ['label' => 'নতুন পণ্য', 'icon' => 'fa-plus', 'url' => 'index.php?page=add-product', 'class' => 'btn btn-primary btn-sm'],
    ]); ?>

    <div class="admin-kpi-row row g-3">
        <div class="col-md-3 col-6"><?php adminStatCard('মোট Revenue', '৳' . number_format($total_revenue), 'fa-wallet', 'green', '+12.5%'); ?></div>
        <div class="col-md-3 col-6"><?php adminStatCard('মোট অর্ডার', $total_orders, 'fa-receipt', 'blue', '+3.2%'); ?></div>
        <div class="col-md-3 col-6"><?php adminStatCard('Inventory', $total_products, 'fa-box', 'amber', '-2.4%', false); ?></div>
        <div class="col-md-3 col-6"><?php adminStatCard('গ্রাহক', $total_customers, 'fa-users', 'purple', '+5.1%'); ?></div>
    </div>

    <div class="row g-4 mb-4">
        <div class="col-md-8">
            <div class="admin-list-shell h-100">
                <div class="admin-list-shell-header">
                    <h2 class="admin-list-shell-title">Sales Velocity</h2>
                    <div class="btn-group btn-group-sm p-1 bg-light rounded-3">
                        <button type="button" id="toggle-revenue" class="btn btn-white border-0 shadow-sm rounded-2 px-3 active">Revenue</button>
                        <button type="button" id="toggle-orders" class="btn btn-transparent border-0 px-3 text-muted">Orders</button>
                    </div>
                </div>
                <div class="p-4">
                    <div style="height: 350px;">
                        <canvas id="velocityChart"></canvas>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-md-4">
            <div class="admin-list-shell h-100">
                <div class="admin-list-shell-header">
                    <h2 class="admin-list-shell-title">Order Status</h2>
                </div>
                <div class="p-4">
                    <div style="height: 250px;" class="mb-3">
                        <canvas id="orderStatusChart"></canvas>
                    </div>
                    <div class="text-center small text-muted">Distribution of current order statuses</div>
                </div>
            </div>
        </div>
    </div>

    <div class="row g-4 mb-4">
        <div class="col-md-6">
            <div class="admin-list-shell h-100">
                <div class="admin-list-shell-header">
                    <h2 class="admin-list-shell-title">Top Selling Products</h2>
                </div>
                <div class="admin-table-wrap">
                    <table class="admin-table admin-table-mobile-cards">
                        <thead>
                            <tr>
                                <th scope="col">Product</th>
                                <th scope="col" class="text-center">Sold</th>
                                <th scope="col" class="text-end">Revenue</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (empty($top_products)): ?>
                                <tr><td colspan="3"><?php adminEmptyState('কোনো সেলস ডেটা নেই', 'অর্ডার হলে টপ প্রোডাক্ট এখানে দেখা যাবে', 'fa-box'); ?></td></tr>
                            <?php else: ?>
                                <?php foreach ($top_products as $idx => $prod): ?>
                                <tr>
                                    <td>
                                        <div class="d-flex align-items-center gap-3">
                                            <div class="rounded-circle bg-primary-subtle text-primary fw-bold d-flex align-items-center justify-content-center" style="width: 30px; height: 30px; font-size: 0.8rem;">
                                                <?php echo $idx + 1; ?>
                                            </div>
                                            <div class="fw-semibold text-truncate" style="max-width: 220px;">
                                                <?php echo htmlspecialchars($prod['name']); ?>
                                            </div>
                                        </div>
                                    </td>
                                    <td class="text-center fw-bold"><?php echo $prod['total_qty']; ?></td>
                                    <td class="text-end fw-bold text-success">৳<?php echo number_format($prod['total_revenue']); ?></td>
                                </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <div class="col-md-6">
            <div class="admin-list-shell h-100">
                <div class="admin-list-shell-header">
                    <h2 class="admin-list-shell-title">Revenue by Category</h2>
                </div>
                <div class="p-4">
                    <div class="row align-items-center">
                        <div class="col-md-6">
                            <div style="height: 200px;">
                                <canvas id="categoryDistribution"></canvas>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="category-legend">
                                <?php
                                $colors = ['#3b82f6', '#10b981', '#f59e0b', '#ef4444', '#8b5cf6'];
                                foreach ($cat_data as $i => $cat):
                                ?>
                                <div class="d-flex align-items-center justify-content-between mb-2 small">
                                    <div class="d-flex align-items-center gap-2">
                                        <span class="dot" style="background: <?php echo $colors[$i] ?? '#ccc'; ?>"></span>
                                        <span class="text-muted text-truncate" style="max-width: 100px;"><?php echo htmlspecialchars($cat['name']); ?></span>
                                    </div>
                                    <span class="fw-bold"><?php echo $cat['count']; ?> items</span>
                                </div>
                                <?php endforeach; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="admin-list-shell">
        <div class="admin-list-shell-header">
            <h2 class="admin-list-shell-title">Recent Transactions</h2>
            <a href="index.php?page=orders" class="btn btn-sm btn-outline-primary">View All</a>
        </div>
        <div class="admin-table-wrap">
            <table class="admin-table admin-table-mobile-cards">
                <thead>
                    <tr>
                        <th scope="col">Order ID</th>
                        <th scope="col">Customer</th>
                        <th scope="col">Status</th>
                        <th scope="col">Amount</th>
                        <th scope="col">Date</th>
                        <th scope="col" class="text-end">Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($recent_orders)): ?>
                        <tr><td colspan="6"><?php adminEmptyState('কোনো অর্ডার নেই', 'নতুন অর্ডার এলে এখানে দেখা যাবে', 'fa-receipt'); ?></td></tr>
                    <?php else: ?>
                        <?php foreach ($recent_orders as $order): ?>
                        <tr>
                            <td><span class="fw-semibold">#<?php echo htmlspecialchars($order['tracking_id']); ?></span></td>
                            <td>
                                <div class="d-flex align-items-center gap-2">
                                    <?php $display_name = $order['customer_name'] ?? $order['user_name'] ?? 'Guest'; ?>
                                    <div class="avatar-sm bg-light rounded-circle text-primary fw-bold"><?php echo htmlspecialchars(substr($display_name, 0, 1)); ?></div>
                                    <span><?php echo htmlspecialchars($display_name); ?></span>
                                </div>
                            </td>
                            <td><?php echo adminStatusBadge($order['order_status']); ?></td>
                            <td class="fw-semibold">৳<?php echo number_format($order['total_amount']); ?></td>
                            <td class="text-muted small"><?php echo date('M d, Y', strtotime($order['created_at'])); ?></td>
                            <td class="text-end">
                                <div class="dropdown">
                                    <button type="button" class="btn btn-icon btn-sm" data-bs-toggle="dropdown" aria-expanded="false"><i class="fas fa-ellipsis-v"></i></button>
                                    <ul class="dropdown-menu dropdown-menu-end shadow border-0 rounded-3">
                                        <li><a class="dropdown-item" href="index.php?page=order-view&id=<?php echo $order['id']; ?>"><i class="fas fa-eye me-2 opacity-50"></i> View Details</a></li>
                                        <li><a class="dropdown-item text-danger delete-order-btn" href="#" data-id="<?php echo $order['id']; ?>"><i class="fas fa-trash me-2 opacity-50"></i> Delete</a></li>
                                    </ul>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<style>
.bg-indigo-600 { background: #4f46e5; }
.tracking-tight { letter-spacing: -0.02em; }
.fw-600 { font-weight: 600; }
.text-slate-900 { color: #0f172a; }
.text-slate-800 { color: #1e293b; }
.text-slate-500 { color: #64748b; }
.avatar-sm { width: 32px; height: 32px; display: flex; align-items: center; justify-content: center; font-size: 0.75rem; }
.metric-icon { width: 44px; height: 44px; display: flex; align-items: center; justify-content: center; font-size: 1.1rem; }
.dot { width: 8px; height: 8px; border-radius: 50%; display: inline-block; }
.btn-white { background: #fff; border: 1px solid #e2e8f0; color: #475569; }
.btn-icon { background: transparent; border: none; color: #94a3b8; width: 30px; height: 30px; border-radius: 8px; }
.btn-icon:hover { background: #f1f5f9; color: #475569; }

.bg-success-subtle { background: #dcfce7; }
.bg-warning-subtle { background: #fef9c3; }
.bg-danger-subtle { background: #fee2e2; }

/* Custom Clock Animation */
@keyframes pulse-clock { 0% { opacity: 1; } 50% { opacity: 0.6; } 100% { opacity: 1; } }
#realtime-clock { animation: pulse-clock 2s infinite; font-variant-numeric: tabular-nums; }
</style>

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
// Real-time Clock
function updateClock() {
    const now = new Date();
    const options = { weekday: 'short', year: 'numeric', month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit', second: '2-digit' };
    document.getElementById('realtime-clock').innerText = now.toLocaleDateString('en-US', options);
}
setInterval(updateClock, 1000);
updateClock();

// Velocity Chart
const velocityLabels = <?php echo $velocity_labels; ?>;
const revenueData = <?php echo $velocity_revenue; ?>;
const ordersData = <?php echo $velocity_orders; ?>;

const vCtx = document.getElementById('velocityChart').getContext('2d');
const vGradient = vCtx.createLinearGradient(0, 0, 0, 400);
vGradient.addColorStop(0, 'rgba(21, 128, 61, 0.2)');
vGradient.addColorStop(1, 'rgba(21, 128, 61, 0)');

let currentMode = 'revenue'; // Default mode

const velocityChart = new Chart(vCtx, {
    type: 'line',
    data: {
        labels: velocityLabels,
        datasets: [{
            label: 'Weekly Revenue',
            data: revenueData,
            borderColor: '#15803d',
            backgroundColor: vGradient,
            fill: true,
            tension: 0.45,
            borderWidth: 4,
            pointRadius: 6,
            pointBackgroundColor: '#fff',
            pointBorderWidth: 3
        }]
    },
    options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: { 
            legend: { display: false },
            tooltip: {
                callbacks: {
                    label: function(context) {
                        let label = context.dataset.label || '';
                        if (label) label += ': ';
                        if (currentMode === 'revenue') {
                            label += '৳' + context.parsed.y.toLocaleString();
                        } else {
                            label += context.parsed.y + ' orders';
                        }
                        return label;
                    }
                }
            }
        },
        scales: {
            y: { 
                beginAtZero: true,
                ticks: { 
                    color: '#94a3b8',
                    callback: function(value) {
                        return currentMode === 'revenue' ? '৳' + value.toLocaleString() : value;
                    }
                }, 
                grid: { color: '#f1f5f9', borderDash: [5, 5] } 
            },
            x: { ticks: { color: '#94a3b8' }, grid: { display: false } }
        }
    }
});

// Toggle Logic
const btnRevenue = document.getElementById('toggle-revenue');
const btnOrders = document.getElementById('toggle-orders');

function updateChart(mode) {
    currentMode = mode;
    const isRevenue = mode === 'revenue';
    
    // Update Button UI
    btnRevenue.className = isRevenue ? 'btn btn-white border-0 shadow-sm rounded-2 px-3 active' : 'btn btn-transparent border-0 px-3 text-muted';
    btnOrders.className = !isRevenue ? 'btn btn-white border-0 shadow-sm rounded-2 px-3 active' : 'btn btn-transparent border-0 px-3 text-muted';
    
    // Update Chart Data
    velocityChart.data.datasets[0].data = isRevenue ? revenueData : ordersData;
    velocityChart.data.datasets[0].label = isRevenue ? 'Weekly Revenue' : 'Weekly Orders';
    
    // Trigger axis update
    velocityChart.update();
}

btnRevenue.addEventListener('click', () => updateChart('revenue'));
btnOrders.addEventListener('click', () => updateChart('orders'));

// Order Status Chart
new Chart(document.getElementById('orderStatusChart'), {
    type: 'doughnut',
    data: {
        labels: <?php echo $status_labels; ?>,
        datasets: [{
            data: <?php echo $status_counts; ?>,
            backgroundColor: ['#f59e0b', '#3b82f6', '#10b981', '#ef4444', '#64748b'],
            borderWidth: 0,
            hoverOffset: 10
        }]
    },
    options: {
        cutout: '70%',
        responsive: true,
        maintainAspectRatio: false,
        plugins: { 
            legend: { position: 'bottom', labels: { usePointStyle: true, boxWidth: 8 } } 
        }
    }
});

// Category Distribution Chart (Existing code...)
new Chart(document.getElementById('categoryDistribution'), {
    type: 'doughnut',
    data: {
        labels: <?php echo $cat_labels; ?>,
        datasets: [{
            data: <?php echo $cat_counts; ?>,
            backgroundColor: ['#3b82f6', '#10b981', '#f59e0b', '#ef4444', '#8b5cf6'],
            borderWidth: 0,
            hoverOffset: 20
        }]
    },
    options: {
        cutout: '80%',
        responsive: true,
        maintainAspectRatio: false,
        plugins: { legend: { display: false } }
    }
});
// Delete Order Functionality
document.querySelectorAll('.delete-order-btn').forEach(btn => {
    btn.addEventListener('click', function(e) {
        e.preventDefault();
        const id = this.getAttribute('data-id');
        if (confirm('Are you sure you want to delete this order?')) {
            fetch('actions/order-delete.php?id=' + id, {
                headers: { 'X-Requested-With': 'XMLHttpRequest' }
            })
            .then(res => res.json())
            .then(data => {
                if (data.success) {
                    if (typeof loadPage === 'function') {
                        loadPage('index.php?page=dashboard&success=' + encodeURIComponent(data.message));
                    } else {
                        window.location.reload();
                    }
                } else {
                    alert('Error: ' + data.message);
                }
            })
            .catch(err => console.error('Delete error:', err));
        }
    });
});
</script>
