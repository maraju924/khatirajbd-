<?php
require_once __DIR__ . '/../../app/Services/AbandonedCartService.php';
require_once __DIR__ . '/../../app/Helpers/WhatsAppHelper.php';

$service = new AbandonedCartService($pdo);
$waHelper = new \App\Helpers\WhatsAppHelper($pdo);

// Auto-expire carts older than 7 days (previously this never ran)
try {
    $service->expireOldCarts();
} catch (PDOException $e) {
    // Table might not exist yet
}

$filter = $_GET['filter'] ?? 'active';
$allowedFilters = ['active', 'recovered', 'expired', 'all'];
if (!in_array($filter, $allowedFilters, true)) {
    $filter = 'active';
}

$search = trim($_GET['q'] ?? '');
$per_page = 25;
$pg = max(1, (int)($_GET['pg'] ?? 1));

// Build WHERE with prepared params
$conditions = [];
$params = [];
if ($filter !== 'all') {
    $conditions[] = 'status = ?';
    $params[] = $filter;
}
if ($search !== '') {
    $conditions[] = '(customer_name LIKE ? OR customer_phone LIKE ? OR customer_email LIKE ?)';
    $like = '%' . $search . '%';
    array_push($params, $like, $like, $like);
}
$whereSql = $conditions ? implode(' AND ', $conditions) : '1=1';

$carts = [];
$total_rows = 0;
$stats = [
    'active' => 0, 'recovered' => 0, 'expired' => 0,
    'potential' => 0.0, 'recovered_revenue' => 0.0, 'today' => 0,
];

try {
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM abandoned_carts WHERE $whereSql");
    $stmt->execute($params);
    $total_rows = (int)$stmt->fetchColumn();

    $offset = ($pg - 1) * $per_page;
    $stmt = $pdo->prepare("SELECT * FROM abandoned_carts WHERE $whereSql ORDER BY updated_at DESC LIMIT $per_page OFFSET $offset");
    $stmt->execute($params);
    $carts = $stmt->fetchAll();

    $row = $pdo->query("
        SELECT
            SUM(status = 'active') AS active_count,
            SUM(status = 'recovered') AS recovered_count,
            SUM(status = 'expired') AS expired_count,
            COALESCE(SUM(CASE WHEN status = 'active' THEN cart_total END), 0) AS potential,
            COALESCE(SUM(CASE WHEN status = 'recovered' THEN cart_total END), 0) AS recovered_revenue,
            SUM(DATE(created_at) = CURDATE()) AS today_count
        FROM abandoned_carts
    ")->fetch(PDO::FETCH_ASSOC) ?: [];

    $stats['active'] = (int)($row['active_count'] ?? 0);
    $stats['recovered'] = (int)($row['recovered_count'] ?? 0);
    $stats['expired'] = (int)($row['expired_count'] ?? 0);
    $stats['potential'] = (float)($row['potential'] ?? 0);
    $stats['recovered_revenue'] = (float)($row['recovered_revenue'] ?? 0);
    $stats['today'] = (int)($row['today_count'] ?? 0);
} catch (PDOException $e) {
    echo '<div class="alert alert-warning">Abandoned cart table will be created automatically on first use.</div>';
}

$total_carts = $stats['active'] + $stats['recovered'] + $stats['expired'];
$recovery_rate = $total_carts > 0 ? round(($stats['recovered'] / $total_carts) * 100, 1) : 0;
$total_pages = max(1, (int)ceil($total_rows / $per_page));

$filter_counts = [
    'active' => $stats['active'],
    'recovered' => $stats['recovered'],
    'expired' => $stats['expired'],
    'all' => $total_carts,
];

// Fetch all active products for the modal item adder
$products = [];
try {
    $products = $pdo->query("SELECT id, name, price, offer_price FROM products WHERE status = 1 ORDER BY name ASC")->fetchAll();
} catch (PDOException $e) {
    // Non-blocking fallback
}

// Status badge: correct labels (previously mislabeled as Pending/Delivered/Cancelled)
function acStatusBadge(string $status): string {
    $map = [
        'active' => ['pending', 'Active'],
        'recovered' => ['delivered', 'Recovered'],
        'expired' => ['cancelled', 'Expired'],
    ];
    [$class, $label] = $map[$status] ?? ['inactive', ucfirst($status)];
    return '<span class="status-badge ' . $class . '">' . $label . '</span>';
}

function acTimeAgo(string $datetime): string {
    $diff = time() - strtotime($datetime);
    if ($diff < 60) return 'এইমাত্র';
    if ($diff < 3600) return floor($diff / 60) . ' মিনিট আগে';
    if ($diff < 86400) return floor($diff / 3600) . ' ঘণ্টা আগে';
    return floor($diff / 86400) . ' দিন আগে';
}
?>

<?php adminFlashMessages(); ?>
<?php adminPageHeader('Abandoned Carts', 'পরিত্যক্ত কার্ট ট্র্যাক, এডিট ও রিকভারি করুন'); ?>

<!-- KPI Cards -->
<div class="row g-3 mb-4 admin-kpi-row">
    <div class="col-md-3 col-6"><?php adminStatCard('Active Carts', number_format($stats['active']), 'fa-cart-arrow-down', 'amber', ($stats['today'] ? '+' . $stats['today'] . ' today' : ''), true); ?></div>
    <div class="col-md-3 col-6"><?php adminStatCard('Potential Revenue', '৳' . number_format($stats['potential']), 'fa-sack-dollar', 'blue'); ?></div>
    <div class="col-md-3 col-6"><?php adminStatCard('Recovered', number_format($stats['recovered']), 'fa-rotate-left', 'green'); ?></div>
    <div class="col-md-3 col-6"><?php adminStatCard('Recovery Rate', $recovery_rate . '%', 'fa-chart-line', 'purple', '৳' . number_format($stats['recovered_revenue']) . ' earned'); ?></div>
</div>

<!-- Filters + Search -->
<div class="admin-filter-bar">
    <div class="admin-filter-row align-items-center">
    <div class="btn-group btn-group-sm">
        <?php foreach (['active' => 'Active', 'recovered' => 'Recovered', 'expired' => 'Expired', 'all' => 'All'] as $key => $label): ?>
            <a href="index.php?page=abandoned-carts&filter=<?php echo $key; ?><?php echo $search !== '' ? '&q=' . urlencode($search) : ''; ?>"
               class="btn <?php echo $filter === $key ? 'btn-primary' : 'btn-outline-secondary'; ?>">
                <?php echo $label; ?>
                <span class="badge <?php echo $filter === $key ? 'bg-white text-primary' : 'bg-light text-secondary'; ?> ms-1"><?php echo number_format($filter_counts[$key]); ?></span>
            </a>
        <?php endforeach; ?>
    </div>
    <form method="GET" action="index.php" class="d-flex gap-2 ms-auto" style="max-width: 340px; flex: 1 1 220px;">
        <input type="hidden" name="page" value="abandoned-carts">
        <input type="hidden" name="filter" value="<?php echo htmlspecialchars($filter); ?>">
        <input type="search" name="q" class="form-control form-control-sm" placeholder="নাম / ফোন / ইমেইল খুঁজুন..." value="<?php echo htmlspecialchars($search); ?>">
        <?php if ($search !== ''): ?>
            <a href="index.php?page=abandoned-carts&filter=<?php echo $filter; ?>" class="btn btn-sm btn-outline-secondary" title="Clear"><i class="fas fa-times"></i></a>
        <?php endif; ?>
        <button type="submit" class="btn btn-sm btn-primary fw-semibold">Search</button>
    </form>
    </div>
</div>

<div class="admin-list-shell overflow-hidden mb-3">
    <div class="admin-list-shell-header">
        <h2 class="admin-list-shell-title">Abandoned Carts</h2>
        <span class="text-muted small fw-semibold"><?php echo number_format(count($carts)); ?>টি</span>
    </div>
    <div class="admin-table-wrap">
        <table class="admin-table admin-table-mobile-cards">
            <thead>
                <tr>
                    <th scope="col">Customer</th>
                    <th scope="col">Contact</th>
                    <th scope="col">Cart</th>
                    <th scope="col">Total</th>
                    <th scope="col">Reminders</th>
                    <th scope="col">Age</th>
                    <th scope="col">Status</th>
                    <th scope="col">Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($carts)): ?>
                    <tr><td colspan="8"><?php adminEmptyState(
                        $search !== '' ? 'কোনো ফলাফল পাওয়া যায়নি' : 'কোনো Abandoned Cart নেই',
                        $search !== '' ? '"' . $search . '" এর জন্য কিছু মেলেনি — অন্য কিছু দিয়ে খুঁজুন' : 'কাস্টমার কার্ট ছেড়ে গেলে এখানে দেখা যাবে',
                        'fa-cart-arrow-down'
                    ); ?></td></tr>
                <?php else: ?>
                    <?php foreach ($carts as $cart):
                        $items = json_decode($cart['cart_data'], true) ?: [];
                        $itemCount = array_sum(array_map(fn($i) => (int)($i['qty'] ?? 1), $items));
                        $waMessage = $service->getWhatsAppPreviewMessage($cart);
                        $waLink = !empty($cart['customer_phone']) ? $waHelper->buildChatLink($cart['customer_phone'], $waMessage) : '';
                        // SITE_URL already includes BASE_URL — previously doubled and links were broken
                        $recoveryLink = SITE_URL . '/cart/recover/' . $cart['recovery_token'];
                        $ageSeconds = time() - strtotime($cart['updated_at']);
                        $initial = mb_strtoupper(mb_substr(trim($cart['customer_name'] ?: '?'), 0, 1));
                    ?>
                    <tr>
                        <td>
                            <div class="d-flex align-items-center gap-2">
                                <div class="rounded-circle d-flex align-items-center justify-content-center flex-shrink-0 fw-bold"
                                     style="width: 36px; height: 36px; font-size: 0.85rem; background: linear-gradient(135deg, #eef2ff, #e0e7ff); color: #4f46e5;">
                                    <?php echo htmlspecialchars($initial); ?>
                                </div>
                                <div>
                                    <div class="fw-bold"><?php echo htmlspecialchars($cart['customer_name'] ?: 'Unknown'); ?></div>
                                    <?php if (!empty($cart['customer_email'])): ?>
                                        <small class="text-muted d-block" style="font-size: 0.75rem;"><?php echo htmlspecialchars($cart['customer_email']); ?></small>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </td>
                        <td>
                            <?php if (!empty($cart['customer_phone'])): ?>
                                <div class="d-flex align-items-center gap-1">
                                    <a href="tel:<?php echo htmlspecialchars($cart['customer_phone']); ?>" class="text-decoration-none fw-semibold"><?php echo htmlspecialchars($cart['customer_phone']); ?></a>
                                    <?php if ($waLink): ?>
                                        <a href="<?php echo htmlspecialchars($waLink); ?>" target="_blank" class="text-success ms-1" title="Open WhatsApp Chat"><i class="fab fa-whatsapp"></i></a>
                                    <?php endif; ?>
                                </div>
                            <?php else: ?>
                                <span class="badge bg-warning-subtle text-warning"><i class="fas fa-phone-slash me-1"></i>No phone</span>
                            <?php endif; ?>
                            <?php if (!empty($cart['customer_area'])): ?>
                                <small class="text-secondary d-block" style="font-size: 0.75rem;"><i class="fas fa-map-marker-alt text-danger me-1"></i><?php echo htmlspecialchars($cart['customer_area']); ?></small>
                            <?php endif; ?>
                        </td>
                        <td>
                            <div class="d-flex align-items-center">
                                <?php
                                $thumbs = 0;
                                foreach ($items as $item):
                                    if (empty($item['image']) || $thumbs >= 3) continue;
                                    $thumbs++;
                                ?>
                                    <img src="<?php echo BASE_URL . '/' . htmlspecialchars($item['image']); ?>"
                                         class="rounded-circle border border-2 border-white shadow-sm"
                                         style="width: 30px; height: 30px; object-fit: cover; <?php echo $thumbs > 1 ? 'margin-left: -10px;' : ''; ?>"
                                         title="<?php echo htmlspecialchars($item['name'] ?? ''); ?>">
                                <?php endforeach; ?>
                                <span class="badge bg-secondary-subtle text-secondary ms-2"><?php echo $itemCount; ?> pcs</span>
                            </div>
                        </td>
                        <td class="fw-bold text-danger">৳<?php echo number_format((float) $cart['cart_total']); ?></td>
                        <td>
                            <?php if ((int)$cart['whatsapp_sent_count'] > 0): ?>
                                <span class="badge bg-success-subtle text-success" title="WhatsApp reminders sent"><i class="fab fa-whatsapp me-1"></i><?php echo (int)$cart['whatsapp_sent_count']; ?>x</span>
                                <?php if (!empty($cart['last_reminder_at'])): ?>
                                    <small class="text-muted d-block" style="font-size: 0.72rem;"><?php echo acTimeAgo($cart['last_reminder_at']); ?></small>
                                <?php endif; ?>
                            <?php else: ?>
                                <span class="badge bg-light text-muted">Not sent</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php if ($cart['status'] === 'active' && $ageSeconds < 3600): ?>
                                <span class="badge bg-danger"><i class="fas fa-fire me-1"></i>HOT</span>
                            <?php endif; ?>
                            <small class="text-muted d-block"><?php echo acTimeAgo($cart['updated_at']); ?></small>
                        </td>
                        <td><?php echo acStatusBadge($cart['status']); ?></td>
                        <td>
                            <div class="btn-group btn-group-sm">
                                <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#editCartModal_<?php echo $cart['id']; ?>" title="View & Edit Cart">
                                    <i class="fas fa-eye"></i>
                                </button>
                                <button type="button" class="btn btn-outline-primary ac-copy-link" data-url="<?php echo htmlspecialchars($recoveryLink); ?>" title="Copy Recovery Link">
                                    <i class="fas fa-link"></i>
                                </button>
                                <?php if ($cart['status'] === 'active' && !empty($cart['customer_phone'])): ?>
                                    <a href="actions/abandoned-cart-send.php?id=<?php echo (int) $cart['id']; ?>" target="_blank" class="btn btn-outline-success" title="Send WhatsApp Reminder"><i class="fab fa-whatsapp"></i></a>
                                <?php endif; ?>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<!-- Edit modals rendered OUTSIDE the table — divs inside <tbody> are invalid HTML
     and the browser hoists their content out, breaking the whole page layout -->
<?php foreach ($carts as $cart):
    $items = json_decode($cart['cart_data'], true) ?: [];
    $recoveryLink = SITE_URL . '/cart/recover/' . $cart['recovery_token'];
?>
                    <!-- View/Edit Cart Modal -->
                    <div class="modal fade" id="editCartModal_<?php echo $cart['id']; ?>" tabindex="-1" aria-hidden="true">
                        <div class="modal-dialog modal-lg modal-dialog-centered">
                            <div class="modal-content border-0 shadow-lg" style="border-radius: 20px;">
                                <form action="actions/abandoned-cart-update.php" method="POST">
                                    <input type="hidden" name="id" value="<?php echo $cart['id']; ?>">
                                    <input type="hidden" name="submit_action" id="submit_action_<?php echo $cart['id']; ?>" value="save">

                                    <div class="modal-header border-0 pb-0 pt-4 px-4 d-flex justify-content-between align-items-center">
                                        <h5 class="modal-title fw-bold">
                                            <i class="fas fa-shopping-cart text-danger me-2"></i> Abandoned Cart #<?php echo $cart['id']; ?>
                                            <?php echo acStatusBadge($cart['status']); ?>
                                        </h5>
                                        <button type="button" class="btn-close bg-light p-2 rounded-circle" data-bs-dismiss="modal" aria-label="Close"></button>
                                    </div>

                                    <div class="modal-body p-4">
                                        <div class="row g-3">
                                            <!-- Customer Info -->
                                            <div class="col-md-6">
                                                <label class="form-label fw-bold small text-secondary">Customer Name</label>
                                                <input type="text" name="customer_name" class="form-control rounded-3" value="<?php echo htmlspecialchars($cart['customer_name'] ?? ''); ?>">
                                            </div>
                                            <div class="col-md-6">
                                                <label class="form-label fw-bold small text-secondary">Customer Phone</label>
                                                <input type="text" name="customer_phone" class="form-control rounded-3" value="<?php echo htmlspecialchars($cart['customer_phone'] ?? ''); ?>">
                                            </div>
                                            <div class="col-md-6">
                                                <label class="form-label fw-bold small text-secondary">Customer Email</label>
                                                <input type="email" name="customer_email" class="form-control rounded-3" value="<?php echo htmlspecialchars($cart['customer_email'] ?? ''); ?>" placeholder="name@example.com">
                                            </div>
                                            <div class="col-md-6">
                                                <label class="form-label fw-bold small text-secondary">Thana / District (Area)</label>
                                                <input type="text" name="customer_area" class="form-control rounded-3" value="<?php echo htmlspecialchars($cart['customer_area'] ?? ''); ?>" placeholder="e.g. Mirpur, Dhaka">
                                            </div>
                                            <div class="col-12">
                                                <label class="form-label fw-bold small text-secondary">Full Shipping Address</label>
                                                <textarea name="customer_address" class="form-control rounded-3" rows="2" placeholder="Street Address, House No, etc."><?php echo htmlspecialchars($cart['customer_address'] ?? ''); ?></textarea>
                                            </div>

                                            <!-- Status Select & Total Display -->
                                            <div class="col-md-6">
                                                <label class="form-label fw-bold small text-secondary">Cart Status</label>
                                                <select name="status" class="form-select rounded-3">
                                                    <option value="active" <?php echo ($cart['status'] === 'active') ? 'selected' : ''; ?>>Active</option>
                                                    <option value="recovered" <?php echo ($cart['status'] === 'recovered') ? 'selected' : ''; ?>>Recovered</option>
                                                    <option value="expired" <?php echo ($cart['status'] === 'expired') ? 'selected' : ''; ?>>Expired</option>
                                                </select>
                                            </div>
                                            <div class="col-md-6 d-flex align-items-end">
                                                <div class="w-100 p-3 bg-light rounded-3 text-end border">
                                                    <span class="small text-secondary d-block fw-bold mb-1">Cart Subtotal</span>
                                                    <span class="h4 fw-bold text-danger mb-0" id="total_display_<?php echo $cart['id']; ?>">৳<?php echo number_format($cart['cart_total']); ?></span>
                                                </div>
                                            </div>

                                            <!-- Recovery link -->
                                            <div class="col-12">
                                                <label class="form-label fw-bold small text-secondary">Recovery Link</label>
                                                <div class="input-group input-group-sm">
                                                    <input type="text" class="form-control bg-light" value="<?php echo htmlspecialchars($recoveryLink); ?>" readonly onclick="this.select()">
                                                    <button type="button" class="btn btn-outline-primary ac-copy-link" data-url="<?php echo htmlspecialchars($recoveryLink); ?>"><i class="fas fa-copy"></i></button>
                                                </div>
                                            </div>

                                            <!-- Cart Items Section -->
                                            <div class="col-12">
                                                <hr class="my-3">
                                                <div class="d-flex justify-content-between align-items-center mb-3">
                                                    <h6 class="fw-bold mb-0 text-dark"><i class="fas fa-shopping-basket text-success me-2"></i>Cart Items</h6>
                                                </div>

                                                <div class="table-responsive rounded-3 border">
                                                    <table class="table table-hover align-middle mb-0" id="items_table_<?php echo $cart['id']; ?>">
                                                        <thead class="bg-light">
                                                            <tr>
                                                                <th>Product</th>
                                                                <th style="width: 100px;">Qty</th>
                                                                <th style="width: 130px;">Price (৳)</th>
                                                                <th style="width: 50px;"></th>
                                                            </tr>
                                                        </thead>
                                                        <tbody>
                                                            <?php
                                                            $idx = 0;
                                                            foreach ($items as $item):
                                                                $pPrice = (float) ($item['price'] ?? 0.0);
                                                                $pQty = (int) ($item['qty'] ?? 1);
                                                            ?>
                                                                <tr data-product-id="<?php echo $item['id']; ?>">
                                                                    <td>
                                                                        <input type="hidden" name="items[<?php echo $idx; ?>][id]" value="<?php echo $item['id']; ?>">
                                                                        <?php if (!empty($item['cart_key'])): ?>
                                                                            <input type="hidden" name="items[<?php echo $idx; ?>][cart_key]" value="<?php echo htmlspecialchars($item['cart_key']); ?>">
                                                                        <?php endif; ?>
                                                                        <div class="d-flex align-items-center">
                                                                            <?php if (!empty($item['image'])): ?>
                                                                                <img src="<?php echo BASE_URL . '/' . htmlspecialchars($item['image']); ?>" class="rounded me-2" style="width: 36px; height: 36px; object-fit: cover;">
                                                                            <?php endif; ?>
                                                                            <div>
                                                                                <span class="fw-semibold text-dark d-block text-truncate" style="max-width: 250px;"><?php echo htmlspecialchars($item['name'] ?? 'Product'); ?></span>
                                                                                <?php if (!empty($item['variant_label'])): ?>
                                                                                    <small class="badge bg-info-subtle text-info"><?php echo htmlspecialchars($item['variant_label']); ?></small>
                                                                                <?php endif; ?>
                                                                            </div>
                                                                        </div>
                                                                    </td>
                                                                    <td>
                                                                        <input type="number" name="items[<?php echo $idx; ?>][qty]" class="form-control form-control-sm qty-input rounded-2 text-center" min="1" value="<?php echo $pQty; ?>" onchange="recalculateCartTotal(<?php echo $cart['id']; ?>)">
                                                                    </td>
                                                                    <td>
                                                                        <input type="number" name="items[<?php echo $idx; ?>][price]" class="form-control form-control-sm price-input rounded-2" min="0" step="1" value="<?php echo $pPrice; ?>" onchange="recalculateCartTotal(<?php echo $cart['id']; ?>)">
                                                                    </td>
                                                                    <td>
                                                                        <button type="button" class="btn btn-sm btn-link text-danger p-0" onclick="this.closest('tr').remove(); recalculateCartTotal(<?php echo $cart['id']; ?>);"><i class="fas fa-trash-alt"></i></button>
                                                                    </td>
                                                                </tr>
                                                            <?php
                                                                $idx++;
                                                            endforeach;
                                                            ?>
                                                        </tbody>
                                                    </table>
                                                </div>

                                                <!-- Add Product to Cart Sub-section -->
                                                <div class="row g-2 mt-3 align-items-center">
                                                    <div class="col-md-8 col-sm-7">
                                                        <select id="add_product_select_<?php echo $cart['id']; ?>" class="form-select form-select-sm rounded-3">
                                                            <option value="">-- Add Product to Cart --</option>
                                                            <?php foreach ($products as $p):
                                                                $pDisplayPrice = (float) ($p['offer_price'] ?: $p['price']);
                                                            ?>
                                                                <option value="<?php echo $p['id']; ?>" data-name="<?php echo htmlspecialchars($p['name']); ?>" data-price="<?php echo $pDisplayPrice; ?>">
                                                                    <?php echo htmlspecialchars($p['name']); ?> (৳<?php echo number_format($pDisplayPrice); ?>)
                                                                </option>
                                                            <?php endforeach; ?>
                                                        </select>
                                                    </div>
                                                    <div class="col-md-4 col-sm-5">
                                                        <button type="button" class="btn btn-success btn-sm w-100 rounded-pill" onclick="addProductToModalCart(<?php echo $cart['id']; ?>)">
                                                            <i class="fas fa-plus me-1"></i> Add Product
                                                        </button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="modal-footer border-0 pt-0 pb-4 px-4 d-flex justify-content-between">
                                        <div>
                                            <?php if ($cart['status'] === 'active'): ?>
                                                <button type="submit" class="btn btn-success rounded-pill px-4 py-2 fw-bold" onclick="document.getElementById('submit_action_<?php echo $cart['id']; ?>').value = 'convert'; return confirm('আপনি কি এই পরিত্যক্ত কার্টটিকে সরাসরি নতুন অর্ডারে রূপান্তর করে অর্ডার লিস্টে পাঠাতে চান?');">
                                                    <i class="fas fa-check-circle me-1"></i> Sent to Order List
                                                </button>
                                            <?php endif; ?>
                                        </div>
                                        <div>
                                            <button type="button" class="btn btn-outline-secondary rounded-pill px-3 py-2" data-bs-dismiss="modal">Cancel</button>
                                            <button type="submit" class="btn btn-primary rounded-pill px-4 py-2 fw-bold" onclick="document.getElementById('submit_action_<?php echo $cart['id']; ?>').value = 'save';">
                                                <i class="fas fa-save me-1"></i> Save Changes
                                            </button>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
<?php endforeach; ?>

<!-- Pagination -->
<?php if ($total_pages > 1): ?>
<nav class="d-flex justify-content-between align-items-center mb-4">
    <small class="text-muted"><?php echo number_format($total_rows); ?> carts — page <?php echo $pg; ?> of <?php echo $total_pages; ?></small>
    <ul class="pagination pagination-sm mb-0">
        <?php
        $qs = 'index.php?page=abandoned-carts&filter=' . $filter . ($search !== '' ? '&q=' . urlencode($search) : '');
        for ($p = max(1, $pg - 2); $p <= min($total_pages, $pg + 2); $p++): ?>
            <li class="page-item <?php echo $p === $pg ? 'active' : ''; ?>">
                <a class="page-link" href="<?php echo $qs . '&pg=' . $p; ?>"><?php echo $p; ?></a>
            </li>
        <?php endfor; ?>
    </ul>
</nav>
<?php endif; ?>

<?php
// Cron key + correct URL (SITE_URL already includes BASE_URL)
try {
    $cronKey = $pdo->query("SELECT value FROM settings WHERE key_name = 'abandoned_cart_cron_key'")->fetchColumn();
    if (empty($cronKey)) {
        $cronKey = bin2hex(random_bytes(16));
        $stmt = $pdo->prepare("INSERT INTO settings (key_name, value) VALUES ('abandoned_cart_cron_key', ?) ON DUPLICATE KEY UPDATE value = ?");
        $stmt->execute([$cronKey, $cronKey]);
    }
    $cronUrl = SITE_URL . '/cron/abandoned-cart?key=' . urlencode($cronKey);
} catch (PDOException $e) {
    $cronUrl = '';
}
?>
<?php if ($cronUrl): ?>
<div class="admin-card p-3 mb-4">
    <a class="text-decoration-none fw-bold small" data-bs-toggle="collapse" href="#cronInfo" role="button">
        <i class="fas fa-clock me-1"></i> Cron / Automation Setup <i class="fas fa-chevron-down ms-1 small"></i>
    </a>
    <div class="collapse mt-2" id="cronInfo">
        <p class="small text-muted mb-2">প্রতি ১৫–৩০ মিনিটে চালান (পুরনো cart auto-expire হবে):</p>
        <code class="user-select-all d-block small mb-2">php "<?php echo realpath(__DIR__ . '/../../cron/abandoned-cart-reminder.php'); ?>"</code>
        <div class="input-group input-group-sm" style="max-width: 640px;">
            <input type="text" class="form-control bg-light" value="<?php echo htmlspecialchars($cronUrl); ?>" readonly onclick="this.select()">
            <button type="button" class="btn btn-outline-primary ac-copy-link" data-url="<?php echo htmlspecialchars($cronUrl); ?>"><i class="fas fa-copy"></i></button>
        </div>
    </div>
</div>
<?php endif; ?>

<script>
function recalculateCartTotal(cartId) {
    const table = document.getElementById('items_table_' + cartId);
    if (!table) return;

    let subtotal = 0.0;
    const qtyInputs = table.querySelectorAll('.qty-input');
    const priceInputs = table.querySelectorAll('.price-input');

    qtyInputs.forEach((qtyIn, index) => {
        const qty = parseInt(qtyIn.value) || 0;
        const price = parseFloat(priceInputs[index].value) || 0.0;
        subtotal += (qty * price);
    });

    const display = document.getElementById('total_display_' + cartId);
    if (display) {
        display.innerText = '৳' + subtotal.toLocaleString(undefined, { minimumFractionDigits: 0, maximumFractionDigits: 0 });
    }
}

function addProductToModalCart(cartId) {
    const select = document.getElementById('add_product_select_' + cartId);
    if (!select || !select.value) return;

    const productId = select.value;
    const selectedOpt = select.options[select.selectedIndex];
    const name = selectedOpt.getAttribute('data-name');
    const price = selectedOpt.getAttribute('data-price');

    const table = document.getElementById('items_table_' + cartId);
    const tbody = table.querySelector('tbody');

    // Generate unique index to avoid collisions with existing rows
    const index = Date.now() + Math.floor(Math.random() * 1000);

    const newRow = document.createElement('tr');
    newRow.setAttribute('data-product-id', productId);
    newRow.innerHTML = `
        <td>
            <input type="hidden" name="items[${index}][id]" value="${productId}">
            <div class="d-flex align-items-center">
                <span class="fw-semibold text-dark text-truncate" style="max-width: 250px;">${name}</span>
            </div>
        </td>
        <td>
            <input type="number" name="items[${index}][qty]" class="form-control form-control-sm qty-input rounded-2 text-center" min="1" value="1" onchange="recalculateCartTotal(${cartId})">
        </td>
        <td>
            <input type="number" name="items[${index}][price]" class="form-control form-control-sm price-input rounded-2" min="0" step="1" value="${price}" onchange="recalculateCartTotal(${cartId})">
        </td>
        <td>
            <button type="button" class="btn btn-sm btn-link text-danger p-0" onclick="this.closest('tr').remove(); recalculateCartTotal(${cartId});"><i class="fas fa-trash-alt"></i></button>
        </td>
    `;

    tbody.appendChild(newRow);
    recalculateCartTotal(cartId);

    select.value = '';
}

// Copy link buttons (recovery link / cron URL) with clipboard fallback
document.querySelectorAll('.ac-copy-link').forEach(function(btn) {
    btn.addEventListener('click', function() {
        const url = btn.getAttribute('data-url');
        const done = function() {
            const icon = btn.querySelector('i');
            const prev = icon.className;
            icon.className = 'fas fa-check';
            btn.classList.add('btn-success');
            btn.classList.remove('btn-outline-primary');
            setTimeout(function() {
                icon.className = prev;
                btn.classList.remove('btn-success');
                btn.classList.add('btn-outline-primary');
            }, 1500);
        };
        if (navigator.clipboard && window.isSecureContext) {
            navigator.clipboard.writeText(url).then(done);
        } else {
            const ta = document.createElement('textarea');
            ta.value = url;
            ta.style.position = 'fixed';
            ta.style.opacity = '0';
            document.body.appendChild(ta);
            ta.select();
            try { document.execCommand('copy'); done(); } catch (e) { window.prompt('Copy link:', url); }
            document.body.removeChild(ta);
        }
    });
});
</script>
