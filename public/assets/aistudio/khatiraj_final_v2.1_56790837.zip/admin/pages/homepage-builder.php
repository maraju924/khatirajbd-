<?php
// admin/pages/homepage-builder.php
declare(strict_types=1);

$home_id = 0;
try {
    $stmt = $pdo->prepare("SELECT id FROM page_registry WHERE route_key = 'home'");
    $stmt->execute();
    $home_id = (int)($stmt->fetchColumn() ?: 0);
} catch (PDOException $e) {
    $home_id = 0;
}
?>

<?php adminFlashMessages(); ?>
<?php adminPageHeader('Homepage Hub', 'হোম পেজের Advanced Builder, স্লাইডার, ক্যাটাগরি ও প্রমো কন্টেন্ট', [
    ['label' => 'Page Manager', 'icon' => 'fa-arrow-left', 'url' => 'index.php?page=page-manager', 'class' => 'btn btn-outline-secondary btn-sm'],
    ['label' => 'হোম দেখুন', 'icon' => 'fa-external-link-alt', 'url' => '../', 'class' => 'btn btn-outline-primary btn-sm', 'target' => '_blank', 'data-no-pjax' => true],
]); ?>

<div class="row g-4">
    <div class="col-md-6 col-lg-4">
        <div class="admin-hub-tile">
            <div class="admin-hub-tile-icon blue"><i class="fas fa-layer-group"></i></div>
            <h5>Advanced Page Builder</h5>
            <p>Drag-drop blocks for home heading overrides and custom section content.</p>
            <?php if ($home_id): ?>
                <a href="index.php?page=edit-page&id=<?php echo $home_id; ?>&tab=content" class="btn btn-primary btn-sm" data-no-pjax>
                    <i class="fas fa-magic me-1"></i> Open Builder
                </a>
            <?php else: ?>
                <span class="badge bg-warning-subtle text-warning">Run migration first</span>
            <?php endif; ?>
        </div>
    </div>
    <div class="col-md-6 col-lg-4">
        <div class="admin-hub-tile">
            <div class="admin-hub-tile-icon green"><i class="fas fa-search"></i></div>
            <h5>Home SEO & Meta</h5>
            <p>Control meta title, description, keywords and social share image.</p>
            <?php if ($home_id): ?>
                <a href="index.php?page=edit-page&id=<?php echo $home_id; ?>&tab=seo" class="btn btn-outline-success btn-sm">
                    <i class="fas fa-sliders-h me-1"></i> Edit SEO
                </a>
            <?php endif; ?>
        </div>
    </div>
    <div class="col-md-6 col-lg-4">
        <div class="admin-hub-tile">
            <div class="admin-hub-tile-icon sky"><i class="fas fa-images"></i></div>
            <h5>Sliders</h5>
            <p>Homepage carousel and banner slides.</p>
            <a href="index.php?page=sliders" class="btn btn-outline-primary btn-sm">
                <i class="fas fa-arrow-right me-1"></i> Manage Sliders
            </a>
        </div>
    </div>
    <div class="col-md-6 col-lg-4">
        <div class="admin-hub-tile">
            <div class="admin-hub-tile-icon red"><i class="fas fa-bolt"></i></div>
            <h5>Flash Sale Banner</h5>
            <p>Countdown promo banner on the home page.</p>
            <a href="index.php?page=flash-sale" class="btn btn-outline-danger btn-sm">
                <i class="fas fa-arrow-right me-1"></i> Flash Sale
            </a>
        </div>
    </div>
    <div class="col-md-6 col-lg-4">
        <div class="admin-hub-tile">
            <div class="admin-hub-tile-icon amber"><i class="fas fa-tags"></i></div>
            <h5>Categories</h5>
            <p>Top active categories shown on the home grid.</p>
            <a href="index.php?page=categories" class="btn btn-outline-warning btn-sm">
                <i class="fas fa-arrow-right me-1"></i> Manage Categories
            </a>
        </div>
    </div>
</div>

<div class="admin-list-shell mt-4">
    <div class="admin-list-shell-header">
        <h2 class="admin-list-shell-title"><i class="fas fa-info-circle me-2 text-success"></i>Tip</h2>
    </div>
    <div class="p-3 small text-muted mb-0">
        In Advanced Builder, add <strong>Rich Text</strong> blocks with keys <code>categories_heading</code> / <code>products_heading</code> and set the <strong>Title</strong> to override home section headings.
    </div>
</div>
