<?php
// admin/pages/coupons.php
$coupons = $pdo->query("SELECT * FROM coupons ORDER BY id DESC")->fetchAll();
?>

<?php adminFlashMessages(); ?>
<?php adminPageHeader('Coupons', 'ডিসকাউন্ট কুপন তৈরি ও ম্যানেজ করুন', [
    ['label' => 'নতুন কুপন', 'icon' => 'fa-plus', 'url' => '#', 'class' => 'btn btn-primary btn-sm', 'modal' => 'addCouponModal'],
]); ?>

<div class="admin-list-shell">
    <div class="admin-list-shell-header">
        <h2 class="admin-list-shell-title">কুপন তালিকা</h2>
        <span class="text-muted small fw-semibold"><?php echo count($coupons); ?>টি</span>
    </div>
    <div class="admin-table-wrap">
        <table class="admin-table admin-table-mobile-cards">
            <thead>
                <tr>
                    <th>কোড</th>
                    <th>টাইপ</th>
                    <th>মান</th>
                    <th>Min. Order</th>
                    <th>Validity</th>
                    <th>স্ট্যাটাস</th>
                    <th class="text-end">অ্যাকশন</th>
                </tr>
            </thead>
            <tbody>
                    <?php if (empty($coupons)): ?>
                        <tr><td colspan="7"><?php adminEmptyState('কোনো কুপন নেই', 'উপরের "নতুন কুপন" বাটন থেকে প্রথম কুপন তৈরি করুন', 'fa-ticket-alt'); ?></td></tr>
                    <?php else: ?>
                        <?php foreach ($coupons as $coupon): ?>
                            <tr>
                                <td><strong class="text-primary"><?php echo htmlspecialchars($coupon['code']); ?></strong></td>
                                <td class="text-capitalize"><?php echo $coupon['type']; ?></td>
                                <td><?php echo $coupon['type'] == 'percent' ? $coupon['value'].'%' : '৳'.number_format($coupon['value']); ?></td>
                                <td>৳<?php echo number_format($coupon['min_order_amount']); ?></td>
                                <td class="small">
                                    <?php echo $coupon['start_date'] ? date('M d', strtotime($coupon['start_date'])) : 'Any'; ?> - 
                                    <?php echo $coupon['end_date'] ? date('M d, Y', strtotime($coupon['end_date'])) : 'Forever'; ?>
                                </td>
                                <td>
                                    <?php echo $coupon['status'] ? adminStatusBadge('Active') : adminStatusBadge('Inactive'); ?>
                                </td>
                                <td class="text-end">
                                    <form action="actions/coupon-actions.php" method="POST" class="d-inline" onsubmit="return confirm('Delete this coupon?')">
                                        <input type="hidden" name="id" value="<?php echo $coupon['id']; ?>">
                                        <button type="submit" name="action" value="delete" class="btn btn-sm btn-outline-danger">
                                            <i class="fas fa-trash"></i>
                                        </button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
    </div>
</div>

<!-- Add Coupon Modal -->
<div class="modal fade" id="addCouponModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content border-0 shadow-lg rounded-4">
            <div class="modal-header border-0 bg-primary text-white">
                <h5 class="modal-title fw-bold">Create New Coupon</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <form action="actions/coupon-actions.php" method="POST">
                <div class="modal-body p-4">
                    <div class="mb-3">
                        <label class="form-label fw-bold">Coupon Code</label>
                        <input type="text" name="code" class="form-control" placeholder="e.g. SAVE20" required>
                    </div>
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label fw-bold">Type</label>
                            <select name="type" class="form-select">
                                <option value="fixed">Fixed Amount (৳)</option>
                                <option value="percent">Percentage (%)</option>
                            </select>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label fw-bold">Value</label>
                            <input type="number" name="value" class="form-control" step="0.01" required>
                        </div>
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-bold">Minimum Order Amount (৳)</label>
                        <input type="number" name="min_order_amount" class="form-control" value="0" step="0.01">
                    </div>
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label fw-bold">Start Date</label>
                            <input type="date" name="start_date" class="form-control">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label fw-bold">End Date</label>
                            <input type="date" name="end_date" class="form-control">
                        </div>
                    </div>
                </div>
                <div class="modal-footer border-0 p-4 pt-0">
                    <button type="button" class="btn btn-light px-4" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" name="action" value="add" class="btn btn-primary px-4 fw-bold">Create Coupon</button>
                </div>
            </form>
        </div>
    </div>
</div>
