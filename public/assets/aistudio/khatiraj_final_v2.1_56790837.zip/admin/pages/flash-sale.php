<?php
// admin/pages/flash-sale.php
if ($_SESSION['admin_role'] !== 'super_admin') {
    echo '<div class="alert alert-danger m-4">Access Denied</div>';
    return;
}

$stmt = $pdo->query("SELECT key_name, value FROM settings WHERE key_name LIKE 'flash_sale_%'");
$settings = $stmt->fetchAll(PDO::FETCH_KEY_PAIR);

$status = $settings['flash_sale_status'] ?? '0';
$end_time = $settings['flash_sale_end_time'] ?? '';
$message = $settings['flash_sale_message'] ?? 'Flash Sale ends in:';
$discount = $settings['flash_sale_discount'] ?? 'UP TO 50% OFF!';
?>

<?php adminFlashMessages(); ?>
<?php if (isset($_SESSION['success'])): ?>
    <div class="admin-flash success"><i class="fas fa-check-circle"></i> <?php echo htmlspecialchars($_SESSION['success']); unset($_SESSION['success']); ?></div>
<?php endif; ?>
<?php adminPageHeader('Flash Sale', 'ফ্ল্যাশ সেল ক্যাম্পেইন সেটিংস ও প্রিভিউ'); ?>

<div class="settings-layout admin-shell" data-panel-prefix="fs">
    <nav class="settings-tabs admin-tabs" aria-label="Flash sale sections">
        <div class="settings-tabs-track admin-tabs-track" role="tablist">
            <a href="#fs-campaign" class="settings-tab admin-tab active" data-admin-nav="campaign" role="tab" aria-selected="true">
                <i class="fas fa-bolt"></i><span>ক্যাম্পেইন</span>
            </a>
            <a href="#fs-preview" class="settings-tab admin-tab" data-admin-nav="preview" role="tab" aria-selected="false">
                <i class="fas fa-eye"></i><span>প্রিভিউ</span>
            </a>
        </div>
    </nav>

    <div class="settings-content">
        <section class="settings-panel admin-panel is-active" id="fs-campaign" role="tabpanel">
            <?php adminPanelHeader('Display Settings', 'ব্যানার স্ট্যাটাস, সময় ও মেসেজ কনফিগার করুন', 'fa-bolt', 'amber'); ?>
            <form action="actions/update-flash-sale.php" method="POST" class="settings-form">
                <div class="settings-panel-body admin-panel-body">
                    <div class="settings-toggle-grid mb-4">
                        <label class="settings-toggle">
                            <input type="hidden" name="flash_sale_status" value="0" id="hidden_fs_status">
                            <input class="form-check-input" type="checkbox" name="flash_sale_status" value="1" id="fsStatus"
                                   data-hidden-pair="hidden_fs_status" <?php echo $status == '1' ? 'checked' : ''; ?>>
                            <span class="settings-toggle-body">
                                <span class="settings-toggle-title">Flash Sale ব্যানার চালু</span>
                                <span class="settings-toggle-desc">স্টোরফ্রন্টে কাউন্টডাউন ব্যানার দেখাবে</span>
                            </span>
                        </label>
                    </div>

                    <div class="mb-3">
                        <label class="form-label">End Date &amp; Time</label>
                        <input type="datetime-local" name="flash_sale_end_time" class="form-control" value="<?php echo date('Y-m-d\TH:i', strtotime($end_time ?: 'now')); ?>" required>
                        <div class="form-text">কাউন্টডাউন শূন্য হলে ব্যানার লজিক অনুযায়ী থেমে যাবে বা লুকবে।</div>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Campaign Message</label>
                        <input type="text" name="flash_sale_message" class="form-control" value="<?php echo htmlspecialchars($message); ?>" placeholder="e.g. Flash Sale ends in:">
                    </div>
                    <div class="mb-0">
                        <label class="form-label">Discount Text</label>
                        <input type="text" name="flash_sale_discount" class="form-control" value="<?php echo htmlspecialchars($discount); ?>" placeholder="e.g. UP TO 50% OFF!">
                    </div>
                </div>
                <?php adminSaveBar('ক্যাম্পেইন সেভ করুন'); ?>
            </form>
        </section>

        <section class="settings-panel admin-panel" id="fs-preview" role="tabpanel" hidden>
            <?php adminPanelHeader('How it looks', 'স্টোরফ্রন্ট ব্যানারের আনুমানিক প্রিভিউ', 'fa-eye', 'blue'); ?>
            <div class="settings-panel-body admin-panel-body bg-light">
                <div class="text-center p-4 border rounded-4 bg-white shadow-sm mx-auto" style="max-width: 400px;">
                    <div class="badge bg-danger mb-3 px-3 py-2 rounded-pill"><?php echo htmlspecialchars($discount); ?></div>
                    <h4 class="fw-bold mb-3"><?php echo htmlspecialchars($message); ?></h4>
                    <div class="d-flex justify-content-center gap-2 mb-2">
                        <div class="bg-dark text-white p-2 rounded-3" style="min-width: 60px;">
                            <div class="h4 mb-0 fw-bold">01</div>
                            <div style="font-size: 0.6rem; opacity: 0.7;">HOURS</div>
                        </div>
                        <div class="h4 align-self-center mb-0">:</div>
                        <div class="bg-dark text-white p-2 rounded-3" style="min-width: 60px;">
                            <div class="h4 mb-0 fw-bold">45</div>
                            <div style="font-size: 0.6rem; opacity: 0.7;">MINS</div>
                        </div>
                        <div class="h4 align-self-center mb-0">:</div>
                        <div class="bg-dark text-white p-2 rounded-3" style="min-width: 60px;">
                            <div class="h4 mb-0 fw-bold">12</div>
                            <div style="font-size: 0.6rem; opacity: 0.7;">SECS</div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
</div>
