<?php
// admin/pages/blog-posts.php
$posts = $pdo->query("SELECT bp.*, a.name as author_name FROM blog_posts bp LEFT JOIN admins a ON bp.author_id = a.id ORDER BY bp.id DESC")->fetchAll();
?>

<?php adminFlashMessages(); ?>
<?php adminPageHeader('Blog', 'ব্লগ পোস্ট তৈরি, সম্পাদনা ও প্রকাশনা ম্যানেজ করুন', [
    ['label' => 'নতুন পোস্ট', 'icon' => 'fa-plus', 'url' => 'index.php?page=add-blog-post', 'class' => 'btn btn-primary btn-sm'],
]); ?>

<div class="admin-list-shell">
  <div class="admin-list-shell-header">
    <h2 class="admin-list-shell-title">ব্লগ পোস্ট</h2>
    <span class="text-muted small fw-semibold"><?php echo count($posts); ?>টি</span>
  </div>
  <div class="admin-table-wrap">
  <table class="admin-table admin-table-mobile-cards">
    <thead>
      <tr>
        <th>#</th>
        <th>ছবি</th>
        <th>শিরোনাম</th>
        <th>স্ট্যাটাস</th>
        <th>Views</th>
        <th>তারিখ</th>
        <th>অ্যাকশন</th>
      </tr>
    </thead>
    <tbody>
      <?php if(count($posts) > 0): ?>
        <?php foreach ($posts as $post): ?>
        <tr id="blog-row-<?php echo $post['id']; ?>">
          <td><?php echo $post['id']; ?></td>
          <td>
            <?php if($post['image']): ?>
              <img src="../<?php echo $post['image']; ?>" width="50" height="35" style="object-fit: cover; border-radius: 6px;">
            <?php else: ?>
              <span class="text-muted"><i class="fas fa-image"></i></span>
            <?php endif; ?>
          </td>
          <td>
            <div class="fw-bold"><?php echo htmlspecialchars(mb_substr($post['title'], 0, 60)); ?><?php echo mb_strlen($post['title']) > 60 ? '...' : ''; ?></div>
            <small class="text-muted">/blog/<?php echo $post['slug']; ?></small>
          </td>
          <td>
            <?php echo $post['status'] == 1 ? adminStatusBadge('published') : adminStatusBadge('draft'); ?>
          </td>
          <td><span class="badge bg-light text-dark"><?php echo number_format($post['views']); ?></span></td>
          <td><?php echo date('d M, Y', strtotime($post['created_at'])); ?></td>
          <td>
            <a href="index.php?page=edit-blog-post&id=<?php echo $post['id']; ?>" class="btn btn-sm btn-outline-secondary">
              <i class="fas fa-edit"></i>
            </a>
            <button type="button" class="btn btn-sm btn-outline-danger delete-blog-btn" data-id="<?php echo $post['id']; ?>">
              <i class="fas fa-trash"></i>
            </button>
          </td>
        </tr>
        <?php endforeach; ?>
      <?php else: ?>
        <tr><td colspan="7"><?php adminEmptyState('কোনো ব্লগ পোস্ট নেই', 'উপরের "নতুন পোস্ট" বাটন থেকে প্রথম পোস্ট তৈরি করুন', 'fa-blog', ['label' => 'নতুন পোস্ট', 'url' => 'index.php?page=add-blog-post', 'icon' => 'fa-plus']); ?></td></tr>
      <?php endif; ?>
    </tbody>
  </table>
  </div>
</div>

<script>
document.querySelectorAll('.delete-blog-btn').forEach(btn => {
    btn.addEventListener('click', function() {
        if(!confirm('Are you sure you want to delete this post?')) return;
        const id = this.dataset.id;
        fetch(`actions/blog-post-delete.php?id=${id}`)
            .then(res => res.json())
            .then(data => {
                if(data.status === 'success') {
                    document.getElementById(`blog-row-${id}`).remove();
                    alert(data.message);
                } else {
                    alert(data.message);
                }
            });
    });
});
</script>
