<?php
// admin/pages/profile.php
$email = $_SESSION['admin_email'];
$stmt = $pdo->prepare("SELECT * FROM admins WHERE email = ?");
$stmt->execute([$email]);
$admin = $stmt->fetch();

// Count admin stats
$admin_role = $admin['role'];
$joined_date = date('d M, Y', strtotime($admin['created_at']));
$days_active = floor((time() - strtotime($admin['created_at'])) / 86400);
?>

<?php adminFlashMessages(); ?>
<?php adminPageHeader('আমার প্রোফাইল', 'অ্যাকাউন্ট সেটিংস ও পাসওয়ার্ড আপডেট করুন'); ?>

<div class="profile-page-v2 animate__animated animate__fadeIn">
    <div class="row g-4">
        <!-- Left: Profile Card -->
        <div class="col-lg-4">
            <div class="admin-list-shell h-100">
                <!-- Profile Cover -->
                <div class="profile-cover position-relative">
                    <div class="profile-cover-bg"></div>
                    <div class="text-center position-relative" style="padding-top: 40px; padding-bottom: 20px;">
                        <div class="profile-avatar-wrapper mx-auto mb-3">
                            <img src="https://ui-avatars.com/api/?name=<?php echo urlencode($admin['name']); ?>&size=120&background=15803d&color=fff&bold=true&font-size=0.4" 
                                 alt="<?php echo htmlspecialchars($admin['name']); ?>" 
                                 class="profile-avatar">
                            <div class="profile-avatar-badge">
                                <i class="fas fa-shield-alt"></i>
                            </div>
                        </div>
                        <h4 class="fw-bold text-white mb-1"><?php echo htmlspecialchars($admin['name']); ?></h4>
                        <span class="badge bg-white bg-opacity-25 text-white rounded-pill px-3 py-1">
                            <i class="fas fa-crown me-1" style="font-size: 0.65rem;"></i>
                            <?php echo ucwords(str_replace('_', ' ', $admin_role)); ?>
                        </span>
                    </div>
                </div>

                <!-- Profile Info -->
                <div class="p-4">
                    <div class="profile-info-item">
                        <div class="d-flex align-items-center gap-3">
                            <div class="profile-info-icon bg-blue-50">
                                <i class="fas fa-envelope text-primary"></i>
                            </div>
                            <div>
                                <div class="text-muted small">Email Address</div>
                                <div class="fw-600 text-slate-800"><?php echo htmlspecialchars($admin['email']); ?></div>
                            </div>
                        </div>
                    </div>

                    <div class="profile-info-item">
                        <div class="d-flex align-items-center gap-3">
                            <div class="profile-info-icon bg-emerald-50">
                                <i class="fas fa-calendar-alt text-success"></i>
                            </div>
                            <div>
                                <div class="text-muted small">Member Since</div>
                                <div class="fw-600 text-slate-800"><?php echo $joined_date; ?></div>
                            </div>
                        </div>
                    </div>

                    <div class="profile-info-item">
                        <div class="d-flex align-items-center gap-3">
                            <div class="profile-info-icon bg-amber-50">
                                <i class="fas fa-clock text-warning"></i>
                            </div>
                            <div>
                                <div class="text-muted small">Days Active</div>
                                <div class="fw-600 text-slate-800"><?php echo $days_active; ?> days</div>
                            </div>
                        </div>
                    </div>

                    <div class="profile-info-item border-0 pb-0 mb-0">
                        <div class="d-flex align-items-center gap-3">
                            <div class="profile-info-icon" style="background:#f0fdf4;">
                                <i class="fas fa-user-tag text-success"></i>
                            </div>
                            <div>
                                <div class="text-muted small">Account Role</div>
                                <div class="fw-600 text-slate-800"><?php echo ucwords(str_replace('_', ' ', $admin_role)); ?></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Right: Edit Forms -->
        <div class="col-lg-8">
            <!-- Personal Information -->
            <div class="admin-list-shell mb-4">
                <div class="admin-list-shell-header">
                    <div class="d-flex align-items-center gap-3">
                        <div class="admin-panel-icon green"><i class="fas fa-user-edit"></i></div>
                        <div>
                            <h2 class="admin-list-shell-title mb-0">Personal Information</h2>
                            <p class="text-muted small mb-0">Update your name and personal details</p>
                        </div>
                    </div>
                </div>
                <div class="p-4">
                <form action="actions/profile-update.php" method="POST" id="profile-form">
                    <div class="row g-3">
                        <div class="col-md-6">
                            <label class="form-label fw-600 text-slate-700 small">Full Name <span class="text-danger">*</span></label>
                            <div class="input-group-modern">
                                <i class="fas fa-user input-icon"></i>
                                <input type="text" name="name" class="form-control form-control-modern" 
                                       value="<?php echo htmlspecialchars($admin['name']); ?>" required 
                                       placeholder="Enter your full name">
                            </div>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label fw-600 text-slate-700 small">Email Address</label>
                            <div class="input-group-modern">
                                <i class="fas fa-envelope input-icon"></i>
                                <input type="email" class="form-control form-control-modern" 
                                       value="<?php echo htmlspecialchars($admin['email']); ?>" readonly disabled>
                            </div>
                            <small class="text-muted"><i class="fas fa-lock me-1" style="font-size:0.6rem;"></i>Email cannot be changed for security</small>
                        </div>
                    </div>

                    <div class="d-flex justify-content-end mt-4">
                        <button type="submit" name="update_info" class="btn btn-primary rounded-3 px-4">
                            <i class="fas fa-save me-2"></i>Save Changes
                        </button>
                    </div>
                </form>
                </div>
            </div>

            <!-- Security / Password -->
            <div class="admin-list-shell">
                <div class="admin-list-shell-header">
                    <div class="d-flex align-items-center gap-3">
                        <div class="admin-panel-icon red"><i class="fas fa-shield-alt"></i></div>
                        <div>
                            <h2 class="admin-list-shell-title mb-0">Security Settings</h2>
                            <p class="text-muted small mb-0">Update your password to keep your account secure</p>
                        </div>
                    </div>
                </div>
                <div class="p-4">
                <form action="actions/profile-update.php" method="POST" id="password-form">
                    <!-- Hidden name field to keep the action handler compatible -->
                    <input type="hidden" name="name" value="<?php echo htmlspecialchars($admin['name']); ?>">
                    
                    <div class="row g-3">
                        <div class="col-md-6">
                            <label class="form-label fw-600 text-slate-700 small">New Password</label>
                            <div class="input-group-modern">
                                <i class="fas fa-lock input-icon"></i>
                                <input type="password" name="password" id="new-password" class="form-control form-control-modern" 
                                       placeholder="Enter new password" minlength="6">
                                <button type="button" class="password-toggle" onclick="togglePassword('new-password', this)">
                                    <i class="fas fa-eye"></i>
                                </button>
                            </div>
                            <div class="password-strength mt-2" id="password-strength" style="display:none;">
                                <div class="d-flex gap-1 mb-1">
                                    <div class="strength-bar" id="str-1"></div>
                                    <div class="strength-bar" id="str-2"></div>
                                    <div class="strength-bar" id="str-3"></div>
                                    <div class="strength-bar" id="str-4"></div>
                                </div>
                                <small class="text-muted" id="strength-text">Enter a password</small>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label fw-600 text-slate-700 small">Confirm New Password</label>
                            <div class="input-group-modern">
                                <i class="fas fa-lock input-icon"></i>
                                <input type="password" name="confirm_password" id="confirm-password" class="form-control form-control-modern" 
                                       placeholder="Confirm new password">
                                <button type="button" class="password-toggle" onclick="togglePassword('confirm-password', this)">
                                    <i class="fas fa-eye"></i>
                                </button>
                            </div>
                            <small class="text-muted password-match-msg" id="password-match" style="display:none;"></small>
                        </div>
                    </div>

                    <div class="d-flex justify-content-end mt-4">
                        <button type="submit" name="update_password" class="btn btn-danger rounded-3 px-4">
                            <i class="fas fa-key me-2"></i>Update Password
                        </button>
                    </div>
                </form>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
/* Profile Page Styles */
.profile-cover-bg {
    position: absolute;
    top: 0; left: 0; right: 0; bottom: 0;
    background: linear-gradient(135deg, #15803d 0%, #166534 50%, #14532d 100%);
}
.profile-cover { position: relative; }

.profile-avatar-wrapper {
    position: relative;
    width: 110px;
    height: 110px;
}
.profile-avatar {
    width: 110px;
    height: 110px;
    border-radius: 50%;
    border: 4px solid rgba(255,255,255,0.3);
    box-shadow: 0 8px 32px rgba(0,0,0,0.2);
    object-fit: cover;
}
.profile-avatar-badge {
    position: absolute;
    bottom: 4px;
    right: 4px;
    width: 30px;
    height: 30px;
    background: #10b981;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    border: 3px solid #fff;
    color: #fff;
    font-size: 0.65rem;
    box-shadow: 0 2px 8px rgba(16, 185, 129, 0.3);
}

.profile-info-item {
    padding: 14px 0;
    border-bottom: 1px solid #f1f5f9;
    margin-bottom: 2px;
}
.profile-info-icon {
    width: 40px;
    height: 40px;
    border-radius: 12px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 0.85rem;
    min-width: 40px;
}
.bg-blue-50 { background: #eff6ff; }
.bg-emerald-50 { background: #ecfdf5; }
.bg-amber-50 { background: #fffbeb; }
.bg-purple-50 { background: #f5f3ff; }
.text-purple { color: #8b5cf6; }

/* Form Styling */
.form-section-icon {
    width: 44px;
    height: 44px;
    border-radius: 14px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 1rem;
    min-width: 44px;
}

.input-group-modern {
    position: relative;
}
.input-group-modern .input-icon {
    position: absolute;
    left: 14px;
    top: 50%;
    transform: translateY(-50%);
    color: #94a3b8;
    font-size: 0.8rem;
    z-index: 5;
    pointer-events: none;
}
.form-control-modern {
    padding: 12px 14px 12px 40px;
    border-radius: 12px;
    border: 1.5px solid #e2e8f0;
    background: #f8fafc;
    font-size: 0.9rem;
    transition: all 0.25s ease;
}
.form-control-modern:focus {
    border-color: #15803d;
    background: #fff;
    box-shadow: 0 0 0 4px rgba(21, 128, 61, 0.08);
}
.form-control-modern:disabled, .form-control-modern[readonly] {
    background: #f1f5f9;
    color: #94a3b8;
}

.password-toggle {
    position: absolute;
    right: 12px;
    top: 50%;
    transform: translateY(-50%);
    border: none;
    background: none;
    color: #94a3b8;
    cursor: pointer;
    padding: 4px;
    z-index: 5;
    transition: color 0.2s;
}
.password-toggle:hover { color: #15803d; }

.password-strength .strength-bar {
    height: 4px;
    border-radius: 2px;
    background: #e2e8f0;
    flex: 1;
    transition: background 0.3s;
}

/* Responsive */
@media (max-width: 991px) {
    .profile-cover-bg { border-radius: 0; }
}
</style>

<script>
// Toggle password visibility
function togglePassword(inputId, btn) {
    const input = document.getElementById(inputId);
    const icon = btn.querySelector('i');
    if (input.type === 'password') {
        input.type = 'text';
        icon.classList.replace('fa-eye', 'fa-eye-slash');
    } else {
        input.type = 'password';
        icon.classList.replace('fa-eye-slash', 'fa-eye');
    }
}

// Password strength indicator
const newPasswordInput = document.getElementById('new-password');
const confirmPasswordInput = document.getElementById('confirm-password');
const strengthDisplay = document.getElementById('password-strength');
const strengthText = document.getElementById('strength-text');
const matchMsg = document.getElementById('password-match');

if (newPasswordInput) {
    newPasswordInput.addEventListener('input', function() {
        const val = this.value;
        if (val.length === 0) {
            strengthDisplay.style.display = 'none';
            return;
        }
        strengthDisplay.style.display = 'block';

        let score = 0;
        if (val.length >= 6) score++;
        if (val.length >= 8) score++;
        if (/[A-Z]/.test(val) && /[0-9]/.test(val)) score++;
        if (/[^A-Za-z0-9]/.test(val)) score++;

        const colors = ['#ef4444', '#f59e0b', '#3b82f6', '#10b981'];
        const labels = ['Weak', 'Fair', 'Good', 'Strong'];
        
        for (let i = 1; i <= 4; i++) {
            document.getElementById('str-' + i).style.background = i <= score ? colors[score - 1] : '#e2e8f0';
        }
        strengthText.textContent = labels[score - 1] || 'Too short';
        strengthText.style.color = colors[score - 1] || '#94a3b8';
        
        checkMatch();
    });
}

if (confirmPasswordInput) {
    confirmPasswordInput.addEventListener('input', checkMatch);
}

function checkMatch() {
    const p1 = document.getElementById('new-password').value;
    const p2 = document.getElementById('confirm-password').value;
    if (p2.length === 0) {
        matchMsg.style.display = 'none';
        return;
    }
    matchMsg.style.display = 'inline';
    if (p1 === p2) {
        matchMsg.innerHTML = '<i class="fas fa-check-circle text-success me-1"></i>Passwords match';
        matchMsg.className = 'password-match-msg text-success small';
    } else {
        matchMsg.innerHTML = '<i class="fas fa-times-circle text-danger me-1"></i>Passwords do not match';
        matchMsg.className = 'password-match-msg text-danger small';
    }
}
</script>
