<?php
/**
 * Admin - Add Landing Page
 */

$products_stmt = $pdo->query("SELECT id, name, image FROM products WHERE status = 1 ORDER BY name ASC");
$products = $products_stmt->fetchAll(PDO::FETCH_ASSOC);

$zones_stmt = $pdo->query("SELECT id, name, charge FROM shipping_zones WHERE status = 1 ORDER BY charge ASC");
$shipping_zones = $zones_stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<?php adminFlashMessages(); ?>
<?php adminPageHeader('নতুন Landing Page', 'প্রোডাক্টের জন্য ডেডিকেটেড ল্যান্ডিং পেজ তৈরি করুন', [
    ['label' => 'ল্যান্ডিং পেজ তালিকা', 'icon' => 'fa-arrow-left', 'url' => 'index.php?page=landing-pages', 'class' => 'btn btn-outline-secondary btn-sm'],
]); ?>

<form action="actions/landing-page-save.php" method="POST" enctype="multipart/form-data" class="settings-form">
    <div class="settings-layout admin-shell" data-panel-prefix="lp">
        <nav class="settings-tabs admin-tabs" aria-label="Landing page sections">
            <div class="settings-tabs-track admin-tabs-track" role="tablist">
                <a href="#lp-hero" class="settings-tab admin-tab active" data-admin-nav="hero" role="tab" aria-selected="true">
                    <i class="fas fa-star"></i><span>Hero</span>
                </a>
                <a href="#lp-products" class="settings-tab admin-tab" data-admin-nav="products" role="tab" aria-selected="false">
                    <i class="fas fa-box"></i><span>Products</span>
                </a>
                <a href="#lp-shipping" class="settings-tab admin-tab" data-admin-nav="shipping" role="tab" aria-selected="false">
                    <i class="fas fa-truck"></i><span>Shipping</span>
                </a>
                <a href="#lp-content" class="settings-tab admin-tab" data-admin-nav="content" role="tab" aria-selected="false">
                    <i class="fas fa-file-alt"></i><span>Content / SEO</span>
                </a>
                <a href="#lp-custom" class="settings-tab admin-tab" data-admin-nav="custom" role="tab" aria-selected="false">
                    <i class="fas fa-code"></i><span>Custom</span>
                </a>
            </div>
        </nav>

        <div class="settings-content">
            <section class="settings-panel admin-panel is-active" id="lp-hero" role="tabpanel">
                <?php adminPanelHeader('Hero Section', 'হিরো টাইটেল, সাবটাইটেল, ইমেজ ও ভিডিও', 'fa-star', 'amber'); ?>
                <div class="settings-panel-body admin-panel-body">
                    <div class="mb-3">
                        <label class="form-label fw-bold">হিরো টাইটেল</label>
                        <input type="text" name="hero_title" class="form-control form-control-lg"
                               placeholder="পেজের মূল শিরোনাম (খালি থাকলে প্রোডাক্টের নাম ব্যবহার হবে)">
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-bold">হিরো সাবটাইটেল</label>
                        <textarea name="hero_subtitle" class="form-control" rows="3"
                                  placeholder="প্রোডাক্টের সংক্ষিপ্ত বিবরণ বা আকর্ষণীয় লাইন"></textarea>
                    </div>
                    <div class="row g-3 mb-3">
                        <div class="col-md-6">
                            <label class="form-label fw-bold">হিরো ইমেজ</label>
                            <input type="file" name="hero_image" class="form-control" accept="image/*">
                            <small class="text-muted">খালি থাকলে প্রোডাক্টের ইমেজ ব্যবহার হবে</small>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label fw-bold">ভিডিও URL</label>
                            <input type="url" name="hero_video_url" class="form-control"
                                   placeholder="https://youtube.com/watch?v=...">
                        </div>
                    </div>
                    <div class="mb-0">
                        <label class="form-label fw-bold">CTA বাটন টেক্সট</label>
                        <input type="text" name="cta_text" class="form-control"
                               value="এখনই অর্ডার করুন" placeholder="বাটনের টেক্সট">
                    </div>
                </div>
            </section>

            <section class="settings-panel admin-panel" id="lp-products" role="tabpanel" hidden>
                <?php adminPanelHeader('Products', 'প্রধান ও অতিরিক্ত প্রোডাক্ট নির্বাচন', 'fa-box', 'green'); ?>
                <div class="settings-panel-body admin-panel-body">
                    <div class="mb-4">
                        <label class="form-label fw-bold">প্রধান প্রোডাক্ট নির্বাচন করুন *</label>
                        <select name="product_id" class="form-select form-select-lg" required>
                            <option value="">-- প্রোডাক্ট নির্বাচন করুন --</option>
                            <?php foreach($products as $product): ?>
                            <option value="<?php echo $product['id']; ?>"><?php echo htmlspecialchars($product['name']); ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="mb-0">
                        <label class="form-label fw-bold">অতিরিক্ত প্রোডাক্ট সমূহ (ঐচ্ছিক)</label>
                        <div class="border rounded-3 p-3 bg-light" style="max-height: 280px; overflow-y: auto;">
                            <input type="text" id="product_search" class="form-control form-control-sm mb-2" placeholder="প্রোডাক্ট খুঁজুন...">
                            <div class="product-checkbox-list">
                                <?php foreach($products as $product): ?>
                                <div class="form-check product-checkbox-item mb-2" data-name="<?php echo htmlspecialchars(strtolower($product['name'])); ?>">
                                    <input class="form-check-input" type="checkbox" name="product_ids[]" value="<?php echo $product['id']; ?>" id="product_<?php echo $product['id']; ?>">
                                    <label class="form-check-label small" for="product_<?php echo $product['id']; ?>">
                                        <?php echo htmlspecialchars($product['name']); ?>
                                    </label>
                                </div>
                                <?php endforeach; ?>
                            </div>
                        </div>
                        <small class="text-muted">চেক করা প্রোডাক্টগুলো ল্যান্ডিং পেজের অর্ডার ফর্মে কাস্টমারদের নির্বাচনের জন্য প্রদর্শন করা হবে।</small>
                    </div>
                </div>
            </section>

            <section class="settings-panel admin-panel" id="lp-shipping" role="tabpanel" hidden>
                <?php adminPanelHeader('Shipping', 'ডেলিভারি এলাকা ও কাস্টম চার্জ', 'fa-truck', 'green'); ?>
                <div class="settings-panel-body admin-panel-body">
                    <p class="text-muted small">ল্যান্ডিং পেজে যে এরিয়াগুলো রাখতে চান তা চেক করুন। এরিয়ার কাস্টম চার্জ দিতে চাইলে তা টাইপ করুন (ফাঁকা রাখলে গ্লোবাল চার্জ ব্যবহার হবে)।</p>
                    <div class="shipping-zones-config-list d-flex flex-column gap-3">
                        <?php foreach ($shipping_zones as $zone): ?>
                        <div class="shipping-zone-config-item border rounded-3 p-3 bg-light">
                            <div class="form-check d-flex justify-content-between align-items-center mb-1">
                                <div>
                                    <input class="form-check-input" type="checkbox" name="shipping_zones[<?php echo $zone['id']; ?>][enabled]" value="1" id="sz_<?php echo $zone['id']; ?>" checked>
                                    <label class="form-check-label small fw-bold" for="sz_<?php echo $zone['id']; ?>">
                                        <?php echo htmlspecialchars($zone['name']); ?>
                                    </label>
                                </div>
                            </div>
                            <div class="input-group input-group-sm mt-1">
                                <span class="input-group-text bg-white text-muted">কাস্টম চার্জ ৳</span>
                                <input type="number" step="0.01" name="shipping_zones[<?php echo $zone['id']; ?>][charge]" class="form-control" placeholder="<?php echo number_format($zone['charge'], 0); ?>">
                            </div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            </section>

            <section class="settings-panel admin-panel" id="lp-content" role="tabpanel" hidden>
                <?php adminPanelHeader('Content / SEO', 'পেজ তথ্য, বেনিফিটস, ট্রাস্ট ও পাবলিশ', 'fa-file-alt', 'blue'); ?>
                <div class="settings-panel-body admin-panel-body">
                    <div class="mb-3">
                        <label class="form-label fw-bold">টেমপ্লেট টাইপ *</label>
                        <div class="d-flex gap-3">
                            <div class="form-check">
                                <input class="form-check-input" type="radio" name="template_type" id="template_default" value="default" checked onchange="toggleTemplateType()">
                                <label class="form-check-label fw-bold" for="template_default">
                                    <i class="fas fa-layer-group text-primary me-1"></i> ডিফল্ট ডিজাইন
                                </label>
                            </div>
                            <div class="form-check">
                                <input class="form-check-input" type="radio" name="template_type" id="template_custom" value="custom" onchange="toggleTemplateType()">
                                <label class="form-check-label fw-bold text-success" for="template_custom">
                                    <i class="fas fa-code me-1"></i> কাস্টম কোড (HTML/JS)
                                </label>
                            </div>
                        </div>
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-bold">পেজ টাইটেল *</label>
                        <input type="text" name="page_title" class="form-control form-control-lg"
                               placeholder="যেমন: প্রিমিয়াম মধু - সীমিত সময়ের অফার" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-bold">স্লাগ (URL) *</label>
                        <div class="input-group input-group-lg">
                            <span class="input-group-text bg-light">/lp/</span>
                            <input type="text" name="slug" class="form-control"
                                   placeholder="premium-honey-offer" required pattern="[a-z0-9-]+">
                        </div>
                        <small class="text-muted">শুধুমাত্র ছোট হাতের অক্ষর, সংখ্যা এবং হাইফেন (-) ব্যবহার করুন</small>
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-bold">মেটা ডেসক্রিপশন (SEO)</label>
                        <textarea name="meta_description" class="form-control" rows="3"
                                  placeholder="সার্চ ইঞ্জিনের জন্য পেজের সংক্ষিপ্ত বিবরণ"></textarea>
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-bold">স্ট্যাটাস</label>
                        <select name="status" class="form-select">
                            <option value="1">Active (পাবলিশ)</option>
                            <option value="0">Inactive (ড্রাফট)</option>
                        </select>
                    </div>

                    <div id="default_sections">
                        <hr class="my-4">
                        <div class="mb-3">
                            <label class="form-label fw-bold">বেনিফিটস টাইটেল</label>
                            <input type="text" name="benefits_title" class="form-control"
                                   value="এই প্রোডাক্টের উপকারিতা" placeholder="সেকশনের শিরোনাম">
                        </div>
                        <div class="mb-3">
                            <label class="form-label fw-bold">বেনিফিটস কন্টেন্ট</label>
                            <textarea name="benefits_content" class="form-control" rows="5"
                                      placeholder="✅ প্রতিটি লাইনে একটি করে বেনিফিট লিখুন&#10;✅ ইমোজি ব্যবহার করতে পারেন"></textarea>
                            <small class="text-muted">খালি থাকলে প্রোডাক্টের বেনিফিটস ব্যবহার হবে</small>
                        </div>
                        <div class="mb-3">
                            <label class="form-label fw-bold">ট্রাস্ট টাইটেল</label>
                            <input type="text" name="trust_title" class="form-control"
                                   value="কেন আমাদের থেকে নিবেন?" placeholder="সেকশনের শিরোনাম">
                        </div>
                        <div class="mb-0">
                            <label class="form-label fw-bold">ট্রাস্ট কন্টেন্ট</label>
                            <textarea name="trust_content" class="form-control" rows="5"
                                      placeholder="🍃 সারাদেশে হোম ডেলিভারি&#10;🍃 সঠিক মাপ ও ওজনের নিশ্চয়তা"></textarea>
                            <small class="text-muted">খালি থাকলে প্রোডাক্টের ট্রাস্ট পয়েন্টস ব্যবহার হবে</small>
                        </div>
                    </div>
                </div>
            </section>

            <section class="settings-panel admin-panel" id="lp-custom" role="tabpanel" hidden>
                <?php adminPanelHeader('Custom Code', 'কাস্টম HTML, JS ও CSS', 'fa-code', 'sky'); ?>
                <div class="settings-panel-body admin-panel-body">
                    <div id="custom_sections">
                        <p class="text-muted small mb-3">অর্ডার ফর্ম দেখাতে চাইলে আপনার HTML কোডের যেকোনো জায়গায় <code>[checkout_form]</code> লিখুন।</p>
                        <div class="mb-3">
                            <label class="form-label fw-bold">Custom HTML</label>
                            <textarea name="custom_html" class="form-control font-monospace" rows="15"
                                      placeholder="<section class='my-custom-section'>&#10;  <h1>Hello World</h1>&#10;  <!-- Checkout Form placeholder -->&#10;  [checkout_form]&#10;</section>"></textarea>
                        </div>
                        <div class="mb-3">
                            <label class="form-label fw-bold">Custom JS (Optional)</label>
                            <textarea name="custom_js" class="form-control font-monospace" rows="8"
                                      placeholder="console.log('Custom landing page initialized');"></textarea>
                            <small class="text-muted">No &lt;script&gt; tags needed, just write raw JS.</small>
                        </div>
                    </div>
                    <div class="mb-0">
                        <label class="form-label fw-bold">কাস্টম CSS</label>
                        <textarea name="custom_css" class="form-control font-monospace" rows="6"
                                  placeholder=".hero-section { background: #custom; }"></textarea>
                        <small class="text-muted">অ্যাডভান্সড ইউজারদের জন্য</small>
                    </div>
                </div>
            </section>
        </div>

        <?php adminSaveBar('সেভ করুন'); ?>
    </div>
</form>

<script>
function toggleTemplateType() {
    const isCustom = document.getElementById('template_custom').checked;
    const defaultSections = document.getElementById('default_sections');
    if (defaultSections) {
        defaultSections.style.display = isCustom ? 'none' : 'block';
    }
}
document.getElementById('product_search')?.addEventListener('input', function(e) {
    const searchVal = e.target.value.toLowerCase();
    document.querySelectorAll('.product-checkbox-item').forEach(item => {
        const name = item.getAttribute('data-name');
        item.style.setProperty('display', name.includes(searchVal) ? 'block' : 'none', 'important');
    });
});
document.addEventListener('DOMContentLoaded', toggleTemplateType);
</script>
