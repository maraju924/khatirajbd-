<?php
// admin/pages/insights.php
try {
    // 1. Core Summary Metrics
    $revenue = $pdo->query("SELECT SUM(total_amount) FROM orders WHERE payment_status = 'Paid'")->fetchColumn() ?: 0;
    $totalOrders = $pdo->query("SELECT COUNT(*) FROM orders")->fetchColumn() ?: 0;
    $totalUsers = $pdo->query("SELECT COUNT(*) FROM users")->fetchColumn() ?: 0;
    $todayOrders = $pdo->query("SELECT COUNT(*) FROM orders WHERE DATE(created_at) = CURDATE()")->fetchColumn() ?: 0;
    
    // Activity and tracking logs removed
    $todayVisitors = 0;
    $todayATC = 0;
    
    // Returning Customer %
    $totalPurchasers = $pdo->query("SELECT COUNT(DISTINCT user_id) FROM orders WHERE user_id IS NOT NULL")->fetchColumn() ?: 1;
    $returningPurchasers = $pdo->query("SELECT COUNT(*) FROM (SELECT user_id FROM orders WHERE user_id IS NOT NULL GROUP BY user_id HAVING COUNT(*) > 1) as t")->fetchColumn() ?: 0;
    $returningPerc = round(($returningPurchasers / $totalPurchasers) * 100);

    // 2. Conversion & Distribution
    $convRate = 0;
    
    $codCount = $pdo->query("SELECT COUNT(*) FROM orders WHERE payment_method = 'COD'")->fetchColumn() ?: 0;
    $onlineCount = $totalOrders - $codCount;
    $codPerc = ($totalOrders > 0) ? round(($codCount / $totalOrders) * 100) : 0;
    
    // 3. Funnel Metrics (Last 30 Days) - Removed
    $funnel = [
        'PageView' => 0,
        'ViewContent' => 0,
        'AddToCart' => 0,
        'InitiateCheckout' => 0,
        'Purchase' => 0,
    ];

    // 4. Communication Clicks - Removed
    $commClicks = [];

    // 5. Traffic Sources - Removed
    $sources = [];

    // 6. Risk: Multi-order IPs
    $riskyIPs = $pdo->query("SELECT ip_address, COUNT(*) as order_count FROM orders GROUP BY ip_address HAVING order_count > 3 ORDER BY order_count DESC LIMIT 5")->fetchAll();

} catch (PDOException $e) {
    $insights_error = $e->getMessage();
}
?>

<?php adminFlashMessages(); ?>
<?php if (!empty($insights_error)): ?>
    <div class="admin-flash error"><i class="fas fa-exclamation-circle"></i> <?php echo htmlspecialchars($insights_error); ?></div>
<?php endif; ?>
<?php adminPageHeader('Business Insights', 'বিজনেস অ্যানালিটিক্স ও পারফরম্যান্স মেট্রিক্স', [
    ['label' => 'Last 30 Days', 'icon' => 'fa-calendar', 'url' => '#', 'class' => 'btn btn-outline-secondary btn-sm'],
]); ?>

<!-- 1. Top Summary Row -->
<div class="admin-kpi-row row g-3">
    <div class="col-md-4"><?php adminStatCard('Today Orders', number_format($todayOrders), 'fa-receipt', 'green'); ?></div>
    <div class="col-md-4"><?php adminStatCard('Returning Customers', $returningPerc . '%', 'fa-users', 'blue'); ?></div>
    <div class="col-md-4"><?php adminStatCard('Total Revenue', '৳' . number_format($revenue), 'fa-wallet', 'amber'); ?></div>
</div>

<div class="row g-4 mb-4">
    <div class="col-lg-4">
        <div class="admin-list-shell h-100">
            <div class="admin-list-shell-header">
                <h2 class="admin-list-shell-title">Payment Distribution</h2>
            </div>
            <div class="p-4">
                <div class="d-flex align-items-center mb-3">
                    <div class="flex-grow-1">
                        <div class="d-flex justify-content-between mb-1">
                            <span class="small">Cash on Delivery (COD)</span>
                            <span class="small fw-bold"><?php echo $codPerc; ?>%</span>
                        </div>
                        <div class="progress rounded-pill" style="height: 8px;">
                            <div class="progress-bar bg-success" style="width: <?php echo $codPerc; ?>%"></div>
                        </div>
                    </div>
                </div>
                <div class="d-flex align-items-center">
                    <div class="flex-grow-1">
                        <div class="d-flex justify-content-between mb-1">
                            <span class="small">Online Payment</span>
                            <span class="small fw-bold"><?php echo (100 - $codPerc); ?>%</span>
                        </div>
                        <div class="progress rounded-pill" style="height: 8px;">
                            <div class="progress-bar bg-primary" style="width: <?php echo (100 - $codPerc); ?>%"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="col-lg-4">
        <div class="admin-list-shell h-100">
            <div class="admin-list-shell-header">
                <h2 class="admin-list-shell-title text-danger">Risk & Fraud Alert</h2>
            </div>
            <div class="p-4">
                <h6 class="small fw-bold text-muted mb-3">Multi-Order IPs (Potential Scam)</h6>
                <?php if (empty($riskyIPs)): ?>
                    <p class="small text-success mb-0"><i class="fas fa-check-circle me-1"></i> No high-risk patterns detected.</p>
                <?php else: ?>
                    <div class="list-group list-group-flush">
                        <?php foreach ($riskyIPs as $rip): ?>
                        <div class="list-group-item px-0 border-0 d-flex justify-content-between small">
                            <code><?php echo htmlspecialchars($rip['ip_address']); ?></code>
                            <span class="badge bg-danger"><?php echo $rip['order_count']; ?> Orders</span>
                        </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <div class="col-lg-4">
        <div class="admin-list-shell h-100">
            <div class="admin-list-shell-header">
                <h2 class="admin-list-shell-title">Customer Strategy</h2>
            </div>
            <div class="p-4">
                <div class="mb-3 p-3 rounded-3" style="background:#eff6ff;">
                    <div class="fw-bold text-primary">VIP Segment</div>
                    <div class="small text-muted">Customer with &gt;5,000 BDT spent.</div>
                </div>
                <div class="p-3 rounded-3" style="background:#f0fdf4;">
                    <div class="fw-bold text-success">Loyal Segment</div>
                    <div class="small text-muted">Multiple repeat orders.</div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="admin-list-shell mb-4">
    <div class="admin-list-shell-header">
        <h2 class="admin-list-shell-title">Sales & Orders Trend (Last 30 Days)</h2>
    </div>
    <div class="p-4">
        <div style="height: 300px;">
            <canvas id="insightsTrendChart"></canvas>
        </div>
    </div>
</div>

<?php
// Fetch trend data for the last 30 days
$trendData = $pdo->query("
    SELECT 
        DATE_FORMAT(d.date, '%d %b') as date_label,
        COALESCE(SUM(o.total_amount), 0) as revenue,
        COALESCE(COUNT(o.id), 0) as orders
    FROM (
        SELECT CURDATE() - INTERVAL (a.a + (10 * b.a)) DAY AS date
        FROM (SELECT 0 AS a UNION ALL SELECT 1 UNION ALL SELECT 2 UNION ALL SELECT 3 UNION ALL SELECT 4 UNION ALL SELECT 5 UNION ALL SELECT 6 UNION ALL SELECT 7 UNION ALL SELECT 8 UNION ALL SELECT 9) AS a
        CROSS JOIN (SELECT 0 AS a UNION ALL SELECT 1 UNION ALL SELECT 2 UNION ALL SELECT 3) AS b
    ) d
    LEFT JOIN orders o ON DATE(o.created_at) = d.date AND o.order_status != 'Cancelled'
    WHERE d.date BETWEEN DATE_SUB(CURDATE(), INTERVAL 29 DAY) AND CURDATE()
    GROUP BY d.date
    ORDER BY d.date ASC
")->fetchAll();

$trendLabels = json_encode(array_column($trendData, 'date_label'));
$trendRevenue = json_encode(array_column($trendData, 'revenue'));
$trendOrders = json_encode(array_column($trendData, 'orders'));
?>

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
(function() {
    const ctx = document.getElementById('insightsTrendChart').getContext('2d');
    new Chart(ctx, {
        type: 'line',
        data: {
            labels: <?php echo $trendLabels; ?>,
            datasets: [
                {
                    label: 'Revenue (৳)',
                    data: <?php echo $trendRevenue; ?>,
                    borderColor: '#3b82f6',
                    backgroundColor: 'rgba(59, 130, 246, 0.1)',
                    fill: true,
                    tension: 0.4,
                    yAxisID: 'y'
                },
                {
                    label: 'Orders',
                    data: <?php echo $trendOrders; ?>,
                    borderColor: '#10b981',
                    backgroundColor: 'transparent',
                    borderDash: [5, 5],
                    tension: 0.4,
                    yAxisID: 'y1'
                }
            ]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                y: { type: 'linear', display: true, position: 'left', title: { display: true, text: 'Revenue' } },
                y1: { type: 'linear', display: true, position: 'right', grid: { drawOnChartArea: false }, title: { display: true, text: 'Orders' } }
            }
        }
    });
})();
</script>
