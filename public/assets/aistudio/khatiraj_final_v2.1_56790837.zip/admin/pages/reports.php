<?php
// admin/pages/reports.php

// Date Filtering Logic
// Date Filtering Logic
$start_date = $_GET['start_date'] ?? date('Y-01-01'); // Default to beginning of the year
$end_date = $_GET['end_date'] ?? date('Y-m-d');

try {
    // 1. Sales Summary by Period (Static Metrics - All non-cancelled orders for better visibility)
    $todaySales = $pdo->query("SELECT SUM(total_amount) FROM orders WHERE order_status != 'Cancelled' AND DATE(created_at) = CURDATE()")->fetchColumn() ?: 0;
    $yesterdaySales = $pdo->query("SELECT SUM(total_amount) FROM orders WHERE order_status != 'Cancelled' AND DATE(created_at) = CURDATE() - INTERVAL 1 DAY")->fetchColumn() ?: 0;
    $last7DaysSales = $pdo->query("SELECT SUM(total_amount) FROM orders WHERE order_status != 'Cancelled' AND created_at >= CURDATE() - INTERVAL 7 DAY")->fetchColumn() ?: 0;
    $thisMonthSales = $pdo->query("SELECT SUM(total_amount) FROM orders WHERE order_status != 'Cancelled' AND MONTH(created_at) = MONTH(CURDATE()) AND YEAR(created_at) = YEAR(CURDATE())")->fetchColumn() ?: 0;

    // 2. Filtered Metrics (Based on selected dates)
    $stmt_filtered = $pdo->prepare("SELECT SUM(total_amount) as total, COUNT(*) as count FROM orders WHERE order_status != 'Cancelled' AND DATE(created_at) BETWEEN ? AND ?");
    $stmt_filtered->execute([$start_date, $end_date]);
    $filteredSummary = $stmt_filtered->fetch();
    $totalFilteredRevenue = $filteredSummary['total'] ?: 0;
    $totalFilteredOrders = $filteredSummary['count'] ?: 0;

    // 3. Top Customers by Revenue (Including Guests, grouping by Phone)
    $stmt = $pdo->prepare("
        SELECT 
            COALESCE(u.name, o.customer_name, 'Guest') as name, 
            COALESCE(u.email, 'N/A') as email, 
            o.customer_phone as phone, 
            SUM(o.total_amount) as total_spent, 
            COUNT(o.id) as total_orders
        FROM orders o
        LEFT JOIN users u ON o.user_id = u.id
        WHERE o.order_status != 'Cancelled' AND DATE(o.created_at) BETWEEN ? AND ?
        GROUP BY o.customer_phone
        ORDER BY total_spent DESC
        LIMIT 10
    ");
    $stmt->execute([$start_date, $end_date]);
    $topCustomers = $stmt->fetchAll();

    // 4. RecentOrder(Filtered, all statuses for better visibility)
    $stmt = $pdo->prepare("
        SELECT o.tracking_id, COALESCE(u.name, o.customer_name, 'Guest') as customer_name, o.total_amount, o.order_status, o.created_at, o.payment_status
        FROM orders o
        LEFT JOIN users u ON o.user_id = u.id
        WHERE DATE(o.created_at) BETWEEN ? AND ?
        ORDER BY o.created_at DESC
        LIMIT 15
    ");
    $stmt->execute([$start_date, $end_date]);
    $recentTransactions = $stmt->fetchAll();

} catch (PDOException $e) {
    $reports_error = $e->getMessage();
}
?>

<?php adminFlashMessages(); ?>
<?php if (!empty($reports_error)): ?>
    <div class="admin-flash error"><i class="fas fa-exclamation-circle"></i> <?php echo htmlspecialchars($reports_error); ?></div>
<?php endif; ?>
<?php adminPageHeader('Performance Reports', 'সেলস রিপোর্ট ও গ্রাহক পারফরম্যান্স দেখুন', [
    ['label' => 'Export CSV', 'icon' => 'fa-download', 'url' => 'actions/export-report.php?start_date=' . urlencode($start_date) . '&end_date=' . urlencode($end_date), 'class' => 'btn btn-outline-primary btn-sm', 'data-no-pjax' => true],
]); ?>

<!-- Filter Section -->
<div class="admin-filter-bar">
    <form method="GET" class="admin-filter-form">
        <input type="hidden" name="page" value="reports">
        <div class="admin-filter-row">
            <div class="admin-filter-field">
                <label class="admin-filter-label">Start Date</label>
                <input type="date" name="start_date" class="form-control form-control-sm" value="<?php echo htmlspecialchars($start_date); ?>">
            </div>
            <div class="admin-filter-field">
                <label class="admin-filter-label">End Date</label>
                <input type="date" name="end_date" class="form-control form-control-sm" value="<?php echo htmlspecialchars($end_date); ?>">
            </div>
            <div class="admin-filter-actions">
                <button type="submit" class="btn btn-primary btn-sm fw-semibold"><i class="fas fa-filter me-1"></i>Filter Results</button>
            </div>
        </div>
    </form>
</div>

<div class="admin-kpi-row row g-3">
    <div class="col-md-6"><?php adminStatCard('Filtered Revenue', '৳' . number_format($totalFilteredRevenue), 'fa-wallet', 'green', date('d M', strtotime($start_date)) . ' – ' . date('d M Y', strtotime($end_date))); ?></div>
    <div class="col-md-6"><?php adminStatCard('Filtered Orders', number_format($totalFilteredOrders), 'fa-receipt', 'blue'); ?></div>
</div>

<div class="admin-kpi-row row g-3">
    <div class="col-md-3 col-6"><?php adminStatCard('Sales Today', '৳' . number_format($todaySales), 'fa-calendar-day', 'blue'); ?></div>
    <div class="col-md-3 col-6"><?php adminStatCard('Yesterday', '৳' . number_format($yesterdaySales), 'fa-calendar', 'amber'); ?></div>
    <div class="col-md-3 col-6"><?php adminStatCard('Last 7 Days', '৳' . number_format($last7DaysSales), 'fa-chart-line', 'green'); ?></div>
    <div class="col-md-3 col-6"><?php adminStatCard('This Month', '৳' . number_format($thisMonthSales), 'fa-calendar-alt', 'sky'); ?></div>
</div>

<div class="row g-4 mb-4">
    <div class="col-lg-8">
        <div class="admin-list-shell">
            <div class="admin-list-shell-header">
                <h2 class="admin-list-shell-title">Top Active Customers</h2>
            </div>
            <div class="admin-table-wrap">
                    <table class="admin-table admin-table-mobile-cards">
                        <thead>
                            <tr>
                                <th scope="col">Customer</th>
                                <th scope="col">Orders</th>
                                <th scope="col" class="text-end">Total Spent</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (empty($topCustomers)): ?>
                                <tr><td colspan="3"><?php adminEmptyState('কোনো ডেটা নেই', 'নির্বাচিত তারিখে গ্রাহক ডেটা পাওয়া যায়নি', 'fa-users'); ?></td></tr>
                            <?php else: ?>
                                <?php foreach ($topCustomers as $cust): ?>
                                    <tr>
                                        <td>
                                            <div class="fw-bold"><?php echo htmlspecialchars($cust['name']); ?></div>
                                            <small class="text-muted"><?php echo htmlspecialchars($cust['email']); ?></small>
                                        </td>
                                        <td><?php echo $cust['total_orders']; ?> Orders</td>
                                        <td class="text-end fw-bold text-primary">৳<?php echo number_format($cust['total_spent']); ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
            </div>
        </div>
    </div>
    <div class="col-lg-4">
        <div class="admin-list-shell">
            <div class="admin-list-shell-header">
                <h2 class="admin-list-shell-title">Recent Transactions</h2>
            </div>
            <div class="p-0">
                <div class="list-group list-group-flush">
                    <?php if (empty($recentTransactions)): ?>
                        <div class="text-center py-5 text-muted small">No paid orders found.</div>
                    <?php else: ?>
                        <?php foreach ($recentTransactions as $tx): ?>
                            <div class="list-group-item px-4 border-0 mb-1">
                                <div class="d-flex justify-content-between align-items-center mb-1">
                                    <span class="text-dark small">#<?php echo htmlspecialchars($tx['tracking_id']); ?></span>
                                    <span class="fw-bold text-success">৳<?php echo number_format($tx['total_amount']); ?></span>
                                </div>
                                <div class="d-flex justify-content-between align-items-center">
                                    <small class="text-muted"><?php echo htmlspecialchars($tx['customer_name'] ?: 'Guest'); ?></small>
                                    <small class="text-muted" style="font-size: 0.75rem;"><?php echo date('d M, h:i A', strtotime($tx['created_at'])); ?></small>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>
