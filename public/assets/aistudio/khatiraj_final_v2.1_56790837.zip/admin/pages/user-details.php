<?php
// admin/pages/user-details.php
$id = $_GET['id'] ?? null;
if (!$id) {
    header("Location: index.php?page=customers");
    exit;
}

// Fetch User
$stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
$stmt->execute([$id]);
$user = $stmt->fetch();

if (!$user) {
    echo "User not found!";
    exit;
}

// Activity logs and tracking events queries removed
$activity = null;
$events_summary = [];
$browsing_history = [];


// Fetch Orders
$stmt_orders = $pdo->prepare("SELECT * FROM orders WHERE user_id = ? ORDER BY created_at DESC");
$stmt_orders->execute([$id]);
$orders = $stmt_orders->fetchAll();

// Calculate Stats
$total_orders = count($orders);
$total_spent = 0;
foreach($orders as $o) if($o['payment_status'] == 'Paid') $total_spent += $o['total_amount'];
?>

<?php adminFlashMessages(); ?>
<?php adminPageHeader('Customer Insight', $user['name'] . ' — অর্ডার ও প্রোফাইল বিস্তারিত', [
    ['label' => 'সম্পাদনা', 'icon' => 'fa-edit', 'url' => 'index.php?page=edit-user&id=' . $user['id'], 'class' => 'btn btn-outline-primary btn-sm'],
    ['label' => 'গ্রাহক তালিকা', 'icon' => 'fa-arrow-left', 'url' => 'index.php?page=customers', 'class' => 'btn btn-outline-secondary btn-sm'],
]); ?>

<div class="row">
    <!-- User Info Card -->
    <div class="col-md-4 mb-4">
        <div class="card shadow-sm border-0 rounded-4 mb-4">
            <div class="card-header bg-white border-0 pt-4 px-4">
                <h5 class="fw-bold mb-0">🧍 Profile Information</h5>
            </div>
            <div class="card-body p-4">
                <div class="text-center mb-4">
                    <img src="https://ui-avatars.com/api/?name=<?php echo urlencode($user['name']); ?>&size=100&background=random" class="rounded-circle shadow-sm">
                    <h5 class="mt-3 mb-0 fw-bold"><?php echo htmlspecialchars($user['name']); ?></h5>
                    <span class="badge bg-primary bg-opacity-10 text-primary rounded-pill px-3">Registered User</span>
                </div>
                
                <div class="info-list">
                    <div class="d-flex justify-content-between mb-3 border-bottom pb-2">
                        <span class="text-muted small">User ID</span>
                        <span class="fw-bold">#<?php echo $user['id']; ?></span>
                    </div>
                    <div class="d-flex justify-content-between mb-3 border-bottom pb-2">
                        <span class="text-muted small">Mobile</span>
                        <span class="fw-bold"><a href="tel:<?php echo $user['phone']; ?>" class="text-decoration-none"><?php echo $user['phone']; ?></a></span>
                    </div>
                    <div class="d-flex justify-content-between mb-3 border-bottom pb-2">
                        <span class="text-muted small">Email</span>
                        <span class="fw-bold"><?php echo htmlspecialchars($user['email']); ?></span>
                    </div>
                    <div class="d-flex justify-content-between mb-3 border-bottom pb-2">
                        <span class="text-muted small">Joined Date</span>
                        <span class="fw-bold"><?php echo date('d M, Y', strtotime($user['created_at'])); ?></span>
                    </div>
                </div>

            </div>
        </div>


    </div>

    <!-- Right Side: Behavior & Orders -->
    <div class="col-md-8">
        <!-- Stats Row -->
        <div class="row g-3 mb-4">
            <div class="col-md-4">
                <div class="card border-0 shadow-sm rounded-4 bg-white p-3 text-center">
                    <div class="text-muted small mb-1">Total Orders</div>
                    <h3 class="fw-bold mb-0"><?php echo $total_orders; ?></h3>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card border-0 shadow-sm rounded-4 bg-white p-3 text-center">
                    <div class="text-muted small mb-1">Total Spent</div>
                    <h3 class="fw-bold mb-0 text-success">৳<?php echo number_format($total_spent); ?></h3>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card border-0 shadow-sm rounded-4 bg-white p-3 text-center">
                    <div class="text-muted small mb-1">Customer Value</div>
                    <h3 class="fw-bold mb-0 text-primary"><?php echo ($total_spent > 5000) ? 'VIP' : (($total_orders > 1) ? 'Loyal' : 'New'); ?></h3>
                </div>
            </div>
        </div>



        <!-- Orders Table -->
        <div class="card shadow-sm border-0 rounded-4">
            <div class="card-header bg-white border-0 pt-4 px-4">
                <h5 class="fw-bold mb-0"><i class="fas fa-shopping-bag text-primary me-2"></i>Order & Payment History</h5>
            </div>
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table table-hover mb-0 align-middle">
                        <thead class="bg-light">
                            <tr>
                                <th class="ps-4">Order ID</th>
                                <th>Date</th>
                                <th>Total</th>
                                <th>Method</th>
                                <th>Status</th>
                                <th class="text-end pe-4">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach($orders as $order): ?>
                            <tr>
                                <td class="ps-4">
                                    <div class="fw-bold">#<?php echo $order['tracking_id']; ?></div>
                                </td>
                                <td><?php echo date('d M, Y', strtotime($order['created_at'])); ?></td>
                                <td class="fw-bold text-slate-800">৳<?php echo number_format($order['total_amount']); ?></td>
                                <td><span class="small text-muted"><?php echo $order['payment_method']; ?></span></td>
                                <td>
                                    <span class="badge bg-<?php echo match($order['order_status']) {'Pending'=>'warning', 'Processing'=>'info', 'Shipped'=>'primary', 'Delivered'=>'success', 'Cancelled'=>'danger', default=>'secondary'}; ?> rounded-pill">
                                        <?php echo $order['order_status']; ?>
                                    </span>
                                </td>
                                <td class="text-end pe-4">
                                    <a href="index.php?page=order-view&id=<?php echo $order['id']; ?>" class="btn btn-sm btn-light border">View</a>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                            <?php if(empty($orders)): ?>
                                <tr><td colspan="6" class="text-center py-5 text-muted">No orders found for this customer.</td></tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
