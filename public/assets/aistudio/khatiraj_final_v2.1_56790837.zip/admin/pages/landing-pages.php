<?php
/**
 * Admin - Landing Pages Management
 */

// Fetch all landing pages
$stmt = $pdo->query("
    SELECT lp.*, p.name as product_name, p.image as product_image 
    FROM landing_pages lp 
    JOIN products p ON lp.product_id = p.id 
    ORDER BY lp.created_at DESC
");
$landing_pages = $stmt->fetchAll(PDO::FETCH_ASSOC);

if (!empty($_GET['success'])) {
    switch ($_GET['success']) {
        case 'created': $_GET['success'] = 'নতুন ল্যান্ডিং পেজ সফলভাবে তৈরি হয়েছে!'; break;
        case 'updated': $_GET['success'] = 'ল্যান্ডিং পেজ সফলভাবে আপডেট হয়েছে!'; break;
        case 'deleted': $_GET['success'] = 'ল্যান্ডিং পেজ সফলভাবে ডিলিট হয়েছে!'; break;
    }
}
?>

<?php adminFlashMessages(); ?>
<?php adminPageHeader('Landing Pages', 'প্রোডাক্টের জন্য ডেডিকেটেড ল্যান্ডিং পেজ তৈরি ও ম্যানেজ করুন', [
    ['label' => 'নতুন ল্যান্ডিং পেজ', 'icon' => 'fa-plus', 'url' => 'index.php?page=add-landing-page', 'class' => 'btn btn-primary btn-sm'],
]); ?>

<div class="admin-list-shell">
    <div class="admin-list-shell-header">
        <h2 class="admin-list-shell-title">ল্যান্ডিং পেজ তালিকা</h2>
        <span class="text-muted small fw-semibold"><?php echo count($landing_pages); ?>টি</span>
    </div>
    <div class="admin-table-wrap">
        <table class="admin-table admin-table-mobile-cards">
            <thead>
                <tr>
                    <th>প্রোডাক্ট</th>
                    <th>পেজ টাইটেল</th>
                    <th>স্লাগ</th>
                    <th>স্ট্যাটাস</th>
                    <th>তৈরির তারিখ</th>
                    <th class="text-end">অ্যাকশন</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($landing_pages)): ?>
                    <tr><td colspan="6"><?php adminEmptyState('কোনো ল্যান্ডিং পেজ নেই', 'এখনই নতুন ল্যান্ডিং পেজ তৈরি করুন', 'fa-rocket', ['label' => 'ল্যান্ডিং পেজ তৈরি করুন', 'url' => 'index.php?page=add-landing-page', 'icon' => 'fa-plus']); ?></td></tr>
                <?php else: ?>
                        <?php foreach($landing_pages as $lp): ?>
                        <tr>
                            <td>
                                <div class="d-flex align-items-center">
                                    <img src="../<?php echo $lp['product_image']; ?>" alt="<?php echo htmlspecialchars($lp['product_name']); ?>" 
                                         width="50" height="50" class="rounded-3 me-3 border" style="object-fit: cover;">
                                    <div>
                                        <h6 class="mb-0 fw-bold"><?php echo htmlspecialchars($lp['product_name']); ?></h6>
                                    </div>
                                </div>
                            </td>
                            <td>
                                <span class="fw-medium"><?php echo htmlspecialchars($lp['page_title']); ?></span>
                            </td>
                            <td>
                                <code class="bg-light px-2 py-1 rounded">/lp/<?php echo htmlspecialchars($lp['slug']); ?></code>
                            </td>
                            <td>
                                <?php echo $lp['status'] ? adminStatusBadge('Active') : adminStatusBadge('Inactive'); ?>
                            </td>
                            <td>
                                <span class="text-muted small"><?php echo date('d M, Y', strtotime($lp['created_at'])); ?></span>
                            </td>
                            <td class="text-end">
                                <div class="btn-group">
                                    <a href="../lp/<?php echo $lp['slug']; ?>" target="_blank" 
                                       class="btn btn-sm btn-outline-primary rounded-pill me-1" title="প্রিভিউ">
                                        <i class="fas fa-eye"></i>
                                    </a>
                                    <a href="index.php?page=edit-landing-page&id=<?php echo $lp['id']; ?>" 
                                       class="btn btn-sm btn-outline-warning rounded-pill me-1" title="এডিট">
                                        <i class="fas fa-edit"></i>
                                    </a>
                                    <button type="button" class="btn btn-sm btn-outline-danger rounded-pill" 
                                            onclick="deleteLandingPage(<?php echo $lp['id']; ?>)" title="ডিলিট">
                                        <i class="fas fa-trash"></i>
                                    </button>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                <?php endif; ?>
                    </tbody>
                </table>
    </div>
</div>

<!-- Delete Confirmation Modal -->
<div class="modal fade" id="deleteModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content border-0 rounded-4">
            <div class="modal-header border-0 pb-0">
                <h5 class="modal-title fw-bold"><i class="fas fa-exclamation-triangle text-danger me-2"></i> কনফার্ম ডিলিট</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <p class="mb-0">আপনি কি নিশ্চিত এই ল্যান্ডিং পেজটি ডিলিট করতে চান? এটি পুনরুদ্ধার করা যাবে না।</p>
            </div>
            <div class="modal-footer border-0">
                <button type="button" class="btn btn-secondary rounded-pill" data-bs-dismiss="modal">বাতিল</button>
                <form id="deleteForm" method="POST" action="actions/landing-page-delete.php" class="d-inline">
                    <input type="hidden" name="id" id="deleteId">
                    <button type="submit" class="btn btn-danger rounded-pill">
                        <i class="fas fa-trash me-1"></i> ডিলিট করুন
                    </button>
                </form>
            </div>
        </div>
    </div>
</div>

<script>
function deleteLandingPage(id) {
    document.getElementById('deleteId').value = id;
    new bootstrap.Modal(document.getElementById('deleteModal')).show();
}
</script>
