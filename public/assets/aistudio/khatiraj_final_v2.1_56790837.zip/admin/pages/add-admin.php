<?php
// admin/pages/add-admin.php
?>
<?php adminFlashMessages(); ?>
<?php adminPageHeader('Add Admin', 'নতুন অ্যাডমিন ইউজার তৈরি করুন', [
    ['label' => 'Admin তালিকা', 'icon' => 'fa-arrow-left', 'url' => 'index.php?page=admins', 'class' => 'btn btn-outline-secondary btn-sm'],
]); ?>

<form action="actions/admin-save.php" method="POST" class="settings-form">
    <div class="settings-layout admin-shell" data-panel-prefix="adm">
        <div class="settings-content">
            <section class="settings-panel admin-panel is-active" id="adm-general" role="tabpanel">
                <?php adminPanelHeader('New Admin', 'নাম, ইমেইল, পাসওয়ার্ড ও রোল', 'fa-user-shield', 'green'); ?>
                <div class="settings-panel-body admin-panel-body">
                    <div class="mb-3">
                        <label class="form-label">Full Name</label>
                        <input type="text" name="name" class="form-control" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Email Address</label>
                        <input type="email" name="email" class="form-control" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Password</label>
                        <input type="password" name="password" class="form-control" required>
                    </div>
                    <div class="mb-0">
                        <label class="form-label">Role</label>
                        <select name="role" class="form-select">
                            <option value="super_admin">Super Admin</option>
                            <option value="editor">Editor (Products only)</option>
                            <option value="moderator">Moderator (Orders only)</option>
                        </select>
                    </div>
                </div>
                <?php adminSaveBar('Create Admin'); ?>
            </section>
        </div>
    </div>
</form>
