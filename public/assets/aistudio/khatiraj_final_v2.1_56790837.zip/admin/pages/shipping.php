<?php
// admin/pages/shipping.php

try {
    $zones = $pdo->query("SELECT * FROM shipping_zones ORDER BY id ASC")->fetchAll();
    $classes = $pdo->query("SELECT * FROM shipping_classes ORDER BY id ASC")->fetchAll();
} catch (PDOException $e) {
    $shipping_error = $e->getMessage();
    $zones = [];
    $classes = [];
}
?>

<?php adminFlashMessages(); ?>
<?php if (!empty($shipping_error)): ?>
    <div class="admin-flash error"><i class="fas fa-exclamation-circle"></i> <?php echo htmlspecialchars($shipping_error); ?></div>
<?php endif; ?>
<?php adminPageHeader('Shipping Management', 'শিপিং জোন ও ক্লাস ম্যানেজ করুন'); ?>

<div class="settings-layout admin-shell" data-panel-prefix="ship">
    <nav class="settings-tabs admin-tabs" aria-label="Shipping sections">
        <div class="settings-tabs-track admin-tabs-track" role="tablist">
            <a href="#ship-zones" class="settings-tab admin-tab active" data-admin-nav="zones" role="tab" aria-selected="true">
                <i class="fas fa-map-marked-alt"></i><span>Zones</span>
            </a>
            <a href="#ship-classes" class="settings-tab admin-tab" data-admin-nav="classes" role="tab" aria-selected="false">
                <i class="fas fa-box"></i><span>Classes</span>
            </a>
        </div>
    </nav>

    <div class="settings-content">
        <section class="settings-panel admin-panel is-active" id="ship-zones" role="tabpanel">
            <?php adminPanelHeader('Shipping Zones', 'ডেলিভারি এলাকা ও চার্জ', 'fa-map-marked-alt', 'blue'); ?>
            <div class="settings-panel-body admin-panel-body pt-3">
                <div class="d-flex justify-content-end mb-3">
                    <button class="btn btn-sm btn-primary fw-semibold px-3" data-bs-toggle="modal" data-bs-target="#addZoneModal">
                        <i class="fas fa-plus me-1"></i> Add Zone
                    </button>
                </div>
                <div class="admin-table-wrap border rounded-3 overflow-hidden">
                    <table class="admin-table admin-table-mobile-cards">
                        <thead>
                            <tr>
                                <th scope="col">Zone Name</th>
                                <th scope="col">Charge</th>
                                <th scope="col">Status</th>
                                <th scope="col" class="text-end">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (empty($zones)): ?>
                                <tr><td colspan="4"><?php adminEmptyState('কোনো Zone নেই', 'প্রথম shipping zone যোগ করুন', 'fa-map-marked-alt'); ?></td></tr>
                            <?php else: ?>
                                <?php foreach ($zones as $zone): ?>
                                    <tr>
                                        <td class="px-4 fw-bold text-dark"><?php echo htmlspecialchars($zone['name']); ?></td>
                                        <td>৳<?php echo number_format($zone['charge']); ?></td>
                                        <td><?php echo $zone['status'] ? adminStatusBadge('Active') : adminStatusBadge('Inactive'); ?></td>
                                        <td class="text-end px-4">
                                            <div class="btn-group">
                                                <button class="btn btn-sm btn-outline-primary edit-zone-btn" data-zone='<?php echo json_encode($zone); ?>' data-bs-toggle="modal" data-bs-target="#editZoneModal">
                                                    <i class="fas fa-edit"></i>
                                                </button>
                                                <form action="actions/shipping-actions.php" method="POST" class="d-inline" onsubmit="return confirm('Are you sure?')">
                                                    <input type="hidden" name="id" value="<?php echo $zone['id']; ?>">
                                                    <input type="hidden" name="type" value="zone">
                                                    <button type="submit" name="action" value="delete" class="btn btn-sm btn-outline-danger">
                                                        <i class="fas fa-trash"></i>
                                                    </button>
                                                </form>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </section>

        <section class="settings-panel admin-panel" id="ship-classes" role="tabpanel" hidden>
            <?php adminPanelHeader('Shipping Classes', 'অতিরিক্ত চার্জ ক্লাস (ওজন/টাইপ)', 'fa-box', 'green'); ?>
            <div class="settings-panel-body admin-panel-body pt-3">
                <div class="d-flex justify-content-end mb-3">
                    <button class="btn btn-sm btn-success fw-semibold px-3" data-bs-toggle="modal" data-bs-target="#addClassModal">
                        <i class="fas fa-plus me-1"></i> Add Class
                    </button>
                </div>
                <div class="admin-table-wrap border rounded-3 overflow-hidden">
                    <table class="admin-table admin-table-mobile-cards">
                        <thead>
                            <tr>
                                <th scope="col">Class Name</th>
                                <th scope="col">Extra Charge</th>
                                <th scope="col">Status</th>
                                <th scope="col" class="text-end">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (empty($classes)): ?>
                                <tr><td colspan="4"><?php adminEmptyState('কোনো Class নেই', 'প্রথম shipping class যোগ করুন', 'fa-box'); ?></td></tr>
                            <?php else: ?>
                                <?php foreach ($classes as $class): ?>
                                    <tr>
                                        <td class="px-4 fw-bold text-dark"><?php echo htmlspecialchars($class['name']); ?></td>
                                        <td>৳<?php echo number_format($class['extra_charge']); ?></td>
                                        <td><?php echo $class['status'] ? adminStatusBadge('Active') : adminStatusBadge('Inactive'); ?></td>
                                        <td class="text-end px-4">
                                            <div class="btn-group">
                                                <button class="btn btn-sm btn-outline-primary edit-class-btn" data-class='<?php echo json_encode($class); ?>' data-bs-toggle="modal" data-bs-target="#editClassModal">
                                                    <i class="fas fa-edit"></i>
                                                </button>
                                                <form action="actions/shipping-actions.php" method="POST" class="d-inline" onsubmit="return confirm('Are you sure?')">
                                                    <input type="hidden" name="id" value="<?php echo $class['id']; ?>">
                                                    <input type="hidden" name="type" value="class">
                                                    <button type="submit" name="action" value="delete" class="btn btn-sm btn-outline-danger">
                                                        <i class="fas fa-trash"></i>
                                                    </button>
                                                </form>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </section>
    </div>
</div>

<!-- Add Zone Modal -->
<div class="modal fade" id="addZoneModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content border-0 shadow-lg rounded-4">
            <div class="modal-header border-0 bg-primary text-white">
                <h5 class="modal-title fw-bold">Add Shipping Zone</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <form action="actions/shipping-actions.php" method="POST">
                <input type="hidden" name="type" value="zone">
                <div class="modal-body p-4">
                    <div class="mb-3">
                        <label class="form-label fw-bold">Zone Name</label>
                        <input type="text" name="name" class="form-control" placeholder="e.g. Inside Dhaka" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-bold">Zone Charge (৳)</label>
                        <input type="number" name="charge" class="form-control" value="0" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-bold">Status</label>
                        <select name="status" class="form-select">
                            <option value="1">Active</option>
                            <option value="0">Inactive</option>
                        </select>
                    </div>
                </div>
                <div class="modal-footer border-0 p-4 pt-0">
                    <button type="button" class="btn btn-light px-4" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" name="action" value="add" class="btn btn-primary px-4 fw-bold">Save Zone</button>
                </div>
            </form>
        </div>
    </div>
</div>

<div class="modal fade" id="editZoneModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content border-0 shadow-lg rounded-4">
            <div class="modal-header border-0 bg-dark text-white">
                <h5 class="modal-title fw-bold">Edit Shipping Zone</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <form action="actions/shipping-actions.php" method="POST">
                <input type="hidden" name="type" value="zone">
                <input type="hidden" name="id" id="edit-zone-id">
                <div class="modal-body p-4">
                    <div class="mb-3">
                        <label class="form-label fw-bold">Zone Name</label>
                        <input type="text" name="name" id="edit-zone-name" class="form-control" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-bold">Zone Charge (৳)</label>
                        <input type="number" name="charge" id="edit-zone-charge" class="form-control" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-bold">Status</label>
                        <select name="status" id="edit-zone-status" class="form-select">
                            <option value="1">Active</option>
                            <option value="0">Inactive</option>
                        </select>
                    </div>
                </div>
                <div class="modal-footer border-0 p-4 pt-0">
                    <button type="button" class="btn btn-light px-4" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" name="action" value="edit" class="btn btn-primary px-4 fw-bold">Update Zone</button>
                </div>
            </form>
        </div>
    </div>
</div>

<div class="modal fade" id="addClassModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content border-0 shadow-lg rounded-4">
            <div class="modal-header border-0 bg-success text-white">
                <h5 class="modal-title fw-bold">Add Shipping Class</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <form action="actions/shipping-actions.php" method="POST">
                <input type="hidden" name="type" value="class">
                <div class="modal-body p-4">
                    <div class="mb-3">
                        <label class="form-label fw-bold">Class Name</label>
                        <input type="text" name="name" class="form-control" placeholder="e.g. Heavy Weight" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-bold">Extra Charge (৳)</label>
                        <input type="number" name="extra_charge" class="form-control" value="0" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-bold">Status</label>
                        <select name="status" class="form-select">
                            <option value="1">Active</option>
                            <option value="0">Inactive</option>
                        </select>
                    </div>
                </div>
                <div class="modal-footer border-0 p-4 pt-0">
                    <button type="button" class="btn btn-light px-4" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" name="action" value="add" class="btn btn-success px-4 fw-bold">Save Class</button>
                </div>
            </form>
        </div>
    </div>
</div>

<div class="modal fade" id="editClassModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content border-0 shadow-lg rounded-4">
            <div class="modal-header border-0 bg-dark text-white">
                <h5 class="modal-title fw-bold">Edit Shipping Class</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <form action="actions/shipping-actions.php" method="POST">
                <input type="hidden" name="type" value="class">
                <input type="hidden" name="id" id="edit-class-id">
                <div class="modal-body p-4">
                    <div class="mb-3">
                        <label class="form-label fw-bold">Class Name</label>
                        <input type="text" name="name" id="edit-class-name" class="form-control" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-bold">Extra Charge (৳)</label>
                        <input type="number" name="extra_charge" id="edit-class-charge" class="form-control" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-bold">Status</label>
                        <select name="status" id="edit-class-status" class="form-select">
                            <option value="1">Active</option>
                            <option value="0">Inactive</option>
                        </select>
                    </div>
                </div>
                <div class="modal-footer border-0 p-4 pt-0">
                    <button type="button" class="btn btn-light px-4" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" name="action" value="edit" class="btn btn-primary px-4 fw-bold">Update Class</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
(function () {
    function bindShippingEditors() {
        document.querySelectorAll('.edit-zone-btn').forEach(function (btn) {
            if (btn.dataset.bound) return;
            btn.dataset.bound = '1';
            btn.addEventListener('click', function () {
                var data = JSON.parse(this.getAttribute('data-zone'));
                document.getElementById('edit-zone-id').value = data.id;
                document.getElementById('edit-zone-name').value = data.name;
                document.getElementById('edit-zone-charge').value = data.charge;
                document.getElementById('edit-zone-status').value = data.status;
            });
        });
        document.querySelectorAll('.edit-class-btn').forEach(function (btn) {
            if (btn.dataset.bound) return;
            btn.dataset.bound = '1';
            btn.addEventListener('click', function () {
                var data = JSON.parse(this.getAttribute('data-class'));
                document.getElementById('edit-class-id').value = data.id;
                document.getElementById('edit-class-name').value = data.name;
                document.getElementById('edit-class-charge').value = data.extra_charge;
                document.getElementById('edit-class-status').value = data.status;
            });
        });
    }
    document.addEventListener('DOMContentLoaded', bindShippingEditors);
    window.addEventListener('pjax:complete', bindShippingEditors);
    if (document.readyState !== 'loading') bindShippingEditors();
})();
</script>
