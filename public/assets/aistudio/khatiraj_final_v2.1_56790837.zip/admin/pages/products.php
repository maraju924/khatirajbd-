<?php
// admin/pages/products.php
// Fetch products from DB
try {
    $stmt = $pdo->query("SELECT p.*, c.name as category_name FROM products p LEFT JOIN categories c ON p.category_id = c.id ORDER BY p.id DESC");
    $products = $stmt->fetchAll();
    
    // Fetch categories for filter dropdown
    $categories = $pdo->query("SELECT * FROM categories ORDER BY name ASC")->fetchAll();
} catch (PDOException $e) {
    $products = [];
    $categories = [];
    $error = "Error fetching data: " . $e->getMessage();
}
?>

<?php adminFlashMessages(); ?>
<?php adminPageHeader('Products', 'সব পণ্য দেখুন ও ম্যানেজ করুন', [
    ['label' => 'Bulk Upload', 'icon' => 'fa-upload', 'url' => 'index.php?page=bulk-upload', 'class' => 'btn btn-outline-primary btn-sm'],
    ['label' => 'নতুন পণ্য', 'icon' => 'fa-plus', 'url' => 'index.php?page=add-product', 'class' => 'btn btn-primary btn-sm'],
]); ?>

<?php if(isset($error)): ?>
    <div class="alert alert-danger"><?php echo htmlspecialchars($error); ?></div>
<?php endif; ?>

<!-- Styling for premium admin panel features -->
<style>
.inline-edit-span {
    border-bottom: 1px dashed rgba(21, 128, 61, 0.4);
    padding-bottom: 2px;
    transition: all 0.2s ease;
}
.inline-edit-span:hover {
    color: var(--kr-primary) !important;
    border-bottom-color: var(--kr-primary);
    background-color: rgba(21, 128, 61, 0.05);
    border-radius: 2px;
    padding: 2px 4px;
}
.visibility-badge, .status-badge {
    user-select: none;
    transition: transform 0.15s ease, opacity 0.15s ease;
}
.visibility-badge:hover, .status-badge:hover {
    transform: scale(1.05);
    opacity: 0.9;
}
.action-btn-circle {
    width: 32px;
    height: 32px;
    border-radius: 50%;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    padding: 0;
    transition: all 0.2s ease;
}
.action-btn-circle:hover {
    transform: scale(1.1);
}
.bulk-bar {
    background: #f0fdf4;
    border: 1px solid #bbf7d0;
    border-radius: 12px;
    animation: fadeInSlide 0.25s ease-out;
}
@keyframes fadeInSlide {
    from { opacity: 0; transform: translateY(-10px); }
    to { opacity: 1; transform: translateY(0); }
}
</style>

<!-- Advanced Filter and Search Bar -->
<div class="admin-filter-bar">
    <div class="admin-filter-row">
        <div class="admin-filter-field" style="flex: 2 1 220px; max-width: none;">
            <label class="admin-filter-label">Search</label>
            <input type="search" id="search-input" class="form-control form-control-sm" placeholder="পণ্য বা SKU দিয়ে সার্চ করুন..." oninput="applyFilters()">
        </div>
        <div class="admin-filter-field">
            <label class="admin-filter-label">Category</label>
            <select id="category-filter" class="form-select form-select-sm" onchange="applyFilters()">
                <option value="">সকল ক্যাটাগরি</option>
                <?php foreach ($categories as $cat): ?>
                    <option value="<?php echo htmlspecialchars($cat['name']); ?>"><?php echo htmlspecialchars($cat['name']); ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="admin-filter-field">
            <label class="admin-filter-label">Stock</label>
            <select id="stock-filter" class="form-select form-select-sm" onchange="applyFilters()">
                <option value="">স্টক অবস্থা</option>
                <option value="instock">ইন স্টক</option>
                <option value="lowstock">লো স্টক (≤5)</option>
                <option value="outstock">আউট অফ স্টক</option>
            </select>
        </div>
        <div class="admin-filter-actions">
            <span class="text-secondary small fw-bold">মোট: <span id="total-count" class="text-primary"><?php echo count($products); ?></span>টি</span>
        </div>
    </div>
</div>

<!-- Bulk Actions Panel (Hidden by default, shown when checkboxes are selected) -->
<div class="bulk-bar p-3 mb-4 align-items-center justify-content-between gap-3" id="bulk-actions-bar" style="display: none !important;">
    <div class="d-flex align-items-center gap-2">
        <i class="fas fa-check-square text-success fs-5"></i>
        <span class="fw-bold text-success small"><span id="selected-count">0</span>টি পণ্য সিলেক্ট করা হয়েছে</span>
    </div>
    <div class="d-flex align-items-center gap-2">
        <select class="form-select form-select-sm" id="bulk-action-select" style="width: 200px;">
            <option value="">অ্যাকশন সিলেক্ট করুন...</option>
            <option value="active">সক্রিয় করুন (Status: Active)</option>
            <option value="inactive">নিষ্ক্রিয় করুন (Status: Inactive)</option>
            <option value="visible">ওয়েবসাইটে দেখান (Visible)</option>
            <option value="hidden">ওয়েবসাইট থেকে লুকান (Hidden)</option>
            <option value="delete">মুছে ফেলুন (Bulk Delete)</option>
        </select>
        <button type="button" class="btn btn-success btn-sm px-4 fw-bold" onclick="applyBulkAction()">প্রয়োগ করুন</button>
    </div>
</div>

<div class="admin-list-shell">
  <div class="admin-list-shell-header">
    <h2 class="admin-list-shell-title">পণ্য তালিকা</h2>
    <span class="text-muted small fw-semibold"><?php echo count($products); ?>টি</span>
  </div>
  <div class="admin-table-wrap">
  <table class="admin-table admin-table-mobile-cards">
    <thead>
      <tr>
        <th scope="col" style="width: 40px;">
            <input type="checkbox" id="check-all" class="form-check-input" onclick="toggleCheckAll(this)">
        </th>
        <th scope="col" style="width: 50px;">#</th>
        <th scope="col" style="width: 80px;">Image</th>
        <th scope="col" class="sortable">Name & SKU</th>
        <th scope="col" class="sortable">Category</th>
        <th scope="col" class="sortable" style="width: 130px;">Price (৳)</th>
        <th scope="col" class="sortable" style="width: 110px;">Stock</th>
        <th scope="col" style="width: 100px;">Status</th>
        <th scope="col" style="width: 100px;">Visibility</th>
        <th scope="col" style="width: 160px;">Actions</th>
      </tr>
    </thead>
    <tbody>
      <?php if(count($products) > 0): ?>
          <?php foreach ($products as $product): ?>
          <tr id="product-row-<?php echo $product['id']; ?>" 
              class="product-row"
              data-name="<?php echo htmlspecialchars($product['name']); ?>"
              data-sku="<?php echo htmlspecialchars($product['sku'] ?? ''); ?>"
              data-category="<?php echo htmlspecialchars($product['category_name'] ?? 'Uncategorized'); ?>"
              data-qty="<?php echo $product['quantity']; ?>">
            
            <!-- Checkbox selection -->
            <td>
                <input type="checkbox" class="product-checkbox form-check-input" value="<?php echo $product['id']; ?>" onclick="toggleRowCheck()">
            </td>
            
            <td><?php echo $product['id']; ?></td>
            
            <!-- Product Image -->
            <td>
                <?php if($product['image']): ?>
                    <img src="../<?php echo $product['image']; ?>" width="44" height="44" alt="img" class="rounded border bg-light" style="object-fit: contain;">
                <?php else: ?>
                    <div class="rounded border bg-light d-flex align-items-center justify-content-center text-muted" style="width: 44px; height: 44px; font-size: 0.7rem;">No Image</div>
                <?php endif; ?>
            </td>
            
            <!-- Name & SKU -->
            <td>
                <div class="fw-bold text-dark"><?php echo htmlspecialchars($product['name']); ?></div>
                <?php if($product['sku']): ?>
                    <span class="badge bg-light text-secondary border small mt-1 font-monospace">SKU: <?php echo htmlspecialchars($product['sku']); ?></span>
                <?php endif; ?>
            </td>
            
            <!-- Category -->
            <td><?php echo htmlspecialchars($product['category_name'] ?? 'Uncategorized'); ?></td>
            
            <!-- Inline Editable Price -->
            <td>
                <span class="inline-edit-span text-primary fw-bold" 
                      style="cursor: pointer;" 
                      onclick="makeEditable(this, <?php echo $product['id']; ?>, 'price', 'numeric')"
                      title="ক্লিক করে সরাসরি মূল্য পরিবর্তন করুন">
                    ৳<?php echo number_format($product['price'], 2); ?>
                </span>
            </td>
            
            <!-- Inline Editable Stock Quantity -->
            <td>
                <span class="inline-edit-span fw-bold <?php echo ($product['quantity'] <= 5) ? (($product['quantity'] == 0) ? 'text-danger' : 'text-warning') : 'text-success'; ?>" 
                      style="cursor: pointer;" 
                      onclick="makeEditable(this, <?php echo $product['id']; ?>, 'quantity', 'integer')"
                      title="ক্লিক করে সরাসরি স্টক পরিমাণ পরিবর্তন করুন">
                    <?php echo $product['quantity']; ?>
                </span>
            </td>
            
            <!-- Active/Inactive Status Toggler -->
            <td>
                <span class="badge bg-<?php echo $product['status'] ? 'success' : 'secondary'; ?> status-badge" 
                      style="cursor: pointer;" 
                      onclick="toggleStatus(<?php echo $product['id']; ?>, this)"
                      title="ক্লিক করে সক্রিয়/নিষ্ক্রিয় টগল করুন">
                    <?php echo $product['status'] ? 'Active' : 'Inactive'; ?>
                </span>
            </td>
            
            <!-- Website Visibility Toggler -->
            <td>
                <span class="badge bg-<?php echo ($product['show_on_website'] ?? 1) ? 'primary' : 'warning text-dark'; ?> visibility-badge" 
                      style="cursor: pointer;" 
                      onclick="toggleVisibility(<?php echo $product['id']; ?>, this)"
                      title="<?php echo ($product['show_on_website'] ?? 1) ? 'ওয়েবসাইটে দৃশ্যমান — ক্লিক করে লুকান' : 'ওয়েবসাইটে লুকানো — ক্লিক করে দেখান'; ?>">
                    <i class="fas fa-<?php echo ($product['show_on_website'] ?? 1) ? 'eye' : 'eye-slash'; ?> me-1"></i>
                    <?php echo ($product['show_on_website'] ?? 1) ? 'Visible' : 'Hidden'; ?>
                </span>
            </td>
            
            <!-- Actions & Shortcuts -->
            <td>
                <div class="d-flex gap-1 align-items-center">
                    <!-- View Live Shortcut -->
                    <?php if(!empty($product['slug'])): ?>
                        <a href="<?php echo BASE_URL; ?>/product/<?php echo urlencode($product['slug']); ?>" 
                           target="_blank" 
                           class="btn btn-sm btn-outline-secondary action-btn-circle" 
                           title="ওয়েবসাইটে লাইভ দেখুন">
                            <i class="fas fa-external-link-alt"></i>
                        </a>
                    <?php endif; ?>
                    
                    <!-- Duplicate / Clone Shortcut -->
                    <button type="button" 
                            class="btn btn-sm btn-outline-success action-btn-circle" 
                            onclick="duplicateProduct(<?php echo $product['id']; ?>)"
                            title="পণ্যটি ডুপ্লিকেট/কপি করুন">
                        <i class="fas fa-copy"></i>
                    </button>
                    
                    <!-- Edit Product -->
                    <a href="index.php?page=edit-product&id=<?php echo $product['id']; ?>" 
                       class="btn btn-sm btn-outline-info action-btn-circle"
                       title="সম্পাদনা করুন">
                        <i class="fas fa-edit"></i>
                    </a>
                    
                    <!-- Delete Product -->
                    <button type="button" 
                            class="btn btn-sm btn-outline-danger action-btn-circle" 
                            onclick="deleteProduct(<?php echo $product['id']; ?>)"
                            title="মুছে ফেলুন">
                        <i class="fas fa-trash"></i>
                    </button>
                </div>
            </td>
          </tr>
          <?php endforeach; ?>
      <?php else: ?>
          <tr><td colspan="10"><?php adminEmptyState('কোনো পণ্য নেই', 'আপনার প্রথম পণ্য যোগ করুন', 'fa-box', ['label' => 'নতুন পণ্য', 'url' => 'index.php?page=add-product', 'icon' => 'fa-plus']); ?></td></tr>
      <?php endif; ?>
    </tbody>
  </table>
  </div>
</div>

<script>
// Filter implementation
function applyFilters() {
    const searchVal = document.getElementById('search-input').value.toLowerCase();
    const categoryVal = document.getElementById('category-filter').value;
    const stockVal = document.getElementById('stock-filter').value;

    const rows = document.querySelectorAll('.product-row');
    let visibleCount = 0;

    rows.forEach(row => {
        const name = row.getAttribute('data-name').toLowerCase();
        const sku = row.getAttribute('data-sku').toLowerCase();
        const category = row.getAttribute('data-category');
        const qty = parseInt(row.getAttribute('data-qty'));

        let matchSearch = name.includes(searchVal) || sku.includes(searchVal);
        let matchCategory = categoryVal === "" || category === categoryVal;
        
        let matchStock = true;
        if (stockVal === "instock") {
            matchStock = qty > 0;
        } else if (stockVal === "outstock") {
            matchStock = qty === 0;
        } else if (stockVal === "lowstock") {
            matchStock = qty > 0 && qty <= 5;
        }

        if (matchSearch && matchCategory && matchStock) {
            row.style.display = "";
            visibleCount++;
        } else {
            row.style.display = "none";
        }
    });

    // Update dynamically total visible count indicator
    document.getElementById('total-count').innerText = visibleCount;

    const emptyRow = document.getElementById('no-results-row');
    if (visibleCount === 0) {
        if (!emptyRow) {
            const tbody = document.querySelector('.admin-table tbody');
            const tr = document.createElement('tr');
            tr.id = 'no-results-row';
            tr.innerHTML = `<td colspan="10" class="text-center py-5 text-muted"><i class="fas fa-box-open fa-3x mb-2 d-block"></i>কোনো পণ্য পাওয়া যায়নি</td>`;
            tbody.appendChild(tr);
        }
    } else {
        emptyRow?.remove();
    }
}

// Inline editing functionality
function makeEditable(span, id, field, type) {
    if (span.querySelector('input')) return; // Avoid re-triggering while editing
    
    // Extract numerical values safely
    const originalText = span.innerText.replace('৳', '').replace(/,/g, '').trim();
    
    const input = document.createElement('input');
    input.type = 'text';
    input.value = originalText;
    input.className = 'form-control form-control-sm d-inline-block';
    input.style.width = '80px';
    input.style.padding = '2px 5px';
    input.style.height = 'auto';
    input.style.textAlign = 'center';

    span.innerHTML = '';
    span.appendChild(input);
    input.focus();
    input.select();

    let wasSaved = false;

    function save() {
        if (wasSaved) return;
        wasSaved = true;
        
        const val = input.value.trim();
        
        // Simple client-side validation
        if (val === '' || isNaN(val) || parseFloat(val) < 0) {
            span.innerHTML = (type === 'numeric' ? '৳' : '') + parseFloat(originalText).toLocaleString(undefined, {
                minimumFractionDigits: type === 'numeric' ? 2 : 0, 
                maximumFractionDigits: type === 'numeric' ? 2 : 0
            });
            return;
        }

        const data = new FormData();
        data.append('id', id);
        data.append('field', field);
        data.append('value', val);

        fetch('actions/product-quick-update.php', {
            method: 'POST',
            body: data,
            headers: { 'X-Requested-With': 'XMLHttpRequest' }
        })
        .then(res => res.json())
        .then(resData => {
            if (resData.success) {
                const parsedVal = parseFloat(resData.value);
                
                // Formatted display text
                span.innerHTML = (type === 'numeric' ? '৳' : '') + parsedVal.toLocaleString(undefined, {
                    minimumFractionDigits: type === 'numeric' ? 2 : 0, 
                    maximumFractionDigits: type === 'numeric' ? 2 : 0
                });
                
                // Update elements and filters
                const row = document.getElementById('product-row-' + id);
                if (field === 'quantity') {
                    row.setAttribute('data-qty', parsedVal);
                    // Update coloring classes based on new stock level
                    span.className = 'inline-edit-span fw-bold ' + (parsedVal <= 5 ? (parsedVal == 0 ? 'text-danger' : 'text-warning') : 'text-success');
                }
            } else {
                alert('Update failed: ' + resData.message);
                restoreOriginal();
            }
        })
        .catch(err => {
            console.error(err);
            restoreOriginal();
        });
    }

    function restoreOriginal() {
        span.innerHTML = (type === 'numeric' ? '৳' : '') + parseFloat(originalText).toLocaleString(undefined, {
            minimumFractionDigits: type === 'numeric' ? 2 : 0, 
            maximumFractionDigits: type === 'numeric' ? 2 : 0
        });
    }

    input.addEventListener('keydown', function(e) {
        if (e.key === 'Enter') {
            save();
        } else if (e.key === 'Escape') {
            wasSaved = true;
            restoreOriginal();
        }
    });

    input.addEventListener('blur', function() {
        save();
    });
}

// Active/Inactive quick toggler
function toggleStatus(productId, badge) {
    const current = badge.innerText.trim() === 'Active' ? 1 : 0;
    const nextVal = current ? 0 : 1;

    const data = new FormData();
    data.append('id', productId);
    data.append('field', 'status');
    data.append('value', nextVal);

    fetch('actions/product-quick-update.php', {
        method: 'POST',
        body: data,
        headers: { 'X-Requested-With': 'XMLHttpRequest' }
    })
    .then(res => res.json())
    .then(data => {
        if(data.success) {
            if(data.value) {
                badge.className = 'badge bg-success status-badge';
                badge.innerText = 'Active';
            } else {
                badge.className = 'badge bg-secondary status-badge';
                badge.innerText = 'Inactive';
            }
        } else {
            alert('Error: ' + data.message);
        }
    })
    .catch(err => console.error('Status Toggle Error:', err));
}

// Visibility quick toggler
function toggleVisibility(productId, badge) {
    fetch('actions/product-toggle-visibility.php?id=' + productId, {
        headers: { 'X-Requested-With': 'XMLHttpRequest' }
    })
    .then(res => res.json())
    .then(data => {
        if(data.success) {
            const icon = badge.querySelector('i');
            if(data.show_on_website) {
                badge.className = 'badge bg-primary visibility-badge';
                badge.title = 'ওয়েবসাইটে দৃশ্যমান — ক্লিক করে লুকান';
                badge.innerHTML = '<i class="fas fa-eye me-1"></i>Visible';
            } else {
                badge.className = 'badge bg-warning text-dark visibility-badge';
                badge.title = 'ওয়েবসাইটে লুকানো — ক্লিক করে দেখান';
                badge.innerHTML = '<i class="fas fa-eye-slash me-1"></i>Hidden';
            }
        } else {
            alert('Error: ' + data.message);
        }
    })
    .catch(err => console.error('Visibility Toggle Error:', err));
}

// Duplicate product shortcut
function duplicateProduct(id) {
    if (confirm('এই পণ্যটি কি ডুপ্লিকেট/কপি করতে চান?')) {
        fetch('actions/product-duplicate.php?id=' + id, {
            headers: { 'X-Requested-With': 'XMLHttpRequest' }
        })
        .then(res => res.json())
        .then(data => {
            if (data.success) {
                // Reload list to display the cloned item
                window.location.reload();
            } else {
                alert('Error duplicating: ' + data.message);
            }
        })
        .catch(err => console.error(err));
    }
}

// Delete product
function deleteProduct(id) {
    if(confirm('Are you sure you want to delete this product?')) {
        fetch('actions/product-delete.php?id=' + id, {
            headers: { 'X-Requested-With': 'XMLHttpRequest' }
        })
        .then(res => res.json())
        .then(data => {
            if(data.success) {
                const row = document.getElementById('product-row-' + id);
                if (row) {
                    row.remove();
                    // Update counts
                    const totalEl = document.getElementById('total-count');
                    totalEl.innerText = parseInt(totalEl.innerText) - 1;
                }
            } else {
                alert('Error: ' + data.message);
            }
        })
        .catch(err => {
            console.error('Delete Error:', err);
            window.location.href = 'actions/product-delete.php?id=' + id;
        });
    }
}

// Checkbox and Bulk Actions functionality
function toggleCheckAll(master) {
    const checkboxes = document.querySelectorAll('.product-checkbox');
    checkboxes.forEach(cb => {
        // Only select rows that are currently visible under current filters
        const row = cb.closest('tr');
        if (row && row.style.display !== 'none') {
            cb.checked = master.checked;
        }
    });
    toggleBulkBar();
}

function toggleRowCheck() {
    const master = document.getElementById('check-all');
    const checkboxes = document.querySelectorAll('.product-checkbox');
    let allChecked = true;
    let anyChecked = false;
    
    checkboxes.forEach(cb => {
        const row = cb.closest('tr');
        if (row && row.style.display !== 'none') {
            if (!cb.checked) allChecked = false;
            if (cb.checked) anyChecked = true;
        }
    });
    
    master.checked = allChecked && checkboxes.length > 0;
    toggleBulkBar();
}

function toggleBulkBar() {
    const bulkBar = document.getElementById('bulk-actions-bar');
    const checkedBoxes = document.querySelectorAll('.product-checkbox:checked');
    const selectedCount = document.getElementById('selected-count');
    
    if (checkedBoxes.length > 0) {
        selectedCount.innerText = checkedBoxes.length;
        bulkBar.style.setProperty('display', 'flex', 'important');
    } else {
        bulkBar.style.setProperty('display', 'none', 'important');
    }
}

function applyBulkAction() {
    const action = document.getElementById('bulk-action-select').value;
    if (!action) {
        alert('অনুগ্রহ করে একটি বাল্ক অ্যাকশন নির্বাচন করুন।');
        return;
    }
    
    const checkedBoxes = document.querySelectorAll('.product-checkbox:checked');
    const ids = Array.from(checkedBoxes).map(cb => cb.value);
    
    if (action === 'delete') {
        if (!confirm('সিলেক্ট করা ' + ids.length + 'টি পণ্য আপনি কি চিরতরে মুছে ফেলতে চান?')) {
            return;
        }
    }
    
    const data = new FormData();
    data.append('action', action);
    ids.forEach(id => data.append('ids[]', id));
    
    fetch('actions/product-bulk-action.php', {
        method: 'POST',
        body: data,
        headers: { 'X-Requested-With': 'XMLHttpRequest' }
    })
    .then(res => res.json())
    .then(resData => {
        if (resData.success) {
            // Uncheck check all
            document.getElementById('check-all').checked = false;
            // Reload page to reflect full database actions
            window.location.reload();
        } else {
            alert('Bulk action failed: ' + resData.message);
        }
    })
    .catch(err => console.error(err));
}
</script>
