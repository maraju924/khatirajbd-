<?php
// admin/pages/reviews.php
$reviews = $pdo->query("
    SELECT r.*, p.name as product_name, p.slug as product_slug 
    FROM reviews r 
    JOIN products p ON r.product_id = p.id 
    ORDER BY r.created_at DESC
")->fetchAll();

// Fetch all products for Add/Edit modals
$products = $pdo->query("SELECT id, name FROM products WHERE status = 1 ORDER BY name ASC")->fetchAll();
?>

<?php adminFlashMessages(); ?>
<?php adminPageHeader('রিভিউ ম্যানেজমেন্ট', 'পণ্য রিভিউ দেখুন, অনুমোদন ও সম্পাদনা করুন', [
    ['label' => 'নতুন রিভিউ', 'icon' => 'fa-plus', 'url' => '#', 'class' => 'btn btn-primary btn-sm', 'modal' => 'addReviewModal'],
]); ?>

<div class="admin-list-shell">
    <div class="admin-list-shell-header">
        <h2 class="admin-list-shell-title">রিভিউ তালিকা</h2>
        <span class="text-muted small fw-semibold"><?php echo count($reviews); ?>টি</span>
    </div>
    <div class="admin-table-wrap">
            <table class="admin-table admin-table-mobile-cards">
                <thead>
                    <tr>
                        <th scope="col">Product</th>
                        <th scope="col">User</th>
                        <th scope="col">Rating</th>
                        <th scope="col">Comment</th>
                        <th scope="col">Status</th>
                        <th scope="col">Date</th>
                        <th scope="col" class="text-end">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($reviews)): ?>
                        <tr><td colspan="7"><?php adminEmptyState('কোনো রিভিউ নেই', 'প্রথম রিভিউ যোগ করুন', 'fa-star', ['label' => 'নতুন রিভিউ', 'url' => '#', 'icon' => 'fa-plus']); ?></td></tr>
                    <?php else: ?>
                        <?php foreach ($reviews as $review): ?>
                            <tr>
                                <td class="px-4">
                                    <a href="../product/<?php echo $review['product_slug']; ?>" target="_blank" class="text-decoration-none small fw-bold">
                                        <?php echo htmlspecialchars($review['product_name']); ?>
                                    </a>
                                </td>
                                <td>
                                    <div class="small fw-bold"><?php echo htmlspecialchars($review['user_name']); ?></div>
                                    <div class="text-muted smaller"><?php echo htmlspecialchars($review['user_email']); ?></div>
                                </td>
                                <td>
                                    <div class="text-warning small text-nowrap">
                                        <?php for ($i = 1; $i <= 5; $i++): ?>
                                            <i class="<?php echo $i <= $review['rating'] ? 'fas' : 'far'; ?> fa-star"></i>
                                        <?php endfor; ?>
                                    </div>
                                </td>
                                <td>
                                    <div class="small text-truncate" style="max-width: 200px;" title="<?php echo htmlspecialchars($review['comment']); ?>">
                                        <?php echo htmlspecialchars($review['comment']); ?>
                                    </div>
                                </td>
                                <td>
                                    <?php echo $review['status'] ? adminStatusBadge('Active') : adminStatusBadge('Pending'); ?>
                                </td>
                                <td class="small text-muted"><?php echo date('M d, Y', strtotime($review['created_at'])); ?></td>
                                <td class="text-end px-4">
                                    <div class="btn-group">
                                        <button class="btn btn-sm btn-outline-primary" 
                                                onclick="editReview(<?php echo htmlspecialchars(json_encode($review)); ?>)">
                                            <i class="fas fa-edit"></i>
                                        </button>
                                        <?php if (!$review['status']): ?>
                                            <form action="actions/review-actions.php" method="POST" class="d-inline">
                                                <input type="hidden" name="id" value="<?php echo $review['id']; ?>">
                                                <button type="submit" name="action" value="approve" class="btn btn-sm btn-outline-success">
                                                    <i class="fas fa-check"></i>
                                                </button>
                                            </form>
                                        <?php endif; ?>
                                        <form action="actions/review-actions.php" method="POST" class="d-inline" onsubmit="return confirm('Delete this review?')">
                                            <input type="hidden" name="id" value="<?php echo $review['id']; ?>">
                                            <button type="submit" name="action" value="delete" class="btn btn-sm btn-outline-danger">
                                                <i class="fas fa-trash"></i>
                                            </button>
                                        </form>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
    </div>
</div>

<!-- Add Review Modal -->
<div class="modal fade" id="addReviewModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content border-0 shadow-lg rounded-4">
            <div class="modal-header border-0 bg-primary text-white">
                <h5 class="modal-title fw-bold">Add New Review</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <form action="actions/review-actions.php" method="POST">
                <div class="modal-body p-4">
                    <div class="mb-3">
                        <label class="form-label fw-bold">Select Product *</label>
                        <select name="product_id" class="form-select" required>
                            <option value="">Choose product...</option>
                            <?php foreach($products as $prod): ?>
                                <option value="<?php echo $prod['id']; ?>"><?php echo htmlspecialchars($prod['name']); ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label fw-bold">User Name *</label>
                            <input type="text" name="user_name" class="form-control" placeholder="Entry name" required>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label fw-bold">User Email *</label>
                            <input type="email" name="user_email" class="form-control" placeholder="Entry email" required>
                        </div>
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-bold">Rating *</label>
                        <select name="rating" class="form-select" required>
                            <option value="5">5 Stars</option>
                            <option value="4">4 Stars</option>
                            <option value="3">3 Stars</option>
                            <option value="2">2 Stars</option>
                            <option value="1">1 Star</option>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-bold">Comment *</label>
                        <textarea name="comment" class="form-control" rows="3" required></textarea>
                    </div>
                    <div class="form-check form-switch">
                        <input class="form-check-input" type="checkbox" name="status" value="1" checked id="addStatus">
                        <label class="form-check-label fw-bold" for="addStatus">Approve Automatically</label>
                    </div>
                </div>
                <div class="modal-footer border-0 p-4 pt-0">
                    <button type="button" class="btn btn-light px-4" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" name="action" value="add" class="btn btn-primary px-4 fw-bold">Submit Review</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Edit Review Modal -->
<div class="modal fade" id="editReviewModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content border-0 shadow-lg rounded-4">
            <div class="modal-header border-0 bg-dark text-white">
                <h5 class="modal-title fw-bold">Edit Review</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <form action="actions/review-actions.php" method="POST">
                <input type="hidden" name="id" id="edit_id">
                <div class="modal-body p-4">
                    <div class="mb-3">
                        <label class="form-label fw-bold">Product</label>
                        <select name="product_id" id="edit_product_id" class="form-select" required>
                            <?php foreach($products as $prod): ?>
                                <option value="<?php echo $prod['id']; ?>"><?php echo htmlspecialchars($prod['name']); ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label fw-bold">User Name</label>
                            <input type="text" name="user_name" id="edit_user_name" class="form-control" required>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label fw-bold">User Email</label>
                            <input type="email" name="user_email" id="edit_user_email" class="form-control" required>
                        </div>
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-bold">Rating</label>
                        <select name="rating" id="edit_rating" class="form-select" required>
                            <option value="5">5 Stars</option>
                            <option value="4">4 Stars</option>
                            <option value="3">3 Stars</option>
                            <option value="2">2 Stars</option>
                            <option value="1">1 Star</option>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-bold">Comment</label>
                        <textarea name="comment" id="edit_comment" class="form-control" rows="3" required></textarea>
                    </div>
                    <div class="form-check form-switch">
                        <input class="form-check-input" type="checkbox" name="status" value="1" id="edit_status">
                        <label class="form-check-label fw-bold" for="edit_status">Approved</label>
                    </div>
                </div>
                <div class="modal-footer border-0 p-4 pt-0">
                    <button type="button" class="btn btn-light px-4" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" name="action" value="update" class="btn btn-dark px-4 fw-bold">Update Review</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
function editReview(review) {
    document.getElementById('edit_id').value = review.id;
    document.getElementById('edit_product_id').value = review.product_id;
    document.getElementById('edit_user_name').value = review.user_name;
    document.getElementById('edit_user_email').value = review.user_email;
    document.getElementById('edit_rating').value = review.rating;
    document.getElementById('edit_comment').value = review.comment;
    document.getElementById('edit_status').checked = review.status == 1;
    
    new bootstrap.Modal(document.getElementById('editReviewModal')).show();
}
</script>
