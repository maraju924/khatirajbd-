<?php
// admin/pages/orders.php — Advanced all-in-one order management

// --- Pagination Config ---
$per_page = intval($_GET['per_page'] ?? 20);
if (!in_array($per_page, [20, 50, 100])) $per_page = 20;
$current_page = max(1, intval($_GET['pg'] ?? 1));
$offset = ($current_page - 1) * $per_page;

// --- Filters ---
$where_clauses = [];
$params = [];

$filter_status = $_GET['status'] ?? '';
if ($filter_status && in_array($filter_status, ['Pending','Processing','Shipped','Delivered','Cancelled'])) {
    $where_clauses[] = "o.order_status = ?";
    $params[] = $filter_status;
}

$filter_payment = $_GET['payment'] ?? '';
if ($filter_payment && in_array($filter_payment, ['COD','Online'])) {
    $where_clauses[] = "o.payment_method = ?";
    $params[] = $filter_payment;
}

$filter_pay_status = $_GET['pay_status'] ?? '';
if ($filter_pay_status && in_array($filter_pay_status, ['Pending','Paid','Failed'])) {
    $where_clauses[] = "o.payment_status = ?";
    $params[] = $filter_pay_status;
}

$filter_courier = $_GET['courier'] ?? '';
if ($filter_courier === 'sent') {
    $where_clauses[] = "o.courier_consignment_id IS NOT NULL";
} elseif ($filter_courier === 'not_sent') {
    $where_clauses[] = "o.courier_consignment_id IS NULL";
}

$filter_date = $_GET['date_range'] ?? '';
if ($filter_date === 'today') {
    $where_clauses[] = "DATE(o.created_at) = CURDATE()";
} elseif ($filter_date === 'yesterday') {
    $where_clauses[] = "DATE(o.created_at) = DATE_SUB(CURDATE(), INTERVAL 1 DAY)";
} elseif ($filter_date === '7days') {
    $where_clauses[] = "o.created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)";
} elseif ($filter_date === '30days') {
    $where_clauses[] = "o.created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)";
} elseif ($filter_date === 'custom') {
    $from = $_GET['date_from'] ?? '';
    $to = $_GET['date_to'] ?? '';
    if ($from) { $where_clauses[] = "DATE(o.created_at) >= ?"; $params[] = $from; }
    if ($to) { $where_clauses[] = "DATE(o.created_at) <= ?"; $params[] = $to; }
}

$search_q = trim($_GET['q'] ?? '');
if ($search_q) {
    $where_clauses[] = "(o.tracking_id LIKE ? OR o.customer_name LIKE ? OR o.customer_phone LIKE ? OR o.customer_email LIKE ? OR o.courier_consignment_id LIKE ?)";
    for ($i = 0; $i < 5; $i++) $params[] = "%$search_q%";
}

$where_sql = count($where_clauses) > 0 ? 'WHERE ' . implode(' AND ', $where_clauses) : '';

// --- Sorting ---
$sort = $_GET['sort'] ?? 'newest';
$order_by = match($sort) {
    'oldest' => 'o.created_at ASC',
    'amount_high' => 'o.total_amount DESC',
    'amount_low' => 'o.total_amount ASC',
    default => 'o.created_at DESC',
};

// --- Total Count ---
$count_stmt = $pdo->prepare("SELECT COUNT(*) FROM orders o $where_sql");
$count_stmt->execute($params);
$total_orders = $count_stmt->fetchColumn();
$total_pages = max(1, ceil($total_orders / $per_page));

// --- Fetch Orders ---
$stmt = $pdo->prepare("SELECT o.*, u.name as user_name FROM orders o LEFT JOIN users u ON o.user_id = u.id $where_sql ORDER BY $order_by LIMIT $per_page OFFSET $offset");
$stmt->execute($params);
$orders = $stmt->fetchAll();

// --- Items preview for visible orders ---
$items_preview = [];
if (!empty($orders)) {
    $ids = array_column($orders, 'id');
    $placeholders = implode(',', array_fill(0, count($ids), '?'));
    $pv_stmt = $pdo->prepare("
        SELECT oi.order_id,
               COUNT(*) AS line_count,
               SUM(oi.qty) AS total_qty,
               GROUP_CONCAT(p.image ORDER BY oi.id SEPARATOR '||') AS images,
               GROUP_CONCAT(p.name ORDER BY oi.id SEPARATOR '||') AS names
        FROM order_items oi
        JOIN products p ON oi.product_id = p.id
        WHERE oi.order_id IN ($placeholders)
        GROUP BY oi.order_id
    ");
    $pv_stmt->execute($ids);
    foreach ($pv_stmt->fetchAll() as $row) {
        $items_preview[$row['order_id']] = $row;
    }
}

// --- Stats (unfiltered) ---
$stats = $pdo->query("SELECT 
    COUNT(*) as total,
    SUM(CASE WHEN order_status = 'Pending' THEN 1 ELSE 0 END) as pending,
    SUM(CASE WHEN order_status = 'Processing' THEN 1 ELSE 0 END) as processing,
    SUM(CASE WHEN order_status = 'Shipped' THEN 1 ELSE 0 END) as shipped,
    SUM(CASE WHEN order_status = 'Delivered' THEN 1 ELSE 0 END) as delivered,
    SUM(CASE WHEN order_status = 'Cancelled' THEN 1 ELSE 0 END) as cancelled,
    SUM(CASE WHEN DATE(created_at) = CURDATE() THEN total_amount ELSE 0 END) as today_revenue,
    SUM(CASE WHEN DATE(created_at) = CURDATE() THEN 1 ELSE 0 END) as today_orders,
    SUM(CASE WHEN payment_method = 'COD' THEN 1 ELSE 0 END) as cod_count,
    SUM(CASE WHEN payment_method = 'Online' THEN 1 ELSE 0 END) as online_count,
    SUM(CASE WHEN courier_consignment_id IS NULL AND order_status NOT IN ('Delivered','Cancelled') THEN 1 ELSE 0 END) as awaiting_courier
FROM orders")->fetch();

// Helper for building filter URLs
function buildFilterUrl($overrides = []) {
    $params = $_GET;
    $params['page'] = 'orders'; // preserve current admin page
    foreach ($overrides as $k => $v) {
        if ($v === '' || $v === null) unset($params[$k]);
        else $params[$k] = $v;
    }
    if (isset($overrides['pg'])) $params['pg'] = $overrides['pg'];
    else unset($params['pg']); // reset to page 1 on filter change
    return 'index.php?' . http_build_query($params);
}

$status_tabs = [
    '' => ['label' => 'All', 'count' => $stats['total'], 'color' => '#475569'],
    'Pending' => ['label' => 'Pending', 'count' => $stats['pending'], 'color' => '#d97706'],
    'Processing' => ['label' => 'Processing', 'count' => $stats['processing'], 'color' => '#2563eb'],
    'Shipped' => ['label' => 'Shipped', 'count' => $stats['shipped'], 'color' => '#4f46e5'],
    'Delivered' => ['label' => 'Delivered', 'count' => $stats['delivered'], 'color' => '#059669'],
    'Cancelled' => ['label' => 'Cancelled', 'count' => $stats['cancelled'], 'color' => '#dc2626'],
];
?>

<?php adminFlashMessages(); ?>
<?php adminPageHeader('অর্ডার তালিকা', 'সব অর্ডার দেখুন, ফিল্টার ও ম্যানেজ করুন — all in one', [
    ['label' => 'Export CSV', 'icon' => 'fa-file-csv', 'url' => 'actions/export-orders-csv.php', 'class' => 'btn btn-outline-primary btn-sm', 'data-no-pjax' => true],
], [['label' => 'অর্ডার', 'url' => '']]); ?>

<div class="row g-3 mb-3 admin-kpi-row">
    <div class="col-6 col-lg-3"><?php adminStatCard('মোট অর্ডার', number_format($stats['total']), 'fa-shopping-bag', 'blue'); ?></div>
    <div class="col-6 col-lg-3"><?php adminStatCard('আজকের অর্ডার', number_format($stats['today_orders']), 'fa-calendar-day', 'amber'); ?></div>
    <div class="col-6 col-lg-3"><?php adminStatCard('আজকের Revenue', '৳' . number_format($stats['today_revenue']), 'fa-coins', 'green'); ?></div>
    <div class="col-6 col-lg-3"><?php adminStatCard('Courier বাকি', number_format($stats['awaiting_courier']), 'fa-truck', 'purple'); ?></div>
</div>

<!-- Status Tabs -->
<div class="d-flex flex-wrap gap-2 mb-3" id="statusTabs">
    <?php foreach ($status_tabs as $key => $tab): $active = $filter_status === $key; ?>
    <a href="<?php echo buildFilterUrl(['status' => $key]); ?>"
       class="btn btn-sm rounded-pill px-3 fw-bold d-inline-flex align-items-center gap-2 <?php echo $active ? 'text-white' : 'bg-white border text-secondary'; ?>"
       style="<?php echo $active ? 'background:' . $tab['color'] . '; border-color:' . $tab['color'] . ';' : ''; ?> font-size: 0.78rem;">
        <?php echo $tab['label']; ?>
        <span class="badge rounded-pill <?php echo $active ? 'bg-white' : ''; ?>"
              style="<?php echo $active ? 'color:' . $tab['color'] . ';' : 'background:#f1f5f9; color:#475569;'; ?> font-size: 0.68rem;">
            <?php echo number_format($tab['count']); ?>
        </span>
    </a>
    <?php endforeach; ?>
</div>

<!-- Filter & Search Bar -->
<div class="admin-filter-bar">
        <form id="orderFilterForm" class="admin-filter-form">
            <input type="hidden" name="page" value="orders">
            <input type="hidden" name="status" value="<?php echo htmlspecialchars($filter_status); ?>">

            <div class="admin-filter-row">
            <!-- Search -->
            <div class="admin-filter-field" style="flex: 2 1 200px; max-width: none;">
                <label class="admin-filter-label">Search</label>
                <input type="search" name="q" class="form-control form-control-sm" placeholder="ID, Name, Phone, Email, Consignment..." value="<?php echo htmlspecialchars($search_q); ?>">
            </div>

            <!-- Payment Method -->
            <div class="admin-filter-field" style="flex: 0 1 110px;">
                <label class="admin-filter-label">Payment</label>
                <select name="payment" class="form-select form-select-sm">
                    <option value="">All</option>
                    <option value="COD" <?php echo $filter_payment==='COD'?'selected':''; ?>>COD</option>
                    <option value="Online" <?php echo $filter_payment==='Online'?'selected':''; ?>>Online</option>
                </select>
            </div>

            <!-- Payment Status -->
            <div class="admin-filter-field" style="flex: 0 1 130px;">
                <label class="admin-filter-label">Pay Status</label>
                <select name="pay_status" class="form-select form-select-sm">
                    <option value="">All</option>
                    <option value="Pending" <?php echo $filter_pay_status==='Pending'?'selected':''; ?>>Pending</option>
                    <option value="Paid" <?php echo $filter_pay_status==='Paid'?'selected':''; ?>>Paid</option>
                    <option value="Failed" <?php echo $filter_pay_status==='Failed'?'selected':''; ?>>Failed</option>
                </select>
            </div>

            <!-- Courier -->
            <div class="admin-filter-field" style="flex: 0 1 130px;">
                <label class="admin-filter-label">Courier</label>
                <select name="courier" class="form-select form-select-sm">
                    <option value="">All</option>
                    <option value="sent" <?php echo $filter_courier==='sent'?'selected':''; ?>>Sent</option>
                    <option value="not_sent" <?php echo $filter_courier==='not_sent'?'selected':''; ?>>Not Sent</option>
                </select>
            </div>

            <!-- Date Range -->
            <div class="admin-filter-field" style="flex: 0 1 140px;">
                <label class="admin-filter-label">Date</label>
                <select name="date_range" class="form-select form-select-sm" onchange="toggleCustomDate(this)">
                    <option value="">All Time</option>
                    <option value="today" <?php echo $filter_date==='today'?'selected':''; ?>>Today</option>
                    <option value="yesterday" <?php echo $filter_date==='yesterday'?'selected':''; ?>>Yesterday</option>
                    <option value="7days" <?php echo $filter_date==='7days'?'selected':''; ?>>Last 7 Days</option>
                    <option value="30days" <?php echo $filter_date==='30days'?'selected':''; ?>>Last 30 Days</option>
                    <option value="custom" <?php echo $filter_date==='custom'?'selected':''; ?>>Custom Range</option>
                </select>
            </div>

            <!-- Sort -->
            <div class="admin-filter-field" style="flex: 0 1 160px;">
                <label class="admin-filter-label">Sort</label>
                <select name="sort" class="form-select form-select-sm">
                    <option value="newest" <?php echo $sort==='newest'?'selected':''; ?>>Newest First</option>
                    <option value="oldest" <?php echo $sort==='oldest'?'selected':''; ?>>Oldest First</option>
                    <option value="amount_high" <?php echo $sort==='amount_high'?'selected':''; ?>>Amount: High → Low</option>
                    <option value="amount_low" <?php echo $sort==='amount_low'?'selected':''; ?>>Amount: Low → High</option>
                </select>
            </div>

            <!-- Buttons -->
            <div class="admin-filter-actions d-flex gap-2">
                <button type="submit" class="btn btn-sm btn-primary fw-semibold px-3"><i class="fas fa-filter me-1"></i>Filter</button>
                <a href="index.php?page=orders" class="btn btn-sm btn-outline-secondary px-3"><i class="fas fa-times me-1"></i>Clear</a>
            </div>
            </div>

            <!-- Custom Date Inputs (hidden by default) -->
            <div class="mt-2" id="customDateRow" style="<?php echo $filter_date==='custom'?'':'display:none;'; ?>">
                <div class="admin-filter-row">
                    <div class="admin-filter-field">
                        <input type="date" name="date_from" class="form-control form-control-sm" value="<?php echo htmlspecialchars($_GET['date_from'] ?? ''); ?>">
                    </div>
                    <div class="admin-filter-field">
                        <input type="date" name="date_to" class="form-control form-control-sm" value="<?php echo htmlspecialchars($_GET['date_to'] ?? ''); ?>">
                    </div>
                </div>
            </div>
        </form>
</div>

<!-- Bulk Actions Bar (hidden until checkboxes are selected) -->
<div class="card border-0 shadow-sm mb-3 d-none" id="bulkBar" style="border-radius: 12px; background: linear-gradient(135deg, #1e293b, #334155);">
    <div class="card-body py-2 px-4 d-flex flex-wrap align-items-center justify-content-between gap-2">
        <div class="d-flex flex-wrap align-items-center gap-2">
            <span class="text-white fw-bold small"><span id="bulkCount">0</span> selected</span>
            <select id="bulkStatusSelect" class="form-select form-select-sm" style="width: 160px;">
                <option value="">Change Status...</option>
                <option value="Pending">Pending</option>
                <option value="Processing">Processing</option>
                <option value="Shipped">Shipped</option>
                <option value="Delivered">Delivered</option>
                <option value="Cancelled">Cancelled</option>
            </select>
            <button type="button" class="btn btn-sm btn-warning fw-bold px-3" onclick="applyBulkAction()">
                <i class="fas fa-bolt me-1"></i>Apply
            </button>
            <button type="button" class="btn btn-sm btn-success fw-bold px-3" onclick="bulkSendCourier()" id="bulkCourierBtn">
                <i class="fas fa-truck-fast me-1"></i>Send to Steadfast
            </button>
        </div>
        <button type="button" class="btn btn-sm btn-outline-light" onclick="clearBulkSelection()">
            <i class="fas fa-times me-1"></i>Clear
        </button>
    </div>
</div>

<!-- Orders Table -->
<div class="admin-list-shell">
<div class="admin-list-shell-header">
    <h2 class="admin-list-shell-title">অর্ডার তালিকা</h2>
    <span class="text-muted small fw-semibold"><?php echo number_format($total_orders); ?>টি</span>
</div>
<div class="admin-table-wrap">
  <table class="admin-table admin-table-mobile-cards" style="font-size: 0.85rem;">
    <thead>
      <tr>
        <th style="width: 30px;">
            <input class="form-check-input" type="checkbox" id="selectAll" onclick="toggleSelectAll(this)">
        </th>
        <th>Order</th>
        <th>Customer</th>
        <th>Items</th>
        <th>Total</th>
        <th>Status</th>
        <th>Payment</th>
        <th>Courier</th>
        <th>Action</th>
      </tr>
    </thead>
    <tbody>
      <?php if(count($orders) > 0): ?>
          <?php foreach ($orders as $order): 
              $pv = $items_preview[$order['id']] ?? null;
              $pv_images = $pv ? array_slice(array_filter(explode('||', $pv['images'])), 0, 3) : [];
              $pv_names = $pv ? explode('||', $pv['names']) : [];
          ?>
          <tr>
            <td>
                <input class="form-check-input bulk-check" type="checkbox" value="<?php echo $order['id']; ?>"
                       data-has-courier="<?php echo $order['courier_consignment_id'] ? '1' : '0'; ?>" onchange="updateBulkBar()">
            </td>
            <td>
                <a href="index.php?page=order-view&id=<?php echo $order['id']; ?>" class="fw-bold text-decoration-none"><?php echo htmlspecialchars($order['tracking_id']); ?></a>
                <div class="text-muted" style="font-size: 0.7rem;"><?php echo date('d M, h:i A', strtotime($order['created_at'])); ?></div>
            </td>
            <td>
                <?php 
                    $display_name = $order['customer_name'] ?? $order['user_name'] ?? 'Guest';
                    echo htmlspecialchars($display_name); 
                ?>
                <div class="small text-muted d-flex align-items-center gap-1" style="font-size: 0.72rem;">
                    <span><?php echo htmlspecialchars($order['customer_phone']); ?></span>
                    <button type="button" class="btn btn-link btn-sm p-0 text-muted" onclick="copyPhone('<?php echo $order['customer_phone']; ?>', this)" title="Copy">
                        <i class="fas fa-copy" style="font-size: 0.65rem;"></i>
                    </button>
                    <a href="https://wa.me/88<?php echo preg_replace('/[^0-9]/', '', $order['customer_phone']); ?>?text=<?php echo urlencode('আসসালামু আলাইকুম। আপনার অর্ডার #' . $order['tracking_id'] . ' সম্পর্কে জানাচ্ছি:'); ?>" target="_blank" class="btn btn-link btn-sm p-0 text-success" title="WhatsApp">
                        <i class="fab fa-whatsapp" style="font-size: 0.78rem;"></i>
                    </a>
                    <?php if($order['digital_delivery_status'] !== 'N/A' && $order['customer_email']): ?>
                        <span title="Digital Delivery: <?php echo $order['digital_delivery_status']; ?>">
                            <?php if($order['digital_delivery_status'] === 'Sent'): ?>
                                <i class="fas fa-check-circle text-success" style="font-size: 0.75rem;"></i>
                            <?php elseif($order['digital_delivery_status'] === 'Failed'): ?>
                                <i class="fas fa-exclamation-circle text-danger" style="font-size: 0.75rem;"></i>
                            <?php else: ?>
                                <i class="fas fa-clock text-warning" style="font-size: 0.75rem;"></i>
                            <?php endif; ?>
                        </span>
                    <?php endif; ?>
                </div>
            </td>
            <td>
                <?php if ($pv): ?>
                <div class="d-flex align-items-center" title="<?php echo htmlspecialchars(implode(', ', $pv_names)); ?>">
                    <div class="d-flex" style="margin-right: 6px;">
                        <?php foreach ($pv_images as $idx => $img): ?>
                        <img src="../<?php echo htmlspecialchars($img); ?>" width="28" height="28" class="rounded border border-white"
                             style="object-fit: cover; <?php echo $idx > 0 ? 'margin-left: -10px;' : ''; ?>" alt="">
                        <?php endforeach; ?>
                    </div>
                    <span class="badge bg-light text-secondary" style="font-size: 0.68rem;"><?php echo (int)$pv['total_qty']; ?> pcs</span>
                </div>
                <?php else: ?>
                <span class="text-muted small">—</span>
                <?php endif; ?>
            </td>
            <td class="fw-bold">
                ৳<?php echo number_format($order['total_amount'], 2); ?>
                <?php if ((float)$order['discount_amount'] > 0): ?>
                    <div class="text-success" style="font-size: 0.68rem;" title="Coupon: <?php echo htmlspecialchars($order['coupon_code'] ?? ''); ?>">
                        <i class="fas fa-tag"></i> -৳<?php echo number_format($order['discount_amount']); ?>
                    </div>
                <?php endif; ?>
            </td>
            <td>
                <!-- Inline Status Change -->
                <select class="form-select form-select-sm border-0 fw-bold inline-status-select" 
                        data-order-id="<?php echo $order['id']; ?>"
                        style="font-size: 0.75rem; width: 120px; padding: 2px 24px 2px 6px; background-color: <?php 
                            echo match($order['order_status']) {
                                'Pending' => '#fef3c7',
                                'Processing' => '#dbeafe',
                                'Shipped' => '#e0e7ff',
                                'Delivered' => '#d1fae5',
                                'Cancelled' => '#fee2e2',
                                default => '#f1f5f9'
                            };
                        ?>; color: <?php 
                            echo match($order['order_status']) {
                                'Pending' => '#92400e',
                                'Processing' => '#1e40af',
                                'Shipped' => '#3730a3',
                                'Delivered' => '#065f46',
                                'Cancelled' => '#991b1b',
                                default => '#475569'
                            };
                        ?>; border-radius: 20px;"
                        onchange="inlineStatusChange(this)">
                    <option value="Pending" <?php echo $order['order_status']==='Pending'?'selected':''; ?>>⏳ Pending</option>
                    <option value="Processing" <?php echo $order['order_status']==='Processing'?'selected':''; ?>>🔄 Processing</option>
                    <option value="Shipped" <?php echo $order['order_status']==='Shipped'?'selected':''; ?>>📦 Shipped</option>
                    <option value="Delivered" <?php echo $order['order_status']==='Delivered'?'selected':''; ?>>✅ Delivered</option>
                    <option value="Cancelled" <?php echo $order['order_status']==='Cancelled'?'selected':''; ?>>❌ Cancelled</option>
                </select>
            </td>
            <td>
                <span class="badge <?php echo $order['payment_method']==='COD' ? 'bg-secondary' : 'bg-info'; ?>" style="font-size: 0.7rem;">
                    <?php echo $order['payment_method']; ?>
                </span>
                <div style="font-size: 0.65rem;" class="mt-1">
                    <span class="badge <?php 
                        echo match($order['payment_status']) {
                            'Paid' => 'bg-success-subtle text-success',
                            'Failed' => 'bg-danger-subtle text-danger',
                            default => 'bg-warning-subtle text-warning-emphasis'
                        };
                    ?>"><?php echo $order['payment_status']; ?></span>
                </div>
            </td>
            <td>
                <?php if($order['courier_consignment_id']): 
                    $cs = strtolower((string)$order['courier_status']);
                    $cs_class = str_contains($cs, 'delivered') ? 'bg-success' : (str_contains($cs, 'cancel') ? 'bg-danger' : 'bg-info text-dark');
                ?>
                    <span class="badge <?php echo $cs_class; ?>" title="Consignment: <?php echo $order['courier_consignment_id']; ?>" style="font-size: 0.68rem;">
                        <i class="fas fa-truck me-1"></i><?php echo htmlspecialchars($order['courier_status'] ?: 'sent'); ?>
                    </span>
                <?php else: ?>
                    <form action="actions/send_to_steadfast.php" method="POST" class="d-inline">
                        <input type="hidden" name="order_id" value="<?php echo $order['id']; ?>">
                        <button type="submit" class="btn btn-sm btn-success py-0 px-2" style="font-size: 0.7rem; border-radius: 20px;">
                            <i class="fas fa-paper-plane me-1"></i>Send
                        </button>
                    </form>
                <?php endif; ?>
            </td>
            <td>
                <div class="d-flex gap-1">
                    <button type="button" class="btn btn-sm btn-outline-dark py-0 px-2" title="Quick View" style="font-size: 0.75rem;"
                            onclick="quickView(<?php echo $order['id']; ?>)">
                        <i class="fas fa-bolt"></i>
                    </button>
                    <a href="index.php?page=order-view&id=<?php echo $order['id']; ?>" class="btn btn-sm btn-outline-primary py-0 px-2" title="View" style="font-size: 0.75rem;">
                        <i class="fas fa-eye"></i>
                    </a>
                    <a href="index.php?page=edit-order&id=<?php echo $order['id']; ?>" class="btn btn-sm btn-outline-info py-0 px-2" title="Edit" style="font-size: 0.75rem;">
                        <i class="fas fa-edit"></i>
                    </a>
                    <a href="pages/invoice-print.php?id=<?php echo $order['id']; ?>" target="_blank" data-no-pjax class="btn btn-sm btn-outline-secondary py-0 px-2" title="Invoice" style="font-size: 0.75rem;">
                        <i class="fas fa-print"></i>
                    </a>
                    <button type="button" class="btn btn-sm btn-outline-danger py-0 px-2" title="Delete" onclick="deleteOrder(<?php echo $order['id']; ?>)" style="font-size: 0.75rem;">
                        <i class="fas fa-trash"></i>
                    </button>
                </div>
            </td>
          </tr>
          <?php endforeach; ?>
      <?php else: ?>
          <tr><td colspan="9"><?php adminEmptyState('কোনো অর্ডার পাওয়া যায়নি', 'ফিল্টার পরিবর্তন করুন অথবা নতুন অর্ডার আসার অপেক্ষা করুন', 'fa-shopping-bag'); ?></td></tr>
      <?php endif; ?>
    </tbody>
  </table>
</div>
</div>

<!-- Pagination -->
<?php if($total_pages > 1): ?>
<div class="d-flex justify-content-between align-items-center mt-4 flex-wrap gap-2">
    <div class="text-muted small">
        Showing <?php echo $offset + 1; ?>-<?php echo min($offset + $per_page, $total_orders); ?> of <?php echo $total_orders; ?> orders
    </div>
    <nav>
        <ul class="pagination pagination-sm mb-0">
            <!-- Prev -->
            <li class="page-item <?php echo $current_page <= 1 ? 'disabled' : ''; ?>">
                <a class="page-link" href="<?php echo buildFilterUrl(['pg' => $current_page - 1]); ?>">&laquo;</a>
            </li>
            
            <?php 
            $start_page = max(1, $current_page - 2);
            $end_page = min($total_pages, $current_page + 2);
            
            if ($start_page > 1): ?>
                <li class="page-item"><a class="page-link" href="<?php echo buildFilterUrl(['pg' => 1]); ?>">1</a></li>
                <?php if ($start_page > 2): ?><li class="page-item disabled"><span class="page-link">…</span></li><?php endif; ?>
            <?php endif;
            
            for ($p = $start_page; $p <= $end_page; $p++): ?>
                <li class="page-item <?php echo $p == $current_page ? 'active' : ''; ?>">
                    <a class="page-link" href="<?php echo buildFilterUrl(['pg' => $p]); ?>"><?php echo $p; ?></a>
                </li>
            <?php endfor;
            
            if ($end_page < $total_pages): ?>
                <?php if ($end_page < $total_pages - 1): ?><li class="page-item disabled"><span class="page-link">…</span></li><?php endif; ?>
                <li class="page-item"><a class="page-link" href="<?php echo buildFilterUrl(['pg' => $total_pages]); ?>"><?php echo $total_pages; ?></a></li>
            <?php endif; ?>
            
            <!-- Next -->
            <li class="page-item <?php echo $current_page >= $total_pages ? 'disabled' : ''; ?>">
                <a class="page-link" href="<?php echo buildFilterUrl(['pg' => $current_page + 1]); ?>">&raquo;</a>
            </li>
        </ul>
    </nav>
    
    <!-- Per Page Selector -->
    <div class="d-flex align-items-center gap-2">
        <span class="text-muted small">Per page:</span>
        <select class="form-select form-select-sm" style="width: 70px;" onchange="changePerPage(this.value)">
            <option value="20" <?php echo $per_page==20?'selected':''; ?>>20</option>
            <option value="50" <?php echo $per_page==50?'selected':''; ?>>50</option>
            <option value="100" <?php echo $per_page==100?'selected':''; ?>>100</option>
        </select>
    </div>
</div>
<?php endif; ?>

<!-- Quick View Modal -->
<div class="modal fade" id="quickViewModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-scrollable">
        <div class="modal-content" style="border-radius: 16px; border: none;">
            <div class="modal-header bg-dark text-white" style="border-radius: 16px 16px 0 0;">
                <h6 class="modal-title fw-bold"><i class="fas fa-bolt me-2 text-warning"></i>Quick View — <span id="qvTrackingId"></span></h6>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body p-0" id="qvBody">
                <div class="text-center py-5"><div class="spinner-border text-primary"></div></div>
            </div>
            <div class="modal-footer py-2">
                <a href="#" class="btn btn-sm btn-outline-secondary" id="qvInvoiceBtn" target="_blank" data-no-pjax><i class="fas fa-print me-1"></i>Invoice</a>
                <a href="#" class="btn btn-sm btn-outline-info" id="qvEditBtn"><i class="fas fa-edit me-1"></i>Edit</a>
                <a href="#" class="btn btn-sm btn-primary" id="qvViewBtn"><i class="fas fa-eye me-1"></i>Full Details</a>
            </div>
        </div>
    </div>
</div>

<style>
    .inline-status-select { cursor: pointer; transition: all 0.2s; }
    .inline-status-select:hover { opacity: 0.9; }
    .inline-status-select:focus { box-shadow: 0 0 0 2px rgba(59,130,246,0.3); }
    .bulk-check:checked { background-color: #3b82f6; border-color: #3b82f6; }
    .pagination .page-link { border-radius: 8px !important; margin: 0 2px; border: none; color: #475569; }
    .pagination .page-item.active .page-link { background: var(--sidebar-active, #3b82f6); color: white; }
    .copy-feedback { position: absolute; background: #10b981; color: white; font-size: 0.6rem; padding: 2px 6px; border-radius: 4px; top: -20px; left: 0; animation: fadeUp 1s forwards; }
    @keyframes fadeUp { to { opacity: 0; transform: translateY(-10px); } }
    #statusTabs .btn { transition: all 0.15s ease; }
    #statusTabs .btn:hover { transform: translateY(-1px); }
</style>

<script>
// --- Custom Date Toggle ---
function toggleCustomDate(el) {
    document.getElementById('customDateRow').style.display = el.value === 'custom' ? 'block' : 'none';
}

// --- Filter Form SPA Submit ---
document.getElementById('orderFilterForm')?.addEventListener('submit', function(e) {
    e.preventDefault();
    const formData = new FormData(this);
    const params = new URLSearchParams();
    for (const [key, value] of formData.entries()) {
        if (value) params.append(key, value);
    }
    const url = 'index.php?' + params.toString();
    if (typeof loadPage === 'function') {
        loadPage(url);
    } else {
        window.location.href = url;
    }
});

// --- Per Page ---
function changePerPage(val) {
    const url = '<?php echo buildFilterUrl([]); ?>&per_page=' + val;
    if (typeof loadPage === 'function') loadPage(url);
    else window.location.href = url;
}

// --- Copy Phone ---
function copyPhone(phone, btn) {
    navigator.clipboard.writeText(phone).then(() => {
        const feedback = document.createElement('span');
        feedback.className = 'copy-feedback';
        feedback.textContent = 'Copied!';
        btn.style.position = 'relative';
        btn.appendChild(feedback);
        setTimeout(() => feedback.remove(), 1000);
    });
}

// --- Inline Status Change ---
function inlineStatusChange(select) {
    const orderId = select.dataset.orderId;
    const status = select.value;
    select.style.opacity = '0.5';
    
    const formData = new FormData();
    formData.append('order_id', orderId);
    formData.append('order_status', status);
    
    fetch('actions/inline-order-status.php', {
        method: 'POST',
        body: formData,
        headers: { 'X-Requested-With': 'XMLHttpRequest' }
    })
    .then(res => res.json())
    .then(data => {
        select.style.opacity = '1';
        if (data.success) {
            const colors = {
                'Pending': {bg:'#fef3c7', fg:'#92400e'},
                'Processing': {bg:'#dbeafe', fg:'#1e40af'},
                'Shipped': {bg:'#e0e7ff', fg:'#3730a3'},
                'Delivered': {bg:'#d1fae5', fg:'#065f46'},
                'Cancelled': {bg:'#fee2e2', fg:'#991b1b'}
            };
            select.style.backgroundColor = colors[status]?.bg || '#f1f5f9';
            select.style.color = colors[status]?.fg || '#475569';
        } else {
            alert('Error: ' + data.message);
        }
    })
    .catch(() => { select.style.opacity = '1'; });
}

// --- Bulk Selection ---
function toggleSelectAll(checkbox) {
    document.querySelectorAll('.bulk-check').forEach(cb => cb.checked = checkbox.checked);
    updateBulkBar();
}

function updateBulkBar() {
    const checked = document.querySelectorAll('.bulk-check:checked');
    const bar = document.getElementById('bulkBar');
    document.getElementById('bulkCount').textContent = checked.length;
    bar.classList.toggle('d-none', checked.length === 0);
}

function clearBulkSelection() {
    document.querySelectorAll('.bulk-check').forEach(cb => cb.checked = false);
    document.getElementById('selectAll').checked = false;
    updateBulkBar();
}

function applyBulkAction() {
    const status = document.getElementById('bulkStatusSelect').value;
    if (!status) { alert('Please select a status'); return; }
    
    const checked = document.querySelectorAll('.bulk-check:checked');
    if (checked.length === 0) return;
    
    if (!confirm('Change ' + checked.length + ' order(s) to "' + status + '"?')) return;
    
    const formData = new FormData();
    formData.append('order_status', status);
    checked.forEach(cb => formData.append('order_ids[]', cb.value));
    
    fetch('actions/bulk-order-status.php', {
        method: 'POST',
        body: formData,
        headers: { 'X-Requested-With': 'XMLHttpRequest' }
    })
    .then(res => res.json())
    .then(data => {
        if (data.success) {
            if (typeof loadPage === 'function') {
                loadPage(window.location.href.replace(/&?success=[^&]*/, '') + '&success=' + encodeURIComponent(data.message));
            } else {
                window.location.reload();
            }
        } else {
            alert('Error: ' + data.message);
        }
    });
}

// --- Bulk Send to Steadfast ---
function bulkSendCourier() {
    const checked = Array.from(document.querySelectorAll('.bulk-check:checked'));
    if (checked.length === 0) return;

    const eligible = checked.filter(cb => cb.dataset.hasCourier === '0');
    if (eligible.length === 0) {
        alert('Selected orders are already sent to courier.');
        return;
    }
    if (eligible.length > 20) {
        alert('Max 20 orders per batch. Please select fewer orders.');
        return;
    }
    if (!confirm(eligible.length + ' order(s) will be sent to Steadfast. Continue?')) return;

    const btn = document.getElementById('bulkCourierBtn');
    btn.disabled = true;
    btn.innerHTML = '<i class="fas fa-spinner fa-spin me-1"></i>Sending...';

    const formData = new FormData();
    eligible.forEach(cb => formData.append('order_ids[]', cb.value));

    fetch('actions/bulk-send-steadfast.php', {
        method: 'POST',
        body: formData,
        headers: { 'X-Requested-With': 'XMLHttpRequest' }
    })
    .then(res => res.json())
    .then(data => {
        btn.disabled = false;
        btn.innerHTML = '<i class="fas fa-truck-fast me-1"></i>Send to Steadfast';
        if (data.success) {
            let msg = data.sent + ' sent';
            if (data.skipped) msg += ', ' + data.skipped + ' skipped';
            if (data.failed && data.failed.length) msg += ', ' + data.failed.length + ' failed:\n' + data.failed.join('\n');
            alert(msg);
            if (typeof loadPage === 'function') loadPage(window.location.href);
            else window.location.reload();
        } else {
            alert('Error: ' + (data.message || 'Unknown error'));
        }
    })
    .catch(() => {
        btn.disabled = false;
        btn.innerHTML = '<i class="fas fa-truck-fast me-1"></i>Send to Steadfast';
        alert('Network error');
    });
}

// --- Quick View ---
function quickView(orderId) {
    const modalEl = document.getElementById('quickViewModal');
    const modal = bootstrap.Modal.getOrCreateInstance(modalEl);
    const body = document.getElementById('qvBody');
    body.innerHTML = '<div class="text-center py-5"><div class="spinner-border text-primary"></div></div>';
    document.getElementById('qvTrackingId').textContent = '...';
    document.getElementById('qvViewBtn').href = 'index.php?page=order-view&id=' + orderId;
    document.getElementById('qvEditBtn').href = 'index.php?page=edit-order&id=' + orderId;
    document.getElementById('qvInvoiceBtn').href = 'pages/invoice-print.php?id=' + orderId;
    modal.show();

    fetch('actions/order-quick-view.php?id=' + orderId, {
        headers: { 'X-Requested-With': 'XMLHttpRequest' }
    })
    .then(res => res.json())
    .then(data => {
        if (!data.success) {
            body.innerHTML = '<div class="alert alert-danger m-3">' + (data.message || 'Failed to load') + '</div>';
            return;
        }
        const o = data.order;
        document.getElementById('qvTrackingId').textContent = o.tracking_id;

        const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
        const money = n => '৳' + Number(n).toLocaleString('en-US');

        let itemsHtml = data.items.map(i => `
            <div class="d-flex align-items-center gap-2 py-2 border-bottom px-3">
                <img src="../${esc(i.image)}" width="42" height="42" class="rounded" style="object-fit:cover;">
                <div class="flex-grow-1">
                    <div class="fw-semibold small">${esc(i.name)}</div>
                    ${i.variant ? '<div class="text-muted" style="font-size:0.7rem;"><i class="fas fa-layer-group me-1"></i>' + esc(i.variant) + '</div>' : ''}
                </div>
                <div class="text-end small">
                    <div>${money(i.price)} × ${i.qty}</div>
                    <div class="fw-bold">${money(i.price * i.qty)}</div>
                </div>
            </div>
        `).join('');

        const h = data.history;
        const statusColors = {'Pending':'warning','Processing':'primary','Shipped':'info','Delivered':'success','Cancelled':'danger'};

        body.innerHTML = `
            <div class="row g-0">
                <div class="col-md-7 border-end">
                    <div class="px-3 pt-3 pb-1 d-flex justify-content-between">
                        <h6 class="fw-bold small text-uppercase text-muted mb-0">Items (${data.items.length})</h6>
                        <span class="badge bg-${statusColors[o.order_status] || 'secondary'}">${esc(o.order_status)}</span>
                    </div>
                    ${itemsHtml}
                    <div class="px-3 py-2 small">
                        <div class="d-flex justify-content-between"><span class="text-muted">Subtotal</span><span>${money(o.subtotal)}</span></div>
                        ${o.discount_amount > 0 ? '<div class="d-flex justify-content-between text-success"><span>Discount' + (o.coupon_code ? ' (' + esc(o.coupon_code) + ')' : '') + '</span><span>-' + money(o.discount_amount) + '</span></div>' : ''}
                        <div class="d-flex justify-content-between fw-bold border-top mt-1 pt-1"><span>Total</span><span class="text-primary">${money(o.total_amount)}</span></div>
                    </div>
                </div>
                <div class="col-md-5">
                    <div class="p-3">
                        <h6 class="fw-bold small text-uppercase text-muted">Customer</h6>
                        <div class="fw-bold">${esc(o.customer_name)}</div>
                        <div class="small text-muted"><i class="fas fa-phone-alt me-1"></i>${esc(o.customer_phone)}</div>
                        ${o.customer_email ? '<div class="small text-muted"><i class="fas fa-envelope me-1"></i>' + esc(o.customer_email) + '</div>' : ''}
                        <div class="small text-muted mt-1"><i class="fas fa-map-marker-alt me-1"></i>${esc(o.shipping_address)}</div>
                        <div class="d-flex gap-2 mt-2 flex-wrap">
                            <span class="badge bg-light text-dark border">Orders: ${h.total}</span>
                            <span class="badge bg-success-subtle text-success border">Delivered: ${h.delivered}</span>
                            <span class="badge bg-danger-subtle text-danger border">Cancelled: ${h.cancelled}</span>
                            <span class="badge bg-primary-subtle text-primary border">Spent: ${money(h.spent)}</span>
                        </div>
                        <hr>
                        <h6 class="fw-bold small text-uppercase text-muted">Payment & Courier</h6>
                        <div class="small"><span class="text-muted">Method:</span> ${esc(o.payment_method)} <span class="badge ${o.payment_status === 'Paid' ? 'bg-success' : (o.payment_status === 'Failed' ? 'bg-danger' : 'bg-warning text-dark')}" style="font-size:0.65rem;">${esc(o.payment_status)}</span></div>
                        <div class="small mt-1"><span class="text-muted">Courier:</span> ${o.courier_consignment_id ? esc(o.courier_status || 'sent') + ' <span class="text-muted">(CID: ' + esc(o.courier_consignment_id) + ')</span>' : '<span class="text-muted">Not sent</span>'}</div>
                        <div class="small mt-1"><span class="text-muted">Placed:</span> ${esc(o.created_at)}</div>
                    </div>
                </div>
            </div>
        `;
    })
    .catch(() => {
        body.innerHTML = '<div class="alert alert-danger m-3">Failed to load order data.</div>';
    });
}

// --- Delete Order ---
function deleteOrder(id) {
    if(confirm('Are you sure you want to delete this order? This action cannot be undone.')) {
        fetch('actions/order-delete.php?id=' + id, {
            headers: { 'X-Requested-With': 'XMLHttpRequest' }
        })
        .then(response => response.json())
        .then(data => {
            if(data.success) {
                if (typeof loadPage === 'function') {
                    loadPage('index.php?page=orders&success=' + encodeURIComponent(data.message));
                } else {
                    window.location.href = 'index.php?page=orders&success=' + encodeURIComponent(data.message);
                }
            } else {
                alert('Error: ' + data.message);
            }
        })
        .catch(error => {
            console.error('Delete error:', error);
            window.location.href = 'actions/order-delete.php?id=' + id;
        });
    }
}
</script>
