<?php
// admin/pages/order-view.php — Advanced all-in-one order detail
$id = $_GET['id'] ?? null;

if (!$id) {
    echo "<h2>Invalid Order ID</h2>";
    return;
}

// Fetch Order Details
$stmt = $pdo->prepare("SELECT o.*, u.name as user_name, u.email as user_email FROM orders o LEFT JOIN users u ON o.user_id = u.id WHERE o.id = ?");
$stmt->execute([$id]);
$order = $stmt->fetch();

if (!$order) {
    echo "<h2>Order Not Found</h2>";
    return;
}

// Fetch Order Items
$stmt_items = $pdo->prepare("SELECT oi.*, p.name as product_name, p.image, p.product_type, p.slug FROM order_items oi JOIN products p ON oi.product_id = p.id WHERE oi.order_id = ?");
$stmt_items->execute([$id]);
$order_items = $stmt_items->fetchAll();

$has_digital_items = false;
$items_subtotal = 0;
$total_qty = 0;
foreach ($order_items as $item) {
    if ($item['product_type'] === 'digital') {
        $has_digital_items = true;
    }
    $items_subtotal += $item['price'] * $item['qty'];
    $total_qty += $item['qty'];
}

// --- Customer intelligence (history by phone) ---
$cust_history = ['total' => 0, 'delivered' => 0, 'cancelled' => 0, 'spent' => 0];
$prev_orders = [];
if (!empty($order['customer_phone'])) {
    $h_stmt = $pdo->prepare("
        SELECT COUNT(*) AS total,
               SUM(order_status = 'Delivered') AS delivered,
               SUM(order_status = 'Cancelled') AS cancelled,
               COALESCE(SUM(CASE WHEN order_status != 'Cancelled' THEN total_amount END), 0) AS spent
        FROM orders WHERE customer_phone = ?
    ");
    $h_stmt->execute([$order['customer_phone']]);
    $h = $h_stmt->fetch();
    if ($h) {
        $cust_history = [
            'total' => (int)$h['total'],
            'delivered' => (int)$h['delivered'],
            'cancelled' => (int)$h['cancelled'],
            'spent' => (float)$h['spent'],
        ];
    }

    $p_stmt = $pdo->prepare("SELECT id, tracking_id, total_amount, order_status, created_at FROM orders WHERE customer_phone = ? AND id != ? ORDER BY created_at DESC LIMIT 5");
    $p_stmt->execute([$order['customer_phone'], $id]);
    $prev_orders = $p_stmt->fetchAll();
}

// --- Internal notes (table created lazily on first note) ---
$order_notes = [];
try {
    $n_stmt = $pdo->prepare("SELECT * FROM order_notes WHERE order_id = ? ORDER BY created_at DESC LIMIT 30");
    $n_stmt->execute([$id]);
    $order_notes = $n_stmt->fetchAll();
} catch (PDOException $e) {
    // table doesn't exist yet — created automatically when first note is added
}

// --- Public order link ---
$public_link = '';
try {
    require_once __DIR__ . '/../../app/Helpers/OrderAccessHelper.php';
    $token = OrderAccessHelper::getOrCreateToken($pdo, (int)$id);
    $public_link = SITE_URL . '/order-summary/' . $token;
} catch (Throwable $e) {}

// --- Status stepper config ---
$steps = ['Pending', 'Processing', 'Shipped', 'Delivered'];
$current_step_idx = array_search($order['order_status'], $steps);
$is_cancelled = $order['order_status'] === 'Cancelled';

$status_badge_class = match($order['order_status']) {
    'Pending' => 'bg-warning text-dark',
    'Processing' => 'bg-primary',
    'Shipped' => 'bg-info text-dark',
    'Delivered' => 'bg-success',
    'Cancelled' => 'bg-danger',
    default => 'bg-secondary'
};

$wa_number = preg_replace('/[^0-9]/', '', $order['customer_phone'] ?? '');
$wa_link = 'https://wa.me/88' . $wa_number . '?text=' . urlencode('আসসালামু আলাইকুম। আপনার অর্ডার #' . $order['tracking_id'] . ' সম্পর্কে জানাচ্ছি:');
?>

<?php adminFlashMessages(); ?>
<?php adminPageHeader('অর্ডার #' . $order['tracking_id'], 'অর্ডার বিস্তারিত, আইটেম ও ইনভয়েস দেখুন — all in one', [
    ['label' => 'Print Invoice', 'icon' => 'fa-print', 'url' => 'pages/invoice-print.php?id=' . $order['id'], 'class' => 'btn btn-dark btn-sm', 'target' => '_blank', 'data-no-pjax' => true],
    ['label' => 'Edit Order', 'icon' => 'fa-edit', 'url' => 'index.php?page=edit-order&id=' . $order['id'], 'class' => 'btn btn-outline-info btn-sm'],
    ['label' => 'অর্ডার তালিকা', 'icon' => 'fa-arrow-left', 'url' => 'index.php?page=orders', 'class' => 'btn btn-outline-secondary btn-sm'],
]); ?>

<!-- Status Progress Tracker -->
<div class="admin-list-shell mb-4">
    <div class="p-3 px-4">
        <?php if ($is_cancelled): ?>
            <div class="d-flex align-items-center gap-3">
                <div class="rounded-circle bg-danger d-flex align-items-center justify-content-center" style="width: 44px; height: 44px;">
                    <i class="fas fa-times text-white"></i>
                </div>
                <div>
                    <div class="fw-bold text-danger">Order Cancelled</div>
                    <div class="small text-muted">এই অর্ডারটি বাতিল করা হয়েছে। Status পরিবর্তন করে পুনরায় active করা যাবে।</div>
                </div>
            </div>
        <?php else: ?>
            <div class="d-flex align-items-center justify-content-between position-relative ov-stepper">
                <?php foreach ($steps as $idx => $step):
                    $done = $current_step_idx !== false && $idx <= $current_step_idx;
                    $active = $current_step_idx !== false && $idx === $current_step_idx;
                    $icons = ['fa-clock', 'fa-cogs', 'fa-truck', 'fa-check'];
                ?>
                <div class="text-center flex-fill position-relative ov-step <?php echo $done ? 'done' : ''; ?>">
                    <?php if ($idx > 0): ?>
                    <div class="ov-step-line <?php echo $done ? 'done' : ''; ?>"></div>
                    <?php endif; ?>
                    <div class="rounded-circle mx-auto d-flex align-items-center justify-content-center ov-step-dot <?php echo $done ? 'done' : ''; ?> <?php echo $active ? 'active' : ''; ?>">
                        <i class="fas <?php echo $icons[$idx]; ?>"></i>
                    </div>
                    <div class="small fw-bold mt-1 <?php echo $done ? 'text-success' : 'text-muted'; ?>" style="font-size: 0.72rem;"><?php echo $step; ?></div>
                </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </div>
</div>

<div class="row g-4">
    <!-- Left Column -->
    <div class="col-lg-8">
        <!-- Ordered Items -->
        <div class="admin-list-shell mb-4">
            <div class="admin-list-shell-header">
                <h2 class="admin-list-shell-title"><i class="fas fa-box-open me-2 text-success"></i>Ordered Items</h2>
                <span class="badge bg-light text-secondary border"><?php echo count($order_items); ?> item(s) • <?php echo $total_qty; ?> pcs</span>
            </div>
            <div class="admin-table-wrap">
                    <table class="admin-table admin-table-mobile-cards mb-0">
                        <thead>
                            <tr>
                                <th scope="col">Product</th>
                                <th scope="col">Price</th>
                                <th scope="col">Qty</th>
                                <th scope="col" class="text-end">Total</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach($order_items as $item): ?>
                            <tr>
                                <td>
                                    <div class="d-flex align-items-center">
                                        <img src="../<?php echo $item['image']; ?>" width="44" height="44" class="rounded me-2 border" style="object-fit: cover;">
                                        <div>
                                            <span class="d-block fw-semibold"><?php echo htmlspecialchars($item['product_name']); ?></span>
                                            <div class="d-flex align-items-center gap-2">
                                                <?php if (!empty($item['variant_label'])): ?>
                                                <small class="text-muted"><i class="fas fa-layer-group me-1"></i><?php echo htmlspecialchars($item['variant_label']); ?></small>
                                                <?php endif; ?>
                                                <?php if ($item['product_type'] === 'digital'): ?>
                                                <span class="badge bg-purple" style="background: #7c3aed; font-size: 0.6rem;">Digital</span>
                                                <?php endif; ?>
                                                <?php if (!empty($item['slug'])): ?>
                                                <a href="<?php echo BASE_URL; ?>/product/<?php echo htmlspecialchars($item['slug']); ?>" target="_blank" class="small text-decoration-none" style="font-size: 0.68rem;" title="View on site">
                                                    <i class="fas fa-external-link-alt"></i>
                                                </a>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </div>
                                </td>
                                <td>৳<?php echo number_format($item['price']); ?></td>
                                <td><?php echo $item['qty']; ?></td>
                                <td class="text-end fw-bold">৳<?php echo number_format($item['price'] * $item['qty']); ?></td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                        <tfoot class="bg-light">
                            <tr>
                                <td colspan="3" class="text-end text-muted small py-1">Subtotal:</td>
                                <td class="text-end small py-1">৳<?php echo number_format($items_subtotal); ?></td>
                            </tr>
                            <?php if ((float)$order['discount_amount'] > 0): ?>
                            <tr>
                                <td colspan="3" class="text-end text-success small py-1">
                                    Discount<?php echo $order['coupon_code'] ? ' (Coupon: ' . htmlspecialchars($order['coupon_code']) . ')' : ''; ?>:
                                </td>
                                <td class="text-end text-success small py-1">-৳<?php echo number_format($order['discount_amount']); ?></td>
                            </tr>
                            <?php endif; ?>
                            <?php $shipping_diff = $order['total_amount'] - ($items_subtotal - $order['discount_amount']);
                            if (abs($shipping_diff) > 0.01): ?>
                            <tr>
                                <td colspan="3" class="text-end text-muted small py-1">Delivery Charge:</td>
                                <td class="text-end small py-1">৳<?php echo number_format($shipping_diff); ?></td>
                            </tr>
                            <?php endif; ?>
                            <tr>
                                <th colspan="3" class="text-end">Total Amount:</th>
                                <th class="text-end text-primary h5 mb-0">৳<?php echo number_format($order['total_amount']); ?></th>
                            </tr>
                        </tfoot>
                    </table>
            </div>
        </div>

        <!-- Internal Notes -->
        <div class="admin-list-shell mb-4">
            <div class="admin-list-shell-header">
                <h2 class="admin-list-shell-title"><i class="fas fa-sticky-note me-2 text-warning"></i>Internal Notes</h2>
                <span class="badge bg-light text-secondary border" id="noteCount"><?php echo count($order_notes); ?></span>
            </div>
            <div class="p-3">
                <form id="noteForm" class="d-flex gap-2 mb-3">
                    <input type="text" class="form-control form-control-sm" id="noteInput" placeholder="অর্ডার সম্পর্কে নোট লিখুন (শুধু admin দেখবে)..." maxlength="1000" autocomplete="off">
                    <button type="submit" class="btn btn-sm btn-warning fw-bold px-3" id="noteBtn"><i class="fas fa-plus me-1"></i>Add</button>
                </form>
                <div id="notesList">
                    <?php if (empty($order_notes)): ?>
                        <p class="text-muted small text-center mb-0 py-2" id="noNotesMsg">এখনো কোনো নোট নেই।</p>
                    <?php else: ?>
                        <?php foreach ($order_notes as $note): ?>
                        <div class="d-flex gap-2 border-bottom py-2 note-row">
                            <div class="rounded-circle bg-warning-subtle text-warning-emphasis d-flex align-items-center justify-content-center flex-shrink-0 fw-bold" style="width: 30px; height: 30px; font-size: 0.7rem;">
                                <?php echo strtoupper(substr($note['admin_name'], 0, 2)); ?>
                            </div>
                            <div>
                                <div class="small"><?php echo nl2br(htmlspecialchars($note['note'])); ?></div>
                                <div class="text-muted" style="font-size: 0.65rem;"><?php echo htmlspecialchars($note['admin_name']); ?> • <?php echo date('d M, h:i A', strtotime($note['created_at'])); ?></div>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <!-- Order Meta -->
        <div class="admin-list-shell mb-4">
            <div class="admin-list-shell-header">
                <h2 class="admin-list-shell-title"><i class="fas fa-info-circle me-2 text-secondary"></i>Order Meta</h2>
            </div>
            <div class="p-3">
                <div class="row g-3 small">
                    <div class="col-md-4">
                        <div class="text-muted" style="font-size: 0.7rem;">PLACED AT</div>
                        <div class="fw-semibold"><?php echo date('d M Y, h:i A', strtotime($order['created_at'])); ?></div>
                    </div>
                    <div class="col-md-4">
                        <div class="text-muted" style="font-size: 0.7rem;">PAYMENT</div>
                        <div class="fw-semibold"><?php echo $order['payment_method']; ?> — <span class="badge <?php echo $order['payment_status'] === 'Paid' ? 'bg-success' : ($order['payment_status'] === 'Failed' ? 'bg-danger' : 'bg-warning text-dark'); ?>" style="font-size: 0.65rem;"><?php echo $order['payment_status']; ?></span></div>
                    </div>
                    <div class="col-md-4">
                        <div class="text-muted" style="font-size: 0.7rem;">IP ADDRESS</div>
                        <div class="fw-semibold"><?php echo htmlspecialchars($order['ip_address'] ?: 'N/A'); ?></div>
                    </div>
                    <?php if ($public_link): ?>
                    <div class="col-md-8">
                        <div class="text-muted" style="font-size: 0.7rem;">PUBLIC ORDER LINK (customer-কে পাঠাতে পারবেন)</div>
                        <div class="d-flex align-items-center gap-2">
                            <input type="text" class="form-control form-control-sm bg-light" value="<?php echo htmlspecialchars($public_link); ?>" readonly id="publicLinkInput" style="font-size: 0.72rem;">
                            <button type="button" class="btn btn-sm btn-outline-primary flex-shrink-0" onclick="copyText('<?php echo htmlspecialchars($public_link, ENT_QUOTES); ?>', this)"><i class="fas fa-copy"></i></button>
                        </div>
                    </div>
                    <?php endif; ?>
                    <?php if (!empty($order['user_agent'])): ?>
                    <div class="col-md-4">
                        <div class="text-muted" style="font-size: 0.7rem;">DEVICE</div>
                        <div class="text-muted text-truncate" title="<?php echo htmlspecialchars($order['user_agent']); ?>" style="font-size: 0.7rem;"><?php echo htmlspecialchars($order['user_agent']); ?></div>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <!-- Right Column -->
    <div class="col-lg-4">
        <!-- Manage Order -->
        <div class="admin-list-shell mb-4">
            <div class="admin-list-shell-header">
                <h2 class="admin-list-shell-title"><i class="fas fa-sliders-h me-2 text-primary"></i>Manage Order</h2>
                <span class="badge <?php echo $status_badge_class; ?>"><?php echo $order['order_status']; ?></span>
            </div>
            <div class="p-3">
                <form action="actions/update-order-status.php" method="POST">
                    <input type="hidden" name="order_id" value="<?php echo $order['id']; ?>">
                    <div class="mb-3">
                        <label class="form-label small fw-bold text-muted">Order Status</label>
                        <select name="order_status" class="form-select form-select-sm">
                            <option value="Pending" <?php echo $order['order_status'] == 'Pending' ? 'selected' : ''; ?>>⏳ Pending</option>
                            <option value="Processing" <?php echo $order['order_status'] == 'Processing' ? 'selected' : ''; ?>>🔄 Processing</option>
                            <option value="Shipped" <?php echo $order['order_status'] == 'Shipped' ? 'selected' : ''; ?>>📦 Shipped</option>
                            <option value="Delivered" <?php echo $order['order_status'] == 'Delivered' ? 'selected' : ''; ?>>✅ Delivered</option>
                            <option value="Cancelled" <?php echo $order['order_status'] == 'Cancelled' ? 'selected' : ''; ?>>❌ Cancelled</option>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label class="form-label small fw-bold text-muted">Payment Status</label>
                        <select name="payment_status" class="form-select form-select-sm">
                            <option value="Pending" <?php echo $order['payment_status'] == 'Pending' ? 'selected' : ''; ?>>Pending</option>
                            <option value="Paid" <?php echo $order['payment_status'] == 'Paid' ? 'selected' : ''; ?>>Paid</option>
                            <option value="Failed" <?php echo $order['payment_status'] == 'Failed' ? 'selected' : ''; ?>>Failed</option>
                        </select>
                    </div>
                    <button type="submit" class="btn btn-primary btn-sm w-100 fw-bold">Update Order</button>
                </form>
            </div>
        </div>

        <!-- Courier -->
        <div class="admin-list-shell mb-4">
            <div class="admin-list-shell-header">
                <h2 class="admin-list-shell-title"><i class="fas fa-truck-fast me-2 text-warning"></i>Steadfast Courier</h2>
            </div>
            <div class="p-3">
                <?php if($order['courier_consignment_id']): ?>
                    <div class="small mb-1 d-flex justify-content-between">
                        <span class="text-muted">Tracking:</span>
                        <span class="fw-bold"><?php echo htmlspecialchars($order['tracking_id']); ?>
                            <button type="button" class="btn btn-link btn-sm p-0 text-muted" onclick="copyText('<?php echo htmlspecialchars($order['tracking_id'], ENT_QUOTES); ?>', this)"><i class="fas fa-copy" style="font-size: 0.65rem;"></i></button>
                        </span>
                    </div>
                    <div class="small mb-1 d-flex justify-content-between">
                        <span class="text-muted">Consignment ID:</span>
                        <span class="fw-bold"><?php echo $order['courier_consignment_id']; ?></span>
                    </div>
                    <div class="small mb-3 d-flex justify-content-between align-items-center">
                        <span class="text-muted">Status:</span>
                        <?php $cs = strtolower((string)$order['courier_status']);
                        $cs_class = str_contains($cs, 'delivered') ? 'bg-success' : (str_contains($cs, 'cancel') ? 'bg-danger' : 'bg-info text-dark'); ?>
                        <span class="badge <?php echo $cs_class; ?>" id="courier_status_badge"><?php echo $order['courier_status'] ?: 'sent'; ?></span>
                    </div>
                    <div class="d-flex gap-2">
                        <form action="actions/sync-steadfast-status.php" method="POST" id="syncStatusForm" class="flex-fill">
                            <input type="hidden" name="order_id" value="<?php echo $order['id']; ?>">
                            <button type="submit" class="btn btn-sm btn-outline-info w-100 fw-bold" id="syncBtn">
                                <i class="fas fa-sync-alt me-1"></i>Sync
                            </button>
                        </form>
                        <a href="https://steadfast.com.bd/t/<?php echo urlencode($order['tracking_id']); ?>" target="_blank" class="btn btn-sm btn-outline-secondary flex-fill fw-bold">
                            <i class="fas fa-external-link-alt me-1"></i>Track
                        </a>
                    </div>
                    <script>
                        document.getElementById('syncStatusForm').addEventListener('submit', function(e) {
                            const btn = document.getElementById('syncBtn');
                            btn.disabled = true;
                            btn.innerHTML = '<i class="fas fa-spinner fa-spin me-1"></i> Syncing...';
                        });
                    </script>
                <?php else: ?>
                    <div class="text-center">
                        <p class="text-muted small mb-3">Order not yet sent to Steadfast Courier.</p>
                        <form action="actions/send_to_steadfast.php" method="POST" onsubmit="this.querySelector('button').disabled = true;">
                            <input type="hidden" name="order_id" value="<?php echo $order['id']; ?>">
                            <button type="submit" class="btn btn-success btn-sm w-100 fw-bold">
                                <i class="fas fa-paper-plane me-2"></i>Send to Steadfast
                            </button>
                        </form>
                    </div>
                <?php endif; ?>
            </div>
        </div>

        <!-- Customer Intelligence -->
        <div class="admin-list-shell mb-4">
            <div class="admin-list-shell-header">
                <h2 class="admin-list-shell-title"><i class="fas fa-user-circle me-2 text-success"></i>Customer</h2>
            </div>
            <div class="p-3">
                <p class="mb-1 fw-bold"><?php echo htmlspecialchars($order['customer_name'] ?: $order['user_name'] ?: 'Guest'); ?></p>

                <div class="d-flex align-items-center gap-2 mb-1">
                    <span class="text-muted small"><i class="fas fa-phone-alt me-1"></i><?php echo htmlspecialchars($order['customer_phone']); ?></span>
                    <button type="button" class="btn btn-link btn-sm p-0 text-muted" onclick="copyText('<?php echo htmlspecialchars($order['customer_phone'], ENT_QUOTES); ?>', this)" title="Copy"><i class="fas fa-copy" style="font-size: 0.7rem;"></i></button>
                    <a href="tel:<?php echo htmlspecialchars($order['customer_phone']); ?>" class="btn btn-link btn-sm p-0 text-primary" title="Call"><i class="fas fa-phone" style="font-size: 0.75rem;"></i></a>
                    <a href="<?php echo $wa_link; ?>" target="_blank" class="btn btn-link btn-sm p-0 text-success" title="WhatsApp"><i class="fab fa-whatsapp" style="font-size: 0.85rem;"></i></a>
                </div>

                <p class="mb-2 text-muted small">
                    <i class="fas fa-envelope me-1"></i>
                    <?php echo htmlspecialchars($order['customer_email'] ?: ($order['user_email'] ?: 'N/A')); ?>
                </p>

                <!-- History badges -->
                <div class="d-flex gap-1 flex-wrap mb-2">
                    <span class="badge bg-light text-dark border" style="font-size: 0.65rem;">Orders: <?php echo $cust_history['total']; ?></span>
                    <span class="badge bg-success-subtle text-success border" style="font-size: 0.65rem;">Delivered: <?php echo $cust_history['delivered']; ?></span>
                    <span class="badge bg-danger-subtle text-danger border" style="font-size: 0.65rem;">Cancelled: <?php echo $cust_history['cancelled']; ?></span>
                    <span class="badge bg-primary-subtle text-primary border" style="font-size: 0.65rem;">Spent: ৳<?php echo number_format($cust_history['spent']); ?></span>
                </div>

                <div id="fraud-result" class="mb-2">
                    <button type="button" class="btn btn-sm btn-outline-warning fw-bold py-1 px-2" id="btn-fraud-check" style="font-size: 0.7rem;">
                        <i class="fas fa-shield-alt me-1"></i> Fraud Check (সব courier)
                    </button>
                </div>

                <?php if ($has_digital_items): ?>
                    <div class="mt-3 pt-3 border-top">
                        <h6 class="fw-bold mb-2 small text-uppercase text-muted" style="letter-spacing: 0.5px;">Digital Delivery</h6>
                        <div class="d-flex align-items-center justify-content-between mb-2">
                            <span class="small">Status:</span>
                            <span class="badge <?php 
                                echo match($order['digital_delivery_status']) {
                                    'Sent' => 'bg-success',
                                    'Failed' => 'bg-danger',
                                    'Pending' => 'bg-warning',
                                    default => 'bg-secondary'
                                };
                            ?>">
                                <?php echo $order['digital_delivery_status'] ?: 'N/A'; ?>
                            </span>
                        </div>
                        <?php if ($order['digital_delivery_at']): ?>
                            <p class="small text-muted mb-2">
                                <i class="fas fa-clock me-1"></i> <?php echo date('d M, Y H:i', strtotime($order['digital_delivery_at'])); ?>
                            </p>
                        <?php endif; ?>
                        <a href="actions/resend-digital-delivery.php?id=<?php echo $order['id']; ?>" 
                           class="btn btn-sm btn-outline-primary w-100 fw-bold" 
                           onclick="return confirm('Do you want to send/resend the digital delivery email?')">
                            <i class="fas fa-paper-plane me-1"></i> Send/Resend Email
                        </a>
                    </div>
                <?php endif; ?>

                <hr>
                <h6 class="fw-bold small d-flex justify-content-between align-items-center">
                    Shipping Address
                    <button type="button" class="btn btn-link btn-sm p-0 text-muted" onclick="copyText(document.getElementById('shipAddr').innerText, this)" title="Copy address"><i class="fas fa-copy" style="font-size: 0.7rem;"></i></button>
                </h6>
                <p class="small text-muted mb-0" id="shipAddr"><?php echo nl2br(htmlspecialchars($order['shipping_address'])); ?></p>
            </div>
        </div>

        <!-- Previous Orders -->
        <?php if (!empty($prev_orders)): ?>
        <div class="admin-list-shell mb-4">
            <div class="admin-list-shell-header">
                <h2 class="admin-list-shell-title"><i class="fas fa-history me-2 text-info"></i>এই Customer-এর আগের অর্ডার</h2>
            </div>
            <div class="p-0">
                <?php foreach ($prev_orders as $po): ?>
                <a href="index.php?page=order-view&id=<?php echo $po['id']; ?>" class="d-flex justify-content-between align-items-center px-3 py-2 border-bottom text-decoration-none prev-order-row">
                    <div>
                        <div class="fw-bold small text-dark"><?php echo htmlspecialchars($po['tracking_id']); ?></div>
                        <div class="text-muted" style="font-size: 0.68rem;"><?php echo date('d M Y', strtotime($po['created_at'])); ?></div>
                    </div>
                    <div class="text-end">
                        <div class="fw-bold small text-dark">৳<?php echo number_format($po['total_amount']); ?></div>
                        <span class="badge <?php 
                            echo match($po['order_status']) {
                                'Pending' => 'bg-warning text-dark',
                                'Processing' => 'bg-primary',
                                'Shipped' => 'bg-info text-dark',
                                'Delivered' => 'bg-success',
                                'Cancelled' => 'bg-danger',
                                default => 'bg-secondary'
                            };
                        ?>" style="font-size: 0.6rem;"><?php echo $po['order_status']; ?></span>
                    </div>
                </a>
                <?php endforeach; ?>
            </div>
        </div>
        <?php endif; ?>
    </div>
</div>

<style>
    .ov-stepper .ov-step-dot {
        width: 40px; height: 40px;
        background: #f1f5f9; color: #94a3b8;
        font-size: 0.85rem;
        position: relative; z-index: 2;
        transition: all 0.3s ease;
    }
    .ov-stepper .ov-step-dot.done { background: #10b981; color: white; }
    .ov-stepper .ov-step-dot.active { box-shadow: 0 0 0 4px rgba(16,185,129,0.25); }
    .ov-stepper .ov-step-line {
        position: absolute; top: 20px; right: 50%;
        width: 100%; height: 3px;
        background: #e2e8f0; z-index: 1;
    }
    .ov-stepper .ov-step-line.done { background: #10b981; }
    .prev-order-row:hover { background: #f8fafc; }
    .copy-feedback { position: absolute; background: #10b981; color: white; font-size: 0.6rem; padding: 2px 6px; border-radius: 4px; top: -20px; left: 0; white-space: nowrap; animation: fadeUp 1s forwards; z-index: 10; }
    @keyframes fadeUp { to { opacity: 0; transform: translateY(-10px); } }
</style>

<script>
// --- Copy helper with feedback ---
function copyText(text, btn) {
    const done = () => {
        const feedback = document.createElement('span');
        feedback.className = 'copy-feedback';
        feedback.textContent = 'Copied!';
        btn.style.position = 'relative';
        btn.appendChild(feedback);
        setTimeout(() => feedback.remove(), 1000);
    };
    if (navigator.clipboard && window.isSecureContext) {
        navigator.clipboard.writeText(text).then(done);
    } else {
        const ta = document.createElement('textarea');
        ta.value = text;
        ta.style.position = 'fixed';
        ta.style.opacity = '0';
        document.body.appendChild(ta);
        ta.select();
        try { document.execCommand('copy'); done(); } catch (e) {}
        ta.remove();
    }
}

// --- Internal Notes ---
document.getElementById('noteForm').addEventListener('submit', function(e) {
    e.preventDefault();
    const input = document.getElementById('noteInput');
    const note = input.value.trim();
    if (!note) return;

    const btn = document.getElementById('noteBtn');
    btn.disabled = true;

    const formData = new FormData();
    formData.append('order_id', '<?php echo (int)$order['id']; ?>');
    formData.append('note', note);

    fetch('actions/order-note-add.php', {
        method: 'POST',
        body: formData,
        headers: { 'X-Requested-With': 'XMLHttpRequest' }
    })
    .then(res => res.json())
    .then(data => {
        btn.disabled = false;
        if (!data.success) { alert('Error: ' + (data.message || 'Failed')); return; }
        input.value = '';

        const noMsg = document.getElementById('noNotesMsg');
        if (noMsg) noMsg.remove();

        const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
        const n = data.note;
        const row = document.createElement('div');
        row.className = 'd-flex gap-2 border-bottom py-2 note-row';
        row.innerHTML = `
            <div class="rounded-circle bg-warning-subtle text-warning-emphasis d-flex align-items-center justify-content-center flex-shrink-0 fw-bold" style="width: 30px; height: 30px; font-size: 0.7rem;">${esc(n.admin_name.substring(0, 2).toUpperCase())}</div>
            <div>
                <div class="small">${esc(n.note)}</div>
                <div class="text-muted" style="font-size: 0.65rem;">${esc(n.admin_name)} • ${esc(n.created_at)}</div>
            </div>
        `;
        const list = document.getElementById('notesList');
        list.insertBefore(row, list.firstChild);
        const count = document.getElementById('noteCount');
        count.textContent = parseInt(count.textContent || '0') + 1;
    })
    .catch(() => { btn.disabled = false; alert('Network error'); });
});

// --- Fraud Check ---
document.getElementById('btn-fraud-check').addEventListener('click', function() {
    const btn = this;
    const phone = '<?php echo $order['customer_phone']; ?>';
    const resultDiv = document.getElementById('fraud-result');
    
    btn.disabled = true;
    btn.innerHTML = '<i class="fas fa-spinner fa-spin me-1"></i> Checking...';
    
    const formData = new FormData();
    formData.append('phone', phone);
    
    fetch('actions/check-fraud.php', {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        if (data.status === 'success') {
            resultDiv.innerHTML = `
                <div class="alert alert-warning py-1 px-2 mt-1 mb-0" style="font-size: 0.75rem; border-radius: 8px;">
                    <div class="d-flex justify-content-between mb-1">
                        <span><strong>Delivered:</strong> ${data.delivered}</span>
                        <span><strong>Cancelled:</strong> ${data.cancelled}</span>
                    </div>
                    <div class="d-flex justify-content-between">
                        <span><strong>Total:</strong> ${data.total_order}</span>
                        <span class="text-danger"><strong>Fraud:</strong> ${data.fraud_reports || 0}</span>
                    </div>
                </div>
            `;
        } else {
            alert('Fraud Check Error: ' + data.message);
            btn.disabled = false;
            btn.innerHTML = '<i class="fas fa-shield-alt me-1"></i> Fraud Check (সব courier)';
        }
    })
    .catch(error => {
        console.error('Error:', error);
        alert('An error occurred during fraud check.');
        btn.disabled = false;
        btn.innerHTML = '<i class="fas fa-shield-alt me-1"></i> Fraud Check (সব courier)';
    });
});
</script>
