<?php
session_start();
require_once '../config/database.php';

if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header('Location: login.php');
    exit;
}

$page = isset($_GET['page']) ? $_GET['page'] : 'dashboard';
$is_ajax = !empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest';

require_once __DIR__ . '/includes/components/init.php';

if (!$is_ajax) {
    include 'includes/header.php';
    include 'includes/sidebar.php';
}

$role = $_SESSION['admin_role'] ?? 'guest';

$permissions = [
    'super_admin' => ['*'],
    'marketing' => [
        'dashboard', 'flash-sale', 'sliders', 'coupons',
        'google-dashboard', 'insights', 'reports', 'tracking-settings',
        'profile'
    ],
    'editor' => [
        'dashboard', 'profile',
        'products', 'add-product', 'edit-product', 'bulk-upload',
        'categories', 'edit-category',
        'menus', 'sliders', 'media', 'coupons',
        'blog-posts', 'add-blog-post', 'edit-blog-post',
        'page-manager', 'edit-page', 'homepage-builder',
        'landing-pages', 'add-landing-page', 'edit-landing-page'
    ],
    'moderator' => [
        'dashboard', 'profile',
        'orders', 'order-view', 'edit-order', 'update-order-status',
        'abandoned-carts', 'courier-dashboard',
        'customers', 'add-user', 'edit-user', 'user-details',
        'reports', 'insights', 'reviews', 'google-dashboard'
    ]
];

$has_access = false;
if ($role === 'super_admin') {
    $has_access = true;
} elseif (isset($permissions[$role]) && in_array($page, $permissions[$role])) {
    $has_access = true;
}

if (!$is_ajax) echo '<main class="content-body" id="pjax-container">';

$page_file = "pages/{$page}.php";

if (!$has_access) {
    echo '<div class="admin-flash error m-0"><i class="fas fa-lock me-2"></i><strong>Access Denied</strong> — You do not have permission to view this page.</div>';
} elseif (file_exists($page_file)) {
    include $page_file;
} else {
    echo '<div class="empty-state"><div class="empty-icon"><i class="fas fa-exclamation-triangle"></i></div><h5>404 - Page Not Found</h5><p>Requested admin page does not exist.</p></div>';
}

if (!$is_ajax) echo '</main>';

if (!$is_ajax) {
    include 'includes/footer.php';
}
?>
