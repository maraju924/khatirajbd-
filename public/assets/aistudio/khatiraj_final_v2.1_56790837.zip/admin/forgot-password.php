<?php
session_start();
require_once __DIR__ . '/../app/Helpers/CsrfHelper.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="<?php echo htmlspecialchars(CsrfHelper::token(), ENT_QUOTES, 'UTF-8'); ?>">
    <title>Forgot Password - Admin Panel</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body { background-color: #f5f5f5; display: flex; align-items: center; justify-content: center; height: 100vh; }
        .login-card { width: 100%; max-width: 400px; padding: 20px; border-radius: 10px; box-shadow: 0 4px 6px rgba(0,0,0,0.1); background: white; }
        .btn-primary { width: 100%; }
    </style>
</head>
<body>

<div class="login-card">
    <h3 class="text-center mb-4">Forgot Password</h3>
    <p class="text-muted text-center mb-4">Enter your admin email and we'll send you a reset link.</p>
    
    <?php if(isset($_GET['error'])): ?>
        <div class="alert alert-danger"><?php echo htmlspecialchars($_GET['error']); ?></div>
    <?php endif; ?>
    <?php if(isset($_GET['success'])): ?>
        <div class="alert alert-success"><?php echo htmlspecialchars($_GET['success']); ?></div>
    <?php endif; ?>

    <form action="actions/forgot-password-process.php" method="POST">
        <?php echo CsrfHelper::field(); ?>
        <div class="mb-3">
            <label class="form-label">Email Address</label>
            <input type="email" name="email" class="form-control" required placeholder="admin@example.com">
        </div>
        <button type="submit" class="btn btn-primary">Send Reset Link</button>
        <div class="mt-3 text-center">
            <a href="login.php" class="text-decoration-none">Back to Login</a>
        </div>
    </form>
</div>

</body>
</html>
