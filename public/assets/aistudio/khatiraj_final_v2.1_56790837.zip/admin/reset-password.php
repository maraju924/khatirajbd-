<?php
session_start();
require_once __DIR__ . '/../app/Helpers/CsrfHelper.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="<?php echo htmlspecialchars(CsrfHelper::token(), ENT_QUOTES, 'UTF-8'); ?>">
    <title>Reset Password - Admin Panel</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body { background-color: #f5f5f5; display: flex; align-items: center; justify-content: center; height: 100vh; }
        .login-card { width: 100%; max-width: 400px; padding: 20px; border-radius: 10px; box-shadow: 0 4px 6px rgba(0,0,0,0.1); background: white; }
        .btn-primary { width: 100%; }
    </style>
</head>
<body>

<div class="login-card">
    <h3 class="text-center mb-4">Reset Password</h3>
    
    <?php if(isset($_GET['error'])): ?>
        <div class="alert alert-danger"><?php echo htmlspecialchars($_GET['error']); ?></div>
    <?php endif; ?>

    <form action="actions/reset-password-process.php" method="POST">
        <?php echo CsrfHelper::field(); ?>
        <input type="hidden" name="token" value="<?php echo htmlspecialchars($_GET['token'] ?? ''); ?>">
        <div class="mb-3">
            <label class="form-label">New Password</label>
            <input type="password" name="password" class="form-control" required placeholder="Min 6 characters" minlength="6">
        </div>
        <div class="mb-3">
            <label class="form-label">Confirm Password</label>
            <input type="password" name="confirm_password" class="form-control" required placeholder="Confirm your password">
        </div>
        <button type="submit" class="btn btn-primary">Update Password</button>
    </form>
</div>

</body>
</html>
