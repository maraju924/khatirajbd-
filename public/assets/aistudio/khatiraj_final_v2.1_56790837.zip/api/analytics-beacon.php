<?php
// api/analytics-beacon.php
// Receives time-on-page and screen resolution beacon from client JS.
// Updates the most recent page_visits record for this session.

// Only accept POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    exit;
}

// Start session to get session_id
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once __DIR__ . '/../config/database.php';

$visitId = $_SESSION['_analytics_last_visit_id'] ?? null;
$timeOnPage = isset($_POST['time_on_page']) ? (int) $_POST['time_on_page'] : null;
$screenRes = isset($_POST['screen_resolution']) ? trim($_POST['screen_resolution']) : null;

// Validate
if (!$visitId || !$timeOnPage) {
    http_response_code(204); // No content — silently skip
    exit;
}

// Sanitize screen resolution (should be like "1920x1080")
if ($screenRes && !preg_match('/^\d{3,5}x\d{3,5}$/', $screenRes)) {
    $screenRes = null;
}

// Cap time_on_page at 30 minutes
if ($timeOnPage > 1800) $timeOnPage = 1800;
if ($timeOnPage < 0) $timeOnPage = 0;

try {
    $updates = [];
    $params = [];

    if ($timeOnPage > 0) {
        $updates[] = 'time_on_page = ?';
        $params[] = $timeOnPage;
    }

    if ($screenRes) {
        $updates[] = 'screen_resolution = ?';
        $params[] = $screenRes;
    }

    if (!empty($updates)) {
        $params[] = $visitId;
        $params[] = session_id();

        $sql = "UPDATE page_visits SET " . implode(', ', $updates) . " WHERE id = ? AND session_id = ?";
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
    }
} catch (PDOException $e) {
    // Silently fail — never break the user experience
}

// Return 204 No Content
http_response_code(204);
exit;
